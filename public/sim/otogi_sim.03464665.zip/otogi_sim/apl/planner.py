"""
Damage-per-orb buff planner (the small scheduler).

Instead of deciding buff casts reactively per unit, plan the *combination* of
buffs that maximizes payload damage per orb:

    efficiency(S) = (projected_payload_damage_with(S) - baseline) / orbs(S)
    S* = argmax_S efficiency(S)

The carries then fire into that fully-buffed window. Sync, marginal-buff-worth,
and overcap all fall out of one objective:
  - sync: S* is cast together by construction;
  - marginal worth: a buff is in S* only if it raises damage-per-orb;
  - overcap: projected payload damage is capped, so a buff that pushes a carry
    over the cap adds nothing to the numerator and is dropped for free.

A team has ~3-5 buffers, so enumerating 2^n subsets each decision is cheap.

Projection reuses the deterministic `Battle.calculate_action_damage(force_crit=)`
by *temporarily* applying a subset's buff modifiers to the carries and reverting.
"""

from __future__ import annotations

import re
from itertools import combinations
from typing import Any

from ..lifecycle import ModifierType
from .state import skill_flags

# Effect token -> the MonsterStat modifier a team buff of that kind adds.
_EFFECT_TO_MOD: dict[str, ModifierType] = {
    "ATK": ModifierType.DAMAGE,
    "CHIT": ModifierType.CRIT,
    "CHIT_ATK": ModifierType.CRIT_DMG,
    "SKILL_ATK": ModifierType.SKILL_DMG,
    "NORM_ATK": ModifierType.NORMAL_DMG,
    "SPD": ModifierType.SPEED,
    "SHIELD": ModifierType.SHIELD,
    "DEF": ModifierType.DEFENSE,
    "DEFENSE": ModifierType.DEFENSE,
    "HP": ModifierType.HP,
}

_EFF_RE = re.compile(r"([A-Z_]+)<(-?[\d.]+)(%?),(-?[\d.]+)(%?),?(\d+)?>")


def _extract_buff_mods(unit: Any) -> list[tuple[ModifierType, float]]:
    """(ModifierType, value) list a unit's buff skill + on-skill abilities apply.

    CRIT is on a 0-1 scale in the stat, but add_modify takes 0-100 percent for
    all types, so values are kept in the raw 0-100 percent the data uses."""
    out: list[tuple[ModifierType, float]] = []
    skill = getattr(unit, "skill", None)
    level = unit.model.level if getattr(unit, "model", None) else 1

    # skill de/ie percentage buffs
    if skill is not None:
        for eff in list(getattr(skill, "buff_effects", [])) + list(
            getattr(skill, "debuff_effects", [])
        ):
            m = _EFF_RE.match(eff.strip())
            if not m or not m.group(3):  # require a % (a real buff, not damage)
                continue
            mod = _EFFECT_TO_MOD.get(m.group(1))
            if mod is None:
                continue
            val = float(m.group(2)) + float(m.group(4)) * (level - 1)
            out.append((mod, val))

    # on-skill (attack_skill) ability effects
    for ab in getattr(unit, "abilities", []) or []:
        trig = getattr(ab, "trigger", None)
        if getattr(trig, "value", trig) != "attack_skill":
            continue
        for e in getattr(ab, "effects", []) or []:
            name = getattr(getattr(e, "effect_type", None), "name", None)
            mod = _EFFECT_TO_MOD.get(name) if name else None
            if mod is None:
                continue
            val = getattr(e, "value", 0.0) + getattr(e, "scale", 0.0) * (level - 1)
            out.append((mod, val))
    return out


def _expected_hit(battle: Any, carry: Any, enemy: Any) -> float:
    """Crit-weighted expected skill hit (capped) for one carry vs the enemy."""
    crit = battle.calculate_action_damage(
        carry, enemy, is_skill=True, force_crit=True
    ).final_damage
    noncrit = battle.calculate_action_damage(
        carry, enemy, is_skill=True, force_crit=False
    ).final_damage
    cr = min(max(float(carry.stat.final_crit), 0.0), 1.0) if carry.stat else 0.0
    return cr * float(crit) + (1.0 - cr) * float(noncrit)


def _project_payload(
    battle: Any,
    carries: list[Any],
    enemy: Any,
    extra_mods: list[tuple[ModifierType, float]],
) -> float:
    """Sum of carries' expected skill hits with extra_mods temporarily applied."""
    applied: list[tuple[str, ModifierType]] = []
    for i, (mt, val) in enumerate(extra_mods):
        sid = f"__plan_{i}"
        for c in carries:
            if c.stat:
                c.stat.add_modify(mt, val, sid)
        applied.append((sid, mt))
    try:
        return sum(_expected_hit(battle, c, enemy) for c in carries)
    finally:
        for sid, mt in applied:
            for c in carries:
                if c.stat:
                    c.stat.get_modifier(mt).remove_modify(sid)


def _classify(battle: Any) -> tuple[list[Any], list[Any]]:
    """Split alive players into (buffers, carries) by their skill's flags."""
    buffers, carries = [], []
    for p in battle.players:
        if not p.is_alive or p.skill is None:
            continue
        flags = skill_flags(p.skill, p)
        if flags["damage"]:
            carries.append(p)
        elif flags["buff"]:
            buffers.append(p)
    return buffers, carries


def best_buff_group(battle: Any, enemy: Any) -> frozenset[str]:
    """Return the set of buffer slots whose combined buffs maximize projected
    payload damage per orb. Cached per tick on the battle."""
    cache = getattr(battle, "_planner_cache", None)
    if cache is not None and cache[0] == battle.current_tick:
        return cache[1]

    buffers, carries = _classify(battle)
    result: frozenset[str] = frozenset()
    if enemy is not None and carries and buffers:
        base = _project_payload(battle, carries, enemy, [])
        best_eff = 0.0
        # Cap the combinatorics defensively (should be tiny in practice).
        for r in range(1, min(len(buffers), 5) + 1):
            for combo in combinations(buffers, r):
                mods: list[tuple[ModifierType, float]] = []
                orbs = 0
                for b in combo:
                    mods += _extract_buff_mods(b)
                    orbs += max(int(getattr(b, "need_cast_point", 1) or 1), 1)
                if orbs <= 0:
                    continue
                gain = _project_payload(battle, carries, enemy, mods) - base
                eff = gain / orbs
                if eff > best_eff:
                    best_eff = eff
                    result = frozenset(b.slot for b in combo)

    battle._planner_cache = (battle.current_tick, result)
    return result


def demo() -> None:
    """Self-check: on a Sola/Hikoboshi-style team the planner picks a non-empty
    buff group and the projection is monotone (more buffs never lowers the
    capped payload below baseline)."""
    import sys

    sys.path.insert(0, "scripts")
    from otogi_sim.apl.inspect import run_team

    b = run_team(
        [549, 1720, 1721, 1578, 1721],
        assist_ids=[697, 1531, 689, 550, 1311],
        reserve_ids=[1615, 690],
        reserve_assist_ids=[680, 723],
        time_limit=30.0,
    )
    enemy = b.enemies[0]
    buffers, carries = _classify(b)
    assert carries, "expected at least one carry"
    base = _project_payload(b, carries, enemy, [])
    all_mods: list[tuple[ModifierType, float]] = []
    for bu in buffers:
        all_mods += _extract_buff_mods(bu)
    full = _project_payload(b, carries, enemy, all_mods)
    assert full >= base, "buffs must not reduce projected (capped) payload"
    grp = best_buff_group(b, enemy)
    print(f"buffers={[u.slot for u in buffers]} carries={[u.slot for u in carries]}")
    print(f"baseline payload={base:,.0f}  all-buffs payload={full:,.0f}")
    print(f"best_buff_group={sorted(grp)}")


if __name__ == "__main__":
    demo()
