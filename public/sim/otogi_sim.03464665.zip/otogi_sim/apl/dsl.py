"""
The APL condition language.

A rule condition is a boolean expression over a small set of named variables
(see ``state.py``), e.g.::

    effect.crit_dmg & !overcap.crit
    effect.crit_rate & buff.crit_rate.target < param.crit_rate_bp

We implement the language by reusing Python's own ``ast`` module rather than
hand-rolling a lexer/parser: SimC operators map 1:1 onto a restricted subset of
Python expressions. ``!``/``&``/``|`` are translated to ``not``/``and``/``or``
(which also gives correct precedence and short-circuit evaluation), the AST is
validated against a node whitelist so no arbitrary code can run, then compiled
once at load time and evaluated against the state namespace in the hot loop.
"""

from __future__ import annotations

import ast
import re
from types import CodeType

# ponytail: reuse Python ast instead of a bespoke parser. The whitelist below is
# the security boundary for the eval() in engine.py — keep it tight.
_ALLOWED_NODES: tuple[type[ast.AST], ...] = (
    ast.Expression,
    ast.BoolOp,
    ast.And,
    ast.Or,
    ast.UnaryOp,
    ast.Not,
    ast.Compare,
    ast.Load,
    ast.Name,
    ast.Attribute,
    ast.Constant,
    # comparison operators
    ast.Lt,
    ast.Gt,
    ast.LtE,
    ast.GtE,
    ast.Eq,
    ast.NotEq,
)

_NOT_RE = re.compile(r"!(?!=)")  # a bare '!' but not '!='


class AplSyntaxError(ValueError):
    """Raised when a rule condition is malformed or uses disallowed syntax."""


def _translate(expr: str) -> str:
    """Translate SimC-style operators to equivalent Python operators."""
    expr = _NOT_RE.sub(" not ", expr)
    expr = expr.replace("&", " and ").replace("|", " or ")
    return (
        expr.strip()
    )  # leading space (from a leading '!') is an indent error in eval mode


def compile_condition(expr: str) -> CodeType:
    """
    Compile a condition string into a Python code object.

    Raises AplSyntaxError if the expression is invalid or contains any construct
    outside the whitelist (calls, subscripts, arithmetic, imports, etc.).
    """
    src = _translate(expr)
    try:
        tree = ast.parse(src, mode="eval")
    except SyntaxError as e:
        raise AplSyntaxError(f"invalid condition {expr!r}: {e}") from e

    for node in ast.walk(tree):
        if not isinstance(node, _ALLOWED_NODES):
            raise AplSyntaxError(
                f"disallowed element {type(node).__name__} in condition {expr!r}"
            )
    return compile(tree, "<apl>", "eval")
