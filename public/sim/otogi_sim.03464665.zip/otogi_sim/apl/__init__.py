"""
APL (Action Priority List) skill-casting policy for the battle simulator.

Replaces the old greedy "cast the instant orbs allow" logic with a data-driven
priority list of conditional cast rules, written in a small SimC-style text DSL
(see ``default.apl``). The DSL + runtime is the deliverable; ``default.apl`` is
just the first policy written in it and is swappable/editable without touching
Python.

Public entry point: ``get_engine().should_cast(attacker, battle, target)``.
"""

from .engine import AplEngine, get_engine
from .dsl import compile_condition, AplSyntaxError

__all__ = ["AplEngine", "get_engine", "compile_condition", "AplSyntaxError"]
