# Flying Nimbus [Awakened] (514) — permanent crit-damage stacker.
#
# Her on-skill ability 51402 adds +60% crit dmg per cast with NO duration, so
# repeated casts compound permanently (verified in test_apl_stacking.py). Casting
# also stacks team ATK speed via her SPD skill. So her optimal play is: keep
# casting to build crit-dmg stacks, then hold orbs for the rest of the team once
# the stacks stop paying off.
#
# Her crit dmg lands on ALLY damage dealers (ts=none inherits her ally-targeting
# skill), so gate on the team's max crit-dmg stack count, not her own.
# nimbus_max_stacks is a breakpoint — sweep it with apl_sweep to find where the
# team's damage dealers start overcapping (a proper per-ally headroom is WS2).
cast, if = team.max_stacks.crit_dmg < param.nimbus_max_stacks
