"""
WS2 — marginal value-per-orb objective.

The signal that lets the APL compare *different kinds* of casts (a damage skill vs
a support debuff vs a buff) on one scale, so it spends each orb on its highest-value
use. A buff/debuff's worth is indirect — it multiplies the *team's* damage over its
duration — so we estimate it from the observed team DPS:

    value(cast) = direct_skill_damage
                + Σ_effects  team_dps × uptime × magnitude
    value_per_orb = value / orb_cost

``team_dps`` = ``player_damage_total / current_time`` (what the team is actually
doing so far). This is an estimate, not a simulation — good enough to rank casts
and gate low-value ones.

**uptime is MARGINAL** (since 2026-08-25): re-applying an effect that is still running
is credited only with the coverage past its current expiry. Crediting the full duration
made "cast now" score identically to "cast at expiry", so nothing ever waited — the
scheduler kept Hikoboshi's 8s amp at ~38% uptime when ~74% was available. Because value
now climbs as an effect decays, holding a cast until just before expiry falls out of the
objective instead of needing a hand-written rule.

Still approximate: ``team_dps`` is backward-looking (≈0 early, and it lags after buffs
land), ``_DMG_MULT_WEIGHT`` is a hand-tuned table rather than the real damage pipeline
(``planner._project_payload`` uses the actual one), and diminishing returns near the
damage cap are not modelled.
"""

from __future__ import annotations

import re
from typing import Any, Iterable

from .payload import skill_payload
from .state import _buff_remains

# Fraction of team damage each buff/debuff type multiplies. Full multipliers for
# general ATK / enemy SHIELD / DEF; partial for type-specific; crit effects are
# only realised on crits, so weighted down (rough).
_DMG_MULT_WEIGHT: dict[str, float] = {
    "ATK": 1.0,  # +x% general damage (ally buff)
    "SHIELD": 1.0,  # -x% shield on enemy = +x% damage amp
    "DEF": 1.0,  # -x% defense on enemy = +x% damage amp
    "DEFENSE": 1.0,
    "SKILL_ATK": 0.6,  # skill hits only
    "NORM_ATK": 0.4,  # normal hits only
    "CHIT_ATK": 0.4,  # crit damage — crits only
    "CHIT": 0.5,  # crit rate — each crit ~2x
}

_SKILL_EFF_RE = re.compile(r"([A-Z_]+)<(-?[\d.]+)(%?),(-?[\d.]+)(%?),?(\d+)?>")


def _skill_effect_mults(
    effect_strs: Iterable[str], level: int
) -> Iterable[tuple[float, int]]:
    """DEPRECATED -- superseded by apl.payload.skill_payload.

    Kept only because it is imported elsewhere. It has no notion of recipient side or
    of permanent-vs-8s durations; new code must use skill_payload.
    """
    for s in effect_strs:
        m = _SKILL_EFF_RE.match(s.strip())
        if not m:
            continue
        w = _DMG_MULT_WEIGHT.get(m.group(1))
        if w is None:
            continue
        base = float(m.group(2))
        has_pct = bool(m.group(3))
        scale = float(m.group(4))
        dur = int(m.group(6)) if m.group(6) else 0
        val = base + scale * (level - 1)
        if not has_pct:
            val /= 100.0  # raw game units -> percent
        yield abs(val) / 100.0 * w, dur


def _ability_effect_mults(unit: Any, level: int) -> Iterable[tuple[float, int]]:
    """(magnitude, duration) from the unit's on-skill (attack_skill) abilities."""
    for ab in getattr(unit, "abilities", []) or []:
        trig = getattr(ab, "trigger", None)
        if getattr(trig, "value", trig) != "attack_skill":
            continue
        for e in getattr(ab, "effects", []) or []:
            name = getattr(getattr(e, "effect_type", None), "name", None)
            w = _DMG_MULT_WEIGHT.get(name) if name else None
            if w is None:
                continue
            val = getattr(e, "value", 0.0) + getattr(e, "scale", 0.0) * (level - 1)
            yield abs(val) / 100.0 * w, int(getattr(e, "duration", 0) or 0)


def _time_remaining(battle: Any) -> float:
    tl = getattr(battle.config, "time_limit", 0.0)
    if not tl or tl <= 0:
        return 60.0  # fallback horizon when no time limit configured
    return max(1.0, tl - battle.current_time)


def value_per_orb(attacker: Any, battle: Any, enemy: Any) -> float:
    """Estimated marginal team damage per orb of casting attacker's skill now."""
    cost = max(int(getattr(attacker, "need_cast_point", 1) or 1), 1)
    skill = getattr(attacker, "skill", None)
    if skill is None:
        return 0.0

    # Direct: the skill's own damage (damage skills), as the crit-weighted
    # EXPECTED hit. The breakpoint only makes sense against the buffed crit — a
    # skill is worth casting when stacked buffs (crit rate + Nimbus crit dmg + atk
    # concentrated on the target) push its crit over the floor. Non-crit alone
    # under-values it and holds everything.
    direct = 0.0
    if getattr(skill, "target_type", "enemy") == "enemy" and enemy is not None:
        crit_rate = 0.0
        if getattr(attacker, "stat", None) is not None:
            crit_rate = min(max(float(attacker.stat.final_crit), 0.0), 1.0)
        noncrit = battle.calculate_action_damage(
            attacker, enemy, is_skill=True, force_crit=False
        ).final_damage
        crit = battle.calculate_action_damage(
            attacker, enemy, is_skill=True, force_crit=True
        ).final_damage
        direct = crit_rate * float(crit) + (1.0 - crit_rate) * float(noncrit)

    # Indirect: team_dps × MARGINAL uptime × magnitude for each buff/debuff applied.
    #
    # Marginal, not nominal. Re-applying an effect that is still running buys only the
    # coverage past its current expiry, not another full duration. Crediting the full
    # duration (as this did before 2026-08-25) makes casting immediately look as good as
    # casting at expiry, which is why the scheduler never learned to space casts: a
    # second Hikoboshi cast 0.5s into its own 8s debuff adds 0.5s of coverage but was
    # scored as if it added 8s. With this correction value-per-orb rises as the effect
    # decays and peaks just before expiry, which is the rotation players actually use.
    team_dps = battle.player_damage_total / max(battle.current_time, 1.0)
    remaining = _time_remaining(battle)
    level = attacker.model.level if getattr(attacker, "model", None) else 1

    indirect = 0.0
    for eff in skill_payload(attacker, level):
        weight = _DMG_MULT_WEIGHT.get(eff.raw_type)
        if weight is None:
            continue  # not a damage-multiplying effect (CC, HP, ...)
        mag = abs(eff.magnitude) / 100.0 * weight

        # A permanent effect never expires, so its window is the rest of the fight and
        # re-applying it always stacks -- no overlap to subtract.
        if eff.is_permanent:
            indirect += team_dps * remaining * mag
            continue

        recipient = enemy if eff.on_enemy else attacker
        already = 0.0
        if recipient is not None and eff.mod_type is not None:
            already = _buff_remains(battle, recipient, eff.mod_type.name)
        window = max(0.0, min(float(eff.duration), remaining) - already)
        indirect += team_dps * window * mag

    return (direct + indirect) / cost
