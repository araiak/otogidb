"""
WS3 — per-team APL parameter discovery.

The WS2 finding was that the APL's breakpoints (value_floor = orb opportunity
cost, nimbus_max_stacks, crit_rate_bp, debuff-window params) are team-dependent.
This optimizer *discovers* the best values for a given team by coordinate ascent
over the param space with simulation as the fitness function — the concrete form
of "identify the correct grouping" for the per-unit-APL architecture.

Variance reduction: every candidate is scored on the SAME battle RNG seeds (common
random numbers), so a param change is compared apples-to-apples and coordinate
ascent isn't fooled by noise.

Read-back: after optimizing, the resulting rotation is printed as a cast timeline
(via the inspector) so it can be diffed against a human rotation.

    python -m otogi_sim.apl.optimize --team 739,514,1401,740 --iters 12
"""

from __future__ import annotations

import argparse
import random

from .engine import load_engine, set_engine
from .inspect import run_team, format_timeline

# Candidate values per tunable param (coarse grid; coordinate ascent refines).
DEFAULT_GRID: dict[str, list[float]] = {
    "value_floor": [150000, 300000, 500000, 800000, 1200000],
    "nimbus_max_stacks": [4, 6, 8, 10, 14],
    "crit_rate_bp": [0.7, 0.8, 0.9, 1.0],
    "refresh_window": [0.1, 0.3, 0.6],
    "min_window": [0.3, 0.5, 1.0],
}


def _score(
    team: list[int],
    params: dict[str, float],
    iters: int,
    time_limit: float,
    helper: int | None,
    reserve: list[int] | None,
) -> float:
    """Mean player damage over `iters` battles at fixed seeds (common random
    numbers) so param sets are compared on identical RNG draws."""
    set_engine(load_engine(param_overrides=params))
    active = team + ([helper] if helper else [])
    total = 0.0
    for k in range(iters):
        random.seed(1000 + k)
        total += run_team(active, reserve, time_limit=time_limit).player_damage_total
    return total / iters


def optimize(
    team: list[int],
    helper: int | None = None,
    reserve: list[int] | None = None,
    grid: dict[str, list[float]] | None = None,
    iters: int = 12,
    time_limit: float = 120.0,
    passes: int = 3,
) -> tuple[dict[str, float], float, float]:
    """Coordinate-ascent over grid. Returns (best_params, best_score, base_score)."""
    grid = grid or DEFAULT_GRID
    base_params = dict(load_engine().params)
    base_score = _score(team, base_params, iters, time_limit, helper, reserve)

    best_params = dict(base_params)
    best_score = base_score
    for _ in range(passes):
        improved = False
        for name, values in grid.items():
            for v in values:
                if best_params.get(name) == v:
                    continue
                trial = {**best_params, name: v}
                s = _score(team, trial, iters, time_limit, helper, reserve)
                if s > best_score:
                    best_score, best_params, improved = s, trial, True
        if not improved:
            break
    set_engine(None)  # don't leak the last-tried override into other callers
    return best_params, best_score, base_score


def main() -> None:
    ap = argparse.ArgumentParser(description="Per-team APL parameter discovery")
    ap.add_argument("--team", required=True, help="4 active card IDs")
    ap.add_argument("--helper", type=int, default=None)
    ap.add_argument("--reserve", default="")
    ap.add_argument("--iters", type=int, default=12)
    ap.add_argument("--time", type=float, default=120.0)
    args = ap.parse_args()

    team = [int(x) for x in args.team.split(",") if x.strip()]
    reserve = [int(x) for x in args.reserve.split(",") if x.strip()] or None

    best, best_score, base_score = optimize(
        team, args.helper, reserve, iters=args.iters, time_limit=args.time
    )
    print(f"\nbaseline (default params): {base_score:,.0f}")
    print(
        f"optimized:                 {best_score:,.0f}  ({(best_score/base_score-1)*100:+.1f}%)"
    )
    print("\ntuned params (differences from default):")
    default = dict(load_engine().params)
    for k, v in best.items():
        if default.get(k) != v:
            print(f"  {k}: {default.get(k)} -> {v}")

    # Read-back: the discovered rotation.
    set_engine(load_engine(param_overrides=best))
    active = team + ([args.helper] if args.helper else [])
    random.seed(1000)
    print("\ndiscovered rotation:")
    print(format_timeline(run_team(active, reserve, time_limit=args.time)))
    set_engine(None)


if __name__ == "__main__":
    main()
