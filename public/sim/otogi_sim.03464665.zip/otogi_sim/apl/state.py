"""
The state view: named variables the APL condition language can reference.

Adding a new referenceable variable is a one-line change here — this module is
the "vocabulary" of the language. Everything is computed lazily (via properties)
so a rule only pays for the sub-expressions it actually reaches; because the DSL
translates ``&``/``|`` to short-circuiting ``and``/``or``, expensive values like
``overcap.*`` (which run a damage projection) are only computed when needed.

Namespaces exposed to a condition:
    effect.<flag>            what this cast carries — skill de/ie PLUS its on-skill
                             abilities (crit_rate, crit_dmg, damage, buff, ...)
    self.<x>                 the caster: crit_rate, crit_dmg, hp_pct, role, attr, stacks.<buff>
    target.<x>               the skill's RESOLVED recipient (max_atk ally for buff
                             skills, else the enemy): crit_rate, hp_pct, stacks.<buff>, ...
    skill.<x>                cost, dmg_per_orb, has_damage
    buff.<name>.<up|remains|target|self>   buff/modifier state (target = recipient)
    team.<x>                 orbs, orbs_regen, buff.<name>.<up|remains>,
                             last_cast.<slot>.<age|ready>, max_stacks.<buff>
    overcap.<crit|normal>    would the relevant damage dealer overcap? (buffed ally
                             for support buffs, else the caster)
    crit_dmg.headroom        fractional room before that dealer's crit hit caps
    time.remaining           battle seconds left
    debuff.<up|remains>      this skill's debuff on the enemy
    param.<name>             tunable breakpoints
"""

from __future__ import annotations

from typing import Any

# DSL buff-name -> MonsterStat modifier attribute (for stack counts)
_MOD_ATTR: dict[str, str] = {
    "crit_rate": "crit_modifier",
    "crit_dmg": "crit_dmg_modifier",
    "damage": "damage_modifier",
    "speed": "speed_modifier",
    "skill_dmg": "skill_dmg_modifier",
    "normal_dmg": "normal_dmg_modifier",
    "shield": "shield_modifier",
    "defense": "defense_modifier",
    "hp": "hp_modifier",
    "vamp": "vamp_modifier",
}

# DSL buff-name -> (reader(stat) -> float, ModifierType.name suffix used in source_ids)
# The reader returns the current effective value; the suffix is used to find the
# remaining duration of a timed buff of that kind in Battle._active_buffs.
_BUFF_SPEC: dict[str, tuple[str, str]] = {
    # name: (stat attribute/derivation key, modifier-name suffix)
    "crit_rate": ("crit", "CRIT"),
    "crit_dmg": ("crit_dmg", "CRIT_DMG"),
    "damage": ("damage", "DAMAGE"),
    "speed": ("speed", "SPEED"),
    "skill_dmg": ("skill_dmg", "SKILL_DMG"),
    "normal_dmg": ("normal_dmg", "NORMAL_DMG"),
    "shield": ("shield", "SHIELD"),
    "defense": ("defense", "DEFENSE"),
}


def _source_matches(source_id: str, suffix: str) -> bool:
    """Match a modifier source_id by its ModifierType-name suffix, tolerating the
    per-cast ``_castN`` suffix that stacking buffs append (abilities and skills).
    Avoids CRIT vs CRIT_DMG confusion because the ``_cast`` boundary differs."""
    tag = "_" + suffix
    return source_id.endswith(tag) or (tag + "_cast") in source_id


def _stat_value(stat: Any, key: str) -> float:
    """Read the current effective value of a modifier from a MonsterStat."""
    if stat is None:
        return 0.0
    if key == "crit":
        return float(stat.final_crit)  # 0-1 scale
    if key == "crit_dmg":
        return float(stat.final_crit_dmg_mult) - 1.0
    if key == "damage":
        return float(stat.final_damage_mult) - 1.0
    if key == "speed":
        return float(stat.final_speed)
    if key == "skill_dmg":
        return float(stat.final_skill_dmg_mult) - 1.0
    if key == "normal_dmg":
        return float(stat.final_normal_dmg_mult) - 1.0
    if key == "shield":
        return float(stat.final_shield)
    if key == "defense":
        return stat.defense_modifier.get_percentage_sum() / 100.0
    return 0.0


def _buff_remains(battle: Any, unit: Any, suffix: str) -> float:
    """Max remaining seconds of a timed buff of the given kind on ``unit``."""
    active = getattr(battle, "_active_buffs", None)
    if not active:
        return 0.0
    best = 0.0
    for target, source_id, expire_time in active:
        if target is unit and _source_matches(source_id, suffix):
            best = max(best, expire_time - battle.current_time)
    return best


def _team_buff_remains(battle: Any, suffix: str) -> float:
    """Max remaining seconds of a timed buff of the given kind across all players."""
    active = getattr(battle, "_active_buffs", None)
    if not active:
        return 0.0
    best = 0.0
    for target, source_id, expire_time in active:
        if not target.is_enemy and _source_matches(source_id, suffix):
            best = max(best, expire_time - battle.current_time)
    return best


class _Ns:
    """Read-only attribute namespace backed by a dict; unknown names raise."""

    __slots__ = ("_d",)

    def __init__(self, **kwargs: Any) -> None:
        object.__setattr__(self, "_d", kwargs)

    def __getattr__(self, name: str) -> Any:
        try:
            return object.__getattribute__(self, "_d")[name]
        except KeyError:
            raise AttributeError(f"unknown APL variable: {name!r}")


class UnitView:
    __slots__ = ("_u",)

    def __init__(self, unit: Any) -> None:
        self._u = unit

    @property
    def crit_rate(self) -> float:
        return float(self._u.stat.final_crit) if self._u and self._u.stat else 0.0

    @property
    def crit_dmg(self) -> float:
        return _stat_value(self._u.stat if self._u else None, "crit_dmg")

    @property
    def hp_pct(self) -> float:
        s = self._u.stat if self._u else None
        if not s:
            return 0.0
        max_hp = float(s.hp_modifier.final_value) or 1.0
        return s.current_hp / max_hp

    @property
    def role(self) -> int:
        return int(self._u.model.unit_type) if self._u and self._u.model else 0

    @property
    def attr(self) -> int:
        return int(self._u.model.attribute) if self._u and self._u.model else 0

    @property
    def stacks(self) -> "StacksView":
        return StacksView(self._u)


class StacksView:
    """self.stacks.<buff> -> number of active modifiers of that kind on the unit.

    A proxy for "how many times has this stacked" — for a permanent stacker like
    Nimbus's crit dmg each cast appends one modifier, so the count grows per cast.
    """

    __slots__ = ("_stat",)

    def __init__(self, unit: Any) -> None:
        self._stat = unit.stat if unit else None

    def __getattr__(self, name: str) -> int:
        attr = _MOD_ATTR.get(name)
        if attr is None or self._stat is None:
            raise AttributeError(f"unknown stack buff: {name!r}")
        return len(getattr(self._stat, attr).modify_list)


class TimeView:
    __slots__ = ("_battle",)

    def __init__(self, battle: Any) -> None:
        self._battle = battle

    @property
    def remaining(self) -> float:
        tl = self._battle.config.time_limit
        if not tl or tl <= 0:
            return 1e9  # no time limit configured
        return max(0.0, tl - self._battle.current_time)


class CritDmgView:
    """crit_dmg.headroom -> fractional room before the caster's own crit hit caps.

    ponytail: caster-based, like overcap.* — exact for self-damage-dealers,
    approximate for supports (whose crit dmg benefits allies). A per-ally headroom
    is a WS2 refinement. 0 means already at/over the cap.
    """

    __slots__ = ("_att", "_battle", "_target")

    def __init__(self, attacker: Any, battle: Any, target: Any) -> None:
        self._att = attacker
        self._battle = battle
        self._target = target

    @property
    def headroom(self) -> float:
        if self._target is None:
            return 1e9
        res = self._battle.calculate_action_damage(
            self._att, self._target, is_skill=True, force_crit=True
        )
        cap = self._battle.config.skill_damage_cap
        if res.after_defense <= 0:
            return 1e9
        return max(0.0, cap / res.after_defense - 1.0)


class _LastCastView:
    __slots__ = ("_battle", "_slot")

    def __init__(self, battle: Any, slot: str) -> None:
        self._battle = battle
        self._slot = slot

    @property
    def age(self) -> float:
        t = self._battle._last_skill_cast.get(self._slot)
        return (self._battle.current_time - t) if t is not None else 1e9

    @property
    def ready(self) -> bool:
        return self._slot in self._battle._last_skill_cast


class LastCastNamespace:
    __slots__ = ("_battle",)

    def __init__(self, battle: Any) -> None:
        self._battle = battle

    def __getattr__(self, slot: str) -> _LastCastView:
        return _LastCastView(self._battle, slot.upper())


class PlanView:
    """Damage-per-orb planner results (see planner.py).

    plan.in_group  -> is this unit in the optimal buff group S*?
    plan.group_cost -> total orb cost of S* (for the pool-to-sync gate)
    """

    __slots__ = ("_battle", "_unit", "_enemy")

    def __init__(self, battle: Any, unit: Any, enemy: Any) -> None:
        self._battle = battle
        self._unit = unit
        self._enemy = enemy

    @property
    def in_group(self) -> bool:
        from .planner import best_buff_group

        return self._unit.slot in best_buff_group(self._battle, self._enemy)

    @property
    def group_cost(self) -> int:
        from .planner import best_buff_group

        group = best_buff_group(self._battle, self._enemy)
        return sum(
            max(int(getattr(p, "need_cast_point", 1) or 1), 1)
            for p in self._battle.players
            if p.slot in group
        )


class _BuffView:
    __slots__ = ("_battle", "_unit", "_target", "_key", "_suffix")

    def __init__(self, battle: Any, unit: Any, target: Any, key: str, suffix: str):
        self._battle = battle
        self._unit = unit
        self._target = target
        self._key = key
        self._suffix = suffix

    @property
    def remains(self) -> float:
        return _buff_remains(self._battle, self._unit, self._suffix)

    @property
    def up(self) -> bool:
        return self.remains > 0.0

    @property
    def target(self) -> float:
        return _stat_value(self._target.stat if self._target else None, self._key)

    def __getattr__(self, name: str) -> Any:
        if name == "self":  # buff.<name>.self — value on the caster
            return _stat_value(self._unit.stat if self._unit else None, self._key)
        raise AttributeError(f"unknown buff field: {name!r}")


class BuffNamespace:
    __slots__ = ("_battle", "_unit", "_target")

    def __init__(self, battle: Any, unit: Any, target: Any) -> None:
        self._battle = battle
        self._unit = unit
        self._target = target

    def __getattr__(self, name: str) -> _BuffView:
        spec = _BUFF_SPEC.get(name)
        if spec is None:
            raise AttributeError(f"unknown buff: {name!r}")
        key, suffix = spec
        return _BuffView(self._battle, self._unit, self._target, key, suffix)


class _TeamBuffView:
    __slots__ = ("_battle", "_suffix")

    def __init__(self, battle: Any, suffix: str) -> None:
        self._battle = battle
        self._suffix = suffix

    @property
    def remains(self) -> float:
        return _team_buff_remains(self._battle, self._suffix)

    @property
    def up(self) -> bool:
        return self.remains > 0.0


class _TeamBuffNamespace:
    __slots__ = ("_battle",)

    def __init__(self, battle: Any) -> None:
        self._battle = battle

    def __getattr__(self, name: str) -> _TeamBuffView:
        spec = _BUFF_SPEC.get(name)
        if spec is None:
            raise AttributeError(f"unknown buff: {name!r}")
        return _TeamBuffView(self._battle, spec[1])


class TeamView:
    __slots__ = ("_battle", "_params")

    def __init__(self, battle: Any, params: dict[str, float]) -> None:
        self._battle = battle
        self._params = params

    @property
    def orbs(self) -> int:
        return int(self._battle.skill_points)

    @property
    def orbs_regen(self) -> float:
        # tick_rate / regen_cd = orbs gained per second
        cd = self._battle.skill_points_regen_cd or 1.0
        return 1.0 / cd

    @property
    def buff(self) -> _TeamBuffNamespace:
        return _TeamBuffNamespace(self._battle)

    @property
    def last_cast(self) -> "LastCastNamespace":
        return LastCastNamespace(self._battle)

    @property
    def max_stacks(self) -> "_TeamMaxStacksNamespace":
        return _TeamMaxStacksNamespace(self._battle)


class _TeamMaxStacksNamespace:
    """team.max_stacks.<buff> -> max stack count of that modifier across all
    players. The right gate for a team-directed stacker like Nimbus, whose crit
    dmg lands on ally damage dealers, not herself."""

    __slots__ = ("_battle",)

    def __init__(self, battle: Any) -> None:
        self._battle = battle

    def __getattr__(self, name: str) -> int:
        attr = _MOD_ATTR.get(name)
        if attr is None:
            raise AttributeError(f"unknown stack buff: {name!r}")
        best = 0
        for p in self._battle.players:
            if p.stat is not None:
                best = max(best, len(getattr(p.stat, attr).modify_list))
        return best


class SkillView:
    __slots__ = ("_att", "_battle", "_target")

    def __init__(self, attacker: Any, battle: Any, target: Any) -> None:
        self._att = attacker
        self._battle = battle
        self._target = target

    @property
    def cost(self) -> int:
        return int(self._att.need_cast_point)

    @property
    def has_damage(self) -> bool:
        sk = self._att.skill
        return bool(sk) and getattr(sk, "target_type", "enemy") == "enemy"

    @property
    def dmg_per_orb(self) -> float:
        if self._target is None:
            return 0.0
        # Projected non-crit skill damage divided by orb cost.
        res = self._battle.calculate_action_damage(
            self._att, self._target, is_skill=True, force_crit=False
        )
        cost = self._att.need_cast_point or 1
        return res.final_damage / cost

    @property
    def value_per_orb(self) -> float:
        # Unified marginal team-damage-per-orb (direct damage + buff/debuff value).
        # Lets one rule rank damage / debuff / buff casts on the same scale (WS2).
        from .window_value import value_per_orb

        return value_per_orb(self._att, self._battle, self._target)

    @property
    def crit_damage(self) -> float:
        # Projected CRIT hit of this skill vs the enemy — the quantity the "cast
        # when your buffed crit clears 500k" breakpoint gates on. A skill is worth
        # casting only when stacked buffs push its crit over the floor.
        if self._target is None:
            return 0.0
        res = self._battle.calculate_action_damage(
            self._att, self._target, is_skill=True, force_crit=True
        )
        return float(res.final_damage)


class Overcap:
    """Would casting this skill this instant push the hit over the damage cap?

    ponytail: v1 projects the *caster's own* hit (the unit deciding to cast).
    For buffs that target allies this under-counts the true team benefit — a
    per-ally projection is a phase-2 refinement. Names the ceiling here.
    """

    __slots__ = ("_att", "_battle", "_target")

    def __init__(self, attacker: Any, battle: Any, target: Any) -> None:
        self._att = attacker
        self._battle = battle
        self._target = target

    def _capped(self, force_crit: bool) -> bool:
        if self._target is None:
            return False
        res = self._battle.calculate_action_damage(
            self._att, self._target, is_skill=True, force_crit=force_crit
        )
        return bool(res.was_capped)

    @property
    def crit(self) -> bool:
        return self._capped(True)

    @property
    def normal(self) -> bool:
        return self._capped(False)


class DebuffView:
    """Remaining time of this skill's debuff on the primary (enemy) target.

    ponytail: approximated as the max remaining of any timed effect currently on
    the primary target. Good enough to author buff-window rules; a per-debuff-type
    projection is a phase-2 refinement.
    """

    __slots__ = ("_battle", "_att", "_target")

    def __init__(self, battle: Any, attacker: Any, target: Any) -> None:
        self._battle = battle
        self._att = attacker
        self._target = target

    @property
    def remains(self) -> float:
        active = getattr(self._battle, "_active_buffs", None)
        if not active or self._target is None:
            return 0.0
        # Track THIS caster's own debuff on the enemy (source_id carries the
        # caster slot), so a card refreshes its own debuff, not someone else's.
        slot = getattr(self._att, "slot", "")
        tag = f"_{slot}_" if slot else None
        best = 0.0
        for target, sid, expire_time in active:
            if target is self._target and (tag is None or tag in sid):
                best = max(best, expire_time - self._battle.current_time)
        return best

    @property
    def up(self) -> bool:
        return self.remains > 0.0


def skill_flags(skill: Any, unit: Any = None) -> dict[str, bool]:
    """Boolean flags describing what a *cast* carries.

    A cast's real effect set is the skill's own de/ie **plus** the unit's
    on-skill (attack_skill) abilities — e.g. Nimbus 514's crit rate/dmg live only
    in ability 51402, not her SPD skill. Without folding those in, the APL would
    see "just an SPD buff" and never cast her, losing the stacking payoff.
    """
    tokens: set[str] = set()
    if skill is not None:
        for eff in list(getattr(skill, "buff_effects", [])) + list(
            getattr(skill, "debuff_effects", [])
        ):
            tokens.add(eff.split("<")[0].strip())
    # Fold in on-skill ability effect types (duck-typed: trigger value "attack_skill").
    has_ability_buff = False
    if unit is not None:
        for ab in getattr(unit, "abilities", []) or []:
            trig = getattr(ab, "trigger", None)
            if getattr(trig, "value", trig) != "attack_skill":
                continue
            for eff in getattr(ab, "effects", []) or []:
                et = getattr(eff, "effect_type", None)
                name = getattr(et, "name", None)
                if name:
                    tokens.add(name)
                    has_ability_buff = True
    target_type = getattr(skill, "target_type", "enemy") if skill else "enemy"
    return {
        "crit_rate": "CHIT" in tokens,
        "crit_dmg": "CHIT_ATK" in tokens,
        "atk": "ATK" in tokens,
        "damage": target_type == "enemy",
        "buff": bool(getattr(skill, "buff_effects", []))
        or target_type == "self"
        or has_ability_buff,
        "debuff": bool(getattr(skill, "debuff_effects", [])),
        "stun": "STUN" in tokens,
        "shield": "SHIELD" in tokens,
        "speed": "SPD" in tokens,
    }


def resolve_skill_targets(attacker: Any, battle: Any, enemy: Any) -> tuple[Any, Any]:
    """Resolve who a cast actually affects, so conditions decide on the real target.

    Returns ``(recipient, proj_attacker)``:
    - ``recipient``: the unit the skill's effects land on — the resolved buff
      target (respecting filters like ``max_atk``) for buff skills, else the
      enemy. Used for ``target.*`` and ``buff.*.target``.
    - ``proj_attacker``: the damage dealer whose overcap/headroom we project — the
      buffed ally for support buffs (so e.g. a crit-dmg buff is judged against the
      max-ATK ally who receives it), else the caster.

    Mirrors ``Battle._apply_skill_effects`` target selection so the APL sees the
    same recipient the effect will actually hit.
    """
    skill = getattr(attacker, "skill", None)
    if skill is not None and getattr(skill, "is_buff_skill", False):
        players = getattr(battle, "players", []) or []
        candidates = [p for p in players if getattr(p, "is_alive", True)]
        filt = getattr(skill, "target_filter", None)
        if filt and candidates:
            mgr = getattr(battle, "ability_manager", None)
            if mgr is not None:
                filtered = mgr._apply_target_filter(candidates, filt, attacker)
                if filtered:
                    candidates = filtered
        recipient = candidates[0] if candidates else attacker
        return recipient, recipient
    return enemy, attacker


def build_namespace(
    attacker: Any,
    battle: Any,
    target: Any,
    params: dict[str, float],
    flags: dict[str, bool],
) -> dict[str, Any]:
    """Assemble the eval namespace for a single cast decision."""
    enemy = target
    recipient, proj_attacker = resolve_skill_targets(attacker, battle, enemy)
    return {
        "effect": _Ns(**flags),
        "self": UnitView(attacker),
        "target": UnitView(recipient),
        "skill": SkillView(attacker, battle, enemy),
        "buff": BuffNamespace(battle, attacker, recipient),
        "team": TeamView(battle, params),
        # overcap / headroom project the relevant damage dealer (the buffed ally
        # for support buffs) hitting the enemy — so decisions are target-aware.
        "overcap": Overcap(proj_attacker, battle, enemy),
        "debuff": DebuffView(battle, attacker, enemy),
        "time": TimeView(battle),
        "crit_dmg": CritDmgView(proj_attacker, battle, enemy),
        "plan": PlanView(battle, attacker, enemy),
        "param": _Ns(**params),
    }
