# Planner policy (damage-per-orb scheduler, expressed as APL rules).
#
# Buffs are chosen as the combination that maximizes projected payload damage per
# orb (planner.py / plan.in_group), and POOLED so the whole group fires together
# (team.orbs >= plan.group_cost) — that keeps buffs synced. Carries then fire into
# the fully-buffed window when their buffed crit clears the floor.

# 1. Crit-rate buff to the breakpoint (hard constraint on the pool contents).
cast, if = effect.crit_rate & buff.crit_rate.target < param.crit_rate_bp

# 2. Buffer casts iff it is in the optimal damage-per-orb group AND the team has
#    pooled enough orbs to fire the whole group at once (synchronization).
cast, if = plan.in_group & team.orbs >= plan.group_cost

# 3. Carry fires when its buffed crit clears the floor (the near-cap window).
cast, if = effect.damage & skill.crit_damage >= param.crit_floor

# else: hold (pool orbs)
