# Default Action Priority List for the battle simulator.
#
# Evaluated top-to-bottom on a unit's turn when it *can* cast (enough energy).
# The first rule whose condition is true -> cast; if none match, the unit
# auto-attacks and team orbs accumulate ("holding" for a better window).
#
# Operators:  &  and   |  or   !  not   ( )  grouping
# Comparisons: < > <= >= == !=
# Variables:  see apl/state.py (effect.*, self.*, target.*, skill.*, buff.*,
#             team.*, overcap.*, debuff.*, param.*)
#
# Every rule also implicitly requires team.orbs >= skill.cost (enforced by the
# engine's can_cast gate), so rules only express the *judgment*, not affordability.

# 1. Crit-rate buff: only if the target isn't already at/above the breakpoint.
cast, if = effect.crit_rate & buff.crit_rate.target < param.crit_rate_bp

# 2. Crit-damage buff: only if the buffed crit hit won't overcap (wasted).
cast, if = effect.crit_dmg & !overcap.crit

# 3. Generic buff (atk/speed/shield/etc.): cast when it won't overcap. A DMG/atk
#    buff helps ALL hits, so it's only wasted when even the non-crit hit is
#    already capped — gate on the normal/skill (non-crit) overcap, NOT crit
#    overcap (crits cap first, so a crit-overcap check holds the buff too early).
cast, if = effect.buff & !effect.damage & !overcap.normal

# 4. Damage skill inside a team buff window, near an edge (refresh debuff /
#    open the window), and not already overcapping the non-crit hit.
cast, if = effect.damage & team.buff.damage.up & !overcap.normal \
         & (debuff.remains < param.refresh_window | debuff.remains > param.min_window)

# 5. Damage skill whose BUFFED CRIT hit clears the floor (~500k). This is the
#    real breakpoint: a carry's skill is only worth an orb once stacked buffs
#    (crit rate ~90% via rule 1, crit dmg via rule 2, atk via rule 3) push its
#    crit over crit_floor. Teams that stack buffs onto a carry clear it and spam;
#    teams that don't never do. crit_floor assumes crit rate is being stacked high.
cast, if = effect.damage & skill.crit_damage >= param.crit_floor

# else: auto-attack (hold orbs)
