"""
APL engine: loads .apl policy files + breakpoint params, compiles the rules
once, and answers ``should_cast(attacker, battle, target)`` in the battle loop.

Policy resolution: per-card override (``apl/overrides/<card_id>.apl``) if present,
else the global ``apl/default.apl``. Nothing about the policy is hardcoded — rules
and params live in editable data files loaded at startup.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from types import CodeType
from typing import Any

from .dsl import compile_condition, AplSyntaxError
from .state import build_namespace, skill_flags

_APL_DIR = Path(__file__).parent
# Line form:  <action> [,] if = <condition>       (continuation with trailing '\')
_RULE_RE = re.compile(r"^\s*(\w+)\s*,?\s*if\s*=\s*(.+)$", re.IGNORECASE)
# eval() with no builtins — names resolve only against the state namespace.
_EVAL_GLOBALS: dict[str, Any] = {"__builtins__": {}}


class Rule:
    __slots__ = ("action", "code", "raw")

    def __init__(self, action: str, code: CodeType, raw: str) -> None:
        self.action = action
        self.code = code
        self.raw = raw


def parse_apl(text: str) -> list[Rule]:
    """Parse an .apl document into an ordered list of compiled rules."""
    rules: list[Rule] = []
    # join backslash line-continuations, drop comments and blanks
    logical: list[str] = []
    buf = ""
    for line in text.splitlines():
        line = line.split("#", 1)[0].rstrip()
        if not line.strip():
            continue
        if line.endswith("\\"):
            buf += line[:-1] + " "
            continue
        logical.append(buf + line)
        buf = ""
    if buf.strip():
        logical.append(buf)

    for line in logical:
        m = _RULE_RE.match(line)
        if not m:
            raise AplSyntaxError(f"cannot parse APL line: {line!r}")
        action, cond = m.group(1).lower(), m.group(2).strip()
        rules.append(Rule(action, compile_condition(cond), cond))
    return rules


class AplEngine:
    def __init__(
        self,
        default_rules: list[Rule],
        params: dict[str, float],
        overrides: dict[int, list[Rule]] | None = None,
        scheduler: Any = None,
    ) -> None:
        self.default_rules = default_rules
        self.params = params
        self.overrides = overrides or {}
        self._flag_cache: dict[int, dict[str, bool]] = {}
        # Optional team-level pool-and-burst scheduler; when set it replaces the
        # per-unit rule evaluation (see scheduler.py).
        self.scheduler = scheduler

    def _flags(self, attacker: Any) -> dict[str, bool]:
        # Cache per card_id: the effect profile folds in the unit's on-skill
        # abilities (per-card), not just the shared skill object.
        card_id = attacker.model.card_id if attacker.model else -1
        flags = self._flag_cache.get(card_id)
        if flags is None:
            flags = skill_flags(attacker.skill, attacker)
            self._flag_cache[card_id] = flags
        return flags

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        """Return True if the APL says this unit should cast its skill now."""
        if self.scheduler is not None:
            return self.scheduler.should_cast(attacker, battle, target)
        card_id = attacker.model.card_id if attacker.model else -1
        rules = self.overrides.get(card_id, self.default_rules)
        ns = build_namespace(
            attacker, battle, target, self.params, self._flags(attacker)
        )
        for rule in rules:
            if eval(rule.code, _EVAL_GLOBALS, ns):  # noqa: S307 — sandboxed, see dsl.py
                return True
        return False


def load_engine(
    apl_path: Path | None = None,
    params_path: Path | None = None,
    param_overrides: dict[str, float] | None = None,
) -> AplEngine:
    """Load an engine from disk. ``param_overrides`` lets the sweep harness tune
    named breakpoints without editing files."""
    apl_path = apl_path or (_APL_DIR / "default.apl")
    params_path = params_path or (_APL_DIR / "params.json")

    params: dict[str, float] = {}
    if params_path.exists():
        with open(params_path, encoding="utf-8") as f:
            params = json.load(f)
    if param_overrides:
        params.update(param_overrides)

    default_rules = parse_apl(apl_path.read_text(encoding="utf-8"))

    overrides: dict[int, list[Rule]] = {}
    override_dir = _APL_DIR / "overrides"
    if override_dir.is_dir():
        for f in override_dir.glob("*.apl"):
            try:
                overrides[int(f.stem)] = parse_apl(f.read_text(encoding="utf-8"))
            except ValueError:
                continue  # non-numeric filename → skip

    return AplEngine(default_rules, params, overrides)


_ENGINE: AplEngine | None = None


def get_engine() -> AplEngine:
    """Process-wide singleton, loaded lazily on first cast decision."""
    global _ENGINE
    if _ENGINE is None:
        _ENGINE = load_engine()
    return _ENGINE


def set_engine(engine: AplEngine | None) -> None:
    """Override / reset the singleton (used by the sweep harness and tests)."""
    global _ENGINE
    _ENGINE = engine
