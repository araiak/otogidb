"""
Rotation inspector: run a team under the APL with the correct orb economy and
cast recording, then print the per-card cast timeline + total damage.

This is the tool for authoring/validating rotations — you can see whether the APL
stacks a permanent buffer (Nimbus), casts buffs before damage, spaces debuffs, and
spends the 8-orbs-per-40s budget sensibly.

    python -m otogi_sim.apl.inspect --team 739,514,1401,740 --time 120
"""

from __future__ import annotations

import argparse

from ..battle import Battle, BattleConfig, BattlePhase
from ..modes import DamageBenchmark
from ..data_loader import get_loader


def run_team(
    card_ids: list[int],
    reserve_ids: list[int] | None = None,
    time_limit: float = 300.0,
    level: int = 90,
    lb: int = 5,
    regen_cd: float = 5.0,
    assist_ids: list[int] | None = None,
    reserve_assist_ids: list[int] | None = None,
) -> Battle:
    """Run one immortal-dummy battle with cast recording enabled.

    assist_ids: parallel to card_ids (0 = no assist). Assists transfer their
    ability to the recipient (TIME extend, crit buffs, etc.) — essential for
    faithfully reproducing real teams."""
    sim = DamageBenchmark()
    loader = get_loader()
    loader.load_all()

    lv = [level] * len(card_ids)
    lbs = [lb] * len(card_ids)
    if assist_ids:
        team = loader.build_team_with_assists(card_ids, assist_ids, lv, lbs)
    else:
        team = sim.build_team(card_ids, lv, lbs)
    reserves = None
    if reserve_ids:
        rl = [level] * len(reserve_ids)
        rlb = [lb] * len(reserve_ids)
        if reserve_assist_ids:
            reserves = loader.build_team_with_assists(
                reserve_ids, reserve_assist_ids, rl, rlb
            )
        else:
            reserves = sim.build_team(reserve_ids, rl, rlb)
    # Same battle Monte Carlo and DamageBenchmark score on -- see
    # modes.run_benchmark_battle. This used to be a third hand-rolled copy that
    # built a bare BattleConfig, silently dropping the shared combat constants
    # (damage caps, crit_max, shield_max, combo_bonus), so cast timelines were
    # inspected on a fight the ranking never actually ran.
    from ..modes import run_benchmark_battle

    return run_benchmark_battle(
        player_models=team,
        ability_data=loader._abilities,
        reserve_models=reserves,
        benchmark_time=time_limit,
        trace=True,
        record_casts=True,
        regen_cd=regen_cd,
        tick_headroom=5.0,  # short time_limits can extend past 2x
    )


def format_timeline(battle: Battle) -> str:
    """Per-slot cast timeline (slot -> card name -> cast times)."""
    slot_name = {u.slot: (u.model.name if u.model else "?") for u in battle.players}
    lines = [f"Battle time: {battle.current_time:.1f}s"]
    total_orbs = 0
    for slot in sorted(battle.skill_cast_log):
        times = battle.skill_cast_log[slot]
        total_orbs += len(times)  # (approx; cost escalates, but count = # casts)
        stamps = ", ".join(f"{t:.1f}" for t in times)
        lines.append(
            f"  {slot:>3} {slot_name.get(slot, '?'):<28} x{len(times):<2} @ {stamps}"
        )
    lines.append(f"Total player casts: {total_orbs}")
    lines.append(f"Total player damage: {battle.player_damage_total:,.0f}")
    return "\n".join(lines)


def main() -> None:
    ap = argparse.ArgumentParser(description="APL rotation inspector")
    ap.add_argument("--team", required=True, help="active card IDs, comma-separated")
    ap.add_argument("--reserve", default="", help="up to 2 reserve card IDs")
    ap.add_argument("--time", type=float, default=120.0)
    ap.add_argument("--level", type=int, default=90)
    ap.add_argument("--lb", type=int, default=5)
    ap.add_argument("--regen-cd", type=float, default=5.0, help="orb income (1/Ns)")
    args = ap.parse_args()

    active = [int(x) for x in args.team.split(",") if x.strip()]
    reserve = [int(x) for x in args.reserve.split(",") if x.strip()] or None
    battle = run_team(active, reserve, args.time, args.level, args.lb, args.regen_cd)
    print(format_timeline(battle))


if __name__ == "__main__":
    main()
