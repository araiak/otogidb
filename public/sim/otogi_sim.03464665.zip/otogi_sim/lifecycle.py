"""
Combat lifecycle classes for the Otogi Battle Simulator.

These classes mirror the game's combat architecture:
- MonsterModel: Pre-calculated stats before battle (level scaling, LB, bonds)
- MonsterStat: Runtime stat tracking with 10 modifier types
- MonsterComponent: A unit in combat with full state

Behaviour observed in play:
- Adding a modifier resolves as: base × (1.0 + percentageSum / 100.0) + flatSum
- Modifiers are stored as 0-100 percentages (not 0-1)
- Each unit carries 10 independent modifier buckets. Values ADD inside a bucket
  and MULTIPLY across buckets -- which is why stacking ATK% with SKILL_ATK% is
  worth more than stacking two of the same kind.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Callable
from enum import Enum, auto
import random


class ModifierType(Enum):
    """
    The 10 modifier buckets a unit carries.
    """

    CRIT = auto()  # Crit rate bonus
    SPEED = auto()  # Attack speed
    DAMAGE = auto()  # General damage bucket - separately capped (see below)
    SHIELD = auto()  # Damage reduction - separately capped (see below)
    HIT_CRIT = auto()  # Crit rate when being hit?
    HP = auto()  # HP modifier
    DEFENSE = auto()  # Defense stat
    CRIT_DMG = auto()  # Crit damage bonus
    SKILL_DMG = auto()  # Skill damage bonus
    NORMAL_DMG = auto()  # Normal attack damage bonus
    VAMP = auto()  # Lifesteal percentage - heals for % of damage dealt
    REVENGE = auto()  # Counter damage - reflects % of damage taken back to attacker


EFFECT_TO_MODIFIER = {
    "ATK": ModifierType.DAMAGE,
    "CHIT": ModifierType.CRIT,
    "CHIT_ATK": ModifierType.CRIT_DMG,
    "SHIELD": ModifierType.SHIELD,
    "SPD": ModifierType.SPEED,
    "SKILL_ATK": ModifierType.SKILL_DMG,
    "NORM_ATK": ModifierType.NORMAL_DMG,
    "HP": ModifierType.HP,
    "DEF": ModifierType.DEFENSE,
    "DEFENSE": ModifierType.DEFENSE,
}
"""Game effect token -> internal modifier slot. The single mapping.

`battle.py` (applying a skill effect) and `apl/payload.py` (projecting what a
cast would do) each had their own copy. A cast the APL values as an ATK buff and
the engine applies as nothing is a silent scoring bug, not a crash -- so add a
token HERE and both the decision and the effect learn it together.
"""


class BondType(Enum):
    """Bond effect types."""

    NORMAL_DMG = auto()  # Increases normal attack damage
    SKILL_DMG = auto()  # Increases skill damage
    HP = auto()  # Increases max HP


# Which damage type a bond's stat bonus lands on.
#
# Measured in play: damage bonds feed the NORMAL-attack bucket, which the skill
# path never reads. A unit given a 5% bond showed a 1.05 normal-damage modifier on
# all 14 of its normal attacks and on 0 of 3 skills (2026-08-25).
#
# Every path that builds a bond MUST use this constant. monte_carlo and
# data_loader each hardcoded their own answer (NORMAL_DMG vs SKILL_DMG), so the
# same team scored ~2% apart depending on which harness ran it.
ASSIST_BOND_TYPE = BondType.NORMAL_DMG


def make_assist_bond(
    donor_card_id: int,
    donor_rarity: int,
    donor_type: int,
    donor_attribute: int,
    ability_ids: "List[int]",
) -> "Bond":
    """Build the bond an assist card grants its holder.

    One constructor, because there are two legitimate ways to *acquire* a model --
    build it from a card id, or decorate a cached one in the search hot loop -- and
    both must attach an identical bond. When each site built its own, they disagreed
    on ``bond_type`` (SKILL_DMG vs NORMAL_DMG) and the same team scored ~2% apart
    depending on which path ran it.
    """
    return Bond(
        donor_card_id=donor_card_id,
        donor_rarity=donor_rarity,
        donor_type=donor_type,
        donor_attribute=donor_attribute,
        bond_type=ASSIST_BOND_TYPE,
        is_assist=True,
        assist_ability_ids=list(ability_ids),
    )


@dataclass
class Bond:
    """
    A bond between two cards.

    Bond bonuses by rarity (5★=5%, 4★=4%, 3★=3%, 2★=2%, 1★=1%)
    +50% bonus if donor has same type AND same class as recipient.

    Assist Bonds:
    - One bond slot can be an "assist" bond
    - Provides stat bonus + transfers donor's abilities to recipient
    - Abilities trigger on recipient's actions
    """

    donor_card_id: int  # Card providing the bond
    donor_rarity: int  # Rarity of donor (1-5)
    donor_type: int  # Type (1=Melee, 2=Ranged, 3=Healer, 4=Support)
    donor_attribute: int  # Attribute (1=Divina, 2=Phantasma, 3=Anima, 4=???)
    bond_type: BondType = BondType.NORMAL_DMG
    is_assist: bool = False  # If True, donor abilities transfer to recipient
    assist_ability_ids: List[int] = field(default_factory=list)  # Donor's ability IDs
    # Bond percentage stated outright instead of derived from the donor.
    #
    # A real bond's value falls out of the donor card (rarity, and +50% when donor
    # and recipient share type AND class). A player configuring a team picks the
    # OUTCOME -- "this slot has a 7.5% normal-damage bond" -- without naming a donor,
    # because any 5star same-type/class card gives the same number. Rather than invent
    # a fake donor whose attributes happen to multiply out, state the value.
    fixed_value: Optional[float] = None

    # Base values by rarity
    RARITY_VALUES = {5: 5.0, 4: 4.0, 3: 3.0, 2: 2.0, 1: 1.0}

    def calculate_value(self, recipient_type: int, recipient_attribute: int) -> float:
        """
        Calculate the bond bonus percentage.

        +50% if donor and recipient share BOTH type and attribute.
        """
        if self.fixed_value is not None:
            return self.fixed_value
        base_value = self.RARITY_VALUES.get(self.donor_rarity, 1.0)

        # Check for same type AND same attribute (class)
        same_type = self.donor_type == recipient_type
        same_attribute = self.donor_attribute == recipient_attribute

        if same_type and same_attribute:
            return base_value * 1.5  # +50% bonus
        else:
            return base_value


# Bond slot types a player can choose, by the name the UI and TeamSpec use.
STAT_BOND_TYPES = {
    "normal": BondType.NORMAL_DMG,  # auto-attack damage; never touches skills
    "skill": BondType.SKILL_DMG,
    "hp": BondType.HP,
}


def make_stat_bond(kind: str, percent: float) -> "Bond":
    """Build one of a card's free (non-assist) bond slots.

    Lives here with ``make_assist_bond`` for the same reason: every Bond gets built
    in exactly one place. The value is stated rather than derived because a player
    picks the OUTCOME ("a 7.5% normal-damage bond") without naming a donor -- any
    5star same-type/class donor yields the same number.
    """
    bond_type = STAT_BOND_TYPES.get(str(kind).lower())
    if bond_type is None:
        raise ValueError(
            f"unknown bond type {kind!r}; expected one of {sorted(STAT_BOND_TYPES)}"
        )
    return Bond(
        donor_card_id=0,
        donor_rarity=5,
        donor_type=0,
        donor_attribute=0,
        bond_type=bond_type,
        fixed_value=float(percent),
    )


class SpecialBondEffect(Enum):
    """Types of special bond effects."""

    SKILL_DMG = auto()  # +X% skill damage
    NORMAL_DMG = auto()  # +X% normal damage
    DAMAGE = auto()  # +X% all damage
    CRIT = auto()  # +X% crit rate
    SPEED = auto()  # +X% speed


@dataclass
class SpecialBond:
    """
    A special bond pair that provides bonus effects beyond standard bond bonuses.

    Some bonds provide effects to the donor, some to the recipient, some mutual.
    """

    donor_card_id: int  # Card providing the bond
    recipient_card_id: int  # Card receiving the bond
    effect: SpecialBondEffect
    value: float  # Effect percentage (e.g., 3.0 for +3%)
    affects_donor: bool = False  # True if effect applies to donor instead of recipient
    is_mutual: bool = False  # True if both cards get the effect

    def get_targets(self) -> str:
        """Return description of who gets the effect."""
        if self.is_mutual:
            return "mutual"
        elif self.affects_donor:
            return "donor"
        else:
            return "recipient"


# Special bond pairs - card IDs from game data
# Format: (donor_id, recipient_id) -> SpecialBond
# Effect applies to recipient unless affects_donor=True
SPECIAL_BONDS: Dict[tuple, SpecialBond] = {
    # Kintaro's Axe (43) → Kintaro (22): +3% skill DMG
    (43, 22): SpecialBond(43, 22, SpecialBondEffect.SKILL_DMG, 3.0),
    # Freyr (167) → Mayflower (166): +5% skill DMG
    (167, 166): SpecialBond(167, 166, SpecialBondEffect.SKILL_DMG, 5.0),
    # Nue (1) → Raiju (169): +4% skill DMG (to Nue - donor gets effect)
    (1, 169): SpecialBond(1, 169, SpecialBondEffect.SKILL_DMG, 4.0, affects_donor=True),
    # TODO: Add more special bonds as card IDs are discovered
    # Goblonara → Kintaro: +3% DMG dealt (need Goblonara ID)
    # Cerberus → Chimera: +4% crit rate (to Cerberus - donor)
    # Princess Saho → Princess Tatsuta: +4% speed (mutual)
    # Goblerna → Gobrute: +1% DMG dealt
    # Quetzalcoatl → Tezcatlipoca: +4% normal DMG (to Quetzalcoatl - donor)
    # Miss Santa (184) → Nyarlathotep: +5% skill DMG (need Nyarlathotep ID)
    # Miss Santa (184) → Knecht Ruprecht: +5% skill DMG (to Miss Santa - donor)
    # Titania [New Year] → New Year Game: +5% crit rate (to Titania - donor)
    # Old Clock Chronos → Belphegor: +5% speed
}


def get_special_bond(donor_id: int, recipient_id: int) -> Optional["SpecialBond"]:
    """Look up a special bond by donor and recipient IDs."""
    return SPECIAL_BONDS.get((donor_id, recipient_id))


@dataclass(slots=True)
class StatModify:
    """
    A single modifier applied to a stat.

    Observed in game:
    - Type 1 = percentage modifier (stored as 0-100)
    - Type != 1 = flat modifier
    """

    value: float  # Stored as 0-100 for percentages
    mod_type: int = 1  # 1 = percentage, other = flat
    source_id: str = ""  # Ability/skill ID that applied this
    duration: int = -1  # -1 = permanent, >0 = turns remaining

    @property
    def is_percentage(self) -> bool:
        return self.mod_type == 1


@dataclass
class StatModifiers:
    """
    Container for a single stat's modifiers.

    One bucket of modifiers for one stat. Formulas observed in play.
    - Multiplicative: finalValue = baseValue × (1.0 + percentageSum / 100.0) + flatSum
    - Additive: finalValue = baseValue + (percentageSum / 100.0) + flatSum
    """

    base_value: float = 0.0
    final_value: float = 0.0
    modify_list: List[StatModify] = field(default_factory=list)
    is_pvp: bool = False
    is_additive: bool = False  # If True, pct buffs are added to base (e.g. Crit)
    has_limit_check: bool = False
    limit_check_callback: Optional[Callable[[float], float]] = None

    def add_modify(self, modify: StatModify) -> None:
        """Add or refresh a modifier."""
        if modify.source_id:
            self.modify_list = [
                m for m in self.modify_list if m.source_id != modify.source_id
            ]
        self.modify_list.append(modify)
        self.recalculate_modify()

    def remove_modify(self, source_id: str) -> None:
        """Remove all modifiers from a specific source."""
        self.modify_list = [m for m in self.modify_list if m.source_id != source_id]
        self.recalculate_modify()

    def clear_modifies(self) -> None:
        """Remove all modifiers."""
        self.modify_list.clear()
        self.recalculate_modify()

    def get_percentage_sum(self) -> float:
        """Sum of all percentage modifiers (0-100 scale)."""
        pct_sum = sum(m.value for m in self.modify_list if m.is_percentage)
        if self.is_pvp:
            pct_sum = self._limit_pvp_buff(pct_sum)
        if self.has_limit_check and self.limit_check_callback:
            pct_sum = self.limit_check_callback(pct_sum)
        return pct_sum

    def get_flat_sum(self) -> float:
        """Sum of all flat modifiers."""
        return sum(m.value for m in self.modify_list if not m.is_percentage)

    def get_modifier_total(self) -> float:
        """Return total multiplier (1.0 + percentageSum / 100.0)."""
        return 1.0 + (self.get_percentage_sum() / 100.0)

    def modify_value(self, input_value: float) -> float:
        """
        Apply modifiers to an input value.
        Multiplicative: input * (1 + pctSum/100) + flatSum
        Additive: input + (pctSum/100) + flatSum
        """
        if self.is_additive:
            return (
                input_value + (self.get_percentage_sum() / 100.0) + self.get_flat_sum()
            )
        else:
            return input_value * self.get_modifier_total() + self.get_flat_sum()

    def recalculate_modify(self) -> None:
        """Update internal final_value."""
        self.final_value = self.modify_value(self.base_value)

    def _limit_pvp_buff(self, value: float) -> float:
        """Apply PVP buff limits. Exact caps TBD."""
        # TODO: Find PVP buff caps Observed in game
        return value


# Default limit check callbacks
def check_damage_modify_limit(value: float) -> float:
    """Damage modifier limit. Clamps reduction to 80% max (-80.0)."""
    # Observed in play: the general damage bucket floors at -80%.
    return max(value, -80.0)


def check_shield_modify_limit(value: float) -> float:
    """Shield modifier limit. Clamps to [-75%, 85%]."""
    # Observed in play: shield is bounded to [-75%, +85%].
    # Note: value is percentage sum (e.g. -72.0 for 72% damage amp)
    return max(-75.0, min(value, 85.0))


@dataclass
class MonsterModel:
    """
    Pre-calculated stats before battle starts.

    In the game, MonsterModel is created before battle with fully calculated stats:
    - Level scaling: baseATK + (maxATK - baseATK) * (level / maxLevel)
    - LB bonus applied to base stats
    - Bond bonus (TeamBonus) applied

    Unit setup just copies these values.
    """

    card_id: int = 0
    level: int = 1
    lb_level: int = 0  # ExceedTime (0-4, max MLB)
    # Effective level for STAT/SKILL scaling. Starts == level; LEVEL abilities
    # (Sola leader, Hikoboshi/Orihime +10) raise it above the card's max level so
    # ATK *and* skill damage extrapolate higher (matches damage-calc.ts). Ability
    # unlocks still use the actual `level`.
    effective_level: int = 0

    # Calculated stats (includes level scaling + LB + bonds)
    attack: int = 0  # Internal ATK (display / 10)
    hp: int = 0
    speed: float = 0.0
    critical: float = 0.0  # Base crit rate (0-100 scale)

    # Raw stat values for level scaling (LEVEL ability)
    # Internal ATK is display ATK / 10
    base_atk_raw: int = 0  # Base ATK at level 1 (internal)
    max_atk_raw: int = 0  # Max ATK at max level (internal)
    base_hp_raw: int = 0  # Base HP at level 1
    max_hp_raw: int = 0  # Max HP at max level
    max_level: int = 70  # Maximum level for this card

    # References
    skill_id: int = 0
    ability_ids: List[int] = field(default_factory=list)

    # Additional data
    name: str = ""
    rarity: int = 1
    attribute: int = 1  # 1=Divina, 2=Phantasma, 3=Anima, 4=Neutral
    unit_type: int = 1  # 1=Melee, 2=Ranged, 3=Healer, 4=Support

    # Bonds (up to 3 per card)
    # Bonds are applied during MonsterStat init as modifiers
    bonds: List["Bond"] = field(default_factory=list)

    # Energy config (parsed from SkillEnergy string)
    init_energy: int = 50  # Starting energy
    max_energy: int = 100  # Max energy cap (the "bar")
    add_energy: int = 25  # Energy gain modifier

    def __post_init__(self) -> None:
        # Default effective_level to level for models built directly (tests,
        # dummy targets) rather than via calculate_from_card.
        if self.effective_level <= 0:
            self.effective_level = self.level

    @property
    def assist_ability_ids(self) -> List[int]:
        """
        Collect ability IDs from all assist bonds.

        Assist bonds transfer the donor's abilities to the recipient.
        These abilities trigger on the recipient's actions.
        """
        result = []
        for bond in self.bonds:
            if bond.is_assist:
                result.extend(bond.assist_ability_ids)
        return result

    @classmethod
    def calculate_from_card(
        cls,
        card_data: dict,
        level: int,
        lb_level: int = 0,
        bond_bonus: float = 0.0,
    ) -> "MonsterModel":
        """
        Create a MonsterModel from card data with level scaling.

        For levels beyond max_level (e.g., level 90 with max_level=70),
        stats are linearly extrapolated. This matches game behavior where
        LB unlocks levels 71-90 with continued stat growth.

        Game formula (confirmed by in-game observation):
        result = base + round((max - base) / (MaxLevel - 1) * (level - 1))

        Example: Grim Reaper [HW] with base_atk=4700, max_atk=14100, max_level=70
        - Level 70: 4700 + round(9400 / 69 * 69) = 14,100
        - Level 90: 4700 + round(9400 / 69 * 89) = 16,825

        LB bonus: +5% per LB level (from constants: dmg_limitBreak_up=0.05)
        Note: LB bonus is applied during damage calc, not here
        """
        stats = card_data.get("stats", {})
        max_level = stats.get("max_level", 70)

        # Level scaling using exact game formula (confirmed in game)
        # Game: base + round((max - base) / (MaxLevel - 1) * (level - 1))
        base_atk = stats.get("base_atk", 0)
        max_atk = stats.get("max_atk", 0)
        if max_level > 1 and level > 1:
            atk_per_level = (max_atk - base_atk) / (max_level - 1)
            scaled_atk = int(round(base_atk + atk_per_level * (level - 1)))
        elif level == 1:
            scaled_atk = base_atk
        else:
            scaled_atk = max_atk

        base_hp = stats.get("base_hp", 0)
        max_hp = stats.get("max_hp", 0)
        if max_level > 1 and level > 1:
            hp_per_level = (max_hp - base_hp) / (max_level - 1)
            scaled_hp = int(round(base_hp + hp_per_level * (level - 1)))
        elif level == 1:
            scaled_hp = base_hp
        else:
            scaled_hp = max_hp

        # Internal ATK is display ATK / 10
        internal_atk = scaled_atk // 10

        # Apply bond bonus to stats (additive percentage)
        if bond_bonus > 0:
            internal_atk = int(internal_atk * (1.0 + bond_bonus / 100.0))
            scaled_hp = int(scaled_hp * (1.0 + bond_bonus / 100.0))

        # Parse skill energy config if available
        init_energy, max_energy, add_energy = 50, 75, 25  # Defaults
        skill_energy_str = card_data.get("skill_energy", "")
        if skill_energy_str and "_" in skill_energy_str:
            parts = skill_energy_str.split("_")
            if len(parts) >= 3:
                init_energy = int(parts[0])
                max_energy = int(parts[1])
                add_energy = int(parts[2])

        return cls(
            card_id=int(card_data.get("id", 0)),
            level=level,
            effective_level=level,  # raised by LEVEL abilities in _apply_level_bonus
            lb_level=lb_level,
            attack=internal_atk,
            hp=scaled_hp,
            speed=stats.get("speed", 1000),
            critical=stats.get("crit", 0) / 10000.0,  # 750 → 7.5% (Correct scale)
            # Store raw values for LEVEL ability scaling
            base_atk_raw=base_atk // 10,  # Convert to internal ATK
            max_atk_raw=max_atk // 10,
            base_hp_raw=base_hp,
            max_hp_raw=max_hp,
            max_level=max_level,
            skill_id=int(card_data.get("skill", {}).get("id", 0)),
            ability_ids=[int(a.get("id", 0)) for a in card_data.get("abilities", [])],
            name=card_data.get("name", ""),
            rarity=stats.get("rarity", 1),
            attribute=stats.get("attribute", 1),
            unit_type=stats.get("type", 1),
            init_energy=init_energy,
            max_energy=max_energy,
            add_energy=add_energy,
        )


@dataclass
class MonsterStat:
    """
    Runtime stat tracking during combat.

    Built during unit setup:
    1. Creates the 10 modifier buckets
    2. Copies base values from MonsterModel
    3. Sets limit check callbacks for damage and shield

    All modifiers use the same AddModify formula (additive stacking).
    """

    # Base values (copied from MonsterModel)
    base_atk: int = 0
    base_hp: int = 0
    base_speed: float = 0.0
    base_critical: float = 0.0

    # Current state
    current_hp: int = 0

    # Skill bond multiplier — applied multiplicatively to skill base (like ATK bond on ATK stat)
    # Separate from skill_dmg_modifier so bond × ability-skill-dmg% is multiplicative, not additive
    skill_bond_mult: float = 1.0

    # 10 modifier types (all use additive stacking)
    crit_modifier: StatModifiers = field(default_factory=StatModifiers)
    speed_modifier: StatModifiers = field(default_factory=StatModifiers)
    damage_modifier: StatModifiers = field(default_factory=StatModifiers)
    shield_modifier: StatModifiers = field(default_factory=StatModifiers)
    hit_crit_modifier: StatModifiers = field(default_factory=StatModifiers)
    hp_modifier: StatModifiers = field(default_factory=StatModifiers)
    defense_modifier: StatModifiers = field(default_factory=StatModifiers)
    crit_dmg_modifier: StatModifiers = field(default_factory=StatModifiers)
    skill_dmg_modifier: StatModifiers = field(default_factory=StatModifiers)
    normal_dmg_modifier: StatModifiers = field(default_factory=StatModifiers)
    vamp_modifier: StatModifiers = field(default_factory=StatModifiers)  # Lifesteal %
    revenge_modifier: StatModifiers = field(
        default_factory=StatModifiers
    )  # Counter damage %

    def init_stat(self, model: MonsterModel, is_pvp: bool = False) -> None:
        """
        Initialize stats from MonsterModel.

        Roll up a unit's starting stats:
        1. Create all 10 modifiers with isPVP flag
        2. Set limit check callbacks for damage and shield
        3. Copy base values from MonsterModel
        """
        # Initialize all modifiers
        self.crit_modifier = StatModifiers(
            base_value=model.critical, is_pvp=is_pvp, is_additive=True
        )
        self.speed_modifier = StatModifiers(base_value=model.speed, is_pvp=is_pvp)
        self.damage_modifier = StatModifiers(
            base_value=0.0,
            is_pvp=is_pvp,
            has_limit_check=True,
            limit_check_callback=check_damage_modify_limit,
        )
        self.shield_modifier = StatModifiers(
            base_value=0.0,
            is_pvp=is_pvp,
            has_limit_check=True,
            limit_check_callback=check_shield_modify_limit,
        )
        self.hit_crit_modifier = StatModifiers(base_value=0.0, is_pvp=is_pvp)
        self.hp_modifier = StatModifiers(base_value=float(model.hp), is_pvp=is_pvp)
        self.defense_modifier = StatModifiers(base_value=0.0, is_pvp=is_pvp)
        self.crit_dmg_modifier = StatModifiers(base_value=0.0, is_pvp=is_pvp)
        self.skill_dmg_modifier = StatModifiers(base_value=0.0, is_pvp=is_pvp)
        self.normal_dmg_modifier = StatModifiers(base_value=0.0, is_pvp=is_pvp)
        self.vamp_modifier = StatModifiers(base_value=0.0, is_pvp=is_pvp)
        self.revenge_modifier = StatModifiers(base_value=0.0, is_pvp=is_pvp)

        # Copy base values
        self.base_atk = model.attack
        self.base_hp = model.hp
        self.base_speed = model.speed
        self.base_critical = model.critical
        self.skill_bond_mult = 1.0

        # Apply bond modifiers
        # Bonds are pre-combat stat adjustments applied as modifiers
        self._apply_bonds(model)

        # Recalculate all modifiers to set final values
        self._recalculate_all()

        # Set current HP to max
        self.current_hp = int(self.hp_modifier.final_value)

    def _apply_bonds(self, model: MonsterModel) -> None:
        """
        Apply bond bonuses as modifiers.

        Bond types apply to specific modifiers:
        - NORMAL_DMG → normal_dmg_modifier
        - SKILL_DMG → skill_dmg_modifier
        - HP → hp_modifier

        Also checks for special bond pairs and applies extra bonuses.

        The value is calculated based on donor rarity and type/attribute matching.
        """
        for bond in model.bonds:
            value = bond.calculate_value(model.unit_type, model.attribute)

            # Apply to appropriate modifier
            if bond.bond_type == BondType.NORMAL_DMG:
                self.normal_dmg_modifier.add_modify(
                    StatModify(value=value, source_id=f"bond_{bond.donor_card_id}")
                )
            elif bond.bond_type == BondType.SKILL_DMG:
                # Bond is multiplicative on skill base (like ATK bond on ATK stat)
                self.skill_bond_mult *= 1.0 + value / 100.0
            elif bond.bond_type == BondType.HP:
                self.hp_modifier.add_modify(
                    StatModify(value=value, source_id=f"bond_{bond.donor_card_id}")
                )

            # Check for special bond pair and apply extra bonus to recipient
            self._apply_special_bond(bond, model.card_id)

    def _apply_special_bond(self, bond: Bond, recipient_card_id: int) -> None:
        """
        Apply special bond bonus if this is a special pair.

        Special bonds provide effects IN ADDITION to standard bond bonus.
        Note: affects_donor special bonds are applied separately during battle setup.
        """
        special = get_special_bond(bond.donor_card_id, recipient_card_id)
        if special is None:
            return

        # Only apply to recipient if this special bond affects recipient (not donor)
        if special.affects_donor and not special.is_mutual:
            return

        # Apply the special bond effect
        source_id = f"special_bond_{bond.donor_card_id}_{recipient_card_id}"
        self._apply_special_effect(special.effect, special.value, source_id)

    def _apply_special_effect(
        self, effect: "SpecialBondEffect", value: float, source_id: str
    ) -> None:
        """Apply a special bond effect to the appropriate modifier."""
        if effect == SpecialBondEffect.SKILL_DMG:
            self.skill_bond_mult *= 1.0 + value / 100.0
        elif effect == SpecialBondEffect.NORMAL_DMG:
            self.normal_dmg_modifier.add_modify(
                StatModify(value=value, source_id=source_id)
            )
        elif effect == SpecialBondEffect.DAMAGE:
            self.damage_modifier.add_modify(
                StatModify(value=value, source_id=source_id)
            )
        elif effect == SpecialBondEffect.CRIT:
            self.crit_modifier.add_modify(StatModify(value=value, source_id=source_id))
        elif effect == SpecialBondEffect.SPEED:
            self.speed_modifier.add_modify(StatModify(value=value, source_id=source_id))

    def _recalculate_all(self) -> None:
        """Recalculate all modifier final values."""
        self.crit_modifier.recalculate_modify()
        self.speed_modifier.recalculate_modify()
        self.damage_modifier.recalculate_modify()
        self.shield_modifier.recalculate_modify()
        self.hit_crit_modifier.recalculate_modify()
        self.hp_modifier.recalculate_modify()
        self.defense_modifier.recalculate_modify()
        self.crit_dmg_modifier.recalculate_modify()
        self.skill_dmg_modifier.recalculate_modify()
        self.normal_dmg_modifier.recalculate_modify()
        self.vamp_modifier.recalculate_modify()
        self.revenge_modifier.recalculate_modify()

    def add_modify(
        self, modifier_type: ModifierType, value: float, source_id: str = ""
    ) -> None:
        """
        Add a percentage modifier to a stat.

        Value should be in 0-100 scale (e.g., 20 for +20%).
        """
        modify = StatModify(value=value, mod_type=1, source_id=source_id)
        self.get_modifier(modifier_type).add_modify(modify)

    def add_flat_modify(
        self, modifier_type: ModifierType, value: float, source_id: str = ""
    ) -> None:
        """Add a flat modifier to a stat."""
        modify = StatModify(value=value, mod_type=0, source_id=source_id)
        self.get_modifier(modifier_type).add_modify(modify)

    def get_modifier(self, modifier_type: ModifierType) -> StatModifiers:
        """Get the StatModifiers object for a type."""
        mapping = {
            ModifierType.CRIT: self.crit_modifier,
            ModifierType.SPEED: self.speed_modifier,
            ModifierType.DAMAGE: self.damage_modifier,
            ModifierType.SHIELD: self.shield_modifier,
            ModifierType.HIT_CRIT: self.hit_crit_modifier,
            ModifierType.HP: self.hp_modifier,
            ModifierType.DEFENSE: self.defense_modifier,
            ModifierType.CRIT_DMG: self.crit_dmg_modifier,
            ModifierType.SKILL_DMG: self.skill_dmg_modifier,
            ModifierType.NORMAL_DMG: self.normal_dmg_modifier,
            ModifierType.VAMP: self.vamp_modifier,
            ModifierType.REVENGE: self.revenge_modifier,
        }
        return mapping[modifier_type]

    # Convenience properties for final values
    @property
    def final_crit(self) -> float:
        """Final crit rate as a 0-1 fraction (crit 750 -> 0.075), not a percentage."""
        return self.crit_modifier.final_value

    @property
    def final_speed(self) -> float:
        """Final speed value."""
        return self.speed_modifier.final_value

    @property
    def final_damage_mult(self) -> float:
        """Total general damage multiplier (e.g. 1.25 for +25% DMG)."""
        # The general damage bucket floors at -80%
        return self.damage_modifier.get_modifier_total()

    @property
    def final_shield(self) -> float:
        """Shield as decimal (-0.75 to 0.85). Negative = damage amp."""
        # Shield is bounded to [-75%, 85%]
        return self.shield_modifier.get_percentage_sum() / 100.0

    @property
    def final_crit_dmg_mult(self) -> float:
        """Total crit damage multiplier."""
        return self.crit_dmg_modifier.get_modifier_total()

    @property
    def final_skill_dmg_mult(self) -> float:
        """Total skill damage multiplier."""
        return self.skill_dmg_modifier.get_modifier_total()

    @property
    def final_normal_dmg_mult(self) -> float:
        """Total normal attack damage multiplier."""
        return self.normal_dmg_modifier.get_modifier_total()

    @property
    def vamp_percent(self) -> float:
        """Get lifesteal as decimal (e.g., 0.15 for 15% lifesteal)."""
        # vamp_modifier stores value like 15.0 for VAMP<15.00%,0%>
        # get_modifier_total() returns 1.0 + 15.0/100 = 1.15
        # So we subtract 1.0 to get the decimal: 0.15
        return self.vamp_modifier.get_modifier_total() - 1.0

    @property
    def revenge_percent(self) -> float:
        """Get counter damage as decimal (e.g., 0.15 for 15% damage reflect)."""
        # revenge_modifier stores value like 15.0 for REVENGE<15.00%,0%>
        # Same formula as vamp_percent
        return self.revenge_modifier.get_modifier_total() - 1.0


class UnitState(Enum):
    """Unit states during combat."""

    IDLE = 0
    ATTACKING = 1
    MOVING = 2
    CASTING = 3  # Skill animation
    STUNNED = 4
    DEAD = 5


class DebuffType(Enum):
    """Debuff types that can be applied to units."""

    STUN = auto()  # Action blocked
    FROZEN = auto()  # Action blocked
    SLEEP = auto()  # Action blocked
    NUMB = auto()  # Action blocked (alias for STUN)
    STONE = auto()  # Action blocked (petrification, alias for STUN)
    POISON = auto()  # DoT: 999 damage per tick
    BURN = auto()  # DoT: 999 damage per tick
    SILENCE = auto()  # Can't use skills


@dataclass
class ActiveDebuff:
    """Tracks an active debuff on a unit."""

    debuff_type: DebuffType
    expire_time: float  # When this debuff expires
    source_id: str = ""  # What applied this debuff
    tick_interval: float = 1.0  # For DoT: seconds between damage ticks
    next_tick_time: float = 0.0  # For DoT: when next damage tick occurs


@dataclass
class ActiveHoT:
    """
    Tracks an active Heal over Time effect on a unit.

    Similar to debuff DoT but heals instead of damages.
    """

    heal_per_tick: int  # HP healed per tick
    ticks_remaining: int  # Number of ticks left
    tick_interval: float = 1.0  # Seconds between heal ticks
    next_tick_time: float = 0.0  # When next heal tick occurs
    source_id: str = ""  # What applied this HoT


@dataclass
class ConditionalEffect:
    """
    Tracks a conditional ability effect that should be re-evaluated during combat.

    Used for HPP_IN/HPP_OUT conditions that activate when HP crosses thresholds.
    """

    ability_id: int  # Source ability ID
    condition_type: str  # "hpp_in" or "hpp_out"
    threshold: float  # HP percentage threshold (0-100)
    modifier_type: "ModifierType"  # What modifier to apply when active
    modifier_value: float  # Value to apply
    source_id: str  # Unique source ID for the modifier
    is_active: bool = False  # Whether effect is currently applied


@dataclass
class MonsterComponent:
    """
    A unit in combat with full state.

    Combines MonsterModel (pre-battle stats) and MonsterStat (runtime state).
    Follows game initialization flow:
    1. initialize() - Full init sequence
    2. init_monster_state() - Create MonsterStat from MonsterModel
    3. init_abilities() - Load and apply entry abilities
    """

    model: Optional[MonsterModel] = None
    stat: Optional[MonsterStat] = None

    # Combat state
    state: UnitState = UnitState.IDLE
    is_enemy: bool = False
    is_alive: bool = True
    immortal: bool = False  # Benchmark mode: unit cannot die (HP floored at 1)
    is_reserve: bool = False  # Reserve cards contribute abilities but don't fight
    slot: str = ""  # P1, P2, E1, E2, R1, R2, etc.

    # Attack timing
    attack_cooldown: float = 0.0
    next_attack_time: float = 0.0

    # Energy system (per-unit energy for skill activation)
    current_energy: int = 0
    need_cast_point: int = 1  # Orb cost (starts at 1, escalates to 3)
    energy_add_rate: float = 1.0  # Multiplier for energy gain
    auto_cast_skill: bool = True  # AUTO mode enabled

    # Skill cooldown tracking
    skill_cooldown: float = 0.0
    minus_cost_pending: bool = False
    minus_cost_timer: float = 0.0

    # Ability references (loaded by data_loader)
    abilities: List = field(default_factory=list)  # List[Ability]
    skill: Optional[object] = None  # Skill object

    # Debuff tracking
    active_debuffs: List[ActiveDebuff] = field(default_factory=list)

    # Heal over Time tracking
    active_hots: List[ActiveHoT] = field(default_factory=list)

    # Conditional effect tracking (HPP_IN/HPP_OUT)
    conditional_effects: List[ConditionalEffect] = field(default_factory=list)

    def initialize(self, model: MonsterModel, is_enemy: bool = False) -> None:
        """
        Full initialization sequence like game.

        Flow: model -> rolled-up stats -> entry abilities
        """
        self.model = model
        self.is_enemy = is_enemy
        self.init_monster_state(model)
        # init_abilities() called separately after abilities are loaded

    def init_monster_state(self, model: MonsterModel) -> None:
        """
        Create MonsterStat from MonsterModel.

        Mirrors the game's unit-setup order.
        """
        self.stat = MonsterStat()
        self.stat.init_stat(model, is_pvp=False)

        # Initialize energy from model
        self.current_energy = model.init_energy
        self.need_cast_point = 1  # Starts at 1 orb

    def init_abilities(self) -> None:
        """
        Apply entry abilities.

        Called after abilities are loaded from data.
        Entry abilities are applied during combat initialization.
        """
        for ability in self.abilities:
            if hasattr(ability, "is_entry_ability") and ability.is_entry_ability:
                ability.apply(self)

    @property
    def is_dead(self) -> bool:
        """Check if unit is dead."""
        return not self.is_alive or self.state == UnitState.DEAD

    def can_attack(self, current_time: float) -> bool:
        """Check if unit can perform an attack."""
        if not self.is_alive or self.state == UnitState.DEAD:
            return False
        if self.state == UnitState.CASTING:
            return False
        if self.is_action_blocked(current_time):
            return False
        return current_time >= self.next_attack_time

    def is_action_blocked(self, current_time: float) -> bool:
        """Check if unit is blocked from acting by a debuff."""
        blocking_debuffs = {
            DebuffType.STUN,
            DebuffType.FROZEN,
            DebuffType.SLEEP,
            DebuffType.NUMB,
            DebuffType.STONE,
        }
        for debuff in self.active_debuffs:
            if (
                debuff.debuff_type in blocking_debuffs
                and current_time < debuff.expire_time
            ):
                return True
        return False

    def has_debuff(self, debuff_type: DebuffType, current_time: float) -> bool:
        """Check if unit has an active debuff of the given type."""
        for debuff in self.active_debuffs:
            if debuff.debuff_type == debuff_type and current_time < debuff.expire_time:
                return True
        return False

    def apply_debuff(
        self,
        debuff_type: DebuffType,
        duration: float,
        current_time: float,
        source_id: str = "",
    ) -> None:
        """
        Apply a debuff to this unit.

        Args:
            debuff_type: Type of debuff to apply
            duration: Duration in seconds
            current_time: Current battle time
            source_id: ID of the source that applied this debuff
        """
        expire_time = current_time + duration

        # For DoT debuffs (POISON, BURN), set up tick timing
        tick_interval = 1.0  # 1 second between ticks
        next_tick = current_time + tick_interval

        debuff = ActiveDebuff(
            debuff_type=debuff_type,
            expire_time=expire_time,
            source_id=source_id,
            tick_interval=tick_interval,
            next_tick_time=next_tick,
        )
        self.active_debuffs.append(debuff)

        # Update unit state for blocking debuffs (CC effects)
        if debuff_type in {
            DebuffType.STUN,
            DebuffType.FROZEN,
            DebuffType.SLEEP,
            DebuffType.NUMB,
            DebuffType.STONE,
        }:
            self.state = UnitState.STUNNED

    def clear_expired_debuffs(self, current_time: float) -> None:
        """Remove expired debuffs from the unit."""
        self.active_debuffs = [
            d for d in self.active_debuffs if current_time < d.expire_time
        ]

        # Reset state if no longer stunned
        if self.state == UnitState.STUNNED and not self.is_action_blocked(current_time):
            self.state = UnitState.IDLE

    def apply_hot(
        self,
        heal_per_tick: int,
        ticks: int,
        current_time: float,
        source_id: str = "",
        tick_interval: float = 1.0,
    ) -> None:
        """
        Apply a Heal over Time effect to the unit.

        Args:
            heal_per_tick: HP healed per tick
            ticks: Number of ticks
            current_time: Current battle time
            source_id: Identifier for this HoT source
            tick_interval: Seconds between ticks (default 1.0)
        """
        if self.is_dead:
            return

        hot = ActiveHoT(
            heal_per_tick=heal_per_tick,
            ticks_remaining=ticks,
            tick_interval=tick_interval,
            next_tick_time=current_time + tick_interval,
            source_id=source_id,
        )
        self.active_hots.append(hot)

    def process_hot_ticks(self, current_time: float) -> int:
        """
        Process HoT ticks and return total healing done.

        Should be called each tick to apply pending heals.

        Args:
            current_time: Current battle time

        Returns:
            Total HP healed this tick
        """
        if self.is_dead or self.stat is None:
            return 0

        total_healed = 0
        hots_to_remove = []

        for hot in self.active_hots:
            if current_time >= hot.next_tick_time and hot.ticks_remaining > 0:
                healed = self.heal(hot.heal_per_tick)
                total_healed += healed
                hot.ticks_remaining -= 1
                hot.next_tick_time = current_time + hot.tick_interval

                if hot.ticks_remaining <= 0:
                    hots_to_remove.append(hot)

        for hot in hots_to_remove:
            self.active_hots.remove(hot)

        return total_healed

    def clear_expired_hots(self) -> None:
        """Remove HoTs with no ticks remaining."""
        self.active_hots = [h for h in self.active_hots if h.ticks_remaining > 0]

    def get_attack_interval(self) -> float:
        """
        Calculate attack interval from speed.

        Observed in game (2025-12-24), including attack-timing measurements.

        IMPORTANT: The "speed" stat is INVERTED from typical game conventions!
        Higher speed_stat = LONGER interval = SLOWER attacks.

        Formula:
            base_interval = (speed_stat + 750) / 900
            With buffs: interval × (1 - modifier/2)  # Buffs are HALVED
            With debuffs: interval × (1 + |modifier|)  # Debuffs apply full

        Examples at 1x game speed:
        - Speed 1300 (Melee/Ranged) → ~2.28s interval
        - Speed 2300 (Healer) → ~3.39s interval
        """
        if self.stat is None:
            return 2.6  # Default fallback (melee interval)

        # Base interval from speed stat (higher speed = longer interval)
        # Validated formula (2026-01-06): (SPD + 750) / 900
        base_speed = self.stat.base_speed
        base_interval = (base_speed + 750) / 900.0

        # Speed modifier applies to interval, not stat
        # Observed in play: speed BUFFS count half, debuffs count in full.
        speed_modifier = self.stat.speed_modifier.get_modifier_total() - 1.0
        capped_modifier = max(-1.0, min(1.0, speed_modifier))

        if capped_modifier >= 0:
            # Speed BUFF: attacks faster (shorter interval)
            # Buffs are halved: +30% buff → 15% faster
            attack_interval = base_interval * (1.0 - capped_modifier / 2.0)
        else:
            # Speed DEBUFF: attacks slower (longer interval)
            # Debuffs apply at full value
            attack_interval = base_interval * (1.0 + abs(capped_modifier))

        return attack_interval

    def add_energy(self, energy_gain: int) -> None:
        """
        Add energy to unit.

        Observed in game (AddEnergy):
        - Applies EnergyAddRate multiplier
        - Clamps to MaxEnergy
        """
        if self.model is None:
            return

        adjusted_gain = int(self.energy_add_rate * energy_gain)
        self.current_energy += adjusted_gain

        # Clamp to max
        if self.current_energy > self.model.max_energy:
            self.current_energy = self.model.max_energy

    def can_cast_skill(self) -> bool:
        """
        Check if unit can cast skill.

        Observed in game (CanCastPointSkill):
        - Must have skill
        - Must not be in wrong state
        - currentEnergy >= needCastPoint
        """
        if self.skill is None:
            return False
        if self.state == UnitState.CASTING:
            return False
        return self.current_energy >= self.need_cast_point

    def add_cast_cost(self) -> None:
        """
        Increase skill cost after casting and reset energy meter.

        Observed in game (addCastCost):
        - Cost increases: 1 → 2 → 3
        - Capped at 3
        - Sets pending minus cost timer
        - Consumption: Meter reset to 0
        """
        if self.need_cast_point < 3:
            self.need_cast_point += 1
        self.minus_cost_pending = True
        self.minus_cost_timer = 0.0
        self.current_energy = 0

    def is_cast_blocked(self, current_time: float) -> bool:
        """True while CC stops this unit from casting (action block or SILENCE)."""
        return self.is_action_blocked(current_time) or self.has_debuff(
            DebuffType.SILENCE, current_time
        )

    def update_cast_cost(
        self,
        delta_time: float,
        skill_minus_cost_cd: float = 20.0,
        current_time: Optional[float] = None,
    ) -> None:
        """
        Update skill cost decay timer.

        Observed in game (CaucalMinusCastCost):
        - After 20 seconds, cost decreases by 1

        CC pauses the decay: a stunned or silenced unit is not ticking down toward
        its cheaper cast. Pass ``current_time`` to get that behaviour; omitting it
        keeps the old unconditional tick (callers that have no clock).
        """
        if current_time is not None and self.is_cast_blocked(current_time):
            return
        if self.minus_cost_pending and self.need_cast_point > 1:
            self.minus_cost_timer += delta_time
            if self.minus_cost_timer >= skill_minus_cost_cd:
                self.do_minus_cast_cost()

    def do_minus_cast_cost(self) -> None:
        """Decrease skill cost by 1."""
        if self.need_cast_point > 1:
            self.need_cast_point -= 1
        self.minus_cost_pending = False
        self.minus_cost_timer = 0.0

    def take_damage(
        self, damage: int, attacker: Optional["MonsterComponent"] = None
    ) -> bool:
        """
        Apply damage to unit and trigger counter-attack if REVENGE modifier active.

        Args:
            damage: Amount of damage to take
            attacker: The attacking unit (for REVENGE counter-attack). None for DoT/environmental.

        Returns True if unit died.
        """
        if self.stat is None:
            return False

        # Apply REVENGE counter-attack before taking damage
        # Only trigger if there's an attacker (not for DoT/environmental damage)
        # and attacker is still alive
        if (
            attacker is not None
            and attacker.stat is not None
            and attacker.is_alive
            and self.stat.revenge_percent > 0
        ):
            counter_damage = int(damage * self.stat.revenge_percent)
            if counter_damage > 0:
                # Apply counter damage WITHOUT triggering their revenge (avoid infinite loop)
                attacker.stat.current_hp -= counter_damage
                if attacker.stat.current_hp <= 0:
                    attacker.stat.current_hp = 0
                    attacker.is_alive = False
                    attacker.state = UnitState.DEAD

        self.stat.current_hp -= damage
        if self.stat.current_hp <= 0:
            if self.immortal:
                # Benchmark mode: keep the unit alive (floor HP at 1) so
                # survivability doesn't truncate the damage measurement.
                self.stat.current_hp = 1
                return False
            self.stat.current_hp = 0
            self.is_alive = False
            self.state = UnitState.DEAD
            return True
        return False

    def heal(self, amount: int) -> int:
        """
        Heal the unit.

        Healing is capped at max HP and does not revive dead units.

        Args:
            amount: Amount of HP to heal

        Returns:
            Actual amount healed
        """
        if self.stat is None or self.is_dead:
            return 0

        max_hp = int(self.stat.hp_modifier.final_value)
        old_hp = self.stat.current_hp
        self.stat.current_hp = min(self.stat.current_hp + amount, max_hp)
        return self.stat.current_hp - old_hp

    def evaluate_conditionals(self) -> None:
        """
        Re-evaluate HP-based conditional effects and apply/remove modifiers.

        Called after damage or healing to check if HPP_IN/HPP_OUT thresholds
        have been crossed, activating or deactivating the conditional buffs.
        """
        if self.stat is None or not self.is_alive:
            return

        hp_pct = (self.stat.current_hp / self.stat.base_hp) * 100.0

        for cond in self.conditional_effects:
            should_be_active = False

            if cond.condition_type == "hpp_in":
                # Active when HP% <= threshold
                should_be_active = hp_pct <= cond.threshold
            elif cond.condition_type == "hpp_out":
                # Active when HP% >= threshold
                should_be_active = hp_pct >= cond.threshold

            # Apply or remove modifier based on state change
            if should_be_active and not cond.is_active:
                # Activate: add the modifier
                self.stat.add_modify(
                    cond.modifier_type, cond.modifier_value, cond.source_id
                )
                cond.is_active = True
            elif not should_be_active and cond.is_active:
                # Deactivate: remove the modifier
                self.stat.get_modifier(cond.modifier_type).remove_modify(cond.source_id)
                cond.is_active = False

    def register_conditional(
        self,
        ability_id: int,
        condition_type: str,
        threshold: float,
        modifier_type: "ModifierType",
        modifier_value: float,
    ) -> None:
        """
        Register a conditional effect for continuous evaluation.

        Args:
            ability_id: Source ability ID
            condition_type: "hpp_in" or "hpp_out"
            threshold: HP percentage threshold (0-100)
            modifier_type: What stat modifier to apply
            modifier_value: The modifier value (percentage)
        """
        source_id = f"conditional_{ability_id}_{condition_type}"
        cond = ConditionalEffect(
            ability_id=ability_id,
            condition_type=condition_type,
            threshold=threshold,
            modifier_type=modifier_type,
            modifier_value=modifier_value,
            source_id=source_id,
            is_active=False,
        )
        self.conditional_effects.append(cond)

        # Evaluate immediately to check initial state
        self.evaluate_conditionals()

    def calculate_exceed_value(self, base_damage: float) -> tuple[float, float]:
        """
        Calculate LB exceed bonus.

        Observed in game (CalculateExceedValue):
        exceed_random = Random(0, ExceedRate × LB_level)
        exceed_percent = floor(exceed_random × 10) / 10  # Round to 0.1
        damage = base_damage × (1.0 + exceed_percent / 100.0)

        Constant: dmg_limitBreak_up = 0.05 (5% per LB level)
        """
        if self.model is None or self.model.lb_level == 0:
            return base_damage, 0.0

        exceed_rate = 5.0  # 5% per LB level
        max_bonus = exceed_rate * self.model.lb_level  # MLB/LB4 = 20% max
        exceed_random = random.uniform(0, max_bonus)

        # Round to 0.1 precision
        exceed_percent = int(exceed_random * 10) / 10.0

        final_damage = base_damage * (1.0 + exceed_percent / 100.0)
        return final_damage, exceed_percent
