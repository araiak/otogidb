"""Turning a team into a score.

The single place the search converts a candidate into a number. Everything above it
(sampling, GA, sweeps) only decides *which* teams to ask about; this decides what
they are worth, so a defect here moves every result at once.

Two properties matter more than they look:

* **The battle itself is not built here.** Benchmark mode delegates to
  ``modes.run_benchmark_battle``, shared with DamageBenchmark and apl.inspect. When
  this module owned a private copy, the copies drifted and the same team scored ~2x
  apart depending on the caller.
* **CRN (common random numbers).** Iteration *i* is seeded identically for every
  team, so the variance of score *differences* collapses even though absolute
  scores stay noisy. That is what makes A/B comparisons cheap. MC_CRN=0 restores
  independent noise when you want true per-team sd.
"""

from __future__ import annotations

import os
import random
from statistics import mean, stdev

from .assists import AssistPool
from .battle import Battle, BattleConfig, BattlePhase
from .config import combat_constants, get_5wave_config
from .constants import SLOT_ACTIVE, SLOT_HELPER, SLOT_RESERVE
from .data_loader import get_loader
from .lifecycle import MonsterModel
from .modes import FiveWaveSimulator, run_benchmark_battle
from .pool import CardPool
from .worldboss import BossSpec, load_boss
from .team import SlotKey, Team

# The boss is a property of the FIGHT and constant for a whole run, so it is
# installed per process exactly like the skill-cast scheduler
# (apl.install.install_cadence_scheduler) rather than threaded through the eight
# positional call sites of _run_team_battles. `spec.Scenario` still names it
# explicitly, so a scripted score() call is self-contained.
_ACTIVE_BOSS: "BossSpec | None" = None


def install_boss(
    boss_id: "int | None", level: int = 30, auto_atk: "int | None" = None
) -> "BossSpec | None":
    """Set (or clear, with boss_id=None) the world boss for this process."""
    global _ACTIVE_BOSS
    _ACTIVE_BOSS = load_boss(boss_id, level, auto_atk) if boss_id else None
    return _ACTIVE_BOSS


def get_active_boss() -> "BossSpec | None":
    return _ACTIVE_BOSS


def _run_team_battles(
    team: "Team",
    n_iters: int,
    pool: CardPool,
    mode: str = "benchmark",
    benchmark_time: float = 60.0,
    assists: "dict[SlotKey, int] | None" = None,
    assist_pool: "AssistPool | None" = None,
    score_threshold: float = 0.0,
    out_stats: "dict | None" = None,
) -> tuple[float, float]:
    """
    Run n_iters battles for a team. Thread-safe (creates fresh objects each call).

    benchmark mode
        Immortal 100M HP target, score = total player damage over benchmark_time
        seconds.  No overkill inflation — every damage point is real DPS.

    five_wave mode
        Standard 5-wave config.  Faster but score inflated by overkill.

    assists
        Optional dict mapping SlotKey -> assist_card_id.  When provided with a
        non-None assist_pool, the matching MonsterModel is rebuilt with the assist
        bond applied so its transferred ability fires during the battle.
    """
    loader = get_loader()
    ability_data = loader._abilities

    def _maybe_assist(slot: SlotKey, cid: int, m: MonsterModel) -> MonsterModel:
        if assists and assist_pool and slot in assists:
            ac = assist_pool.cards.get(assists[slot])
            if ac is not None:
                return assist_pool.build_assisted_model(m, ac)
        return m

    # Build player / reserve models. Iterate by slot so helper can have its
    # own assist independent of any active-slot duplicate.
    player_models: list[MonsterModel] = []
    for i, cid in enumerate(team.active):
        m = pool.get_model(cid)
        if m is None:
            return 0.0, 0.0
        player_models.append(_maybe_assist((SLOT_ACTIVE, i), cid, m))

    helper_model = pool.get_model(team.helper)
    if helper_model is None:
        return 0.0, 0.0
    player_models.append(_maybe_assist((SLOT_HELPER, 0), team.helper, helper_model))

    reserve_models: list[MonsterModel] = []
    for i, cid in enumerate(team.reserve):
        m = pool.get_model(cid)
        if m is not None:
            reserve_models.append(_maybe_assist((SLOT_RESERVE, i), cid, m))

    reserves_arg = reserve_models if reserve_models else None

    scores: list[float] = []

    # Aggressive early-abort (opt-in, for the Cadence exploratory search): most
    # teams' carries never clear the crit floor, so they crawl at the ~auto-attack
    # pace. Kill anything not on track for MC_ABORT_PACE final damage by
    # MC_ABORT_AT of the window, so duds cost a fraction of a full battle and we
    # sample far more teams. Off by default (default runs are unaffected).
    _abort_pace = float(os.environ.get("MC_ABORT_PACE", "0") or "0")
    _abort_at = float(os.environ.get("MC_ABORT_AT", "0.25") or "0.25")

    # Common Random Numbers (CRN): seed the global RNG per iteration index with a
    # base constant that is the same for every team, so iteration k replays the
    # identical crit/proc/stagger stream for all teams. This scores every team on
    # the same luck -> the variance of *score differences* (what ranking cares
    # about) collapses, and battles become reproducible run-to-run and
    # worker-count-independent. Read live (like the abort vars) so tests/analysis
    # can flip it. MC_CRN=0 restores independent noise (for true per-team sd).
    # ponytail: partial CRN — teams consume different draw counts, so the shared
    # stream desyncs mid-battle (strong early, decaying). If measurement shows
    # that's not enough, upgrade to per-unit random.Random substreams keyed by slot.
    _crn = os.environ.get("MC_CRN", "1") != "0"
    _crn_base = int(os.environ.get("MC_CRN_SEED", "12345"))

    if mode == "benchmark":
        # --- Benchmark mode: world-boss DPS vs an immortal target ---
        # The battle itself lives in modes.run_benchmark_battle, shared with
        # DamageBenchmark so both harnesses score a team identically. They used
        # to each own a copy of this loop and silently drifted ~2x apart.
        for _iter in range(n_iters):
            if _crn:
                random.seed(_crn_base + _iter)
            battle = run_benchmark_battle(
                player_models=player_models,
                ability_data=ability_data,
                reserve_models=reserves_arg,
                benchmark_time=benchmark_time,
                score_threshold=score_threshold,
                abort_pace=_abort_pace,
                abort_at=_abort_at,
                boss=_ACTIVE_BOSS,
            )
            scores.append(battle.player_damage_total)
            if out_stats is not None:
                # Survivability, only meaningful in boss mode: against the
                # immortal dummy nobody can die, so these are constant.
                out_stats.setdefault("wipes", 0)
                out_stats.setdefault("deaths", [])
                out_stats.setdefault("survival", [])
                if not any(p.is_alive for p in battle.players):
                    out_stats["wipes"] += 1
                out_stats["deaths"].append(
                    sum(1 for p in battle.players if not p.is_alive)
                )
                out_stats["survival"].append(battle.current_time)

    else:
        # --- Five-wave mode ---
        sim_cfg = get_5wave_config()
        tmp_sim = FiveWaveSimulator(sim_cfg)
        enemy_pool: list[MonsterModel] = []
        for wave_cfg in sim_cfg.waves:
            wave_enemies = tmp_sim.build_enemies(
                wave_cfg.get_enemies(), len(enemy_pool)
            )
            enemy_pool.extend(wave_enemies)

        battle_config = BattleConfig(
            wave_count=sim_cfg.wave_count,
            tick_rate=sim_cfg.tick_rate,
            turn_limit=sim_cfg.turn_limit,
            **combat_constants(sim_cfg),
        )

        for _iter in range(n_iters):
            if _crn:
                random.seed(_crn_base + _iter)
            battle = Battle(battle_config)
            battle.trace_enabled = False
            battle.skill_points = sim_cfg.team_skill_points

            battle.set_battle_data(
                player_models=player_models,
                enemy_models=enemy_pool[:5],
                ability_data=ability_data,
                reserve_models=reserves_arg,
            )
            battle._enemy_pool = enemy_pool  # type: ignore[attr-defined]
            battle._ability_data = ability_data  # type: ignore[attr-defined]

            victory = battle.simulate_battle()

            attacks = [
                e
                for e in battle.events
                if e.event_type == "attack"
                and e.attacker is not None
                and e.attacker.startswith("P")
            ]
            total_damage = sum(a.damage for a in attacks)
            waves_done = (
                battle.current_wave + 1
                if battle.phase == BattlePhase.VICTORY
                else battle.current_wave
            )
            wave_bonus = 1.0 + 0.1 * (waves_done - 1)
            completion_bonus = 1.5 if victory else 1.0
            scores.append(total_damage * wave_bonus * completion_bonus)

    avg = mean(scores) if scores else 0.0
    sd = stdev(scores) if len(scores) > 1 else 0.0
    return avg, sd


# ---------------------------------------------------------------------------
# Shapley estimator
# ---------------------------------------------------------------------------
