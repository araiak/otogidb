"""
Comparison and Reporting for Battle Simulator

Compares actual vs predicted damage and generates reports
to identify gaps in formula understanding.
"""

from typing import List, Dict, Tuple
from dataclasses import dataclass, field

from .models import Action, DamageResult, ComparisonResult


def compare_single(
    action: Action,
    predicted: DamageResult,
    tolerance: float = 0.05,
) -> ComparisonResult:
    """
    Compare actual vs predicted damage for a single action.

    Args:
        action: Action with actual damage
        predicted: Simulated damage result
        tolerance: Acceptable variance (0.05 = 5%)

    Returns:
        ComparisonResult with analysis
    """
    actual = action.actual_damage
    pred = predicted.final_damage

    # Calculate variance
    if actual == 0:
        variance = 0.0 if pred == 0 else 1.0
        variance_pct = variance * 100
    else:
        variance = abs(pred - actual)
        variance_pct = (variance / actual) * 100

    return ComparisonResult(
        action=action,
        predicted=predicted,
        actual_damage=actual,
        predicted_damage=pred,
        variance=variance,
        variance_pct=variance_pct,
        within_tolerance=(variance_pct / 100 <= tolerance),
        assumptions_used=predicted.assumptions_used.copy(),
    )


def compare_results(
    results: List[Tuple[Action, DamageResult]],
    tolerance: float = 0.05,
) -> List[ComparisonResult]:
    """
    Compare all action results.

    Args:
        results: List of (action, predicted) tuples from simulator
        tolerance: Acceptable variance percentage

    Returns:
        List of ComparisonResult
    """
    comparisons = []
    for action, predicted in results:
        comp = compare_single(action, predicted, tolerance)
        comparisons.append(comp)
    return comparisons


@dataclass
class ReportSummary:
    """Summary statistics for comparison report."""

    total_actions: int = 0
    within_tolerance: int = 0
    accuracy_rate: float = 0.0
    avg_variance_pct: float = 0.0
    max_variance_pct: float = 0.0
    min_variance_pct: float = 0.0

    # By action type
    normal_count: int = 0
    normal_avg_variance: float = 0.0
    skill_count: int = 0
    skill_avg_variance: float = 0.0

    # Assumption analysis
    actions_with_assumptions: int = 0
    actions_validated_only: int = 0
    variance_with_assumptions: float = 0.0
    variance_validated_only: float = 0.0

    # Assumption breakdown
    assumptions_used: Dict[str, int] = field(default_factory=dict)


def generate_report(
    comparisons: List[ComparisonResult],
    tolerance: float = 0.05,
) -> ReportSummary:
    """
    Generate summary report from comparisons.

    Args:
        comparisons: List of comparison results
        tolerance: Tolerance used for "within tolerance" check

    Returns:
        ReportSummary with statistics
    """
    if not comparisons:
        return ReportSummary()

    report = ReportSummary()
    report.total_actions = len(comparisons)

    # Basic stats
    variances = [c.variance_pct for c in comparisons]
    report.within_tolerance = sum(1 for c in comparisons if c.within_tolerance)
    report.accuracy_rate = report.within_tolerance / report.total_actions
    report.avg_variance_pct = sum(variances) / len(variances)
    report.max_variance_pct = max(variances)
    report.min_variance_pct = min(variances)

    # By action type
    from .models import ActionType

    normal_comps = [c for c in comparisons if c.action.action_type == ActionType.NORMAL]
    skill_comps = [c for c in comparisons if c.action.action_type == ActionType.SKILL]

    report.normal_count = len(normal_comps)
    if normal_comps:
        report.normal_avg_variance = sum(c.variance_pct for c in normal_comps) / len(
            normal_comps
        )

    report.skill_count = len(skill_comps)
    if skill_comps:
        report.skill_avg_variance = sum(c.variance_pct for c in skill_comps) / len(
            skill_comps
        )

    # Assumption analysis
    with_assumptions = [c for c in comparisons if c.assumptions_used]
    validated_only = [c for c in comparisons if not c.assumptions_used]

    report.actions_with_assumptions = len(with_assumptions)
    report.actions_validated_only = len(validated_only)

    if with_assumptions:
        report.variance_with_assumptions = sum(
            c.variance_pct for c in with_assumptions
        ) / len(with_assumptions)
    if validated_only:
        report.variance_validated_only = sum(
            c.variance_pct for c in validated_only
        ) / len(validated_only)

    # Count assumption usage
    for comp in comparisons:
        for assumption in comp.assumptions_used:
            report.assumptions_used[assumption] = (
                report.assumptions_used.get(assumption, 0) + 1
            )

    return report


def format_comparison_table(
    comparisons: List[ComparisonResult],
    max_rows: int = 50,
) -> str:
    """
    Format comparisons as a readable table.

    Args:
        comparisons: List of comparison results
        max_rows: Maximum rows to display

    Returns:
        Formatted table string
    """
    lines = []
    lines.append("=" * 90)
    lines.append("ACTUAL vs PREDICTED DAMAGE COMPARISON")
    lines.append("=" * 90)
    lines.append("")

    header = f"{'#':<4} {'Attacker':<10} {'Type':<8} {'Combo':<6} {'Actual':<10} {'Predicted':<10} {'Var%':<8} {'Status':<12}"
    lines.append(header)
    lines.append("-" * 90)

    for i, comp in enumerate(comparisons[:max_rows]):
        action_type = comp.action.action_type.value
        combo = comp.action.combo_count

        # Status indicator
        if comp.within_tolerance:
            status = "OK"
        else:
            status = "MISMATCH"

        # Mark if assumptions used
        if comp.assumptions_used:
            status += "*"
            assumptions_str = ",".join(
                a.replace("ASSUMPTION:", "") for a in comp.assumptions_used
            )
            status += f" [{assumptions_str}]"

        # Crit indicator
        from .models import CritType

        if comp.action.crit_type == CritType.NORMAL:
            action_type += " C"
        elif comp.action.crit_type == CritType.SUPER:
            action_type += " SC"

        line = (
            f"{i+1:<4} "
            f"{comp.action.attacker_slot:<10} "
            f"{action_type:<8} "
            f"{combo:<6} "
            f"{comp.actual_damage:<10} "
            f"{comp.predicted_damage:<10} "
            f"{comp.variance_pct:>6.1f}% "
            f"{status:<12}"
        )
        lines.append(line)

    if len(comparisons) > max_rows:
        lines.append(f"... and {len(comparisons) - max_rows} more rows")

    lines.append("-" * 90)
    lines.append("* = Uses unvalidated assumptions")
    lines.append("C = Normal Crit (2x), SC = Super Crit (4x)")
    lines.append("")

    return "\n".join(lines)


def format_summary(report: ReportSummary, tolerance: float = 0.05) -> str:
    """
    Format report summary as readable text.

    Args:
        report: ReportSummary from generate_report()
        tolerance: Tolerance percentage used

    Returns:
        Formatted summary string
    """
    lines = []
    lines.append("=" * 50)
    lines.append("SUMMARY")
    lines.append("=" * 50)
    lines.append("")

    # A validation report over nothing is not a pass, but every line below reads
    # like one: "Within 5% Tolerance: 0/0", "Average Variance: 0.00%", and worst
    # of all "NO ASSUMPTIONS USED - All calculations used validated formulas!".
    # All three checked-in v2.0 captures are empty (0 actions, 0 units), so this
    # is what the tool actually prints today -- a clean bill of health from zero
    # evidence. Say so instead.
    if report.total_actions == 0:
        lines.append("NOT VALIDATED - the capture contained no comparable actions.")
        lines.append("")
        lines.append(
            "  This is not a pass. Nothing was checked. A capture with no actions"
        )
        lines.append(
            "  usually means the hook recorded metadata only, or the file predates"
        )
        lines.append("  the format `parse_battle_capture` reads (see simulator.py).")
        return "\n".join(lines)

    lines.append(f"Total Actions: {report.total_actions}")
    lines.append(
        f"Within {tolerance*100:.0f}% Tolerance: {report.within_tolerance}/{report.total_actions} ({report.accuracy_rate*100:.1f}%)"
    )
    lines.append(f"Average Variance: {report.avg_variance_pct:.2f}%")
    lines.append(f"Max Variance: {report.max_variance_pct:.2f}%")
    lines.append("")

    lines.append("BY ACTION TYPE:")
    lines.append(
        f"  Normal Attacks: {report.normal_count}, avg variance {report.normal_avg_variance:.2f}%"
    )
    lines.append(
        f"  Skill Attacks: {report.skill_count}, avg variance {report.skill_avg_variance:.2f}%"
    )
    lines.append("")

    lines.append("ASSUMPTION ANALYSIS:")
    lines.append(
        f"  Actions using validated formulas only: {report.actions_validated_only}"
    )
    if report.actions_validated_only > 0:
        lines.append(f"    -> Average variance: {report.variance_validated_only:.2f}%")
    lines.append(f"  Actions using assumptions: {report.actions_with_assumptions}")
    if report.actions_with_assumptions > 0:
        lines.append(
            f"    -> Average variance: {report.variance_with_assumptions:.2f}%"
        )
    lines.append("")

    if report.assumptions_used:
        lines.append("ASSUMPTIONS USED:")
        for assumption, count in sorted(report.assumptions_used.items()):
            lines.append(f"  {assumption}: {count} actions")
    else:
        lines.append("NO ASSUMPTIONS USED - All calculations used validated formulas!")

    lines.append("")
    lines.append("=" * 50)

    return "\n".join(lines)


def format_full_report(
    comparisons: List[ComparisonResult],
    tolerance: float = 0.05,
    max_table_rows: int = 50,
) -> str:
    """
    Generate full formatted report.

    Args:
        comparisons: List of comparison results
        tolerance: Tolerance percentage
        max_table_rows: Maximum table rows to show

    Returns:
        Complete formatted report
    """
    report = generate_report(comparisons, tolerance)

    parts = []
    parts.append(format_comparison_table(comparisons, max_table_rows))
    parts.append(format_summary(report, tolerance))

    return "\n".join(parts)


def export_comparison_json(
    comparisons: List[ComparisonResult],
    tolerance: float = 0.05,
) -> Dict:
    """
    Export comparison results as JSON-serializable dict.

    Args:
        comparisons: List of comparison results
        tolerance: Tolerance percentage

    Returns:
        Dict suitable for JSON export
    """
    report = generate_report(comparisons, tolerance)

    return {
        "summary": {
            "total_actions": report.total_actions,
            "within_tolerance": report.within_tolerance,
            "accuracy_rate": report.accuracy_rate,
            "avg_variance_pct": report.avg_variance_pct,
            "max_variance_pct": report.max_variance_pct,
            "normal_count": report.normal_count,
            "normal_avg_variance": report.normal_avg_variance,
            "skill_count": report.skill_count,
            "skill_avg_variance": report.skill_avg_variance,
            "actions_with_assumptions": report.actions_with_assumptions,
            "actions_validated_only": report.actions_validated_only,
            "assumptions_used": report.assumptions_used,
        },
        "comparisons": [
            {
                "attacker": c.action.attacker_slot,
                "action_type": c.action.action_type.value,
                "combo": c.action.combo_count,
                "crit_type": c.action.crit_type.value,
                "actual_damage": c.actual_damage,
                "predicted_damage": c.predicted_damage,
                "variance_pct": c.variance_pct,
                "within_tolerance": c.within_tolerance,
                "assumptions_used": c.assumptions_used,
                "breakdown": {
                    "base": c.predicted.base_damage,
                    "after_exceed": c.predicted.after_exceed,
                    "after_combo": c.predicted.after_combo,
                    "after_modifiers": c.predicted.after_modifiers,
                    "after_crit": c.predicted.after_crit,
                    "after_shield": c.predicted.after_shield,
                    "multipliers": {
                        "exceed": c.predicted.exceed_mult,
                        "combo": c.predicted.combo_mult,
                        "modifier": c.predicted.modifier_mult,
                        "crit": c.predicted.crit_mult,
                        "crit_dmg": c.predicted.crit_dmg_mult,
                        "shield": c.predicted.shield_mult,
                    },
                    "was_capped": c.predicted.was_capped,
                },
            }
            for c in comparisons
        ],
    }
