"""
Ability system for the Otogi Battle Simulator.

Handles ability parsing, trigger conditions, and effect application.
Behaviour observed in play; the once-per-battle rule is described in Ability.apply.

Ability Flow:
1. Abilities loaded from abilities.json
2. During init: entry abilities are applied once
3. During combat: attack_normal/attack_skill abilities triggered
4. Wave transitions: entry_wave/last_wave abilities applied
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any, TYPE_CHECKING
from enum import Enum, auto
import copy
import re

from .lifecycle import ModifierType, StatModify, MonsterComponent

if TYPE_CHECKING:
    from .battle import Battle


class AbilityTrigger(Enum):
    """
    Ability trigger types.

    From abilities.json `er` field analysis (2025-12-24).
    """

    ENTRY = "entry"  # Applied once during unit setup
    ENTRY_WAVE = "entry_wave"  # Applied at each wave start
    ENTRY_LEADER = "entry_leader"  # Applied if unit is team leader
    LAST_WAVE = "last_wave"  # Applied on final wave only
    ATTACK_NORMAL = "attack_normal"  # Triggers on normal attack
    ATTACK_SKILL = "attack_skill"  # Triggers on skill use


class EffectType(Enum):
    """
    Effect types that abilities can apply.

    Maps to StatModifier types in MonsterStat.
    """

    # Stat modifiers
    ATK = auto()  # Attack modifier -> general damage bucket
    CHIT = auto()  # Crit rate
    CHIT_ATK = auto()  # Crit damage
    SPD = auto()  # Speed
    SHIELD = auto()  # Damage reduction
    DEF = auto()  # Defense
    HP = auto()  # HP modifier

    # Attack type modifiers
    NORM_ATK = auto()  # Normal attack damage
    SKILL_ATK = auto()  # Skill damage

    # Conditional triggers
    HPP_IN = auto()  # HP percentage threshold (below)
    HPP_OUT = auto()  # HP percentage threshold (above)
    COMBO_IN = auto()  # Combo count threshold

    # Debuff effects (CC = crowd control, blocks actions)
    STUN = auto()
    POISON = auto()
    BURN = auto()
    FROZEN = auto()
    SLEEP = auto()
    NUMB = auto()  # CC alias for STUN
    STONE = auto()  # CC alias for STUN (petrification)
    SILENCE = auto()

    # Debuff modifiers
    HIT = auto()  # Proc rate for debuffs (e.g., HIT<15%,0.43%> = 15% + 0.43%/level)

    # Counter effects
    REVENGE = auto()  # Reflect X% of damage taken back to attacker

    # Other
    ENERGY = auto()  # Energy gain modifier
    HEAL = auto()  # Immediate healing effect
    HEAL_DOT = auto()  # Heal over time (ticks)
    TIME = auto()  # Battle time limit increase (e.g., Chronus #209)
    VAMP = auto()  # Lifesteal - heals for % of damage dealt
    LEVEL = auto()  # Level increase - scales stats by adding virtual levels
    UNKNOWN = auto()


# Mapping from effect type string to EffectType enum
EFFECT_TYPE_MAP = {
    "ATK": EffectType.ATK,
    "CHIT": EffectType.CHIT,
    "CHIT_ATK": EffectType.CHIT_ATK,
    "SPD": EffectType.SPD,
    "SHIELD": EffectType.SHIELD,
    "DEF": EffectType.DEF,
    "HP": EffectType.HP,
    "NORM_ATK": EffectType.NORM_ATK,
    "SKILL_ATK": EffectType.SKILL_ATK,
    "HPP_IN": EffectType.HPP_IN,
    "HPP_OUT": EffectType.HPP_OUT,
    "COMBO_IN": EffectType.COMBO_IN,
    "STUN": EffectType.STUN,
    "POISON": EffectType.POISON,
    "BURN": EffectType.BURN,
    "FROZEN": EffectType.FROZEN,
    "SLEEP": EffectType.SLEEP,
    "NUMB": EffectType.NUMB,
    "STONE": EffectType.STONE,
    "SILENCE": EffectType.SILENCE,
    "HIT": EffectType.HIT,
    "REVENGE": EffectType.REVENGE,
    "ENERGY": EffectType.ENERGY,
    "HEAL": EffectType.HEAL,
    "HEAL_DOT": EffectType.HEAL_DOT,
    "TIME": EffectType.TIME,
    "VAMP": EffectType.VAMP,
    "LEVEL": EffectType.LEVEL,
}

# Mapping from EffectType to ModifierType for stat effects
EFFECT_TO_MODIFIER = {
    EffectType.ATK: ModifierType.DAMAGE,
    EffectType.CHIT: ModifierType.CRIT,
    EffectType.CHIT_ATK: ModifierType.CRIT_DMG,
    EffectType.SPD: ModifierType.SPEED,
    EffectType.SHIELD: ModifierType.SHIELD,
    EffectType.DEF: ModifierType.DEFENSE,
    EffectType.HP: ModifierType.HP,
    EffectType.NORM_ATK: ModifierType.NORMAL_DMG,
    EffectType.SKILL_ATK: ModifierType.SKILL_DMG,
    EffectType.VAMP: ModifierType.VAMP,
    EffectType.REVENGE: ModifierType.REVENGE,
}


@dataclass
class AbilityEffect:
    """A single effect within an ability."""

    effect_type: EffectType
    value: float  # Primary value (stored as 0-100 for percentages)
    scale: float = 0.0  # Level scaling factor
    condition_value: float = 0.0  # For conditional effects (e.g., HP threshold)
    condition_type: Optional[str] = None  # "hpp_in", "hpp_out", or "combo_in"
    ticks: int = 1  # For HEAL_DOT: number of heal ticks
    duration: int = 0  # Duration in seconds; 0 = permanent (no expiry)

    # Proc rate for debuffs (from HIT effect)
    # HIT<15.00%,0.43%> means 15% base + 0.43% per level
    proc_rate: float = 100.0  # Base proc rate (100 = always applies)
    proc_scale: float = 0.0  # Per-level scaling for proc rate

    def get_proc_chance(self, level: int = 1) -> float:
        """Calculate proc chance as decimal (0.0-1.0) based on level."""
        total_rate = self.proc_rate + (self.proc_scale * level)
        return min(total_rate / 100.0, 1.0)  # Cap at 100%


@dataclass
class Ability:
    """
    Parsed ability data with effects and trigger conditions.

    Behaviour observed in play; the once-per-battle rule is described in Ability.apply.
    """

    id: int
    trigger: AbilityTrigger
    target_selector: str  # Raw target selector string
    effects: List[AbilityEffect] = field(default_factory=list)
    unlock_level: int = 1
    is_overlay: bool = False  # Can stack with same ability

    # Parsed from target_selector
    target_type: str = "self"  # self, enemy
    target_count: int = 1
    target_filter: Optional[str] = None  # type<1>, prof<1,2,3>, etc.

    # Monster needs (mns field) - required cards in party
    # Format: "AND(268)" = all listed cards required, "OR(1,2,3)" = any one required
    mns_type: Optional[str] = None  # "AND" or "OR" or None
    mns_card_ids: List[int] = field(default_factory=list)  # Required card IDs

    # Tracking for setup-phase application (e.g. LEVEL)
    setup_applied: bool = False

    @property
    def is_entry_ability(self) -> bool:
        """Check if this ability triggers on battle entry."""
        return self.trigger in (AbilityTrigger.ENTRY, AbilityTrigger.ENTRY_LEADER)

    @property
    def is_wave_ability(self) -> bool:
        """Check if this ability triggers on wave transitions."""
        return self.trigger in (AbilityTrigger.ENTRY_WAVE, AbilityTrigger.LAST_WAVE)

    @property
    def is_attack_ability(self) -> bool:
        """Check if this ability triggers on attacks."""
        return self.trigger in (
            AbilityTrigger.ATTACK_NORMAL,
            AbilityTrigger.ATTACK_SKILL,
        )

    @property
    def is_self_target(self) -> bool:
        """Check if this ability targets self/allies."""
        return self.target_type == "self"

    def can_apply(
        self,
        caster: MonsterComponent,
        is_leader: bool = False,
        is_last_wave: bool = False,
        party_card_ids: Optional[List[int]] = None,
        force_conditionals: bool = False,
    ) -> bool:
        """
        Check if ability can be applied in current context.

        Observed in game CanOpenAbility checks.

        Args:
            caster: The unit casting/owning this ability
            is_leader: Whether the caster is the team leader
            is_last_wave: Whether this is the final wave
            party_card_ids: List of card IDs in the party
            force_conditionals: If True, bypass party member requirement checks (mns).
                               Used for baselining abilities without requiring specific
                               party compositions (e.g., Platina Elf #266 requiring Aurum Elf).
        """
        # Check level requirement
        if caster.model and caster.model.level < self.unlock_level:
            return False

        # Check trigger conditions
        if self.trigger == AbilityTrigger.ENTRY_LEADER and not is_leader:
            return False
        if self.trigger == AbilityTrigger.LAST_WAVE and not is_last_wave:
            return False

        # Check monster needs (mns) - required cards in party
        # Skip if force_conditionals is enabled (for baselining)
        if not force_conditionals and self.mns_type and self.mns_card_ids:
            if party_card_ids is None:
                party_card_ids = []

            if self.mns_type == "AND":
                # All required cards must be present
                if not all(cid in party_card_ids for cid in self.mns_card_ids):
                    return False
            elif self.mns_type == "OR":
                # At least one required card must be present
                if not any(cid in party_card_ids for cid in self.mns_card_ids):
                    return False

        return True

    def apply(
        self,
        caster: MonsterComponent,
        targets: Optional[List[MonsterComponent]] = None,
        battle: Optional["Battle"] = None,
        wave_num: Optional[int] = None,
    ) -> None:
        """
        Apply ability effects to targets.

        Observed in game ApplyMonsterAbility logic.

        Args:
            caster: The unit casting the ability
            targets: List of targets to apply effects to
            battle: The battle instance
            wave_num: Current wave number for wave abilities (enables stacking)
        """
        if targets is None:
            targets = [caster]  # Default to self

        # Overlay gate: an ability flagged o:false fires only ONCE per scope, no
        # matter how many copies of it the team carries.
        #
        # The gate sits here, before any individual effect is processed, so every
        # effect type (HEAL, TIME, stat mods) is covered by one rule rather than
        # each re-implementing it.
        #
        # Two exemptions, both observed in play:
        #   * Attack-triggered abilities (AttackLink) are exempt -- they fire on
        #     every attack by design, not once per battle.
        #   * Wave abilities (WaveEntry / LastWaveEntry) are NOT exempt, but the
        #     scope is per wave: folding wave_num into the key lets them fire once
        #     each wave while duplicate cards still dedup within a wave.
        #
        # Scope is per side, not battle-wide: the team and the helper are tracked
        # separately, so one team copy AND one helper copy of the same o:false
        # ability both apply. Measured in play -- Stella: Phoenix (680) yields
        # speed modifier 0.7 / 1.1 / 1.1 for 1 / 2 / 3 copies, the third being a
        # second in-team copy that correctly adds nothing.
        #
        # Gate is at the ability level (not per-target) so multi-target abilities
        # still apply to all resolved targets on their first fire.
        is_attack_trigger = self.trigger in (
            AbilityTrigger.ATTACK_SKILL,
            AbilityTrigger.ATTACK_NORMAL,
        )
        if not self.is_overlay and not is_attack_trigger:
            if battle is not None:
                is_helper = caster.slot == "P5"
                applied = (
                    battle._helper_overlay_abilities
                    if is_helper
                    else battle._team_overlay_abilities
                )
                key: object = (self.id, wave_num) if self.is_wave_ability else self.id
                if key in applied:
                    return
                applied.add(key)

        for target in targets:
            self._apply_effects(caster, target, battle, wave_num=wave_num)

    def _apply_effects(
        self,
        caster: MonsterComponent,
        target: MonsterComponent,
        battle: Optional["Battle"] = None,
        wave_num: Optional[int] = None,
    ) -> None:
        """Apply all effects to a single target."""

        for effect in self.effects:
            self._apply_single_effect(caster, target, effect, battle, wave_num=wave_num)

    def _apply_level_bonus(
        self,
        target: MonsterComponent,
        bonus_levels: int,
    ) -> None:
        """
        Apply level bonus by recalculating stats with increased effective level.

        IMPORTANT: LEVEL ability pushes cards ABOVE their natural max level!
        This is the key benefit of cards like Sola #549 - a level 90 card
        becomes effectively level 105 for stat purposes.

        Note: Ability unlocks are NOT affected - abilities unlock based on
        the card's actual level, not the boosted effective level.

        Game formula (confirmed by in-game observation):
        stat = base + round((max - base) / (maxLevel - 1) * (level - 1))

        Adding +15 levels means bonus stat per level * 15:
        bonus = round((max - base) / (maxLevel - 1) * bonus_levels)

        Example: Grim Reaper [HW] at level 90, +15 from Sola
        - base_atk=4700, max_atk=14100, max_level=70
        - Level 90 ATK: 4700 + round(9400 / 69 * 89) = 16,825
        - +15 levels ATK bonus: round(9400 / 69 * 15) = 2,043
        - Final ATK at effective level 105: 16,825 + 2,043 = 18,868
        """
        if target.model is None or target.stat is None:
            return

        model = target.model
        max_level = model.max_level if model.max_level > 0 else 70

        if bonus_levels <= 0:
            return

        # Raise the effective level so BOTH ATK (below) and skill damage
        # (slv1 + (effective_level-1)*slvup) scale up. Matches damage-calc.ts,
        # where LEVEL abilities push the level past max for stat/skill purposes.
        model.effective_level += bonus_levels

        # Calculate ATK bonus using exact game formula - NO CAP, levels can exceed max_level
        # Formula: bonus = round((max - base) / (maxLevel - 1) * bonus_levels)
        if model.max_atk_raw > 0 and model.base_atk_raw > 0 and max_level > 1:
            atk_per_level = (model.max_atk_raw - model.base_atk_raw) / (max_level - 1)
            atk_bonus = int(round(atk_per_level * bonus_levels))
            if atk_bonus > 0:
                # Add as flat bonus to base ATK
                target.stat.base_atk += atk_bonus

        # Calculate HP bonus using exact game formula - NO CAP, levels can exceed max_level
        if model.max_hp_raw > 0 and model.base_hp_raw > 0 and max_level > 1:
            hp_per_level = (model.max_hp_raw - model.base_hp_raw) / (max_level - 1)
            hp_bonus = int(round(hp_per_level * bonus_levels))
            if hp_bonus > 0:
                # Add as flat bonus to HP modifier and update current HP
                target.stat.add_flat_modify(
                    ModifierType.HP, float(hp_bonus), f"ability_{self.id}_level"
                )
                # Also increase current HP by the bonus
                max_hp = int(target.stat.hp_modifier.final_value)
                target.stat.current_hp = min(target.stat.current_hp + hp_bonus, max_hp)

    def _apply_single_effect(
        self,
        caster: MonsterComponent,
        target: MonsterComponent,
        effect: AbilityEffect,
        battle: Optional["Battle"] = None,
        wave_num: Optional[int] = None,
    ) -> None:
        """
        Apply a single effect to target.

        Args:
            caster: The unit casting the ability
            target: The target unit
            effect: The effect to apply
            battle: The battle instance
            wave_num: Current wave number for wave abilities (enables stacking)
        """
        if target.stat is None:
            return

        # Handle HP-based conditional effects with continuous evaluation
        # If this effect has a condition_type, register for re-evaluation
        if effect.condition_type in ("hpp_in", "hpp_out"):
            modifier_type = EFFECT_TO_MODIFIER.get(effect.effect_type)
            if modifier_type:
                # Register for continuous evaluation instead of one-time check
                target.register_conditional(
                    ability_id=self.id,
                    condition_type=effect.condition_type,
                    threshold=effect.condition_value,
                    modifier_type=modifier_type,
                    modifier_value=effect.value,
                )
                return  # Don't apply immediately, let conditional system handle it

        # Check COMBO_IN condition (one-time check, combo doesn't change for a unit)
        if effect.condition_type == "combo_in":
            if battle is None or battle.combo_counter < effect.condition_value:
                return  # Combo too low

        # Handle heal effects
        if effect.effect_type == EffectType.HEAL:
            # Immediate heal
            # Formula: heal = targetMaxHP × effect.value%
            # Note: This is a simplified formula. The actual game may use
            # casterATK × Heal_attack_x + targetMaxHP × Heal_attack_y × effectPercent
            # See constants: Heal_attack_x=90%, Heal_attack_y=20%
            heal_amount = int(target.stat.base_hp * effect.value / 100.0)
            target.stat.current_hp = min(
                target.stat.current_hp + heal_amount,
                int(target.stat.hp_modifier.final_value),  # Cap at max HP
            )
            return

        if effect.effect_type == EffectType.HEAL_DOT:
            # Heal over time - apply as ticking HoT
            # Format: HEAL_DOT<X%,Y%,Z> where X=% per tick, Z=ticks
            # Each tick heals X% of target's base HP
            heal_per_tick = int(target.stat.base_hp * effect.value / 100.0)

            # Get current time from battle if available, otherwise use 0
            current_time = battle.current_time if battle else 0.0

            # Apply HoT effect (will tick over time)
            target.apply_hot(
                heal_per_tick=heal_per_tick,
                ticks=effect.ticks,
                current_time=current_time,
                source_id=f"ability_{self.id}_hot",
                tick_interval=1.0,  # 1 second between ticks
            )
            return

        # Handle TIME effect (battle time limit increase)
        if effect.effect_type == EffectType.TIME:
            # TIME<10.00%,0%> means +10% battle time limit.
            # Only applies when battle has a time limit.
            #
            # Uniqueness for o:false TIME abilities is enforced by the ordinary
            # overlay gate in apply(), which is team-scoped with the helper on a
            # separate dictionary. A previous battle-wide `_applied_time_abilities`
            # set was used here instead, on the assumption that a second
            # application "from the other side" would compound the global clock
            # illegitimately — but the RE notes show the game genuinely allows one
            # team copy plus one helper copy (buff_stacking.md, confirmed
            # 2026-02-01). Ninetails Fox on your team AND on the helper is +20%.
            if battle is not None and battle.base_time_limit > 0:
                # Stacks ADDITIVELY with other TIME extensions
                battle.time_limit_extension_pct += effect.value
            return

        # Handle LEVEL effect (stat scaling via level increase)
        if effect.effect_type == EffectType.LEVEL:
            # LEVEL effects are handled exclusively in apply_setup_abilities (phase 1.5).
            # Skip here to avoid double-application during entry phase (phase 2).
            if self.setup_applied:
                return
            self._apply_level_bonus(target, int(effect.value))
            return

        # Get modifier type for stat effects
        modifier_type = EFFECT_TO_MODIFIER.get(effect.effect_type)
        if modifier_type:
            # Source ID strategy mirrors the game's CasterKey system (observed in game):
            # Game uses CasterKey = "{slot}_{abilityID}" (slot-based).
            # Duplicate cards in DIFFERENT slots stack.
            # Same card in SAME slot refreshes (overwrites).

            is_attack_trigger = self.trigger in (
                AbilityTrigger.ATTACK_SKILL,
                AbilityTrigger.ATTACK_NORMAL,
            )

            if wave_num is not None and self.is_wave_ability:
                # Wave buffs stack across waves (wave_num distinguishes them).
                source_id = f"{caster.slot}_ability_{self.id}_wave_{wave_num}_{modifier_type.name}"
            elif is_attack_trigger and self.is_overlay and battle is not None:
                # o=True attack-triggered buffs (e.g. Nimbus[Awakened] 51402)
                # STACK on repeated applications. Each cast appends a new
                # modifier rather than refreshing the existing one. The
                # per-cast counter ensures source_id uniqueness; permanent
                # buffs (duration=0) compound for the rest of the battle.
                key = (caster.slot, self.id, modifier_type)
                counter = battle._ability_cast_counter.get(key, 0) + 1
                battle._ability_cast_counter[key] = counter
                source_id = f"{caster.slot}_ability_{self.id}_{modifier_type.name}_cast{counter}"
            else:
                # Default path: slot-based key. Repeated applications refresh
                # (Stat.add_modify removes prior matching source_id first).
                # Covers o=False attack triggers and all non-attack paths.
                source_id = f"{caster.slot}_ability_{self.id}_{modifier_type.name}"

            target.stat.add_modify(modifier_type, effect.value, source_id)

            # Timed buffs: register with battle's expiry system so _expire_buffs
            # removes the modifier after `duration` seconds each tick.
            if effect.duration > 0 and battle is not None:
                battle._track_buff(target, source_id, float(effect.duration))


def parse_ability(raw_data: dict, ability_id: int) -> Ability:
    """
    Parse raw ability data into Ability object.

    Args:
        raw_data: Raw ability dict from abilities.json
        ability_id: The ability ID

    Returns:
        Parsed Ability instance
    """
    # Parse trigger
    trigger_str = raw_data.get("er", "entry")
    try:
        trigger = AbilityTrigger(trigger_str)
    except ValueError:
        trigger = AbilityTrigger.ENTRY

    target_selector = raw_data.get("ts", "self_ime")
    target_type, target_count, target_filter = parse_target_selector(target_selector)

    # Parse effects
    effect_str = raw_data.get("de", "")
    effects = parse_effects(effect_str)

    # Parse monster needs (mns) - required cards in party
    mns_type, mns_card_ids = parse_monster_needs(raw_data.get("mns", ""))

    return Ability(
        id=ability_id,
        trigger=trigger,
        target_selector=target_selector,
        effects=effects,
        unlock_level=raw_data.get("ul", 1),
        is_overlay=raw_data.get("o", False),
        target_type=target_type,
        target_count=target_count,
        target_filter=target_filter,
        mns_type=mns_type,
        mns_card_ids=mns_card_ids,
    )


def parse_monster_needs(mns: str) -> tuple[Optional[str], List[int]]:
    """
    Parse monster needs (mns) field.

    Format: "AND(268)" or "OR(1,2,3)" or empty string
    AND = all listed cards required
    OR = any one of the listed cards required

    Returns:
        Tuple of (type, card_ids) where type is "AND", "OR", or None
    """
    if not mns:
        return None, []

    # Try OR format first (e.g., "OR(73,114,172)")
    match = re.search(r"OR\(([\d,]+)\)", mns)
    if match:
        card_ids = [int(cid.strip()) for cid in match.group(1).split(",")]
        return "OR", card_ids

    # Try AND format (e.g., "AND(268)")
    match = re.search(r"AND\(([\d,]+)\)", mns)
    if match:
        card_ids = [int(cid.strip()) for cid in match.group(1).split(",")]
        return "AND", card_ids

    return None, []


def parse_target_selector(selector: str) -> tuple[str, int, Optional[str]]:
    """
    Parse target selector string matching TargetStragetyData$$parse.

    Types:
    - self: Allies side
    - self_ime: Immediate self only
    - enemy: Enemy side
    - current_target: The unit being attacked/skilled
    - none: Inherit targets from trigger event
    """
    if not selector:
        return "self", 1, None

    if selector == "self_ime":
        return "self_ime", 1, None
    if selector == "current_target":
        return "current_target", 1, None
    if selector == "none":
        return "none", 1, None

    parts = selector.split(";")
    target_type = parts[0] if parts else "self"

    target_count = 1
    filter_parts: list[str] = []

    for part in parts[1:]:
        if part.startswith("count<"):
            match = re.search(r"count<(\d+)>", part)
            if match:
                target_count = int(match.group(1))
        else:
            # Everything else (type, prof, max_atk, min_hp) is a filter
            filter_parts.append(part)

    target_filter = ";".join(filter_parts) if filter_parts else None
    return target_type, target_count, target_filter


def parse_effects(effect_str: str) -> List[AbilityEffect]:
    """
    Parse effect string into list of AbilityEffect.

    Examples:
        "CHIT<15.00%,0%>" → [AbilityEffect(CHIT, 15.0, 0.0)]
        "HPP_IN<0.00%,10.00%>;SHIELD<90.00%,0%>" → conditional + shield
        "ATK<5.00%,0%>" → damage modifier
        "HIT<40.00%,0%>;BURN<15.00%,0%,5>" → 40% chance to apply burn
        "STUN<5>;HIT<15.00%,0.43%>" → stun with 15% + 0.43%/level proc rate
    """
    if not effect_str or effect_str == "none":
        return []

    effects = []
    parts = effect_str.split(";")

    # Track conditional state (HPP_IN/OUT sets condition for next effect)
    pending_condition: Optional[tuple[EffectType, float]] = None
    # Track HIT for linking to debuffs
    pending_hit: Optional[tuple[float, float]] = None  # (proc_rate, proc_scale)

    # Debuff types that can have HIT applied (CC and DoT effects)
    debuff_types = {
        EffectType.STUN,
        EffectType.POISON,
        EffectType.BURN,
        EffectType.FROZEN,
        EffectType.SLEEP,
        EffectType.NUMB,
        EffectType.STONE,
        EffectType.SILENCE,
    }

    for part in parts:
        if "<" not in part:
            continue

        # Parse "TYPE<value,scale>"
        type_end = part.index("<")
        type_str = part[:type_end]
        values_str = part[type_end + 1 : -1]

        effect_type = EFFECT_TYPE_MAP.get(type_str, EffectType.UNKNOWN)

        # Parse values
        values = values_str.split(",")
        value = parse_percentage(values[0]) if values else 0.0
        scale = parse_percentage(values[1]) if len(values) > 1 else 0.0

        # Parse third parameter
        # HEAL/HEAL_DOT/BURN/POISON: third param = tick count
        # Stat buffs (CHIT, ATK, SPD, etc.): third param = duration in seconds
        ticks = 1
        duration = 0
        if len(values) > 2:
            try:
                third = int(float(values[2]))
            except (ValueError, IndexError):
                third = 0
            if effect_type in (
                EffectType.HEAL,
                EffectType.HEAL_DOT,
                EffectType.BURN,
                EffectType.POISON,
            ):
                ticks = third
            elif third > 0 and effect_type in EFFECT_TO_MODIFIER:
                # Stat buff with finite duration in seconds — track so we can skip it
                # at apply time. We have no expiry system for ability buffs, so applying
                # a temporary buff permanently would overstate the card. E.g. card 514's
                # CHIT<70%,4> lasts only 4 seconds out of a 300s benchmark window.
                duration = third

        # Handle conditional effects
        if effect_type in (EffectType.HPP_IN, EffectType.HPP_OUT, EffectType.COMBO_IN):
            # This sets a condition for the next effect
            # Store (condition_type_name, threshold)
            cond_name = {
                EffectType.HPP_IN: "hpp_in",
                EffectType.HPP_OUT: "hpp_out",
                EffectType.COMBO_IN: "combo_in",
            }[effect_type]
            pending_condition = (cond_name, scale if scale > 0 else value)
            continue

        # Handle HIT - sets proc rate for adjacent debuff
        if effect_type == EffectType.HIT:
            # Check if there's a previous debuff to apply this to
            if effects and effects[-1].effect_type in debuff_types:
                # Apply to previous debuff (e.g., "STUN<5>;HIT<15%,0.43%>")
                effects[-1].proc_rate = value
                effects[-1].proc_scale = scale
            else:
                # Save for next debuff (e.g., "HIT<40%,0%>;BURN<...>")
                pending_hit = (value, scale)
            continue

        # Create effect
        effect = AbilityEffect(
            effect_type=effect_type,
            value=value,
            scale=scale,
            ticks=ticks,
            duration=duration,
        )

        if pending_condition:
            effect.condition_type = pending_condition[
                0
            ]  # "hpp_in", "hpp_out", "combo_in"
            effect.condition_value = pending_condition[1]  # threshold
            pending_condition = None

        # Apply pending HIT to debuffs
        if pending_hit and effect_type in debuff_types:
            effect.proc_rate = pending_hit[0]
            effect.proc_scale = pending_hit[1]
            pending_hit = None

        effects.append(effect)

    return effects


def parse_percentage(s: str) -> float:
    """Parse percentage string to float (keeps 0-100 scale)."""
    s = s.strip()
    if s.endswith("%"):
        return float(s[:-1])
    return float(s)


class AbilityManager:
    """
    Manages abilities for a battle.

    Handles loading abilities for units and applying them at the correct times.
    """

    def __init__(self, force_conditionals: bool = False):
        """
        Initialize the AbilityManager.

        Args:
            force_conditionals: If True, bypass party member requirement checks (mns)
                               for all abilities. Used for baselining abilities without
                               requiring specific party compositions.
        """
        self._ability_cache: Dict[int, Ability] = {}
        self.force_conditionals = force_conditionals

    def load_abilities_for_unit(
        self, unit: MonsterComponent, ability_data: Dict[str, dict]
    ) -> None:
        """
        Load and attach abilities to a unit.

        Loads:
        1. Unit's own abilities from ability_ids
        2. Assist abilities from any assist bonds

        Args:
            unit: The MonsterComponent to load abilities for
            ability_data: Raw abilities from abilities.json
        """
        if unit.model is None:
            return

        unit.abilities = []

        # Load unit's own abilities
        for ability_id in unit.model.ability_ids:
            self._load_ability(unit, ability_id, ability_data, is_assist=False)

        # Load assist abilities from assist bonds
        for ability_id in unit.model.assist_ability_ids:
            self._load_ability(unit, ability_id, ability_data, is_assist=True)

    def _load_ability(
        self,
        unit: MonsterComponent,
        ability_id: int,
        ability_data: Dict[str, dict],
        is_assist: bool = False,
    ) -> None:
        """
        Load a single ability for a unit.

        Args:
            unit: The MonsterComponent to load ability for
            ability_id: The ability ID to load
            ability_data: Raw abilities from abilities.json
            is_assist: Whether this is an assist ability (for logging/debugging)
        """
        # Check cache first
        if ability_id in self._ability_cache:
            ability = self._ability_cache[ability_id]
        else:
            # Parse and cache
            raw = ability_data.get(str(ability_id))
            if raw:
                ability = parse_ability(raw, ability_id)
                self._ability_cache[ability_id] = ability
            else:
                return

        # Check if unit meets level requirement
        # For assist abilities, the recipient must meet the unlock level
        if unit.model and unit.model.level >= ability.unlock_level:
            # Give each unit its OWN copy — the cache shares one parsed Ability by
            # id, but Ability carries per-unit mutable state (setup_applied). Two
            # copies of the same card (e.g. active + helper Hikoboshi) must each
            # apply their own setup/LEVEL ability, not share one "already applied"
            # flag. Shallow copy is enough (effects list is read-only).
            unit.abilities.append(copy.copy(ability))

    def apply_setup_abilities(
        self,
        units: List[MonsterComponent],
        party_card_ids: Optional[List[int]] = None,
        is_leader_slot: bool = False,
        battle: Optional["Battle"] = None,
    ) -> None:
        """
        Phase 1.5: Apply permanent setup abilities (like LEVEL).
        These must be processed before any standard entry abilities because
        they permanently modify base stats used for targeting.
        """
        for unit in units:
            for ability in unit.abilities:
                if ability.is_entry_ability and not ability.setup_applied:
                    # Check if it has a LEVEL effect
                    has_level = any(
                        e.effect_type == EffectType.LEVEL for e in ability.effects
                    )
                    if has_level and ability.can_apply(
                        unit,
                        is_leader_slot,
                        party_card_ids=party_card_ids,
                        force_conditionals=self.force_conditionals,
                    ):
                        # Resolve targets and apply ONLY the level effects
                        targets = self._resolve_targets(ability, unit, units, battle)
                        for target in targets:
                            for effect in ability.effects:
                                if effect.effect_type == EffectType.LEVEL:
                                    ability._apply_level_bonus(
                                        target, int(effect.value)
                                    )

                        ability.setup_applied = True

    def apply_entry_abilities(
        self,
        unit: MonsterComponent,
        is_leader: bool = False,
        party_card_ids: Optional[List[int]] = None,
        party: Optional[List[MonsterComponent]] = None,
        battle: Optional["Battle"] = None,
    ) -> None:
        """Apply entry abilities during battle initialization."""
        for ability in unit.abilities:
            if ability.is_entry_ability and ability.can_apply(
                unit,
                is_leader,
                party_card_ids=party_card_ids,
                force_conditionals=self.force_conditionals,
            ):
                # Resolve targets based on ability's target selector
                targets = self._resolve_targets(ability, unit, party or [unit], battle)
                ability.apply(unit, targets, battle)

    def apply_wave_abilities(
        self,
        unit: MonsterComponent,
        is_last_wave: bool = False,
        wave_num: int = 0,
        party_card_ids: Optional[List[int]] = None,
        party: Optional[List[MonsterComponent]] = None,
        enemies: Optional[List[MonsterComponent]] = None,
        battle: Optional["Battle"] = None,
    ) -> None:
        """
        Apply wave transition abilities.

        Args:
            unit: The unit whose abilities to apply
            is_last_wave: Whether this is the final wave
            wave_num: Current wave number (0-indexed) for stacking buffs
            party_card_ids: List of card IDs in the party
            party: List of party members
            enemies: List of enemies
            battle: The battle instance
        """
        for ability in unit.abilities:
            if ability.is_wave_ability and ability.can_apply(
                unit,
                is_last_wave=is_last_wave,
                party_card_ids=party_card_ids,
                force_conditionals=self.force_conditionals,
            ):
                # Resolve targets - enemy abilities need enemy list
                if ability.target_type == "enemy" and enemies:
                    targets = self._resolve_targets(ability, unit, enemies, battle)
                elif party:
                    targets = self._resolve_targets(ability, unit, party, battle)
                else:
                    targets = [unit]
                # Pass wave_num to enable stacking for wave abilities
                ability.apply(unit, targets, battle, wave_num=wave_num)

    def apply_attack_abilities(
        self,
        unit: MonsterComponent,
        is_skill: bool,
        targets: List[MonsterComponent],
        battle: Optional["Battle"] = None,
        party_card_ids: Optional[List[int]] = None,
    ) -> None:
        """Apply attack-triggered abilities."""
        trigger = (
            AbilityTrigger.ATTACK_SKILL if is_skill else AbilityTrigger.ATTACK_NORMAL
        )

        for ability in unit.abilities:
            if ability.trigger == trigger and ability.can_apply(
                unit,
                party_card_ids=party_card_ids,
                force_conditionals=self.force_conditionals,
            ):
                # Determine actual targets based on ability's target selector
                actual_targets = self._resolve_targets(ability, unit, targets, battle)
                ability.apply(unit, actual_targets, battle)

    def apply_reserve_abilities(
        self,
        reserve_unit: MonsterComponent,
        party_card_ids: Optional[List[int]] = None,
        party: Optional[List[MonsterComponent]] = None,
        battle: Optional["Battle"] = None,
    ) -> None:
        """
        Apply entry abilities from a reserve card to the main team.

        Reserve cards:
        - Contribute their passive abilities to the main team
        - Do NOT participate in combat themselves
        - Their abilities target main team members (party), not themselves

        Note: Reserve cards are never leaders, so entry_leader abilities don't apply.
        Wave abilities are handled separately via apply_reserve_wave_abilities().
        """
        for ability in reserve_unit.abilities:
            # Only apply entry abilities from reserve
            # Reserve cards don't trigger attack abilities (they don't attack)
            # Wave abilities are handled separately via apply_reserve_wave_abilities()
            if ability.is_entry_ability and ability.can_apply(
                reserve_unit,
                is_leader=False,  # Reserve cards are never leaders
                party_card_ids=party_card_ids,
                force_conditionals=self.force_conditionals,
            ):
                # Resolve targets - abilities target the main team
                # Use the reserve unit as the "source" but targets are main team
                targets = self._resolve_targets(
                    ability, reserve_unit, party or [], battle
                )

                # Apply ability to each target
                ability.apply(reserve_unit, targets, battle)

    def _resolve_targets(
        self,
        ability: Ability,
        caster: MonsterComponent,
        default_targets: List[MonsterComponent],
        battle: Optional["Battle"] = None,
    ) -> List[MonsterComponent]:
        """
        Resolve ability targets based on target selector matching TargetStragetyData.
        """
        if ability.target_type == "self_ime":
            return [caster]

        if ability.target_type == "current_target":
            # Target the unit currently being acted upon (enemy being attacked)
            return [default_targets[0]] if default_targets else []

        if ability.target_type == "none":
            # Inherit targets from the trigger event (the skill/attack targets)
            return [t for t in default_targets if t.is_alive]

        # Standard side-based targeting
        if ability.target_type == "self":
            # Target allies side
            candidates = [
                t for t in (battle.players if battle else default_targets) if t.is_alive
            ]
        else:
            # Target enemies side
            candidates = [
                t for t in (battle.enemies if battle else default_targets) if t.is_alive
            ]

        # Apply filter if present
        if ability.target_filter:
            candidates = self._apply_target_filter(
                candidates, ability.target_filter, caster
            )

        # Apply count limit
        return candidates[: ability.target_count]

    def _apply_target_filter(
        self,
        candidates: List[MonsterComponent],
        filter_str: str,
        caster: MonsterComponent,
    ) -> List[MonsterComponent]:
        """
        Apply target filter to candidate list.

        Filter meanings:
        - type<N>: Attribute (1=Divina, 2=Phantasma, 3=Anima, 4=Neutral)
        - prof<N>: Unit type (1=Melee, 2=Ranged, 3=Healer, 4=Assist)
        - max_atk: Sort by highest ATK
        - min_hp/min_hpp: Sort by lowest HP / HP%
        - max_hp: Sort by highest HP
        """
        import re

        # Attribute filter: type<N>
        type_match = re.search(r"type<(\d+)>", filter_str)
        if type_match:
            attr_id = int(type_match.group(1))
            candidates = [
                t for t in candidates if t.model and t.model.attribute == attr_id
            ]

        # Unit type filter: prof<N> or prof<N,M,...>
        prof_match = re.search(r"prof<([\d,]+)>", filter_str)
        if prof_match:
            type_ids = [int(x) for x in prof_match.group(1).split(",")]
            candidates = [
                t for t in candidates if t.model and t.model.unit_type in type_ids
            ]

        # Priority targeting
        if "max_atk" in filter_str:
            # Sort on the POST-SETUP ATK value: base_atk (level scaling, limit
            # breaks, and Phase 1.5 LEVEL abilities, which write straight into
            # stat.base_atk) scaled by the Attack-bond contribution.
            #
            # Both inputs are fixed before the first action and never change in
            # combat, so max_atk ordering is stable for the whole wave and can be
            # steered deliberately -- Attack bonds are the lever for deciding who
            # receives a ranked buff such as Orihime's +125% to the top 2 ATK.
            #
            # normal_dmg_modifier is safe to include precisely BECAUSE nothing in
            # combat writes to it: NORM_ATK has zero ability and skill sources in
            # the entire game, so its only contributors are _apply_bonds and
            # _apply_special_effect, both of which run during setup.
            #
            # Corrected 2026-08-07: this previously scaled by damage_modifier,
            # which carries TEMPORARY combat buffs (Orihime's own 8s +125% ATK
            # from her skill), so the ordering churned mid-battle and targets
            # could not be planned.
            # ATK/HP are fully resolved BEFORE the battle starts, so target
            # selection must read the post-setup value, not a mid-battle one.
            def _post_setup_atk(t: MonsterComponent) -> float:
                if t.stat is None:
                    return 0.0
                return t.stat.base_atk * t.stat.normal_dmg_modifier.get_modifier_total()

            candidates = sorted(candidates, key=_post_setup_atk, reverse=True)
        elif "min_hpp" in filter_str:
            # min_hpp = lowest HP percentage
            candidates = sorted(
                candidates,
                key=lambda t: (t.stat.current_hp / t.stat.base_hp if t.stat else 1),
            )
        elif "min_hp" in filter_str:
            # min_hp = lowest absolute current HP
            candidates = sorted(
                candidates,
                key=lambda t: t.stat.current_hp if t.stat else float("inf"),
            )
        elif "max_hp" in filter_str:
            candidates = sorted(
                candidates,
                key=lambda t: t.stat.current_hp if t.stat else 0,
                reverse=True,
            )

        return candidates
