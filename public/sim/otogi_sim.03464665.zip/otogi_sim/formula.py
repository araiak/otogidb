"""
Otogi Battle Damage and Timing Formulas

This module implements the damage and attack timing formulas with clearly marked
assumptions and validation status.

Observed in game (2025-12-18):
- Base damage = ATK x 1.0
- Display ATK = Internal ATK x 10
- Normal crit = 2x multiplier
- Modifiers stack ADDITIVELY (not multiplicatively)
- Shield cap = 85% max reduction

DISPROVEN (2026-01-16):
- Combo bonuses: COSMETIC ONLY - combo counter does NOT affect damage
  (constants exist but are never accessed at runtime)

Observed in game (2025-12-24):
- LB Exceed formula: Random(0, ExceedRate × LB_level), rounded to 0.1
  - Applied as: damage × (1.0 + exceed_percent / 100.0)
- Super crit = 4x multiplier (present in game data but its rate is 0, so unreachable)
- Team race bonus: LeaderBonus + MemberBonus×same_race_members + AssistBonus×same_race_assists
- Defense/Shield modifiers stack ADDITIVELY via StatModifiers
- Damage clamped to a minimum of 1.0, and to a per-hit maximum
- Crit chance is capped
- Attack interval = (speed_stat + 750) / 900 (V17) - INVERTED from typical conventions!
  - Higher speed_stat = LONGER interval = SLOWER attacks
  - Melee/Ranged: 1300 -> 2.28s, Healer: 2300 -> 3.39s
  - Speed buffs are HALVED: +30% buff -> 15% faster (shorter interval)
  - Speed debuffs apply at full value (longer interval)
  - Speed modifiers capped at +/-100%
- Initial attack stagger: attackSpeed - Random(1.0, 2.0) (V19)
- Timer-based attack system: nextAttackTime += DeltaTime (V19)

Observed in game (2025-12-25, re-confirmed 2026-01-09):
- Defense uses LINEAR formula: damage * (1 - defense%), same as Shield
  - defense and shield resolve through the same modifier machinery
  - Both apply: damage * (1 + total_mod) where total_mod is negative
  - Flat debuffs (e.g., -1746 DEF) translate to damage amplification: damage * (1 - (-0.1746))
  - Modifier stacking is ADDITIVE: FinalValue = Base * (1 + Sum(percent)/100) + Sum(flat)

ASSUMPTIONS (marked with [ASSUMPTION:X]):
- [ASSUMPTION:CAP] Normal cap = 99999, Skill cap = 999999

Observed in game (2026-01-15):
- ATK buff % cap: NONE in PvE (capped by PVPBuffTopData in PvP only)
- Crit DMG buff % cap: NONE in PvE (capped by PVPBuffTopData in PvP only)
- Skill DMG buff % cap: NONE in PvE (capped by PVPBuffTopData in PvP only)
- Normal DMG buff % cap: NONE in PvE (capped by PVPBuffTopData in PvP only)
- PVPBuffTopData value: UNKNOWN (not present in server config; never observed in play)
- Realistic achievable: ~200% ATK buff, ~200% Crit DMG buff with stacked team abilities
"""

from typing import Optional
from .models import DamageResult, CritType, ActionType

# =============================================================================
# Constants from the game's own constants.json, cross-checked against play
# =============================================================================

# COMBO_BONUS removed (2026-01-16) - DISPROVEN
# Combo counter is purely cosmetic and does NOT affect damage.
# The combo_effect_* constants exist in constants.json but are NEVER accessed.
# Previous "+30%" observations were actually Divina race bonus, not combo.

CRIT_MULTIPLIERS = {
    CritType.NONE: 1.0,
    CritType.NORMAL: 2.0,  # observed in game
    CritType.SUPER: 4.0,  # exists in game data but its rate is 0, so never rolls
}

# Shield limits from constants.json
SHIELD_MAX = 0.85  # shield_max
SHIELD_MIN = -0.75  # shield_min (damage amplification)


# =============================================================================
# LIMIT BREAK (EXCEED) MULTIPLIERS
# =============================================================================

# Observed in game (2025-12-24, CalculateExceedValue):
#   exceed_random = Random(0, ExceedRate × LB_level)
#   exceed_percent = floor(exceed_random × 10) / 10   // Round to 0.1
#   damage = base_damage × (1.0 + exceed_percent / 100.0)
#
# Constant: dmg_limitBreak_up = 0.05 (5% per LB level)
# Formula: Random(0, 5% × LB_level) → 1.00 to 1.XX multiplier
#
# Note: in-game observation observed higher values (LB1: 1.26-1.51x) but likely included
# other modifiers. Using confirmed in game formula for accuracy.

EXCEED_MULT = {
    0: {"min": 1.00, "max": 1.00, "avg": 1.000},  # No LB bonus (0%)
    1: {"min": 1.00, "max": 1.05, "avg": 1.025},  # Random(0, 5%)
    2: {"min": 1.00, "max": 1.10, "avg": 1.050},  # Random(0, 10%)
    3: {"min": 1.00, "max": 1.15, "avg": 1.075},  # Random(0, 15%)
    4: {"min": 1.00, "max": 1.20, "avg": 1.100},  # MLB max - Random(0, 20%)
}

MAX_LB_LEVEL = 4  # Max achievable limit break level (5★ cards)


# =============================================================================
# DAMAGE CAPS
# =============================================================================

DAMAGE_CAPS = {
    "normal": 99999,  # max_player_normal_atk - [ASSUMPTION:CAP]
    "skill": 999999,  # max_player_skill_atk - [ASSUMPTION:CAP]
}


# =============================================================================
# STAT CAPS (Validated 2026-01-15)
# =============================================================================

STAT_CAPS = {
    # Validated - have caps (PvE and PvP)
    "crit_rate": 1.0,  # 100% cap from chit_max constant
    "speed_pct": 1.0,  # Speed modifiers observed to cap at +/-100%
    "shield": 0.85,  # 85% max from shield_max constant
    "shield_min": -0.75,  # -75% min (damage amp) from shield_min constant
    # Validated - NO CAPS in PvE (capped by PVPBuffTopData in PvP only)
    "attack_pct": None,  # No cap in PvE - ~200% achievable
    "crit_dmg_pct": None,  # No cap in PvE - ~200% achievable
    "skill_dmg_pct": None,  # No cap in PvE
    "normal_dmg_pct": None,  # No cap in PvE
    # PvP-specific cap (applies to all buff %s above)
    "pvp_buff_top": None,  # never observed in play; PvP is not simulated
}


# =============================================================================
# ATTACK TIMING - Observed in game (2026-01-06)
# =============================================================================
# Measured in play: re-confirmed against live attack timings 2026-08-25.
#
# IMPORTANT: The "speed" stat is INVERTED from typical game conventions!
# Higher speed_stat = LONGER interval = SLOWER attacks
# It's really an "attack interval base" not a "speed" stat.

# Attack interval formula constants (validated 2026-01-06 via world boss test)
# Formula: interval = (speed_stat + ATTACK_INTERVAL_OFFSET) / ATTACK_INTERVAL_DIVISOR
# Validated with 52 attack samples, <2% error
ATTACK_INTERVAL_OFFSET = 750
ATTACK_INTERVAL_DIVISOR = 900

# Speed stat values by unit type (from game config)
# Note: Higher value = SLOWER attacks (longer intervals)
SPEED_STATS = {
    "Melee": 1300,  # (1300+750)/900 = 2.28s interval (fastest)
    "Ranged": 1300,  # (1300+750)/900 = 2.28s interval (fastest)
    "Healer": 2300,  # (2300+750)/900 = 3.39s interval (slowest)
}

# Initial attack stagger range (seconds)
# From ResetInitAttack: nextAttackTime = attackSpeed - Random(1.0, 2.0)
INITIAL_ATTACK_STAGGER = (1.0, 2.0)


# =============================================================================
# DAMAGE CALCULATION
# =============================================================================


def calculate_damage(
    atk: int,
    lb_level: int = 0,
    is_skill: bool = False,
    skill_base_damage: Optional[int] = None,
    crit_type: CritType = CritType.NONE,
    damage_mod: float = 0.0,
    skill_mod: float = 0.0,
    normal_mod: float = 0.0,
    crit_dmg_mod: float = 0.0,
    defense_flat: float = 0.0,
    shield_mod: float = 0.0,
    exceed_actual: Optional[float] = None,
    use_exceed_avg: bool = True,
) -> DamageResult:
    """
    Calculate damage using the validated formula.

    NOTE: Combo parameter removed (2026-01-16) - combo is purely cosmetic
    and does NOT affect damage calculations.

    Args:
        atk: Internal ATK value (display ATK / 10)
        lb_level: Limit break level (0-4, max MLB)
        is_skill: True if this is a skill attack
        skill_base_damage: Pre-calculated skill damage (slv1 + level * slvup)
        crit_type: CritType enum (NONE, NORMAL, SUPER)
        damage_mod: General damage modifier (e.g., 0.17 for +17%)
        skill_mod: Skill damage modifier (only for skills)
        normal_mod: Normal attack modifier (only for normals)
        crit_dmg_mod: Critical damage modifier (only on crit)
        defense_flat: Target's defense in raw damage points, subtracted from
            the hit (e.g. 500.0 removes 500 damage). NOT a percentage: the
            same defense costs a big hit and a small hit the same points.
        shield_mod: Target's shield modifier (0.0 to 0.85)
        exceed_actual: Override exceed multiplier (from in-game capture)
        use_exceed_avg: Use average LB multiplier (True) or minimum (False)

    Returns:
        DamageResult with full breakdown and assumption tracking
    """
    result = DamageResult()

    # =========================================================================
    # STEP 1: Base Damage
    # =========================================================================
    # For skills, skill_base_damage is the raw damage from skill description
    # (slv1 + slvup*(level-1) = displayed damage value)

    if is_skill and skill_base_damage is not None:
        result.base_damage = float(skill_base_damage)
    else:
        result.base_damage = float(atk) * 1.0

    # =========================================================================
    # STEP 2: Exceed (Limit Break) Bonus
    # =========================================================================
    # LB units get a damage multiplier with random variance

    if exceed_actual is not None:
        # Use actual value from in-game capture for exact replay
        result.exceed_mult = exceed_actual
    elif lb_level > 0:
        # Look up LB multiplier (confirmed in game: 5% per LB level)
        lb_data = EXCEED_MULT.get(lb_level, EXCEED_MULT[MAX_LB_LEVEL])
        result.exceed_mult = lb_data["avg"] if use_exceed_avg else lb_data["min"]
    else:
        result.exceed_mult = 1.0

    result.after_exceed = result.base_damage * result.exceed_mult

    # =========================================================================
    # STEP 3: Combo Bonus - REMOVED (2026-01-16)
    # =========================================================================
    # DISPROVEN: Combo is purely cosmetic and does NOT affect damage.
    # The combo_effect_* constants exist but are never accessed at runtime.
    # Previous "+30%" observations were actually Divina race bonus.
    result.combo_mult = 1.0  # Always 1.0 - combo has no effect
    result.after_combo = result.after_exceed

    # =========================================================================
    # STEP 4: Damage Modifiers (Additive WITHIN a category, MULTIPLICATIVE ACROSS)
    # =========================================================================
    # The general damage bucket and the skill/normal buckets are SEPARATE
    # modifier instances. Each one independently applies
    # `base * (1 + addSum/100) + flatSum` (the game's own stat-modifier order),
    # and the damage pipeline calls them in sequence on the
    # running damage value. So percentages stack additively inside one instance
    # and the instances compound.
    #
    # Corrected 2026-08-07: this previously summed damage_mod + type_mod into a
    # single bucket, which understated any build stacking both ATK% and
    # SKILL_ATK%/NORM_ATK% (e.g. +100%/+150% gave 3.5x instead of 5.0x).
    # See the stacking note on StatModifiers in lifecycle.py.

    type_mod = skill_mod if is_skill else normal_mod

    # Apply stat cap if defined [PLACEHOLDER:ATTACK_CAP] - per instance, since
    # each modifier instance clamps its own percentage sum independently.
    if STAT_CAPS["attack_pct"] is not None:
        damage_mod = min(damage_mod, STAT_CAPS["attack_pct"])
        type_mod = min(type_mod, STAT_CAPS["attack_pct"])

    result.modifier_mult = (1.0 + damage_mod) * (1.0 + type_mod)
    result.after_modifiers = result.after_combo * result.modifier_mult

    # =========================================================================
    # STEP 5: Critical Hit Multiplier
    # =========================================================================
    # Validated: Normal crit = 2x
    # [ASSUMPTION:SUPER_CRIT]: Super crit = 4x

    result.crit_mult = CRIT_MULTIPLIERS.get(crit_type, 1.0)

    if crit_type == CritType.SUPER:
        result.add_assumption("ASSUMPTION:SUPER_CRIT")

    # Apply crit damage modifier (only on crit)
    if crit_type != CritType.NONE:
        # Apply stat cap if defined [PLACEHOLDER:CRIT_DMG_CAP]
        effective_crit_dmg = crit_dmg_mod
        if STAT_CAPS["crit_dmg_pct"] is not None:
            effective_crit_dmg = min(effective_crit_dmg, STAT_CAPS["crit_dmg_pct"])

        result.crit_dmg_mult = 1.0 + effective_crit_dmg
        total_crit_mult = result.crit_mult * result.crit_dmg_mult
    else:
        result.crit_dmg_mult = 1.0
        total_crit_mult = result.crit_mult

    result.after_crit = result.after_modifiers * total_crit_mult

    # =========================================================================
    # STEP 6: Defense (FLAT SUBTRACTION, and the game applies it LAST)
    # =========================================================================
    # This was long believed to be a linear percentage. It is not, and the belief
    # rested on inference rather than on any observed number.
    #
    # Measured in play 2026-08-25 (n=207 world-boss hits): a hit went in at
    # 4024.663 and came out at 3524.663 -- exactly -500 -- and across the whole run
    # the only distinct (input - output) values were {500.0, 0.0} and nothing else.
    # A percentage would produce a spread across the damage range; a flat cost does
    # not. This is the strongest evidence tier in the package: an observed number
    # reproduced, not a formula assumed.
    #
    # NOTE: this function still applies defense BEFORE shield, whereas the game does
    # shield then defense. That was harmless while both were multiplicative; now that
    # defense is flat it is NOT commutative. battle.py -- the path that actually
    # drives the tier lists -- has the correct order. formula.py is used only by
    # tests and the capture-replay harness.
    result.defense_flat = defense_flat
    result.after_defense = result.after_crit - defense_flat
    result.defense_mult = (
        (result.after_defense / result.after_crit) if result.after_crit else 1.0
    )

    # =========================================================================
    # STEP 7: Shield (Damage Reduction)
    # =========================================================================
    # Shield is clamped between SHIELD_MIN and SHIELD_MAX

    clamped_shield = max(SHIELD_MIN, min(SHIELD_MAX, shield_mod))
    result.shield_mult = 1.0 - clamped_shield
    result.after_shield = result.after_defense * result.shield_mult

    # =========================================================================
    # STEP 8: Apply Damage Cap
    # =========================================================================
    # [ASSUMPTION:CAP]: Normal = 99999, Skill = 999999

    cap_key = "skill" if is_skill else "normal"
    damage_cap = DAMAGE_CAPS[cap_key]

    if result.after_shield > damage_cap:
        result.final_damage = damage_cap
        result.was_capped = True
        result.cap_applied = damage_cap
        result.add_assumption("ASSUMPTION:CAP")
    else:
        result.final_damage = int(result.after_shield)
        result.was_capped = False

    return result


def calculate_skill_base_damage(slv1: int, slvup: int, card_level: int) -> int:
    """
    Calculate skill base damage from skill data.

    Formula: slv1 + (cardLevel - 1) * slvup

    Status: Partially validated (1 data point)

    Args:
        slv1: Base skill damage at level 1
        slvup: Damage increase per level
        card_level: Card level (1-90)

    Returns:
        Calculated skill base damage
    """
    return slv1 + (card_level - 1) * slvup


def get_combo_bonus(combo: int) -> float:
    """
    Get combo bonus percentage for given combo count.

    DEPRECATED (2026-01-16): Combo is purely cosmetic and has NO effect on damage.
    This function always returns 0.0. Kept for backwards compatibility.
    """
    return 0.0


def get_exceed_mult(lb_level: int, use_avg: bool = True) -> float:
    """
    Get exceed multiplier for given LB level.

    Args:
        lb_level: Limit break level (0-4, max MLB)
        use_avg: Use average (True) or minimum (False)

    Returns:
        Exceed damage multiplier
    """
    lb_data = EXCEED_MULT.get(lb_level, EXCEED_MULT[MAX_LB_LEVEL])
    return lb_data["avg"] if use_avg else lb_data["min"]


# =============================================================================
# INTEGRATION WITH LIFECYCLE CLASSES
# =============================================================================


def calculate_damage_from_component(
    attacker: "MonsterComponent",
    target: "MonsterComponent",
    is_skill: bool = False,
    skill_base_damage: Optional[int] = None,
    crit_type: CritType = CritType.NONE,
) -> DamageResult:
    """
    Calculate damage using MonsterComponent stats.

    This is a convenience wrapper that extracts stats from lifecycle classes
    and calls the main calculate_damage function.

    NOTE: Combo parameter removed (2026-01-16) - combo is purely cosmetic.

    Args:
        attacker: Attacking MonsterComponent
        target: Target MonsterComponent
        is_skill: Whether this is a skill attack
        skill_base_damage: Pre-calculated skill damage (if skill)
        crit_type: The crit roll result

    Returns:
        DamageResult with full breakdown
    """
    # Import here to avoid circular imports
    from .lifecycle import MonsterComponent

    if attacker.stat is None or target.stat is None:
        return DamageResult()

    # Extract stats from MonsterComponent
    atk = attacker.stat.base_atk
    lb_level = attacker.model.lb_level if attacker.model else 0

    # Get modifier totals (convert from multiplier back to percentage)
    damage_mod = attacker.stat.damage_modifier.get_modifier_total() - 1.0
    skill_mod = attacker.stat.skill_dmg_modifier.get_modifier_total() - 1.0
    normal_mod = attacker.stat.normal_dmg_modifier.get_modifier_total() - 1.0
    crit_dmg_mod = attacker.stat.crit_dmg_modifier.get_modifier_total() - 1.0
    # Defense is a FLAT subtraction, so take the raw points -- not
    # get_modifier_total() - 1.0, which yields a RATIO (500 defense -> 5.0) and
    # under-subtracts by 100x. battle.py reads the same field this way.
    defense_flat = target.stat.defense_modifier.get_percentage_sum()
    shield_mod = target.stat.final_shield

    return calculate_damage(
        atk=atk,
        lb_level=lb_level,
        is_skill=is_skill,
        skill_base_damage=skill_base_damage,
        crit_type=crit_type,
        damage_mod=damage_mod,
        skill_mod=skill_mod,
        normal_mod=normal_mod,
        crit_dmg_mod=crit_dmg_mod,
        defense_flat=defense_flat,
        shield_mod=shield_mod,
        use_exceed_avg=False,  # Use random for simulation
    )


def format_formula() -> str:
    """Return a human-readable description of the damage formula."""
    return """
OTOGI DAMAGE FORMULA (Updated 2026-01-16)
============================================

Base Formula:
    damage = ATK x 1.0

Full Formula (7 steps):
    1. baseDamage = ATK x 1.0
    2. exceedDamage = baseDamage x exceedMult        // LB bonus: 1.00-1.20x for LB0-4 (MLB)
    3. modDamage = exceedDamage x (1 + modifiers)    // Additive stacking
    4. critDamage = modDamage x critMult x critDmgMult  // 2x crit (4x disabled)
    5. defenseDamage = critDamage x (1 - defenseMod) // Linear (same as shield)
    6. shieldDamage = defenseDamage x (1 - shieldMod) // Linear reduction
    7. finalDamage = clamp(shieldDamage, 1, cap)

Validation Status:
- [OBSERVED] Base damage = ATK x 1.0
- [OBSERVED] LB Exceed: Random(0, 5% x LB_level), avg 1.025-1.125x for LB1-5
- [DISPROVEN] Combo: COSMETIC ONLY - combo counter does NOT affect damage
- [OBSERVED] Modifiers stack additively (damage%, skill%, normal%)
- [OBSERVED] Normal crit = 2x, Super crit = 4x (disabled, rate=0)
- [OBSERVED] Defense: damage x (1 - defense%), same pattern as shield
- [OBSERVED] Shield: damage x (1 - shield%), capped at 85%

Key Notes:
- Display ATK = Internal ATK x 10
- Normal attack cap: 99,999
- Skill attack cap: 999,999
- Speed stat is INVERTED: higher = slower attacks
- Combo counter is purely cosmetic UI
""".strip()
