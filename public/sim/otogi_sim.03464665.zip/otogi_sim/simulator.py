"""
Otogi Battle Simulator Engine

Main simulation engine that processes battle captures and calculates
predicted damage using validated formulas.
"""

import json
from pathlib import Path
from typing import List, Dict, Optional, Tuple

from .models import (
    Unit,
    Action,
    DamageResult,
    BattleCapture,
    WaveInfo,
    ActionType,
    CritType,
    Modifiers,
)
from .formula import calculate_damage, calculate_skill_base_damage


class BattleSimulator:
    """
    Simulates battle damage calculations.

    Loads game data (skills, abilities) and uses validated formulas
    to predict damage for comparison with actual results.
    """

    def __init__(
        self,
        skills_data: Optional[Dict] = None,
        abilities_data: Optional[Dict] = None,
        constants_data: Optional[Dict] = None,
    ):
        """
        Initialize simulator with game data.

        Args:
            skills_data: Skill definitions from skills.json
            abilities_data: Ability definitions from abilities.json
            constants_data: Game constants from constants.json
        """
        self.skills = skills_data or {}
        self.abilities = abilities_data or {}
        self.constants = constants_data or {}

    @classmethod
    def from_data_dir(cls, data_dir: Path) -> "BattleSimulator":
        """
        Load simulator with data from output/data directory.

        Args:
            data_dir: Path to output/data directory

        Returns:
            Initialized BattleSimulator
        """
        skills = {}
        abilities = {}
        constants = {}

        skills_path = data_dir / "skills.json"
        abilities_path = data_dir / "abilities.json"
        constants_path = data_dir / "constants.json"

        if skills_path.exists():
            with open(skills_path, encoding="utf-8") as f:
                data = json.load(f)
                skills = data.get("skills", data)

        if abilities_path.exists():
            with open(abilities_path, encoding="utf-8") as f:
                data = json.load(f)
                abilities = data.get("abilities", data)

        if constants_path.exists():
            with open(constants_path, encoding="utf-8") as f:
                constants = json.load(f)

        return cls(skills, abilities, constants)

    def get_skill_data(self, skill_id: str) -> Optional[Dict]:
        """Look up skill by ID."""
        return self.skills.get(skill_id)

    def calculate_skill_damage(
        self,
        skill_id: str,
        card_level: int,
    ) -> Optional[int]:
        """
        Calculate skill base damage for a card.

        Args:
            skill_id: Skill ID
            card_level: Card level (affects scaling)

        Returns:
            Calculated skill base damage, or None if skill not found
        """
        skill = self.get_skill_data(skill_id)
        if not skill:
            return None

        slv1 = skill.get("slv1", 0)
        slvup = skill.get("slvup", 0)

        if slv1 == 0:
            return None

        return calculate_skill_base_damage(slv1, slvup, card_level)

    def simulate_action(
        self,
        action: Action,
        attacker: Unit,
        target: Optional[Unit] = None,
    ) -> DamageResult:
        """
        Simulate a single action and return calculated damage.

        Args:
            action: The action to simulate
            attacker: Attacking unit
            target: Target unit (for shield mod)

        Returns:
            DamageResult with full breakdown
        """
        # Determine if skill and get skill base damage
        is_skill = action.action_type == ActionType.SKILL
        skill_base_damage = None

        if is_skill and attacker.skill_id:
            skill_base_damage = self.calculate_skill_damage(
                attacker.skill_id, attacker.card_level
            )

        # Get target shield modifier
        target_shield = 0.0
        if target:
            target_shield = target.modifiers.shield
        elif action.target_shield:
            target_shield = action.target_shield

        result = calculate_damage(
            atk=attacker.internal_atk,
            lb_level=attacker.lb_level,
            # combo removed 2026-01-16: combo is cosmetic and does not affect damage.
            # Passing it here raised TypeError, so this replay path was dead.
            is_skill=is_skill,
            skill_base_damage=skill_base_damage,
            crit_type=action.crit_type,
            damage_mod=attacker.modifiers.damage,
            skill_mod=attacker.modifiers.skill if is_skill else 0.0,
            normal_mod=attacker.modifiers.normal if not is_skill else 0.0,
            crit_dmg_mod=attacker.modifiers.crit_dmg,
            shield_mod=target_shield,
            exceed_actual=(
                action.exceed_damage / attacker.internal_atk
                if action.exceed_damage and attacker.internal_atk > 0
                else None
            ),
        )

        return result

    def simulate_battle(
        self,
        capture: BattleCapture,
    ) -> List[Tuple[Action, DamageResult]]:
        """
        Simulate all actions in a battle capture.

        Args:
            capture: Battle capture data from in-game observation hook

        Returns:
            List of (action, predicted_result) tuples
        """
        results = []

        # Build unit lookup by slot
        units = {}
        for unit in capture.player_units:
            units[unit.slot] = unit
        for unit in capture.enemy_units:
            units[unit.slot] = unit

        for action in capture.actions:
            attacker = units.get(action.attacker_slot)
            target = units.get(action.target_slot) if action.target_slot else None

            if not attacker:
                # Try to create a minimal attacker from action data
                if action.attacker_atk > 0:
                    attacker = Unit(
                        slot=action.attacker_slot,
                        internal_atk=action.attacker_atk,
                        hp=0,
                        lb_level=action.attacker_lb,
                        modifiers=action.attacker_mods,
                    )
                else:
                    # Skip action if we can't determine attacker
                    continue

            result = self.simulate_action(action, attacker, target)
            results.append((action, result))

        return results


def parse_battle_capture(data: Dict) -> BattleCapture:
    """
    Parse JSON export from in-game observation hook into BattleCapture.

    Handles both the current exportJSON() format (v1.0) and the enhanced
    exportForSimulator() format (v2.0 from battle_daemon).

    Args:
        data: JSON data from in-game observation hook

    Returns:
        Parsed BattleCapture
    """
    capture = BattleCapture()

    # Parse metadata
    if "meta" in data:
        capture.version = data["meta"].get("version", "1.0")
        capture.capture_time = data["meta"].get("capture_time", "")
        capture.duration_ms = data["meta"].get("duration_ms", 0)

        # v2.0 metadata fields
        capture.is_pvp = data["meta"].get("is_pvp", False)
        capture.wave_count = data["meta"].get("wave_count", 1)

    # Parse waves (v2.0)
    if "waves" in data:
        for w in data["waves"]:
            wave_info = WaveInfo(
                wave=w.get("wave", 1),
                start_time_ms=w.get("start_time_ms", 0),
                enemy_count=w.get("enemy_count", 0),
            )
            capture.waves.append(wave_info)

    # Parse units
    if "units" in data:
        # v1.0 format: flat dict of units
        for key, u in data["units"].items():
            unit = _parse_unit(u)
            if unit.is_player:
                capture.player_units.append(unit)
            else:
                capture.enemy_units.append(unit)
    elif "teams" in data:
        # v2.0 format: teams.player and teams.enemy
        if "player" in data["teams"]:
            for u in data["teams"]["player"].get("units", []):
                capture.player_units.append(_parse_unit(u, is_player=True))
        if "enemy" in data["teams"]:
            for u in data["teams"]["enemy"].get("units", []):
                capture.enemy_units.append(_parse_unit(u, is_player=False))

    # Parse actions
    if "actions" in data:
        for a in data["actions"]:
            capture.actions.append(_parse_action(a))
    else:
        capture.actions = _build_actions_from_logs(data)

    # Store raw logs - handle both v1.0 (top-level) and v2.0 (under "raw")
    raw_data = data.get("raw", data)
    capture.exceed_log = raw_data.get("exceedLog", [])
    capture.crit_log = raw_data.get("critLog", [])
    capture.skill_log = raw_data.get("skillLog", [])
    capture.damage_log = raw_data.get("damageLog", [])
    capture.stats = data.get("stats", {})

    return capture


def _parse_unit(data: Dict, is_player: Optional[bool] = None) -> Unit:
    """Parse unit data from JSON."""
    mods_data = data.get("modifiers", data.get("active_modifiers", {}))
    modifiers = Modifiers(
        damage=mods_data.get("damage", 0),
        skill=mods_data.get("skill", 0),
        normal=mods_data.get("normal", 0),
        crit_rate=mods_data.get("crit_rate", mods_data.get("crit", 0)),
        crit_dmg=mods_data.get("crit_dmg", mods_data.get("critDmg", 0)),
        shield=mods_data.get("shield", 0),
        speed=mods_data.get("speed", 0),
    )

    return Unit(
        slot=data.get("slot", ""),
        internal_atk=data.get("atk", data.get("internal_atk", 0)),
        hp=data.get("hp", 0),
        lb_level=data.get("exceedTime", data.get("lb_level", 0)),
        is_player=(
            is_player
            if is_player is not None
            else data.get("isPlayer", data.get("is_player", True))
        ),
        card_id=data.get("card_id"),
        name=data.get("name", data.get("card_name", "")),
        card_level=data.get("card_level", 1),
        crit_rate=data.get("crit_rate", 0),
        speed=data.get("speed", 0),
        skill_id=data.get("skill_id"),
        ability_ids=data.get("ability_ids", []),
        modifiers=modifiers,
        wave=data.get("wave", 0),
    )


def _parse_action(data: Dict) -> Action:
    """Parse action data from JSON."""
    action_type_str = data.get("action_type", "normal")
    if isinstance(action_type_str, str):
        action_type = (
            ActionType.SKILL if action_type_str == "skill" else ActionType.NORMAL
        )
    else:
        action_type = ActionType.SKILL if action_type_str else ActionType.NORMAL

    crit_type_val = data.get("crit_type", 0)
    if isinstance(crit_type_val, int):
        crit_type = (
            CritType(crit_type_val) if crit_type_val in [0, 1, 2] else CritType.NONE
        )
    else:
        crit_type = CritType.NONE

    # Parse attacker mods if present
    mods_data = data.get("attacker_mods", {})
    attacker_mods = Modifiers(
        damage=mods_data.get("damage", 0),
        skill=mods_data.get("skill", 0),
        normal=mods_data.get("normal", 0),
        crit_dmg=mods_data.get("crit_dmg", 0),
        shield=mods_data.get("shield", 0),
    )

    return Action(
        timestamp_ms=data.get("timestamp_ms", 0),
        turn=data.get("turn", 0),
        attacker_slot=data.get("attacker", data.get("attacker_slot", "")),
        target_slot=data.get("target", data.get("target_slot", "")),
        action_type=action_type,
        combo_count=data.get("combo", data.get("combo_count", 1)),
        crit_type=crit_type,
        exceed_damage=data.get("exceed_damage"),
        exceed_random=data.get("exceed_random"),
        actual_damage=data.get(
            "damage", data.get("final_damage", data.get("actual_damage", 0))
        ),
        was_capped=data.get("damage_capped", data.get("was_capped", False)),
        attacker_atk=data.get("atk", data.get("attacker_atk", 0)),
        attacker_lb=data.get("attacker_lb", 0),
        attacker_mods=attacker_mods,
        target_shield=data.get("target_shield", 0),
        wave=data.get("wave", 1),
    )


def _build_actions_from_logs(data: Dict) -> List[Action]:
    """
    Build action list from raw logs when structured actions aren't available.

    This attempts to correlate exceedLog, critLog, and damageLog by timestamp.
    """
    actions = []

    # For now, just use damageLog as the primary source
    damage_log = data.get("damageLog", [])
    exceed_log = data.get("exceedLog", [])
    crit_log = data.get("critLog", [])

    # Simple approach: treat each damage event as an action
    for i, dmg in enumerate(damage_log):
        action = Action(
            timestamp_ms=i * 100,  # Approximate timing
            turn=i + 1,
            attacker_slot=dmg.get("attacker", "???"),
            action_type=ActionType.SKILL if dmg.get("isSkill") else ActionType.NORMAL,
            combo_count=dmg.get("combo", 1),
            actual_damage=dmg.get("damage", 0),
            attacker_atk=dmg.get("atk", 0),
        )
        actions.append(action)

    return actions


def load_capture(file_path: Path) -> BattleCapture:
    """
    Load battle capture from JSON file.

    Args:
        file_path: Path to capture JSON file

    Returns:
        Parsed BattleCapture
    """
    with open(file_path, encoding="utf-8") as f:
        data = json.load(f)
    return parse_battle_capture(data)
