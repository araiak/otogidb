"""
Data models for the Otogi Battle Simulator.

These dataclasses represent battle entities and calculation results.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional
from enum import Enum


class ActionType(Enum):
    """Type of attack action."""

    NORMAL = "normal"
    SKILL = "skill"


class CritType(Enum):
    """Critical hit type."""

    NONE = 0
    NORMAL = 1  # 2x multiplier (validated)
    SUPER = 2  # 4x multiplier [ASSUMPTION:SUPER_CRIT]


@dataclass
class Modifiers:
    """
    Stat modifiers from abilities, skills, and buffs.

    All values are percentages (0.17 = +17%).
    Modifiers stack ADDITIVELY (observed in game).
    """

    damage: float = 0.0  # General damage bucket
    skill: float = 0.0  # Skill-only damage bucket
    normal: float = 0.0  # Normal-attack-only damage bucket
    crit_rate: float = 0.0  # Crit rate bonus
    crit_dmg: float = 0.0  # Crit damage bucket
    shield: float = 0.0  # Damage reduction
    speed: float = 0.0  # Attack speed modifier
    defense: float = 0.0  # Flat points subtracted from a hit, applied last


@dataclass
class Unit:
    """
    Represents a unit in battle.

    Stats are INTERNAL values (display ATK = internal ATK * 10).
    """

    slot: str  # P1, P2, E1, E2, etc.
    internal_atk: int  # Internal ATK (display / 10)
    hp: int  # HP value (not scaled)
    lb_level: int = 0  # Limit break level (0-4, max MLB)
    is_player: bool = True  # True for player units

    # Optional fields for richer simulation
    card_id: Optional[str] = None  # Card ID for skill lookup
    name: str = ""  # Card name
    card_level: int = 1  # Card level (affects skill damage)
    crit_rate: int = 0  # Base crit rate stat
    speed: int = 0  # Base speed stat
    skill_id: Optional[str] = None  # Skill ID for damage lookup
    ability_ids: List[str] = field(default_factory=list)
    modifiers: Modifiers = field(default_factory=Modifiers)

    # v2.0 fields
    wave: int = 0  # Wave this unit appeared in (0 for players)

    @property
    def display_atk(self) -> int:
        """Display ATK shown in game UI (internal * 10)."""
        return self.internal_atk * 10


@dataclass
class Action:
    """
    Represents a single attack action in battle.

    Contains both input parameters and actual results for comparison.
    """

    # Timing
    timestamp_ms: int  # Milliseconds since battle start
    turn: int = 0  # Turn number (if tracked)

    # Attacker/Target
    attacker_slot: str = ""  # P1, E2, etc.
    target_slot: str = ""  # P1, E2, etc. (may be unknown)

    # Action type
    action_type: ActionType = ActionType.NORMAL

    # Combat parameters
    combo_count: int = 1  # Combo count (1-5+)
    crit_type: CritType = CritType.NONE  # Crit result

    # Exceed (LB) bonus - if captured from hook
    exceed_damage: Optional[float] = None  # Damage after exceed calc
    exceed_random: Optional[float] = None  # Random component

    # Actual results (from in-game capture)
    actual_damage: int = 0  # Final damage dealt
    was_capped: bool = False  # Whether damage cap was hit

    # Attacker stats snapshot (for simulation)
    attacker_atk: int = 0  # ATK at time of attack
    attacker_lb: int = 0  # LB level
    attacker_mods: Modifiers = field(default_factory=Modifiers)

    # Target stats snapshot
    target_shield: float = 0.0  # Target's shield modifier

    # v2.0 fields
    wave: int = 1  # Battle wave this action occurred in


@dataclass(slots=True)
class DamageResult:
    """
    Result of a damage calculation with full breakdown.

    Shows each step in the damage pipeline for debugging.
    """

    # Final result
    final_damage: int = 0
    was_capped: bool = False
    cap_applied: Optional[int] = None

    # Step-by-step breakdown
    base_damage: float = 0  # ATK * 1.0 (or skill base)
    after_exceed: float = 0  # After LB bonus
    after_combo: float = 0  # After combo bonus
    after_modifiers: float = 0  # After damage/skill/normal mods
    after_crit: float = 0  # After crit multiplier
    after_type_mod: float = 0  # After normal/skill specific mods
    after_shield: float = 0  # After shield reduction
    after_defense: float = 0  # After defense reduction

    # Multipliers applied
    exceed_mult: float = 1.0
    combo_mult: float = 1.0
    modifier_mult: float = 1.0  # General damage bucket
    crit_mult: float = 1.0
    crit_dmg_mult: float = 1.0  # Crit damage mod
    skill_dmg_mult: float = 1.0  # Skill damage mod
    normal_dmg_mult: float = 1.0  # Normal damage mod
    defense_mult: float = 1.0  # Derived only; defense is not really a multiplier
    defense_flat: float = 0.0  # Defense is a FLAT SUBTRACTION (live-verified, V21)
    shield_mult: float = 1.0  # 1 - shield%

    # Assumption tracking
    assumptions_used: List[str] = field(default_factory=list)

    def add_assumption(self, assumption: str):
        """Track that an assumption was used in this calculation."""
        if assumption not in self.assumptions_used:
            self.assumptions_used.append(assumption)


@dataclass
class ComparisonResult:
    """
    Result of comparing actual vs predicted damage.
    """

    action: Action  # Original action
    predicted: DamageResult  # Simulated result

    # Comparison metrics
    actual_damage: int = 0
    predicted_damage: int = 0
    variance: float = 0.0  # Absolute variance
    variance_pct: float = 0.0  # Percentage variance
    within_tolerance: bool = False  # Within acceptable range

    # Assumption info
    assumptions_used: List[str] = field(default_factory=list)


@dataclass
class WaveInfo:
    """Information about a battle wave."""

    wave: int = 1  # Wave number
    start_time_ms: int = 0  # When wave started
    enemy_count: int = 0  # Enemies in this wave


@dataclass
class BattleCapture:
    """
    Complete battle capture from in-game observation hook.

    Contains all data needed to replay and simulate a battle.
    """

    # Metadata
    version: str = "1.0"
    capture_time: str = ""
    duration_ms: int = 0

    # v2.0 metadata
    is_pvp: bool = False  # True if PvP battle
    wave_count: int = 1  # Number of waves

    # Teams
    player_units: List[Unit] = field(default_factory=list)
    enemy_units: List[Unit] = field(default_factory=list)

    # Waves (v2.0)
    waves: List[WaveInfo] = field(default_factory=list)

    # Actions
    actions: List[Action] = field(default_factory=list)

    # Raw logs (for debugging)
    exceed_log: List[Dict] = field(default_factory=list)
    crit_log: List[Dict] = field(default_factory=list)
    skill_log: List[Dict] = field(default_factory=list)
    damage_log: List[Dict] = field(default_factory=list)

    # Summary stats
    stats: Dict = field(default_factory=dict)

    def get_unit(self, slot: str) -> Optional[Unit]:
        """Look up a unit by slot name."""
        for unit in self.player_units + self.enemy_units:
            if unit.slot == slot:
                return unit
        return None
