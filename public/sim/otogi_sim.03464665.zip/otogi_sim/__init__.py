"""
Otogi Battle Simulator

Lifecycle-accurate combat simulation, modelled on behaviour observed in game.
Supports 5-wave, 1-wave, and defensive evaluation modes.

Usage:
    # Simulate a team battle
    python -m otogi_sim simulate --team 1,15,733 --mode 5wave

    # Compare in-game capture to simulation
    python -m otogi_sim compare -i battle_capture.json

    # Show damage formula
    python -m otogi_sim formula
"""

# Core models
from .models import Unit, Action, DamageResult, ActionType, CritType

# Formula calculations
# Note: COMBO_BONUS removed (2026-01-16) - combo is purely cosmetic
from .formula import calculate_damage, EXCEED_MULT, DAMAGE_CAPS, STAT_CAPS

# Lifecycle classes (NEW)
from .lifecycle import MonsterModel, MonsterStat, MonsterComponent, ModifierType

# Data loading (NEW)
from .data_loader import GameDataLoader, get_loader, build_monster

# Battle simulation (NEW)
from .battle import Battle, BattleConfig, BattleEvent

# Simulation modes (NEW)
from .modes import (
    FiveWaveSimulator,
    OneWaveSimulator,
    DefenseSimulator,
    SimulationResult,
    run_simulation,
)

# Legacy comparison
from .simulator import BattleSimulator
from .compare import compare_results, generate_report

__version__ = "2.0.0"
__all__ = [
    # Core models
    "Unit",
    "Action",
    "DamageResult",
    "ActionType",
    "CritType",
    # Formula
    "calculate_damage",
    # "COMBO_BONUS",  # Removed (2026-01-16) - combo is purely cosmetic
    "EXCEED_MULT",
    "DAMAGE_CAPS",
    "STAT_CAPS",
    # Lifecycle
    "MonsterModel",
    "MonsterStat",
    "MonsterComponent",
    "ModifierType",
    # Data loading
    "GameDataLoader",
    "get_loader",
    "build_monster",
    # Battle
    "Battle",
    "BattleConfig",
    "BattleEvent",
    # Simulation modes
    "FiveWaveSimulator",
    "OneWaveSimulator",
    "DefenseSimulator",
    "SimulationResult",
    "run_simulation",
    # Legacy
    "BattleSimulator",
    "compare_results",
    "generate_report",
]
