"""Shared constants for the team search.

Lifted out of ``monte_carlo`` so the modules split from it do not all have to
import the searcher just to name a role or an attribute.
"""

from __future__ import annotations

from pathlib import Path

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

ROLE_MELEE = 1
ROLE_RANGED = 2
ROLE_HEALER = 3
ROLE_ASSIST = 4

ROLE_NAMES = {ROLE_MELEE: "melee", ROLE_RANGED: "ranged", ROLE_HEALER: "healer"}

# Card attributes
ATTR_DIVINA = 1
ATTR_PHANTASMA = 2
ATTR_ANIMA = 3
ATTR_NEUTRAL = 4

ATTR_NAMES = {ATTR_DIVINA: "Divina", ATTR_PHANTASMA: "Phantasma", ATTR_ANIMA: "Anima"}

# Valid (n_melee, n_healer, n_ranged) compositions for 4 active slots.
# Constraints: melee 0-2, healer 1-2, ranged 1-4.
VALID_COMPOSITIONS: list[tuple[int, int, int]] = [
    (0, 1, 3),
    (0, 2, 2),
    (1, 1, 2),
    (1, 2, 1),
    (2, 1, 1),
]

# Benchmark-mode immortal target config (mirrors DamageBenchmark)

# Max level a card of each rarity can reach in game.  cards.json stores the
# PRE-limit-break cap (`max_level`: 70 for 5★, 60 for 4★); limit breaking adds
# 20 levels on top, and MonsterModel.calculate_from_card extrapolates stats
# linearly past max_level to match.  Simulating a card above its own cap would
# overstate it, so the level is chosen per rarity, never globally.
RARITY_MAX_LEVEL: dict[int, int] = {4: 80, 5: 90}

MC_SCORES_FILE = "mc_card_scores.json"
MC_TEAMS_FILE = "mc_top_teams.json"
MC_CHECKPOINT_FILE = "mc_checkpoint.ndjson"

# One definition of "where the repo is". Every module that hardcoded its own
# ``parent.parent.parent`` broke the moment the package moved directory depth.
REPO_ROOT = Path(__file__).resolve().parent.parent

_TIER_MAP_PATH = REPO_ROOT / "tier_card_mapping.csv"

# Slot-keyed assist assignments. Keys are (slot_kind, slot_index):
#   ("active", 0..3)   — four active slots, slot 0 is leader
#   ("reserve", 0..1)  — two reserve slots
#   ("helper", 0)      — single helper slot
# This lets the helper carry its own assist even when its card_id matches
# an active slot's card_id.
SLOT_ACTIVE = "active"
SLOT_RESERVE = "reserve"
SLOT_HELPER = "helper"

SlotKey = tuple[str, int]
