"""Kit-reading helpers the schedulers share.

This was the variable vocabulary of the retired APL rule language; only the
helpers the team schedulers call survive.
"""

from __future__ import annotations
from typing import Any

# Fixed LB-exceed percent for APL *projections*. The real roll is
# `random.uniform(0, 5 * lb_level)` -- 0..20% at LB4 -- so a projection that takes a
# roll answers a different question every call, and comparisons built on it (which
# carry is strongest, is this hit capped) come out partly random. 10% is the mean,
# which keeps those comparisons stable and unbiased. The overcap probes in
# `scheduler._channel_capped` use 0.0 instead: "is it capped" is not a comparison,
# and a stack is only definitively waste once even the worst roll is capped.
APL_PROJECTION_EXCEED = 10.0


def _source_matches(source_id: str, suffix: str) -> bool:
    """Match a modifier source_id by its ModifierType-name suffix, tolerating the
    per-cast ``_castN`` suffix that stacking buffs append (abilities and skills).
    Avoids CRIT vs CRIT_DMG confusion because the ``_cast`` boundary differs."""
    tag = "_" + suffix
    return source_id.endswith(tag) or (tag + "_cast") in source_id


def _buff_remains(battle: Any, unit: Any, suffix: str) -> float:
    """Max remaining seconds of a timed buff of the given kind on ``unit``."""
    active = getattr(battle, "_active_buffs", None)
    if not active:
        return 0.0
    best = 0.0
    for target, source_id, expire_time in active:
        if target is unit and _source_matches(source_id, suffix):
            best = max(best, expire_time - battle.current_time)
    return best


def skill_flags(skill: Any, unit: Any = None) -> dict[str, bool]:
    """Boolean flags describing what a *cast* carries.

    A cast's real effect set is the skill's own de/ie **plus** the unit's
    on-skill (attack_skill) abilities — e.g. Nimbus 514's crit rate/dmg live only
    in ability 51402, not her SPD skill. Without folding those in, the APL would
    see "just an SPD buff" and never cast her, losing the stacking payoff.
    """
    tokens: set[str] = set()
    if skill is not None:
        for eff in list(getattr(skill, "buff_effects", [])) + list(
            getattr(skill, "debuff_effects", [])
        ):
            tokens.add(eff.split("<")[0].strip())
    # Fold in on-skill ability effect types (duck-typed: trigger value "attack_skill").
    has_ability_buff = False
    if unit is not None:
        for ab in getattr(unit, "abilities", []) or []:
            trig = getattr(ab, "trigger", None)
            if getattr(trig, "value", trig) != "attack_skill":
                continue
            for eff in getattr(ab, "effects", []) or []:
                et = getattr(eff, "effect_type", None)
                name = getattr(et, "name", None)
                if name:
                    tokens.add(name)
                    has_ability_buff = True
    target_type = getattr(skill, "target_type", "enemy") if skill else "enemy"
    return {
        "crit_rate": "CHIT" in tokens,
        "crit_dmg": "CHIT_ATK" in tokens,
        "atk": "ATK" in tokens,
        "damage": target_type == "enemy",
        "buff": bool(getattr(skill, "buff_effects", []))
        or target_type == "self"
        or has_ability_buff,
        "debuff": bool(getattr(skill, "debuff_effects", [])),
        "stun": "STUN" in tokens,
        "shield": "SHIELD" in tokens,
        "speed": "SPD" in tokens,
    }
