"""The battle loop's one question about casting: ``should_cast(attacker, battle, target)``.

The answer comes from a team-level scheduler (``apl.schedulers``). This used to be
a SimC-style rule language (``default.apl`` + per-card overrides) that ran whenever
no scheduler was installed; every production path installs one, so the rules only
ever ran by accident. They were retired 2026-11-04 along with ``MC_SCHEDULER=none``.
"""

from __future__ import annotations

from typing import Any


class AplEngine:
    def __init__(self, scheduler: Any = None) -> None:
        self.scheduler = scheduler

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        if self.scheduler is None:
            # ponytail: nothing installed -> install the default policy (cadence
            # unless MC_SCHEDULER says otherwise) rather than score with none.
            from .install import install_cadence_scheduler

            install_cadence_scheduler()
        return self.scheduler.should_cast(attacker, battle, target)


_ENGINE: AplEngine | None = None


def get_engine() -> AplEngine:
    """Process-wide singleton."""
    global _ENGINE
    if _ENGINE is None:
        _ENGINE = AplEngine()
    return _ENGINE


def set_engine(engine: AplEngine | None) -> None:
    """Replace / reset the singleton (tests)."""
    global _ENGINE
    _ENGINE = engine
