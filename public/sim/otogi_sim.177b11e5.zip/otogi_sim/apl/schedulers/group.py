"""GroupScheduler: player-authored cast groups (drives the web calculator)."""

from __future__ import annotations

from typing import Any
from ..scheduler import (
    SWAP_CONDITIONS,
    _AMP_TAGS,
    _DMG_BUFF_TAGS,
    _buffer_signature,
    _note_buff,
    next_cc_risk,
    next_cleanse_in,
    scaled_cycle,
    swap_triggered,
)
from ...lifecycle import HARD_CC_DEBUFFS, DebuffType
from ..state import _buff_remains, _source_matches, skill_flags
from .cadence import CadenceScheduler


class GroupScheduler(CadenceScheduler):
    """Player-authored cast groups: the policy the web calculator drives.

    The player drags cards into ordered groups. Priority is left to right; any slot
    in no group never casts at all (the "do not cast" bucket). A group *opens* when
    every one of its eligible members can cast at cost 1, and once open it stays the
    active group until all of them have fired -- that is what makes a group fire
    *together* rather than dribbling out as orbs trickle in.

    This is deliberately less optimal than ``cadence``. Cadence discovers a rotation;
    this one executes the rotation the player asked for, so they can compare two
    teams under a policy they can reason about. Three of cadence's judgments are
    kept because they are about waste, not optimisation:

    - **cost 1 only** (``_cost_ready``): skill cost escalates 1 -> 2 -> 3 and decays
      one step per 20s, so a group that re-fires too early pays double and triple.
      This gate is what produces the natural ~20s group cadence -- no cycle constant.
    - **dominated buffers** (``_dominated_buffers``): a buff another member already
      supplies to more targets at higher magnitude is skipped. It neither casts nor
      blocks its group.
    - **amp stagger** (``_amp_still_running``): a duplicate damage-amp debuff that is
      already running is skipped for this opening rather than refreshed into itself.

    ``skip_after`` is the deadlock guard: a member held by CC (or by a lapsing amp)
    for that many seconds is passed over so one stunned unit cannot lock the group.
    """

    def __init__(
        self,
        groups: list[list[str]],
        cost_target: int = 1,
        skip_after: float = 8.0,
        stagger_amp: bool = True,
        cycle: float = 20.5,
        swap: dict[str, str] | None = None,
        hold_cc: float = 0.0,
        end_dump: float = 8.0,
        swap_when: str = "autos",
        cc_mid: str = "skip",
        cc_wait: float = 6.0,
        cleanse_dodge: float = 4.0,
        cc_dodge: tuple = (),
        amp_wait: bool = True,
        buffer_wait: float = 6.0,
        offset: dict[int, float] | None = None,
        speed_stagger: bool = False,
        retire: dict[str, str] | None = None,
        protect_lead: bool = False,
        overflow: list[tuple[str, int]] | None = None,
        overflow_after: float = 0.0,
        overflow_horizon: float = 0.0,
        rich: dict[str, int] | None = None,
        rich_window: bool = True,
        late_carry: float = 1.0,
    ) -> None:
        super().__init__(cost_target=cost_target, stagger_amp=stagger_amp)
        # Seconds of margin for the player's "late second carry": an amp carry listed
        # after one that already fired this opening holds, and casts on the last skill
        # tick whose hit still lands this many seconds before its ally buffs or the
        # earlier amp run out -- stretching the amp over more autos (measured +0.2..+1.3% on
        # every duplicated-Hikoboshi ledger team, 2026-10-18; player staggers ~6s). 0 = off. Early
        # beats late: a nuke that misses the buffs loses several hundred K.
        self.late_carry = late_carry
        # {group_index: seconds} -- that group's first opening is due this far into
        # the fight, and the fixed grid below keeps the phase. Puts a second buffer
        # half a cycle off the burst so a timed buff (an 8s speed buff) is up
        # between bursts instead of on top of the burst's own.
        self.offset = {int(k): float(v) for k, v in (offset or {}).items()}
        # A speed-only cast (Ohina) holds while the carry is already speed-capped by
        # a timed buff, and fires as that buff runs out -- overlapping two capped
        # speed buffs buys nothing. See `_speed_held`.
        self.speed_stagger = speed_stagger
        # {slot: condition} -- that slot stops casting for good once the condition
        # ("autos"/"skills"/"either"/"both") reads true at a cold moment, with no
        # replacement. A buffer whose only job was pushing a carry's nuke to the
        # cap (Mira) frees its orb once the nuke caps without it.
        # Later groups may not spend an orb the FIRST group needs at its next due
        # time: the burst outranks the fillers between bursts. See `_starves_lead`.
        self.protect_lead = protect_lead
        # [(slot, casts), ...] -- the player's orb-overflow dump ("Mira x1, Odairi
        # x4 when orbs are in excess"): once the pool is FULL (income would be lost)
        # and the fight is past `overflow_after` s, cast this sequence at whatever
        # cost it takes, then resume the rotation. See `_overflow_cast`.
        self.overflow = [(str(s), int(n)) for s, n in (overflow or [])]
        self.overflow_after = overflow_after
        # 0 = dump whenever the pool is full. N = only when the excess is sustained:
        # pool + income over the next N s must still cover the bursts due in that
        # window after paying for the dump (N=40: cost 3 decays back to 1 in 40s).
        self.overflow_horizon = overflow_horizon
        # {slot: reserve} -- that slot may also cast ABOVE cost 1 (2 or 3 orbs)
        # whenever the pool stays >= reserve after paying; with `rich_window`, only
        # while a timed DAMAGE/ATK buff is on it (Mira's window, so the nuke caps).
        # Cost-1 casts still go through the group. Cost decays one step per 20s to
        # 1, so a card averages one cost-1 cast per 20s; every cast beyond that is
        # paid at 2-3 orbs -- this is where surplus orbs become extra nukes.
        self.rich = {str(k): int(v) for k, v in (rich or {}).items()}
        self.rich_window = rich_window
        self.retire = {
            k: (v if v in SWAP_CONDITIONS else "skills")
            for k, v in (retire or {}).items()
        }
        # A BUFFER CC'd after its group has opened (the player's mid-rotation call):
        #   skip -- step over it, carries fire now, it may still cast late this opening
        #   drop -- step over it and give up its cast this opening (keeps its orb)
        #   wait -- carries hold for it, up to `cc_wait` s after the opening
        self.cc_mid = cc_mid
        self.cc_wait = cc_wait
        # Don't open a burst if the boss self-cleanse lands within this many seconds:
        # it would strip the first carry's amp before the second carry casts. 0 = off.
        # Defaults (4s / amp_wait / buffer_wait 6s) measured 2026-09-30 on the player's
        # 67M Hinoto team: 64.6M -> 66.5M, Hiko skill cap rate 74% -> 99%.
        self.cleanse_dodge = cleanse_dodge
        # (horizon s, risk): don't open a burst while boss CC due within `horizon`
        # s carries at least `risk` expected team share (`next_cc_risk`); open just
        # after it instead. () = off.
        self.cc_dodge = tuple(cc_dodge)
        # A carry whose cast also debuffs the enemy (Hikoboshi's amp) is a buffer for
        # the carries after it: they wait for its debuff to land, as for a support's.
        self.amp_wait = amp_wait
        # Carries hold for an earlier, unfired buffer that will be castable within
        # this many seconds (CC ending, or its cost decaying back after a CC pause).
        self.buffer_wait = buffer_wait

        # End-of-fight rotation, the one piece of `cadence` this policy was missing.
        # Orbs are worthless after the bell, so the last `end_dump` seconds spend
        # everything affordable regardless of cost or beat -- and the `skill_minus_cost_cd`
        # seconds BEFORE that window are held idle so every cost decays back to 1 and
        # the buffs cast at the opening cover the whole dump. 8s == the standard buff
        # duration, so hold from T-28 to T-8 then dump fully buffed.
        self.end_dump = end_dump
        # Drop empty groups so an empty UI row can't stall the rotation.
        self.groups = [list(g) for g in groups if g]
        self.skip_after = skip_after
        # {retiring_slot: replacement_slot}. The ramp swap: a permanent-crit-damage
        # buffer (Nimbus) is worth nothing once a carry's autos cap, so at that
        # point it drops out and the named slot takes over its place in the group.
        # Both slots are listed in the group as normal, adjacent and in the order
        # the player wants them; exactly one of the pair is eligible at a time.
        self.swap = dict(swap or {})
        self.swap_in = {v: k for k, v in self.swap.items()}
        # Which channel has to saturate before the retiring card stands down.
        self.swap_when = swap_when if swap_when in SWAP_CONDITIONS else "autos"
        # Seconds a group will wait for a CC'd member before opening without it.
        # 0 = off, which is the default and the measured-best setting: see
        # `test_group_scheduler.test_cc_hold_is_not_worth_it` and CLAUDE.md.
        self.hold_cc = hold_cc
        # The beat a group tries to keep. Openings are scheduled on a FIXED grid
        # (due, due+cycle, due+2*cycle, ...) rather than measured from the previous
        # cast, because the latter compounds: a cast delayed by CC, a stagger hold or
        # plain turn timing pushes the next opening, which pushes the one after that.
        # Measured on a real team, that drift walked the carries out of an 8s crit
        # window by 66s and never recovered -- 5 of 31 casts landed with no crit for
        # ~150k instead of ~950k. A fixed grid lets a late cycle catch up instead.
        self.cycle = cycle

    def _is_buffer_cast(self, unit: Any) -> bool:
        f = skill_flags(unit.skill, unit)
        return not f["damage"] or (self.amp_wait and f["debuff"])

    def _castable_in(self, battle: Any, u: Any) -> float:
        """Seconds until this unit can cast at cost 1. Hard CC pauses the cost decay,
        so its time adds to the decay left; SILENCE only blocks the cast while the
        decay runs underneath."""
        now = battle.current_time

        def left(kinds: Any) -> float:
            return max(
                (
                    d.expire_time - now
                    for d in u.active_debuffs
                    if d.debuff_type in kinds and d.expire_time > now
                ),
                default=0.0,
            )

        steps = int(u.need_cast_point) - self.cost_target
        cd = float(getattr(battle.config, "skill_minus_cost_cd", 20.0) or 20.0)
        decay = (cd - u.minus_cost_timer) + (steps - 1) * cd if steps > 0 else 0.0
        return max(left(HARD_CC_DEBUFFS) + decay, left((DebuffType.SILENCE,)))

    # -- membership ---------------------------------------------------------
    def _group_of(self, slot: str) -> int | None:
        for i, g in enumerate(self.groups):
            if slot in g:
                return i
        return None

    def _unit(self, battle: Any, slot: str) -> Any:
        for p in battle.players:
            if p.slot == slot:
                return p
        return None

    def _dominated_buffers(self, battle: Any) -> set[str]:
        """Strict domination only -- an exact duplicate is the player's to place.

        A strictly worse copy of a live buff is never worth an orb, under any policy.
        An IDENTICAL copy is different: worthless at the same instant, but a real
        refresher, because the two sit on separate cost tracks and can alternate.
        Measured on the player's Odairi team, the second Ohina is +1.6% with orb
        headroom and -7.4% when it competes with the burst -- so the answer is where
        it is placed, and a group layout already says that. `cadence` has no groups
        and must decide for itself, so it keeps muting ties; here the player decides.

        This is also what left a swap's replacement permanently mute: it was an exact
        tie with the card already casting, so it never fired and the retired card's
        orbs simply evaporated -- 57 casts against 78 orbs of income.
        """
        return {
            slot
            for slot in super()._dominated_buffers(battle)
            if slot not in self._exact_ties(battle)
        }

    def _exact_ties(self, battle: Any) -> set[str]:
        """Slots whose buff signature exactly matches another casting buffer's."""
        casting = self._casting_slots(battle)
        seen: dict[tuple, str] = {}
        ties: set[str] = set()
        for p in battle.players:
            if p.slot not in casting or getattr(p, "skill", None) is None:
                continue
            f = skill_flags(p.skill, p)
            if not (f["buff"] and not f["damage"]):
                continue
            sig, tc = _buffer_signature(p)
            if not sig:
                continue
            key = (tuple(sorted(sig.items())), tc)
            if key in seen:
                ties.add(p.slot)
                ties.add(seen[key])
            else:
                seen[key] = p.slot
        return ties

    def _casting_slots(self, battle: Any) -> set[str]:
        """Who this rotation will actually cast: grouped, alive, and on the right
        side of a swap.

        A slot in no group never casts, and a swapped-out card has stopped casting,
        so neither can dominate anything. That is what left a retired Nimbus still
        muting the Ohina meant to replace it, with the freed orbs going nowhere:
        63 casts against 78 orbs of income, where not swapping casts 70.
        """
        out: set[str] = set()
        capped = self._capped(battle)
        for g in self.groups:
            for slot in g:
                if slot in self.swap and capped:
                    continue  # retired
                if slot in self.swap_in and not capped:
                    continue  # not on yet
                u = self._unit(battle, slot)
                if u is not None and u.is_alive and getattr(u, "skill", None):
                    out.add(slot)
        return out

    def _eligible(self, battle: Any, slot: str) -> bool:
        """Can this slot cast right now? Dead/skill-less/dominated/swapped-out cannot."""
        u = self._unit(battle, slot)
        if u is None or not u.is_alive or getattr(u, "skill", None) is None:
            return False
        if slot in self.swap and self._capped(battle):
            return False  # the ramp has done its job
        if slot in self.swap_in and not self._capped(battle):
            return False  # its replacement is not on yet
        if slot in self.retire and self.retire[slot] in getattr(
            battle, "_group_capped_by", ()
        ):
            return False  # its condition has been met: retired for the fight
        return slot not in self._dominated_buffers(battle)

    def _capped(self, battle: Any) -> bool:
        """Sticky "a carry's baseline autos have capped", sampled BETWEEN bursts.

        Sampling only while no group holds the floor is what keeps the reading at
        baseline: that is when the cycle's timed buffs are down. Sticky because a permanent crit-damage ramp never
        gives its stacks back, and because a mid-fight flip-flop would swap a card
        out and back inside one rotation.
        """
        return bool(getattr(battle, "_group_capped", False))

    def _sample_capped(self, battle: Any) -> None:
        """Read the cap only at a COLD moment: no group holding the floor AND no
        timed buff live on anyone.

        "No group active" alone is not cold enough -- with three groups something is
        almost always mid-rotation, and a buffed carry reads as capped long before
        its baseline does, retiring the ramp far too early. `_active_buffs` is
        exactly the timed set (permanent ability buffs are never tracked there), so
        an empty live set is the baseline the retire rule means.

        ponytail: a team that keeps a timed buff up 100% of the time never samples,
        so its ramp never retires -- which is the safe failure (that is the
        whole-fight rotation). Project the buffs off instead if that ever bites.
        """
        conds = set(self.retire.values())
        if self.swap:
            conds.add(self.swap_when)
        done = getattr(battle, "_group_capped_by", None)
        if done is None:
            done = battle._group_capped_by = set()
        if not conds - done:
            return
        now = battle.current_time
        for _t, sid, expire in getattr(battle, "_active_buffs", ()):
            # A speed buff changes how often a unit hits, not how hard, so it does
            # not spoil a cap reading -- and a team built to keep speed up 100% of
            # the time would otherwise never sample at all.
            if expire > now and not _source_matches(sid, "SPEED"):
                return
        for c in conds - done:
            if swap_triggered(battle, c):
                done.add(c)
        if self.swap_when in done:
            battle._group_capped = True

    def _can_act(self, battle: Any, slot: str) -> bool:
        """Cost has decayed back to 1 and no CC is stopping this unit casting.

        Deliberately does NOT include the amp-stagger check. Stagger is a judgment
        about one unit wasting its own orb; folding it in here made a single carry
        whose debuff was still running hold the ENTIRE group at the gate, which
        measured -20% and left the orb pool pinned at its cap of 10 with income
        overflowing. Stagger belongs to the caster, not to the group.
        """
        u = self._unit(battle, slot)
        if u is None:
            return False
        if u.is_cast_blocked(battle.current_time):
            return False
        return self._cost_ready(u, battle)

    def _speed_held(self, battle: Any, unit: Any) -> bool:
        """Is this a speed-only cast whose speed the carry already has at the cap?

        Speed-only = a SPD buff with no damage, ATK, crit or shield in the cast
        (a heal is allowed: Ohina). The carry is the top post-setup-ATK ally, the
        same ranking `max_atk` buffs use. Holds while the carry sits at the +100%
        speed clamp and its timed speed buff outlasts this cast's own landing
        delay, so the new buff lands as the old one expires. A DELAY, like the amp
        stagger: it resolves within one buff window.
        """
        if not self.speed_stagger or unit is None or unit.skill is None:
            return False
        f = skill_flags(unit.skill, unit)
        if not f["speed"] or any(
            f[k] for k in ("damage", "atk", "crit_rate", "crit_dmg", "shield")
        ):
            return False
        alive = [p for p in battle.players if p.is_alive and p.stat is not None]
        if not alive:
            return False
        carry = max(
            alive,
            key=lambda p: p.stat.base_atk
            * p.stat.normal_dmg_modifier.get_modifier_total(),
        )
        if carry.stat.speed_modifier.get_modifier_total() - 1.0 < 1.0:
            return False
        return _buff_remains(battle, carry, "SPEED") > battle.skill_effect_delay_for(
            unit
        )

    def _lead_block(self, battle: Any, gi: int) -> int:
        """Orbs group `gi` needs to open: members up to and including its first nuke."""
        n = 0
        for s in self.groups[gi]:
            if not self._eligible(battle, s):
                continue
            n += 1
            u = self._unit(battle, s)
            if u is not None and skill_flags(u.skill, u)["damage"]:
                break
        return n

    def _starves_lead(self, battle: Any, gi: int) -> bool:
        """Would one more orb spent by group `gi` (> 0) leave group 0 short at its due?

        Counts the pool after this cast plus income until group 0's next due time,
        against what group 0 needs to open. Group 0 already open, or no orb income
        modelled, never starves.
        """
        if not self.protect_lead or gi == 0 or not self.groups:
            return False
        st = getattr(battle, "_group_st", None)
        if st is not None and st["gi"] == 0:
            return False
        regen = float(getattr(battle, "skill_points_regen_cd", 0) or 0)
        if regen <= 0:
            return False
        timer = getattr(battle, "skill_points_timer", 0.0)
        due0 = (getattr(battle, "_group_due", None) or {}).get(
            0, self.offset.get(0, 0.0)
        )
        wait = max(0.0, due0 - battle.current_time)
        income = int((timer + wait) // regen)
        return battle.skill_points - 1 + income < self._lead_block(battle, 0)

    def _ready(self, battle: Any, slot: str, target: Any) -> bool:
        """`_can_act`, the caster's own amp-stagger skip, and the buff-landing wait.

        Applied to the unit actually asking to cast, never to the group as a whole.
        """
        if not self._can_act(battle, slot):
            return False
        u = self._unit(battle, slot)
        if self._waiting_for_buffs(battle, u):
            return False
        if self.stagger_amp and self._amp_still_running(
            u, battle, target, enemy_only=True
        ):
            return False
        if self._speed_held(battle, u):
            return False
        return True

    # -- rotation -----------------------------------------------------------
    def _overflow_cast(self, battle: Any, attacker: Any) -> bool:
        """Is this cast the next step of an orb-overflow dump?

        A dump starts when the pool is full past `overflow_after`. It spends the
        listed sequence in order and ignores the cost-1 rule -- the orbs would
        otherwise be lost to the cap -- and the escalated cost it leaves behind is
        the trade the player accepts. It ends when the sequence is spent, or when
        the next step cannot be paid or cannot act (dead / CC'd).
        """
        if not self.overflow:
            return False
        q = getattr(battle, "_overflow_q", None)
        if q is None:
            cap = int(getattr(battle, "skill_points_max", 10) or 10)
            if (
                battle.skill_points < cap
                or battle.current_time < self.overflow_after
                or not self._excess_sustained(battle)
            ):
                return False
            q = battle._overflow_q = [s for s, n in self.overflow for _ in range(n)]
        while q:
            u = self._unit(battle, q[0])
            if (
                u is None
                or not u.is_alive
                or u.skill is None
                or u.is_cast_blocked(battle.current_time)
                or battle.skill_points < u.need_cast_point
            ):
                q.clear()  # cannot finish the sequence: back to the rotation
                break
            if q[0] != attacker.slot:
                return False  # someone else is next; normal rotation meanwhile
            q.pop(0)
            if not q:
                battle._overflow_q = None
            return True
        battle._overflow_q = None
        return False

    def _excess_sustained(self, battle: Any) -> bool:
        """Will the pool still fund every burst due in the horizon after a dump?

        Dump cost assumes each repeat escalates 1 -> 2 -> 3 (capped at 3); bursts
        are counted at cost 1 per eligible member of every group, per cycle.
        """
        h = self.overflow_horizon
        if h <= 0:
            return True
        regen = float(getattr(battle, "skill_points_regen_cd", 5.0) or 5.0)
        dump = sum(min(i + 1, 3) for _s, n in self.overflow for i in range(n))
        per_cycle = sum(
            len([s for s in g if self._eligible(battle, s)]) for g in self.groups
        )
        bursts = per_cycle * h / scaled_cycle(self.cycle, battle)
        return battle.skill_points + h / regen - dump >= bursts

    def _rich_cast(self, battle: Any, unit: Any) -> bool:
        """An above-cost-1 cast the pool can afford while keeping its reserve."""
        reserve = self.rich.get(unit.slot)
        if reserve is None or unit.need_cast_point <= self.cost_target:
            return False
        if battle.skill_points - unit.need_cast_point < reserve:
            return False
        if not self._eligible(battle, unit.slot) or unit.is_cast_blocked(
            battle.current_time
        ):
            return False
        # Mira's "deal X% more DMG" is a DAMAGE buff; ATK-type buffs count too.
        if self.rich_window and max(
            _buff_remains(battle, unit, "DAMAGE"), _buff_remains(battle, unit, "ATK")
        ) <= battle.skill_effect_delay_for(unit):
            return False
        return True

    def _late_member(self, battle: Any, slot: str) -> list:
        """`late_carry` applies to ``slot`` this opening: it is an amp carry listed
        after amp carries that already fired. Returns those earlier carries."""
        st = getattr(battle, "_group_st", None)
        u = self._unit(battle, slot)
        if not self.late_carry or not isinstance(st, dict) or u is None:
            return []
        g = self.groups[st["gi"]]
        if slot not in g or slot in st["fired"]:
            return []
        fl = skill_flags(u.skill, u)
        if not (fl["damage"] and fl["debuff"]):
            return []
        earlier = []
        for s in g[: g.index(slot)]:
            e = self._unit(battle, s)
            ef = skill_flags(e.skill, e) if e is not None else None
            if ef and ef["damage"] and ef["debuff"] and s in st["fired"]:
                earlier.append(e)
        return earlier

    def _late_held(self, battle: Any, slot: str) -> bool:
        """`late_carry`: hold until the hit would land just inside the FIRST of this
        carry's ally skill buffs / the earlier carries' amps to run out."""
        earlier = self._late_member(battle, slot)
        if not earlier:
            return False
        u = self._unit(battle, slot)
        now = battle.current_time
        mine = {e.slot for e in earlier}

        def caster(sid: str) -> str:
            # skill_<id>_<slot>_<TYPE>[_castN]; the boss's own casts carry E1.
            parts = sid.split("_")
            return parts[2] if len(parts) > 2 else ""

        ends = [
            exp
            for t, sid, exp in getattr(battle, "_active_buffs", None) or ()
            if exp > now
            and sid.startswith("skill_")
            and (
                (
                    t is u
                    and caster(sid).startswith("P")
                    and caster(sid) != slot
                    and any(_source_matches(sid, k) for k in _DMG_BUFF_TAGS)
                )
                or (
                    t.is_enemy
                    and caster(sid) in mine
                    and any(_source_matches(sid, k) for k in _AMP_TAGS)
                )
            )
        ]
        if not ends:
            return False  # nothing left to land inside: cast now
        t_cl = next_cleanse_in(battle)
        if t_cl is not None:
            ends.append(now + t_cl)  # the boss cleanse strips the amp: beat it
        step = float(getattr(battle.config, "skill_tick_rate", 0.5) or 0.5)
        lag = battle.skill_effect_delay_for(u)
        return now + step + lag + self.late_carry < min(ends)

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        if self._overflow_cast(battle, attacker):
            return True
        if self.rich and self._rich_cast(battle, attacker):
            return True
        gi = self._group_of(attacker.slot)
        if gi is None:
            return False  # "do not cast" bucket
        # The caster's own eligibility was only ever consulted for the group's
        # bookkeeping, never for the unit actually asking -- so a slot the policy
        # had ruled out (swapped-out ramp, dominated buffer) still cast.
        if not self._eligible(battle, attacker.slot):
            return False

        now = battle.current_time
        if self.end_dump:
            verdict = self._end_of_fight(battle, attacker, gi, now)
            if verdict is not None:
                return verdict

        st = self._retire_group(battle, getattr(battle, "_group_st", None), target, now)
        if st is None:
            st = self._open_group(battle, now)
            if st is None:
                return False

        if st["gi"] != gi:
            return False  # a higher-priority group holds the floor

        # One cast per member per opening. Without this a healer whose skill carries a
        # buff (Sola, Ameno Uzume, Classic Alice) casts TWICE in the same tick: the
        # engine offers it a cast on both the heal path and the attack path, and the
        # in-order loop below breaks at the attacker immediately, re-approving it.
        if attacker.slot in st["fired"]:
            return False

        # Re-check THIS unit at cast time. `_ready` was previously consulted only when
        # opening the group, so once open a member could cast at an escalated cost --
        # the one thing this policy promises never to do. The engine gate only asks
        # whether the orbs are affordable, not whether the cost is still 1, so nothing
        # downstream would have caught it.
        if not self._can_act(battle, attacker.slot):
            return False

        # Amp stagger is a DELAY, not a veto: a duplicated carry holds while its own
        # debuff is still running with time to spare, then fires as that window is
        # about to lapse -- which extends the debuff rather than re-applying it into
        # itself. `_ready` carries that check, and the retire rule refuses to time out
        # on a member that is only being held, so the delay always resolves.
        if self._waiting_for_buffs(battle, attacker):
            return False

        if self.stagger_amp and self._amp_still_running(
            self._unit(battle, attacker.slot), battle, target, enemy_only=True
        ):
            return False

        if self._speed_held(battle, attacker):
            return False

        if self._late_held(battle, attacker.slot):
            return False

        if self._starves_lead(battle, gi):
            return False

        if self._queue_holds(battle, st, gi, attacker, target, now):
            return False

        st["fired"].add(attacker.slot)
        if getattr(attacker, "skill", None) is not None and self._is_buffer_cast(
            attacker
        ):
            # A support just cast; its effects land after its own delay and the
            # carries in this opening wait for them.
            _note_buff(st, battle, attacker)
        return True

    def _end_of_fight(
        self, battle: Any, attacker: Any, gi: int, now: float
    ) -> bool | None:
        """The final `end_dump` s spend everything; the cost-decay span before them
        holds. Returns the verdict inside those windows, None outside them."""
        left = battle.effective_time_limit - battle.current_time
        if left <= self.end_dump:
            # Orbs are worthless after the bell, so cost and beat stop mattering
            # -- but a nuke that lands before its buff does is still wasted, so
            # the dump keeps its own opening state purely to time that wait.
            dst = getattr(battle, "_group_st", None)
            if not isinstance(dst, dict) or not dst.get("dump"):
                dst = {"gi": -1, "fired": set(), "opened": now, "due": now}
                dst["dump"] = True
                battle._group_st = dst
            if self._waiting_for_buffs(battle, attacker):
                return False
            if not skill_flags(attacker.skill, attacker)["damage"]:
                # Buff once at cost 1, then nuke. A second buff inside one 8s
                # window only refreshes a buff that already outlasts the fight,
                # and it costs the orb a carry would have spent on damage
                # (measured -3.5%) -- so damage skills alone are allowed to
                # climb 1 -> 2 -> 3 here until the pool is empty.
                if attacker.slot in dst["fired"]:
                    return False
                if not self._cost_ready(attacker, battle):
                    return False
                dst["fired"].add(attacker.slot)
                _note_buff(dst, battle, attacker)
            elif self.amp_wait:
                # Carries fire in group order: one listed after an amp carry that
                # has not fired this dump waits for it, if it can come back in time.
                amp = dst.setdefault("amp_fired", set())
                g = self.groups[gi]
                for s_ in g[: g.index(attacker.slot)]:
                    u_ = self._unit(battle, s_)
                    if (
                        s_ not in amp
                        and self._eligible(battle, s_)
                        and skill_flags(u_.skill, u_)["damage"]
                        and skill_flags(u_.skill, u_)["debuff"]
                        and self._castable_in(battle, u_) < left - 1.0
                    ):
                        return False
                if skill_flags(attacker.skill, attacker)["debuff"]:
                    amp.add(attacker.slot)
                    _note_buff(dst, battle, attacker)  # next carry waits for it
            return True
        if left <= self.end_dump + float(
            getattr(battle.config, "skill_minus_cost_cd", 20.0) or 20.0
        ):
            return False  # hold: let every cost decay to 1 for the dump window
        return None

    def _retire_group(
        self, battle: Any, st: dict | None, target: Any, now: float
    ) -> dict | None:
        """Retire the active group once everyone eligible has fired, or once it has
        been stuck past skip_after (a chain-CC'd member must not lock the team out).
        Returns the group state still holding the floor, or None."""
        if st is None:
            return None
        members = [
            s
            for s in self.groups[st["gi"]]
            if self._eligible(battle, s) and s not in st["fired"]
        ]
        # A member that CAN act but is being held by the amp stagger is waiting on
        # purpose. Timing the group out on it is how the duplicate carry ended up
        # never casting at all, so the clock does not run against it.
        held = any(
            self._can_act(battle, s)
            and (
                not self._ready(battle, s, target) or bool(self._late_member(battle, s))
            )
            for s in members
        )
        if members and (now - st["opened"] <= self.skip_after or held):
            return st
        # Next opening is one cycle after the time this one was DUE, not after
        # the time it actually happened -- so a cycle that ran late does not
        # push every cycle after it.
        due = getattr(battle, "_group_due", None)
        if due is None:
            due = {}
            battle._group_due = due
        due[st["gi"]] = st.get("due", st["opened"]) + scaled_cycle(self.cycle, battle)
        battle._group_st = None
        return None

    def _open_group(self, battle: Any, now: float) -> dict | None:
        """No group active: open the highest-priority one whose LEAD member can act.

        Requiring every member to be ready simultaneously was too strong. Orb income
        is 1 per 5s -- 4 per 20s, enough to fund a four-card group each cycle -- but
        lockstep paced the group to its slowest member, so it fired 13 times instead
        of 17 and the pool sat pinned at its cap of 10 with the surplus evaporating.
        Opening on the lead card starts the window on time; the rest join as their
        turns come, and anyone CC'd or still paying an escalated cost is passed over
        rather than holding the window shut.
        """
        # Don't open a burst the pre-dump hold would cut short: its buffers cast,
        # then the hold strands the carries (2026-10-18 capture review: a burst
        # opened 28.5s out, two buffer casts went out with no nuke, P4 lost its
        # 18th cast). The player skips that burst and dumps instead.
        if self.end_dump:
            hold = self.end_dump + float(
                getattr(battle.config, "skill_minus_cost_cd", 20.0) or 20.0
            )
            if battle.effective_time_limit - now <= hold + self.skip_after:
                return None
        # No group holds the floor, so the timed buffs are down -- the only
        # moment the ramp-retire check reads a baseline rather than a peak.
        self._sample_capped(battle)
        due = getattr(battle, "_group_due", None)
        if due is None:
            due = {}
            battle._group_due = due
        cap = int(getattr(battle, "skill_points_max", 10) or 10)
        for i, g in enumerate(self.groups):
            elig = [s for s in g if self._eligible(battle, s)]
            if not elig:
                continue
            if now < due.get(i, self.offset.get(i, 0.0)):
                continue  # not yet on this group's beat
            # Opening sync: the group's lead block is everyone up to and including
            # its first damage dealer -- they must fire inside one buff window, so
            # do not open until the pool can fund all of them. Members after the
            # first nuke may lag; `_amp_still_running` and the player's own
            # ordering handle those.
            if battle.skill_points < min(self._lead_block(battle, i), cap):
                continue
            if self._starves_lead(battle, i):
                continue
            # Optional: wait out a CC'd member so the group fires whole, up to
            # `hold_cc` seconds past its due time. Off by default -- measured a
            # loss on every team tried, because boss CC recurs faster than the
            # rotation and the slid cycle never catches up.
            if self.hold_cc and now - due.get(i, now) < self.hold_cc:
                if any(
                    self._unit(battle, s_).is_cast_blocked(now)
                    for s_ in elig
                    if self._unit(battle, s_) is not None
                ):
                    continue
            if self.cc_dodge and next_cc_risk(battle, self.cc_dodge[0]) >= (
                self.cc_dodge[1]
            ):
                continue  # a CC cast is about to land: open just after it
            if self.cleanse_dodge:
                t_cl = next_cleanse_in(battle)
                if t_cl is not None and t_cl <= self.cleanse_dodge:
                    continue  # open just after the cleanse instead
            if self._can_act(battle, elig[0]):
                st = {"gi": i, "fired": set(), "opened": now, "due": due.get(i, now)}
                battle._group_st = st
                return st
        return None

    def _queue_holds(
        self, battle: Any, st: dict, gi: int, attacker: Any, target: Any, now: float
    ) -> bool:
        """Cast in the player's listed order within the group. An earlier member holds
        the queue only while it CAN act and simply has not had its turn yet -- one
        that is stunned, silenced or still paying an escalated cost is stepped over,
        so a single CC cannot cost the whole group its window."""
        for s in self.groups[gi]:
            if s == attacker.slot:
                return False
            if s in st["fired"] or not self._eligible(battle, s):
                continue
            su = self._unit(battle, s)
            if (
                self.buffer_wait
                and not self._ready(battle, s, target)
                and self._is_buffer_cast(su)
                and not self._speed_held(battle, su)  # held on purpose: don't wait
                and skill_flags(attacker.skill, attacker)["damage"]
                and now - st["opened"] < self.buffer_wait
                and self._castable_in(battle, su) <= self.buffer_wait
            ):
                return True  # hold for a buffer that will be back within the window
            if (
                self.cc_mid != "skip"
                and su.is_cast_blocked(now)
                and not skill_flags(su.skill, su)["damage"]
            ):
                if self.cc_mid == "drop":
                    st["fired"].add(s)  # gives up this opening's cast
                    continue
                if now - st["opened"] < self.cc_wait:
                    return True  # wait: hold the queue for the CC'd buffer
                continue
            if not self._ready(battle, s, target):
                continue  # blocked or deliberately held -- step over it
            return True  # an earlier member still owes its cast
        return False
