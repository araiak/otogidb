"""
Data models for the Otogi Battle Simulator.

These dataclasses represent battle entities and calculation results.
"""

from dataclasses import dataclass, field
from typing import List, Optional
from enum import Enum


class ActionType(Enum):
    """Type of attack action."""

    NORMAL = "normal"
    SKILL = "skill"


class CritType(Enum):
    """Critical hit type."""

    NONE = 0
    NORMAL = 1  # 2x multiplier (validated)
    SUPER = 2  # 4x multiplier [ASSUMPTION:SUPER_CRIT]


@dataclass
class Modifiers:
    """
    Stat modifiers from abilities, skills, and buffs.

    All values are percentages (0.17 = +17%).
    Modifiers stack ADDITIVELY (observed in game).
    """

    damage: float = 0.0  # General damage bucket
    skill: float = 0.0  # Skill-only damage bucket
    normal: float = 0.0  # Normal-attack-only damage bucket
    crit_rate: float = 0.0  # Crit rate bonus
    crit_dmg: float = 0.0  # Crit damage bucket
    shield: float = 0.0  # Damage reduction
    speed: float = 0.0  # Attack speed modifier
    defense: float = 0.0  # Flat points subtracted from a hit, applied last


@dataclass(slots=True)
class DamageResult:
    """
    Result of a damage calculation with full breakdown.

    Shows each step in the damage pipeline for debugging.
    """

    # Final result
    final_damage: int = 0
    was_capped: bool = False
    cap_applied: Optional[int] = None

    # Step-by-step breakdown
    base_damage: float = 0  # ATK * 1.0 (or skill base)
    after_exceed: float = 0  # After LB bonus
    after_combo: float = 0  # After combo bonus
    after_modifiers: float = 0  # After damage/skill/normal mods
    after_crit: float = 0  # After crit multiplier
    after_type_mod: float = 0  # After normal/skill specific mods
    after_shield: float = 0  # After shield reduction
    after_defense: float = 0  # After defense reduction

    # Multipliers applied
    exceed_mult: float = 1.0
    combo_mult: float = 1.0
    modifier_mult: float = 1.0  # General damage bucket
    crit_mult: float = 1.0
    crit_dmg_mult: float = 1.0  # Crit damage mod
    skill_dmg_mult: float = 1.0  # Skill damage mod
    normal_dmg_mult: float = 1.0  # Normal damage mod
    defense_mult: float = 1.0  # Derived only; defense is not really a multiplier
    defense_flat: float = 0.0  # Defense is a FLAT SUBTRACTION (live-verified, V21)
    shield_mult: float = 1.0  # 1 - shield%

    # Assumption tracking
    assumptions_used: List[str] = field(default_factory=list)

    def add_assumption(self, assumption: str):
        """Track that an assumption was used in this calculation."""
        if assumption not in self.assumptions_used:
            self.assumptions_used.append(assumption)
