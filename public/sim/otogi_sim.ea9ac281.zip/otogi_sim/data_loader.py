"""
Data loader for the Otogi Battle Simulator.

Loads card, skill, ability, and constant data from JSON files.
Provides factory methods to build MonsterModel instances.
"""

import json
import re
from pathlib import Path
from typing import Dict, Optional, Any, List
from dataclasses import dataclass, field

from .constants import REPO_ROOT
from .lifecycle import MonsterModel, Bond, BondType, make_assist_bond


def ie_damage(ie: str) -> tuple[int, int]:
    """``"ATK<2400,70>"`` -> ``(2400, 70)``: a skill's damage base and per-level scale.

    Reads the FIRST ``;`` token; a non-damage `ie` (none, HEAL, a %-buff) gives
    ``(0, 0)``. Measured in play for both card skills (2026-09-30, see
    ``skill_from_raw``) and world-boss skills (2026-09-09: ATK<1000> hit for 1000,
    ATK<6000> for 6000).
    """
    if not ie or ie == "none":
        return (0, 0)
    head = ie.split(";")[0].strip()
    m = re.match(r"ATK<(-?[\d.]+),(-?[\d.]+)>$", head)
    if not m:  # a percentage is a self-buff, not damage
        return (0, 0)
    return (int(float(m.group(1))), int(float(m.group(2))))


@dataclass
class SkillData:
    """Parsed skill data."""

    id: int
    slv1: int  # Base damage at skill level 1
    slvup: int  # Damage increase per skill level
    target_count: int  # Number of targets
    target_selector: str  # Targeting pattern
    effects: List[str]  # Raw effect strings from 'de' (for backwards compat)
    max_level: int = 70

    # Parsed targeting info
    target_type: str = "enemy"  # "self" for buff skills, "enemy" for damage
    target_filter: Optional[str] = None  # type<N>, prof<N>, etc.

    # Separate effect lists for proper targeting
    debuff_effects: List[str] = field(
        default_factory=list
    )  # 'de' field - applied to enemy
    buff_effects: List[str] = field(
        default_factory=list
    )  # 'ie' field - applied to self/allies

    # What the skill does the instant it is cast, from the HEAD of 'ie':
    #   ATK<base,scale>   -> damage        (558 skills)
    #   HEAL<base,scale>  -> healing       (148 skills)
    #   none              -> nothing       (290 skills)
    # A skill with no ATK head deals NO damage. The engine used to take
    # slv1 + (level-1)*slvup as damage for every cast regardless, which gave 438
    # of 996 skills damage the data does not give them. Orihime is the clean
    # example: ie='none', ts='self;count<2>;max_atk' (ALLIES), de='ATK<35%,1.01%,8>'.
    # Her skill is a pure buff, and the phantom hit would have landed on her own
    # team, since the team is what her targeting selects.
    immediate: str = "none"

    @property
    def deals_damage(self) -> bool:
        """Does casting this skill do direct damage? Gated on `ie`, not on slv1."""
        return self.immediate == "ATK"

    def calculate_damage(self, card_level: int) -> int:
        """
        Calculate skill damage at given level.

        Formula: slv1 + (level - 1) * slvup, where for a damage skill slv1/slvup
        hold the `ie` ATK<base,scale> numbers (see ``ie_damage``), NOT the raw
        config columns of the same name.
        """
        return self.slv1 + (card_level - 1) * self.slvup

    @property
    def is_buff_skill(self) -> bool:
        """Check if this skill buffs allies (vs damaging enemies)."""
        return self.target_type == "self"

    @property
    def has_buff_effects(self) -> bool:
        """Check if skill has buff effects to apply (from ie field)."""
        buff_types = [
            "ATK<",
            "CHIT<",
            "SHIELD<",
            "SPD<",
            "HP<",
            "SKILL_ATK<",
            "NORM_ATK<",
        ]
        return any(any(bt in e for bt in buff_types) for e in self.buff_effects)

    @property
    def has_debuff_effects(self) -> bool:
        """Check if skill has debuff effects to apply to enemy (from de field)."""
        # Any de effect is a debuff - including negative SHIELD (damage amp)
        return len(self.debuff_effects) > 0


@dataclass
class AbilityData:
    """Parsed ability data."""

    id: int
    trigger: str  # entry, entry_wave, attack_normal, etc.
    target_selector: str  # self_ime, self;type<1>;count<5>, etc.
    effects: List[Dict[str, Any]]  # Parsed effects
    unlock_level: int = 1
    is_overlay: bool = False  # Whether it stacks with same ability

    @property
    def is_entry_ability(self) -> bool:
        """Check if this is an entry ability (applied during init)."""
        return self.trigger in ("entry", "entry_leader")

    @property
    def is_wave_ability(self) -> bool:
        """Check if this is a wave-start ability."""
        return self.trigger in ("entry_wave", "last_wave")

    @property
    def is_attack_ability(self) -> bool:
        """Check if this triggers on attack."""
        return self.trigger in ("attack_normal", "attack_skill")


@dataclass
class GameConstants:
    """Game constants for damage calculation."""

    # Combo bonuses (validated)
    combo_bonus: Dict[int, float] = field(
        default_factory=lambda: {1: 0.0, 2: 0.05, 3: 0.10, 4: 0.20, 5: 0.30}
    )

    # Crit multipliers (validated: normal=2x, super=4x but disabled)
    crit_normal: float = 2.0
    crit_super: float = 4.0
    crit_super_rate: float = 0.0  # Disabled

    # LB exceed bonus (5% per LB level, random 0 to max)
    lb_exceed_rate: float = 0.05

    # Caps
    crit_max: float = 1.0  # 100% crit rate cap
    shield_max: float = 0.85  # 85% damage reduction cap
    shield_min: float = -0.75  # Negative shield (increased damage)
    damage_max: int = 99999  # Player normal attack cap (display)
    skill_damage_max: int = 999999  # Skill damage cap (display)

    # Energy system (confirmed in game)
    skill_energy_min: int = 5
    skill_energy_max: int = 18
    skill_energy_damage_mult: int = 10
    skill_energy_kill: int = 20
    skill_energy_wave_end: int = 10

    # Skill cost escalation
    skill_minus_cost_cd: float = 20.0  # Seconds before cost decreases

    # Team bonuses
    race_above_leader: float = 0.10
    race_above_per_member: float = 0.05
    race_above_per_assist: float = 0.05

    # Wave recovery
    wave_recover: float = 0.05  # 5% HP recovery between waves


class GameDataLoader:
    """
    Loads and caches game data from JSON files.

    Usage:
        loader = GameDataLoader()
        loader.load_all()
        card = loader.get_card(1)
        model = loader.build_monster_model(1, level=90, lb_level=4)
    """

    def __init__(self, data_dir: Optional[Path] = None):
        """
        Initialize the data loader.

        Args:
            data_dir: Path to data directory. Defaults to output/data/
        """
        if data_dir is None:
            # Default to output/data relative to this file
            self.data_dir = REPO_ROOT / "output" / "data"
        else:
            self.data_dir = Path(data_dir)

        self._cards: Dict[str, dict] = {}
        self._skills: Dict[str, dict] = {}
        self._abilities: Dict[str, dict] = {}
        self._constants: Dict[str, str] = {}
        self._wb_levels: List[dict] = []
        self._wb_skills: List[dict] = []
        self._loaded = False

    def load_all(self) -> None:
        """Load all game data files."""
        if self._loaded:
            return

        self._load_cards()
        self._load_skills()
        self._load_abilities()
        self._load_constants()
        self._load_world_boss()
        self._load_anim_frames()
        self._loaded = True

    def _load_cards(self) -> None:
        """Load cards.json."""
        cards_path = self.data_dir / "cards.json"
        if cards_path.exists():
            with open(cards_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                self._cards = data.get("cards", {})

    def _load_skills(self) -> None:
        """Load skills.json."""
        skills_path = self.data_dir / "skills.json"
        if skills_path.exists():
            with open(skills_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                self._skills = data.get("skills", {})

    def _load_abilities(self) -> None:
        """Load abilities.json."""
        abilities_path = self.data_dir / "abilities.json"
        if abilities_path.exists():
            with open(abilities_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                self._abilities = data.get("abilities", {})

    def _load_constants(self) -> None:
        """Load constants.json."""
        constants_path = self.data_dir / "constants.json"
        if constants_path.exists():
            with open(constants_path, "r", encoding="utf-8") as f:
                self._constants = json.load(f)

    def _load_world_boss(self) -> None:
        """Load wbLv.json / wbSkill.json (world boss levels and skills)."""
        for name, attr in (("wbLv", "_wb_levels"), ("wbSkill", "_wb_skills")):
            path = self.data_dir / f"{name}.json"
            if path.exists():
                with open(path, "r", encoding="utf-8") as f:
                    setattr(self, attr, json.load(f))

    def _load_anim_frames(self) -> None:
        """Load anim_frames.json (per-card animation hit frames; optional)."""
        path = self.data_dir / "anim_frames.json"
        self._anim_frames: dict = {}
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                self._anim_frames = json.load(f)

    def auto_frame(self, card_id: int, unit_type: int) -> Optional[float]:
        """The card's auto-attack hit frame, or its role's average if unseen.

        Healers have no auto action in the assets, so they get None, as does
        everything when the table is absent.
        """
        self.load_all()
        table = getattr(self, "_anim_frames", None) or {}
        card = (table.get("cards") or {}).get(str(card_id))
        if card is not None:
            return card.get("auto_frame")
        role = {1: "melee", 2: "ranged"}.get(unit_type)
        default = (table.get("role_defaults") or {}).get(role or "") or {}
        return default.get("auto_frame")

    def boss_cast_timing(self, boss_id: int) -> dict:
        """World-boss skill id -> extracted cast timing (anim_frames.json "bosses")."""
        self.load_all()
        table = getattr(self, "_anim_frames", None) or {}
        raw = (table.get("bosses") or {}).get(str(boss_id)) or {}
        return {int(k): v for k, v in raw.items()}

    def skill_time_attack(self, card_id: int, unit_type: int) -> Optional[float]:
        """Cast -> effect delay from the card's skill effect asset, else role average."""
        self.load_all()
        table = getattr(self, "_anim_frames", None) or {}
        card = (table.get("cards") or {}).get(str(card_id)) or {}
        if "skill_time_attack" in card:
            return card["skill_time_attack"]
        role = {1: "melee", 2: "ranged", 3: "healer"}.get(unit_type)
        if card and role in ("melee", "ranged"):
            role = "melee" if card.get("melee") else "ranged"
        default = (table.get("role_defaults") or {}).get(role or "") or {}
        return default.get("skill_time_attack")

    def get_wb_level(self, boss_id: int, level: int) -> Optional[dict]:
        """Raw wbLv row for (bossId, bossLv)."""
        self.load_all()
        for row in self._wb_levels:
            if (
                str(row.get("bossId")) == str(boss_id)
                and int(row.get("bossLv", 0)) == level
            ):
                return row
        return None

    def get_wb_skills(self, boss_id: int) -> Dict[int, dict]:
        """Raw wbSkill rows for one boss, keyed by skillId (1-5)."""
        self.load_all()
        return {
            int(r["skillId"]): r
            for r in self._wb_skills
            if str(r.get("bid")) == str(boss_id)
        }

    # Card access methods
    def get_card(self, card_id: int) -> Optional[dict]:
        """Get raw card data by ID."""
        self.load_all()
        return self._cards.get(str(card_id))

    def get_all_cards(self) -> Dict[str, dict]:
        """Get all cards."""
        self.load_all()
        return self._cards

    # Skill access methods
    def get_skill(self, skill_id: int) -> Optional[dict]:
        """Get raw skill data by ID."""
        self.load_all()
        return self._skills.get(str(skill_id))

    def parse_skill(self, skill_id: int) -> Optional[SkillData]:
        """Parse skill into SkillData object."""
        raw = self.get_skill(skill_id)
        if raw is None:
            return None
        return self.skill_from_raw(skill_id, raw)

    def skill_from_raw(self, skill_id: int, raw: dict) -> SkillData:
        """Build SkillData from a raw skill row.

        Split out of parse_skill so world-boss skills (wbSkill.json, same
        ie/ts/de grammar but a separate id namespace) go through one parser
        instead of a second copy.
        """
        # Parse debuff effects from 'de' field - applied to enemy target
        debuff_effects = []
        de = raw.get("de", "none")
        if de and de != "none":
            debuff_effects = [e.strip() for e in de.split(";") if e.strip()]

        # Parse buff effects from 'ie' field - applied to self/allies
        # Note: For damage skills, ie usually contains ATK<base,scale> for damage calc
        # But some skills have buff components like ATK<10%> buffs
        buff_effects = []
        ie = raw.get("ie", "none")
        # The head of `ie` before '<' is the immediate effect type. A '%' means the
        # token is a buff, not an immediate payload, so it does not count as one.
        immediate = "none"
        if ie and ie != "none":
            head = ie.split(";")[0].strip()
            if "<" in head and "%" not in head.split("<", 1)[1].split(",")[0]:
                immediate = head.split("<", 1)[0].strip()
        if ie and ie != "none":
            # Parse ie for non-damage buff effects (those with % sign are buffs)
            for part in ie.split(";"):
                part = part.strip()
                if not part:
                    continue
                # Skip pure damage (ATK<2200,61> without % is damage)
                # Buff effects have % like ATK<10.00%,0.50%,8>
                if "%" in part:
                    buff_effects.append(part)

        ie_dmg = ie_damage(ie)

        # Parse target selector
        ts = raw.get("ts", "current_target")
        target_type = "enemy"  # Default to enemy targeting
        target_filter = None

        if ts.startswith("self"):
            target_type = "self"

        # Extract filter (type<N>, prof<N>, sort, etc.)
        # Collect all filter parts into a list to avoid overwriting earlier parts
        # (e.g. "self;type<1>;count<2>;max_atk" must keep both type<1> and max_atk).
        filter_parts: list[str] = []
        for part in ts.split(";"):
            if part.startswith("type<") or part.startswith("prof<"):
                filter_parts.append(part)
            elif "max_atk" in part or "min_hp" in part or "max_hp" in part:
                filter_parts.append(part)
        target_filter = ";".join(filter_parts) if filter_parts else None

        return SkillData(
            id=skill_id,
            # A damage skill's value is its `ie` ATK<base,scale>. Observed in play
            # 2026-09-30: Dora 1651 entered the pipeline at 8630 = 2400 + 70*89 and
            # Cao Cao 738 at 3581 = 1000 + 29*89, and the Lv90 Dora card screen
            # shows 9147 = 8630 x 1.06 skill bond. The config's own slv1/slvup
            # columns (5583/64 for Dora) fit no level and are not the damage value.
            # Non-damage skills keep them (only the heal path reads those; unverified).
            slv1=(ie_dmg[0] if immediate == "ATK" else raw.get("slv1", 0)),
            slvup=(ie_dmg[1] if immediate == "ATK" else raw.get("slvup", 0)),
            target_count=raw.get("tn", 1),
            target_selector=ts,
            effects=debuff_effects,  # Backwards compat
            max_level=raw.get("ml", 70),
            target_type=target_type,
            target_filter=target_filter,
            debuff_effects=debuff_effects,
            buff_effects=buff_effects,
            immediate=immediate,
        )

    # Ability access methods
    @property
    def abilities(self) -> Dict[str, dict]:
        """Raw abilities table, loaded on first access.

        Read this, never `_abilities`: loading REPLACES the dict, so a reference
        taken before the first load stays empty (every spawned worker's first
        battle ran with no abilities that way).
        """
        self.load_all()
        return self._abilities

    def get_ability(self, ability_id: int) -> Optional[dict]:
        """Get raw ability data by ID."""
        self.load_all()
        return self._abilities.get(str(ability_id))

    def parse_ability(self, ability_id: int) -> Optional[AbilityData]:
        """Parse ability into AbilityData object."""
        raw = self.get_ability(ability_id)
        if raw is None:
            return None

        effects = self._parse_effect_string(raw.get("de", ""))

        return AbilityData(
            id=ability_id,
            trigger=raw.get("er", "entry"),
            target_selector=raw.get("ts", "self_ime"),
            effects=effects,
            unlock_level=raw.get("ul", 1),
            is_overlay=raw.get("o", False),
        )

    def _parse_effect_string(self, effect_str: str) -> List[Dict[str, Any]]:
        """
        Parse effect string into structured data.

        Examples:
            "CHIT<15.00%,0%>" -> [{"type": "CHIT", "value": 15.0, "scale": 0.0}]
            "ATK<5.00%,0%>" -> [{"type": "ATK", "value": 5.0, "scale": 0.0}]
            "HPP_IN<0.00%,10.00%>;SHIELD<90.00%,0%>" -> multiple effects
        """
        if not effect_str or effect_str == "none":
            return []

        effects = []
        parts = effect_str.split(";")

        for part in parts:
            if "<" not in part:
                continue

            # Parse "TYPE<value,scale>"
            type_end = part.index("<")
            effect_type = part[:type_end]
            values_str = part[type_end + 1 : -1]  # Remove < and >

            values = values_str.split(",")
            value = self._parse_percentage(values[0]) if values else 0.0
            scale = self._parse_percentage(values[1]) if len(values) > 1 else 0.0

            effects.append({"type": effect_type, "value": value, "scale": scale})

        return effects

    def _parse_percentage(self, s: str) -> float:
        """Parse percentage string like '15.00%' to float 15.0."""
        s = s.strip()
        if s.endswith("%"):
            return float(s[:-1])
        return float(s)

    # Constants access
    def get_constant(self, key: str, default: str = "0") -> str:
        """Get raw constant value."""
        self.load_all()
        return self._constants.get(key, default)

    def get_constant_float(self, key: str, default: float = 0.0) -> float:
        """Get constant as float."""
        value = self.get_constant(key, str(default))
        try:
            return float(value.replace("%", ""))
        except ValueError:
            return default

    # MonsterModel factory
    def build_monster_model(
        self,
        card_id: int,
        level: Optional[int] = None,
        lb_level: int = 0,
        bond_bonus: float = 0.0,
    ) -> Optional[MonsterModel]:
        """
        Build a MonsterModel from card data.

        Args:
            card_id: Card ID to load
            level: Card level (defaults to max level)
            lb_level: Limit break level (0-4, max MLB)
            bond_bonus: Bond bonus percentage (0-100 scale)

        Returns:
            MonsterModel instance or None if card not found
        """
        card_data = self.get_card(card_id)
        if card_data is None:
            return None

        # Default to max level if not specified
        if level is None:
            level = card_data.get("stats", {}).get("max_level", 70)

        model = MonsterModel.calculate_from_card(card_data, level, lb_level, bond_bonus)
        model.auto_frame = self.auto_frame(card_id, model.unit_type)
        model.skill_time_attack = self.skill_time_attack(card_id, model.unit_type)
        return model

    def build_team(
        self,
        card_ids: List[int],
        levels: Optional[List[int]] = None,
        lb_levels: Optional[List[int]] = None,
    ) -> List[MonsterModel]:
        """
        Build a team of MonsterModels.

        Args:
            card_ids: List of card IDs
            levels: Optional list of levels (defaults to max)
            lb_levels: Optional list of LB levels (defaults to 0)

        Returns:
            List of MonsterModel instances
        """
        team = []

        for i, card_id in enumerate(card_ids):
            level = levels[i] if levels and i < len(levels) else None
            lb = lb_levels[i] if lb_levels and i < len(lb_levels) else 0

            model = self.build_monster_model(card_id, level, lb)
            if model:
                team.append(model)

        return team

    def player_level_cap(self, card_id: int, lb_level: int) -> int:
        """Highest level a PLAYER can take this card to: cards.json max_level is the
        pre-limit-break cap and each LB adds 5 (5★ 70->90, 4★ 60->80, 3★ 50->70 at
        LB4; Orpheus observed Lv70 at LB0, 2026-10-01). Enemies are not bound by it
        -- content levels build mobs past 100 -- so only player paths clamp."""
        card = self.get_card(card_id) or {}
        return card.get("stats", {}).get("max_level", 70) + 5 * lb_level

    def build_team_with_assists(
        self,
        card_ids: List[int],
        assist_ids: Optional[List[int]] = None,
        levels: Optional[List[int]] = None,
        lb_levels: Optional[List[int]] = None,
    ) -> List[MonsterModel]:
        """
        Build a team with assist bonds applied to each card.

        Each assist card's abilities are transferred to the host via an assist Bond,
        matching the pattern used by benchmark.py and monte_carlo.py.

        Args:
            card_ids: Main team card IDs
            assist_ids: Parallel list of assist card IDs (0 or None = no assist)
            levels: Card levels (defaults to max)
            lb_levels: LB levels (defaults to 4 for MLB)
        """
        team = []
        for i, card_id in enumerate(card_ids):
            level = levels[i] if levels and i < len(levels) else None
            lb = lb_levels[i] if lb_levels and i < len(lb_levels) else 4

            if level is not None:
                level = min(level, self.player_level_cap(card_id, lb))
            model = self.build_monster_model(card_id, level, lb)
            if model is None:
                continue

            assist_id = assist_ids[i] if assist_ids and i < len(assist_ids) else 0
            if assist_id:
                assist_model = self.build_monster_model(assist_id, level, lb)
                if assist_model:
                    model.bonds.append(
                        make_assist_bond(
                            assist_model.card_id,
                            assist_model.rarity,
                            assist_model.unit_type,
                            assist_model.attribute,
                            assist_model.ability_ids,
                            assist_model.bond_grant,
                        )
                    )

            team.append(model)
        return team


# Global singleton for convenience
_loader: Optional[GameDataLoader] = None


def get_loader() -> GameDataLoader:
    """Get the global data loader instance."""
    global _loader
    if _loader is None:
        _loader = GameDataLoader()
    return _loader


def set_loader(loader: Optional[GameDataLoader]) -> None:
    """Point the process-wide singleton at a specific loader (None resets it).

    Mirrors ``apl.engine.set_engine``. This is NOT redundant with passing ``loader=``
    to ``spec.simulate``: ``modes.DamageBenchmark`` resolves its own loader via
    ``get_loader()``, so a caller whose data lives somewhere other than
    ``REPO_ROOT/output/data`` must set the singleton too. Skipping it does not raise
    -- the models build fine and every unit silently comes out with no skill, which
    scores about a third of the real number.
    """
    global _loader
    _loader = loader


# Convenience functions
def get_card(card_id: int) -> Optional[dict]:
    """Get card data by ID."""
    return get_loader().get_card(card_id)


def get_skill(skill_id: int) -> Optional[SkillData]:
    """Get parsed skill data by ID."""
    return get_loader().parse_skill(skill_id)


def get_ability(ability_id: int) -> Optional[AbilityData]:
    """Get parsed ability data by ID."""
    return get_loader().parse_ability(ability_id)


def build_monster(
    card_id: int, level: Optional[int] = None, lb_level: int = 0
) -> Optional[MonsterModel]:
    """Build a MonsterModel from card ID."""
    return get_loader().build_monster_model(card_id, level, lb_level)
