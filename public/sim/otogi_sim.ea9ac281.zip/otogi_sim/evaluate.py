"""Turning a team into a score.

The single place the search converts a candidate into a number. Everything above it
(sampling, GA, sweeps) only decides *which* teams to ask about; this decides what
they are worth, so a defect here moves every result at once.

Two properties matter more than they look:

* **The battle itself is not built here.** Benchmark mode delegates to
  ``modes.run_benchmark_battle``, shared with DamageBenchmark and apl.inspect. When
  this module owned a private copy, the copies drifted and the same team scored ~2x
  apart depending on the caller.
* **CRN (common random numbers).** Iteration *i* is seeded identically for every
  team, so the variance of score *differences* collapses even though absolute
  scores stay noisy. That is what makes A/B comparisons cheap. MC_CRN=0 restores
  independent noise when you want true per-team sd.
"""

from __future__ import annotations

import copy
import os
import random
from statistics import mean, stdev

from .assists import AssistPool
from .constants import SLOT_ACTIVE, SLOT_HELPER, SLOT_RESERVE
from .data_loader import get_loader
from .lifecycle import MonsterModel
from .modes import run_benchmark_battle
from .pool import CardPool
from .worldboss import BossSpec
from .team import SlotKey, Team


def _run_team_battles(
    team: "Team",
    n_iters: int,
    pool: CardPool,
    mode: str = "benchmark",
    benchmark_time: float = 60.0,
    assists: "dict[SlotKey, int] | None" = None,
    assist_pool: "AssistPool | None" = None,
    score_threshold: float = 0.0,
    out_stats: "dict | None" = None,
    check_at: float = 0.0,
    check_min: "list[float] | None" = None,
    check_out: "list[float] | None" = None,
    bonds: tuple = (),
) -> tuple[float, float]:
    """
    Run n_iters battles for a team. Thread-safe (creates fresh objects each call).

    benchmark mode
        Immortal 100M HP target, score = total player damage over benchmark_time
        seconds.  No overkill inflation — every damage point is real DPS.

    assists
        Optional dict mapping SlotKey -> assist_card_id.  When provided with a
        non-None assist_pool, the matching MonsterModel is rebuilt with the assist
        bond applied so its transferred ability fires during the battle.

    bonds
        Free-slot bonds per row, TeamSpec.bonds layout (4 active, helper, then
        reserves), e.g. (("normal", 7.5), ("normal", 7.5)). Applied to COPIES:
        pool models are cached and shared across battles.

    check_at / check_min / check_out
        Paired early stop (benchmark mode): iteration k stops at ``check_at``
        seconds if its damage is below ``check_min[k]``, and then the whole call
        returns 0 -- the trial lost. Damage at ``check_at`` is appended to
        ``check_out`` so the caller can keep the incumbent's curve.
    """
    models = _build_team_models(team, pool, assists, assist_pool, bonds)
    if models is None:
        return 0.0, 0.0
    player_models, reserve_models = models
    ability_data = get_loader().abilities

    # Common Random Numbers (CRN): seed the global RNG per iteration index with a
    # base constant that is the same for every team, so iteration k replays the
    # identical crit/proc/stagger stream for all teams. This scores every team on
    # the same luck -> the variance of *score differences* (what ranking cares
    # about) collapses, and battles become reproducible run-to-run and
    # worker-count-independent. Read live (like the abort vars) so tests/analysis
    # can flip it. MC_CRN=0 restores independent noise (for true per-team sd).
    # ponytail: partial CRN — teams consume different draw counts, so the shared
    # stream desyncs mid-battle (strong early, decaying). If measurement shows
    # that's not enough, upgrade to per-unit random.Random substreams keyed by slot.
    crn_seed = (
        int(os.environ.get("MC_CRN_SEED", "12345"))
        if os.environ.get("MC_CRN", "1") != "0"
        else None
    )

    if mode == "benchmark":
        scores = _benchmark_scores(
            player_models,
            reserve_models,
            ability_data,
            n_iters,
            crn_seed,
            benchmark_time=benchmark_time,
            score_threshold=score_threshold,
            out_stats=out_stats,
            check_at=check_at,
            check_min=check_min,
            check_out=check_out,
            boss=pool.boss,
        )
        if scores is None:
            return 0.0, 0.0  # stopped at check_at: behind the incumbent
    else:
        raise ValueError(f"unknown scoring mode {mode!r}")

    avg = mean(scores) if scores else 0.0
    sd = stdev(scores) if len(scores) > 1 else 0.0
    return avg, sd


def _build_team_models(
    team: "Team",
    pool: CardPool,
    assists: "dict[SlotKey, int] | None",
    assist_pool: "AssistPool | None",
    bonds: tuple,
) -> "tuple[list[MonsterModel], list[MonsterModel]] | None":
    """(active + helper models, reserve models), assists and bonds applied.

    None when an active or helper card is missing from the pool; a missing
    reserve is just left out.
    """

    def _maybe_assist(slot: SlotKey, m: MonsterModel) -> MonsterModel:
        if assists and assist_pool and slot in assists:
            ac = assist_pool.cards.get(assists[slot])
            if ac is not None:
                return assist_pool.build_assisted_model(m, ac)
        return m

    # Iterate by slot so helper can have its own assist independent of any
    # active-slot duplicate.
    player_models: list[MonsterModel] = []
    for i, cid in enumerate(team.active):
        m = pool.get_model(cid)
        if m is None:
            return None
        player_models.append(_maybe_assist((SLOT_ACTIVE, i), m))

    helper_model = pool.get_model(team.helper)
    if helper_model is None:
        return None
    player_models.append(_maybe_assist((SLOT_HELPER, 0), helper_model))

    reserve_models: list[MonsterModel] = []
    for i, cid in enumerate(team.reserve):
        m = pool.get_model(cid)
        if m is not None:
            reserve_models.append(_maybe_assist((SLOT_RESERVE, i), m))

    if any(bonds):
        from .spec import _apply_bonds

        rows = [copy.copy(m) for m in player_models + reserve_models]
        for m in rows:
            m.bonds = list(m.bonds)
        _apply_bonds(rows, bonds)
        n = len(player_models)
        player_models, reserve_models = rows[:n], rows[n:]

    return player_models, reserve_models


def _benchmark_scores(
    player_models: list[MonsterModel],
    reserve_models: list[MonsterModel],
    ability_data: dict,
    n_iters: int,
    crn_seed: "int | None",
    *,
    benchmark_time: float,
    score_threshold: float,
    out_stats: "dict | None",
    check_at: float,
    check_min: "list[float] | None",
    check_out: "list[float] | None",
    boss: "BossSpec | None",
) -> "list[float] | None":
    """World-boss DPS vs an immortal target, one score per iteration.

    None when an iteration fell behind ``check_min`` at ``check_at``.
    """
    # Aggressive early-abort (opt-in, for the Cadence exploratory search): most
    # teams' carries never clear the crit floor, so they crawl at the ~auto-attack
    # pace. Kill anything not on track for MC_ABORT_PACE final damage by
    # MC_ABORT_AT of the window, so duds cost a fraction of a full battle and we
    # sample far more teams. Off by default (default runs are unaffected).
    abort_pace = float(os.environ.get("MC_ABORT_PACE", "0") or "0")
    abort_at = float(os.environ.get("MC_ABORT_AT", "0.25") or "0.25")

    # The battle itself lives in modes.run_benchmark_battle, shared with
    # DamageBenchmark so both harnesses score a team identically. They used
    # to each own a copy of this loop and silently drifted ~2x apart.
    scores: list[float] = []
    for it in range(n_iters):
        if crn_seed is not None:
            random.seed(crn_seed + it)
        battle = run_benchmark_battle(
            player_models=player_models,
            ability_data=ability_data,
            reserve_models=reserve_models or None,
            benchmark_time=benchmark_time,
            score_threshold=score_threshold,
            check_at=check_at,
            check_min=check_min[it] if check_min else 0.0,
            check_out=check_out,
            abort_pace=abort_pace,
            abort_at=abort_at,
            boss=boss,
        )
        if check_min and battle.player_damage_total < check_min[it]:
            return None
        scores.append(battle.player_damage_total)
        if out_stats is not None:
            # Survivability, only meaningful in boss mode: against the
            # immortal dummy nobody can die, so these are constant.
            out_stats.setdefault("wipes", 0)
            out_stats.setdefault("deaths", [])
            out_stats.setdefault("survival", [])
            if not any(p.is_alive for p in battle.players):
                out_stats["wipes"] += 1
            out_stats["deaths"].append(sum(1 for p in battle.players if not p.is_alive))
            out_stats["survival"].append(battle.current_time)
    return scores


# ---------------------------------------------------------------------------
# Shapley estimator
# ---------------------------------------------------------------------------
