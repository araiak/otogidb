"""ChainScheduler and TimelineScheduler: back-to-back amp chains and fixed cast timelines."""

from __future__ import annotations

from typing import Any
from ..scheduler import ROTATION_DUMP, derive_chain, scaled_cycle
from .cadence import CadenceScheduler


class ChainScheduler(CadenceScheduler):
    """Back-to-back debuff chain: each link refreshes the damage-up as the last expires.

    The Assassination-rogue model: keep one damage window up permanently instead of
    bursting everything into one window. ``links`` is the chain in order, e.g.
    ``[["P2", "P4"], ["P3"], ["P5"]]`` -- Senji buffs, Dora casts her amp, then each
    Andromeda's amp follows. Link k is due ``k * gap`` after the chain's anchor, and the
    anchor advances on a fixed ``cycle`` grid (orb-bound, scaled to regen) so small
    per-cast slips do not pile up. Members of a link fire in listed order, each after
    the previous member's effect has landed (a buffer first, so the carry casts inside
    it). Slots in no link never cast except in the end dump.

    A link that cannot fire within ``late`` seconds of its due time has broken the
    chain (CC, orb shortage). ``restart="clean"`` abandons the rest of the chain and
    pools until ``pool`` orbs are banked and every link-0 member is back to cost 1,
    then re-anchors on a fresh chain; ``restart="slip"`` keeps going from the late link.
    """

    def __init__(
        self,
        links: list[list[str]] | None = None,
        gap: float = 0.0,
        cycle: float = 20.5,
        late: float = 4.0,
        restart: str = "clean",
        pool: int = 2,
        end_dump: float = 8.0,
        spare: int = 0,
    ) -> None:
        super().__init__(cycle=cycle, end_dump=end_dump)
        # links=None derives the chain from the team's kit (``derive_chain``); gap 0
        # uses the derived amp duration.
        self.links = [list(link) for link in links] if links else None
        self.gap, self.late = gap, late
        self.restart, self.pool = restart, pool
        # Orbs at or above this let an off-chain caster (a team buffer) cast; 0 = never.
        self.spare = spare

    def _st(self, battle: Any) -> dict:
        st = getattr(battle, "_chain_st", None)
        if st is None:
            links, gap = derive_chain(list(battle.players))
            links = self.links or links
            st = {"anchor": 0.0, "link": 0, "fired": [], "land": 0.0}
            st.update(idle=True, breaks=0, links=links, gap=self.gap or gap or 8.0)
            st["link_of"] = {s: i for i, link in enumerate(links) for s in link}
            battle._chain_st = st
        return st

    def _slot_ready(self, battle: Any, slot: str) -> bool:
        u = next((p for p in battle.players if p.slot == slot and p.is_alive), None)
        return (
            u is not None
            and not u.is_cast_blocked(battle.current_time)
            and self._cost_ready(u, battle)
        )

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        now = battle.current_time
        if self.end_dump and battle.effective_time_limit - now <= self.end_dump:
            return True  # orbs are worthless after the bell
        st = self._st(battle)
        if not st["links"]:
            # No chain on this team: fall back to the default rotation.
            return CadenceScheduler.should_cast(self, attacker, battle, target)
        li = st["link_of"].get(attacker.slot)
        if li is None:
            # Off-chain caster: only spends orbs the chain would not, at cost 1.
            return bool(
                self.spare
                and battle.skill_points >= self.spare
                and self._cost_ready(attacker, battle)
            )
        links = st["links"]
        if st["idle"]:
            # Clean start: link 0 only, once the pool and every link-0 member are ready.
            if li != 0 or battle.skill_points < self.pool:
                return False
            if not all(self._slot_ready(battle, s) for s in links[0]):
                return False
            st.update(idle=False, anchor=now, link=0, fired=[], land=now)
        due = st["anchor"] + st["link"] * st["gap"]
        if now > due + self.late and not st["fired"]:
            st["breaks"] += 1
            if self.restart == "clean":
                st.update(idle=True, link=0, fired=[])
                return False
        if li != st["link"] or now < due or now < st["land"]:
            return False
        link = links[li]
        if link[len(st["fired"])] != attacker.slot:
            return False  # members go in listed order
        if not self._cost_ready(attacker, battle):
            return False
        st["fired"].append(attacker.slot)
        delay_for = getattr(battle, "skill_effect_delay_for", None)
        st["land"] = now + (delay_for(attacker) if delay_for else 0.0)
        if len(st["fired"]) == len(link):
            st.update(link=(li + 1) % len(links), fired=[])
            if st["link"] == 0:
                st["anchor"] += scaled_cycle(self.cycle, battle)
        return True


class TimelineScheduler:
    """The amp-chain timeline with a choice of how to recover from a CC'd cast.

    ``recover``: "grid" -- the slipped cast fires when free, the rest keep their
    times (what ``ReplayScheduler(rotation_timeline(...))`` does); "shift" -- every
    later cast slides by the delay, for the rest of the fight; "shift-cycle" -- only
    this cycle's later casts slide, the next cycle starts on the grid; "skip" -- a
    cast more than ``late`` s past due is dropped and its orb kept. ``dump_all``
    spends the banked orbs in the last ``ROTATION_DUMP`` s instead of one cast each.
    """

    def __init__(
        self,
        rot: dict,
        horizon: float,
        recover: str = "grid",
        late: float = 99.0,
        dump_all: bool = False,
    ) -> None:
        self.cycle, self.t0, self.off = rot["cycle"], rot["t0"], rot["off"]
        self.end = horizon - ROTATION_DUMP
        self.recover, self.late, self.dump_all = recover, late, dump_all

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        s = attacker.slot
        if s not in self.off:
            return False
        st = getattr(battle, "_tl_st", None)
        if st is None:
            st = battle._tl_st = {"k": {}, "shift": 0.0, "cs": {}, "dumped": set()}
        now = battle.current_time
        if now >= self.end - 1e-6:
            if self.dump_all:
                return True
            if s in st["dumped"]:
                return False
            st["dumped"].add(s)
            return True
        k = st["k"].get(s, 0)
        while True:
            due = round(self.t0 + k * self.cycle + self.off[s], 1)
            due += st["shift"] if self.recover == "shift" else st["cs"].get(k, 0.0)
            if due >= self.end:
                return False
            if now < due - 1e-6:
                return False
            if self.recover == "skip" and now - due > self.late:
                k += 1
                st["k"][s] = k
                continue
            break
        if int(getattr(attacker, "need_cast_point", 1)) > 1:
            return False
        d = now - due
        if d > 0.05:
            if self.recover == "shift":
                st["shift"] += d
            elif self.recover == "shift-cycle":
                st["cs"][k] = st["cs"].get(k, 0.0) + d
        st["k"][s] = k + 1
        return True
