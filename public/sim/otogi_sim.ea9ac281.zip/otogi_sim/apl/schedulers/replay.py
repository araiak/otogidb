"""ReplayScheduler: replays a captured fight's cast times."""

from __future__ import annotations

from typing import Any


class ReplayScheduler:
    """Cast each slot at the times a captured fight did (`scripts/replay_capture.py`).

    `casts` is {slot: [seconds into the fight, ...]}. A slot casts at its first
    chance at or after each time; the engine still gates on orbs and CC, so a cast
    the sim cannot afford or that is stunned slips until it can -- it is never
    dropped. Slots with no times never cast. Isolates the ENGINE: same casts as
    play, so any remaining gap is damage/timing modelling, not rotation.

    An entry may be ``[t, max_cost]``: the cast also waits until the unit's orb cost
    has decayed to ``max_cost`` (``scripts/rotation_grid.py`` uses this to express
    "cost 1 only" vs "spend up to cost 3"). ``[t, max_cost, lead, lag]`` also waits
    until slot ``lead`` has cast at or after ``t`` and ``lag`` seconds have passed,
    so a carry never fires ahead of a buffer whose cast slipped.
    """

    def __init__(self, casts: dict[str, list]) -> None:
        def entry(t: Any) -> tuple:
            if not isinstance(t, list):
                return (float(t), 99.0, "", 0.0)
            t = list(t) + [99.0, "", 0.0][len(t) - 1 :]
            return (float(t[0]), float(t[1]), str(t[2]), float(t[3]))

        self.casts = {str(k): sorted(entry(t) for t in v) for k, v in casts.items()}

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        times = self.casts.get(attacker.slot)
        if not times:
            return False
        idx = getattr(battle, "_replay_idx", None)
        if idx is None:
            idx = battle._replay_idx = {}
        i = idx.get(attacker.slot, 0)
        if i >= len(times) or battle.current_time < times[i][0] - 1e-6:
            return False
        if int(getattr(attacker, "need_cast_point", 1)) > times[i][1]:
            return False
        last = getattr(battle, "_replay_last", None)
        if last is None:
            last = battle._replay_last = {}
        lead, lag = times[i][2], times[i][3]
        if lead:
            lt = last.get(lead, -1.0)
            if lt < times[i][0] - 1e-6 or battle.current_time < lt + lag - 1e-6:
                return False
        idx[attacker.slot] = i + 1
        last[attacker.slot] = battle.current_time
        return True
