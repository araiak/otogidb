"""
Pool-and-burst rotation scheduler (the 40s-rotation model).

The community rotation is: pool orbs, then burst — cast the buffs together, then
dump the carry skills while the buffs are peaked — then pool again. A reactive
per-unit APL can't express "wait for orbs then fire the whole group", so this is
a small team-level state machine consulted in place of the APL rules.

Phases (hysteresis on the team orb pool):
  POOL   : hold everything until team orbs >= pool_target.
  BURST  : buffers cast (peak the buffs); carries cast only when their projected
           crit is near cap (which is only true once the buffs have landed, so
           carries naturally fire AFTER the buffers). Continue until orbs drain
           to burst_floor, then return to POOL.

Tunable + meta-aware: buffers/carries are identified from each unit's own skill
flags, and the thresholds are params so we can min-max per team.
"""

from __future__ import annotations

from typing import Any
from ..payload import amp_effects, skill_payload
from ..scheduler import (
    _DEFENSIVE_ON_ALLY,
    _TEAM_SIZE,
    _buffer_signature,
    _note_buff,
    _pure_buffer,
    _ramp_profile,
    scaled_cycle,
)
from ..state import APL_PROJECTION_EXCEED, _buff_remains, skill_flags
from ..window_value import _DMG_MULT_WEIGHT
from .. import scheduler as _s


class CadenceScheduler:
    """Time-cadence generalization of the human "buff then dump carries" rotation.

    Every ``cycle`` seconds a fresh burst opens: cast each buffer once
    (``buff & !damage``, synced by construction), then fire each *true carry* up
    to ``casts_per_carry`` times. In the last ``end_dump`` seconds everything is
    dumped (orbs are worthless after the bell).

    A carry is gated by two **relative** thresholds — no absolute damage number,
    so the policy puts *every* team in its best light and can't be gamed by
    absolute-damage inflation (a fixed floor let mediocre cards + strong assists
    clear a magic number and spam; the score then reflected the exploit, not the
    cards). The two roles a floor plays are split:

    - **Selection** — a unit is a spam-carry only if its peak projected crit is at
      least ``carry_select_frac`` of the *team's best* carry peak. This drops
      utility damage skills (a debuffer that merely *has* a damage skill) whose
      ceiling sits far below the real carries, on any team, at any magnitude.
    - **Timing** — a selected carry fires only when its *current* projected crit is
      at least ``window_frac`` of *its own* running peak, i.e. it is inside its
      buff window. Between bursts (buffs expired) its crit falls below that and it
      holds; the next buff refresh lifts it back and it fires.

    Peaks are per-unit running maxima of the forced-crit skill projection, tracked
    on the battle (``_carry_peak``); the projection reuses
    ``Battle.calculate_action_damage(force_crit=True)`` — no new damage math.

    Why time-cadence rather than an orb threshold: the orb pool caps (~10), so
    pooling to a high threshold leaks regen; a fixed cadence keeps orbs churning
    and spends the full ~72-orb budget. Affordability is still gated by the engine
    before ``should_cast`` is consulted, so this only expresses judgment.

    Per-burst state lives on the battle so one instance is safe to share across
    battles. Tuned on the Sola/Orihime + 2x Hikoboshi worldboss team -- a
    *2*-buffer team. The sync-block and buffs-first gates both scale with buffer
    count, so a 3+-buffer team (e.g. Mira/Nimbus/Ohina) pays a heavier tax than
    this class was ever validated against; a ramp-shaped buffer (see
    ``_ramp_profile``) is exempted from both gates for exactly that reason.
    """

    def __init__(
        self,
        cycle: float = 20.5,
        casts_per_carry: int = 1,
        carry_select_frac: float = 0.5,
        window_frac: float = 0.85,
        end_dump: float = 8.0,
        cost_target: int = 1,
        stagger_amp: bool = True,
    ) -> None:
        self.cycle = cycle
        self.casts_per_carry = casts_per_carry
        self.carry_select_frac = carry_select_frac
        self.window_frac = window_frac
        self.end_dump = end_dump
        self.cost_target = cost_target
        # Hold a carry whose damage-amp debuff is ALREADY running on the target until
        # it is about to lapse, instead of re-applying it inside its own window.
        #
        # Why this matters: a duplicated carry (e.g. Hikoboshi in the active team AND
        # as the helper) fires both copies in the same burst, 0.3s apart. The amp is
        # already at the -75% shield floor from one cast, so the second adds no
        # magnitude -- it only refreshes a full window, buying ~0s of extra coverage.
        # Spacing the second cast to just before expiry roughly doubles amp uptime for
        # the same two orbs. Buff timing and the burst structure are untouched.
        self.stagger_amp = stagger_amp

    # -- orb-cost economy ---------------------------------------------------
    def _cost_ready(self, unit: Any, battle: Any) -> bool:
        """Has this unit's escalated orb cost decayed back to ``cost_target``?

        Skill cost escalates 1 -> 2 -> 3 per cast (``MonsterComponent.add_cast_cost``)
        and decays one step per ``BattleConfig.skill_minus_cost_cd`` (20s). So casting
        a unit ONCE per ~21s keeps every cast at 1 orb, while casting it twice inside a
        burst immediately pays 1+2 and then 2+3 on the following cycle.

        Measured on a world-boss team: the cliff sits exactly on the 20s constant —
        cycle 20 scores 45.9M, cycle 21 scores 69.98M, because at 21s every cast is
        affordable at 1 orb and the carries get 38 casts instead of 29.

        Gating on the *cost itself* rather than on a tuned cycle length means the
        rotation stays correct if ``skill_minus_cost_cd`` changes, and a unit whose
        cost has drifted to 2-3 simply waits one decay step instead of paying triple.
        """
        if int(getattr(unit, "need_cast_point", 1)) <= self.cost_target:
            return True
        # Safety valve: only hold if waiting can actually help. Decay runs one step
        # per 20s all the way back to 1 (measured in play), so a unit above
        # cost_target always has decay pending; if one ever does not, its cost is
        # as low as it will get and holding would be an indefinite lockout.
        return not bool(getattr(unit, "minus_cost_pending", False))

    # -- opening sync -------------------------------------------------------
    def _sync_block(self, battle: Any, pending_buffers: int) -> int:
        """Orbs the opening of a burst costs: every buffer still owing a cast,
        plus ONE carry.

        A buff lasts ~8s and orb income is 1 per 5s, so a burst that opens on a
        thin pool spends its orbs on buffs and then leaves the first nuke waiting
        for income until the window it was buffed for has lapsed. Measured on the
        reference world-boss team with the corrected 2-orb opening: the two
        buffers cast at 0.5s, the carry could not afford to cast until 10.2s, and
        the 8s crit window it was supposed to fire inside was already gone.

        Only the FIRST carry is counted. A second copy is free to lag -- the
        `window_frac` timing gate already refuses to let it fire outside its buff
        window, so delaying it buys amp uptime rather than losing the window.

        Clamped to the pool cap: a team whose opening block is larger than the
        pool could never open at all, and a burst that fires late beats one that
        never fires.
        """
        # Read the carry off the team's SKILLS, not off `_carry_peak_life`: that
        # dict is populated by projections, so it is empty on the opening tick --
        # exactly the moment this gate has to be right.
        carries = (
            1
            if any(
                p.is_alive
                and getattr(p, "skill", None) is not None
                and skill_flags(p.skill, p)["damage"]
                for p in battle.players
            )
            else 0
        )
        cap = int(getattr(battle, "skill_points_max", 10) or 10)
        return min(pending_buffers + carries, cap)

    def _opening_funded(self, battle: Any, pending_buffers: int) -> bool:
        return battle.skill_points >= self._sync_block(battle, pending_buffers)

    def _casting_slots(self, battle: Any) -> set[str] | None:
        """Slots this policy will actually cast, or None for "everyone alive".

        Domination asks whether another buffer ALREADY supplies this stat. A buffer
        that is never going to cast supplies nothing, so it cannot dominate anything.
        The base policy casts whoever is alive; `GroupScheduler` knows better.
        """
        return None

    def _dominated_buffers(self, battle: Any) -> set[str]:
        """Slots of buffers that are redundant this battle — a same-stat buff is
        already provided to >= targets at >= magnitude by another buffer THAT CASTS,
        so casting them just burns orbs (e.g. Classic Alice's single-target ATK buff
        when Orihime gives the same 35% ATK to two targets).

        Removing the rule entirely measured -11.7% on the player's Odairi team and
        0.0% on thirteen others, so it earns its place -- but only against a supplier
        that is really in the rotation. It used to mute a copy on behalf of a card
        sitting in the "do not cast" bucket or already retired by a swap, which is
        how a retired Nimbus left its replacement muted and ~15 orbs of income
        unspent: 63 casts against 78 orbs, where not swapping at all casts 70.

        Cached per battle AND per casting set, because that set changes when someone
        dies or a swap fires -- the old cache was computed once on the opening tick
        and never revisited, so `is_alive` below was effectively frozen there.
        """
        casting = self._casting_slots(battle)
        ckey = None if casting is None else frozenset(casting)
        cached = getattr(battle, "_dominated_buffers_cache", None)
        if cached is not None and cached[0] == ckey:
            return cached[1]
        buffers = []
        for p in battle.players:
            if not p.is_alive or p.skill is None:
                continue
            if casting is not None and p.slot not in casting:
                continue
            f = skill_flags(p.skill, p)
            if f["buff"] and not f["damage"]:
                sig, tc = _buffer_signature(p)
                if sig:
                    buffers.append((p.slot, sig, tc))
        dominated: set[str] = set()
        for slot, sig, tc in buffers:
            for oslot, osig, otc in buffers:
                if oslot == slot:
                    continue
                # o covers every stat of this buffer at >= magnitude and >= targets
                covers = all(
                    stat in osig and osig[stat] >= mag for stat, mag in sig.items()
                )
                if not covers or otc < tc:
                    continue
                strictly_better = otc > tc or any(
                    osig[stat] > mag for stat, mag in sig.items()
                )
                # Strictly-better dominates; exact ties broken by slot so identical
                # buffers don't mutually cancel (keep the lower slot, drop the rest).
                if strictly_better or oslot < slot:
                    dominated.add(slot)
                    break
        battle._dominated_buffers_cache = (ckey, dominated)
        return dominated

    def _surplus_buffer(self, battle: Any) -> str | None:
        """The one buffer to drop when the team cannot afford its own rotation, else None.

        Orb income is 1 per ``skill_points_regen_cd`` (5s), so a 20.5s cycle funds
        ~4.1 casts. A team that wants MORE than that every cycle cannot hold the
        cadence: each burst opens a little later than the last, and the slip
        compounds. Measured on the player's Hinoto Lv30 team (Mira + Tsukuyomi +
        Orihime buffing 2x Hikoboshi = 5 casts a cycle against 4.1 orbs): bursts ran
        25.6s apart instead of 20.5s, so every unit got 15 casts instead of 19-20 and
        the team scored 66.8M against the 71.0M the same roster reaches with the
        weakest buffer simply left out of the rotation.

        So drop exactly one buffer and let the other four casts run on time. The
        candidate must be a *surplus copy* -- every stat it supplies also comes from
        another live buffer -- because dropping a sole source is a different and much
        worse trade: on this team skipping Tsukuyomi (the only crit-rate buffer)
        costs 13%, while skipping Mira (ATK +71.6%, behind Orihime's +124.9%) gains
        4.5%.

        Carries are counted off ``_carry_peak_life`` through the same selection gate
        ``should_cast`` uses, so a utility damage skill that never qualifies to spam
        is not counted against the budget. That dict is empty on the opening tick, so
        this returns None for the first cycle and the rotation starts intact.

        ponytail: drops at most one, ranked by summed buff magnitude. Target count is
        ignored -- the payload does not say WHICH allies a partial-target buff hits.
        Drop more than one, or rank by magnitude x carries-covered, if a team ever
        overruns the budget by more than a single cast.
        """
        life = getattr(battle, "_carry_peak_life", None)
        if not life:
            return None  # first cycle: nothing has projected yet

        buffers: list[Any] = []
        for p in battle.players:
            if not p.is_alive or not _pure_buffer(p) or _ramp_profile(p)[0]:
                continue
            if p.slot in self._dominated_buffers(battle):
                continue
            buffers.append(p)

        best = max(life.values())
        carries = sum(1 for v in life.values() if v >= self.carry_select_frac * best)
        wanted = len(buffers) + carries * self.casts_per_carry
        regen = float(getattr(battle, "skill_points_regen_cd", 5.0) or 5.0)
        if wanted <= scaled_cycle(self.cycle, battle) / regen:
            return None  # the rotation fits in the orb budget -- nothing to trim

        # Rank every buffer by the damage it actually delivers to the carries, and
        # trim the weakest. Three things this used to get wrong, each measured on
        # the rank-10 team of the 2026-09-18 cadence run (Seel Imperio + Senji
        # Ryakketsu + Edo Castle), which cadence scored 29% under what it is worth:
        #
        #   * an ALLY-side positive SHIELD is defence and buys nothing in a damage
        #     race, but `on_enemy` skipped the enemy-side debuff -- the one that IS
        #     a damage amp -- and kept the ally buff at full weight. Edo Castle's
        #     +71.6% shield outranked Il Milione's +53.3% crit rate, so the crit
        #     buffer was cut and the defensive one survived.
        #   * `_DMG_MULT_WEIGHT` decided WHETHER to count an effect and never how
        #     much, so crit rate (0.5) and crit damage (0.4) were summed raw.
        #   * target count was ignored, which cannot compare a 5-target 40% against
        #     a 2-target 50% -- and cards like 1129 and 564 make that the live
        #     question rather than a hypothetical.
        n_carries = max(1, carries)
        totals: dict[str, float] = {}
        supply: dict[str, int] = {}
        stats: dict[str, set[str]] = {}
        unpriced: set[str] = set()
        for p in buffers:
            sk = getattr(p, "skill", None)
            sel = str(getattr(sk, "target_selector", "") or "")
            n_t = int(getattr(sk, "target_count", 1) or 1)
            # `max_atk` picks the top-ATK allies, which is where the carries are; an
            # unfiltered count<n> sprays across the whole team and only covers the
            # carries in proportion.
            ally_hits = (
                min(n_t, n_carries)
                if "max_atk" in sel
                else n_carries * min(n_t, _TEAM_SIZE) / _TEAM_SIZE
            )
            for eff in skill_payload(p, p.model.level if p.model else 1):
                w = _DMG_MULT_WEIGHT.get(eff.raw_type)
                if w is None:
                    # UNKNOWN is not WORTHLESS. The table has no entry for SPD,
                    # POISON or HIT, and scoring those 0 made the weakest-looking
                    # buffer the trim-first candidate: on the Seel Imperio team that
                    # cut a +14% attack-speed buff, which is real auto damage, and
                    # left a defensive ally shield casting all fight. A buffer we
                    # cannot price falls back to the surplus-copy gate below.
                    unpriced.add(p.slot)
                    continue
                if eff.raw_type in _DEFENSIVE_ON_ALLY:
                    # Only the enemy-side (negative) version amplifies damage.
                    if not eff.on_enemy:
                        continue
                elif eff.on_enemy:
                    continue
                # An enemy debuff multiplies every carry's damage at once.
                hits = n_carries if eff.on_enemy else ally_hits
                totals[p.slot] = totals.get(p.slot, 0.0) + w * abs(eff.magnitude) * hits
                supply[eff.raw_type] = supply.get(eff.raw_type, 0) + 1
                stats.setdefault(p.slot, set()).add(eff.raw_type)
        # Only a SURPLUS COPY may be trimmed -- one whose every stat another live
        # buffer also supplies. The gate stays because the weights above cannot
        # compare across stats: CHIT is weighted 0.5 ("each crit ~2x"), but on a team
        # stacking crit DAMAGE a crit is worth far more than 2x, so ranking by value
        # alone trims Tsukuyomi on the Hinoto team -- measured at -13%.
        candidates = {
            slot: v
            for slot, v in totals.items()
            if all(supply[stat] > 1 for stat in stats.get(slot, ()))
        }
        # ...with one exception: a buffer supplying NOTHING damage-relevant. It was
        # structurally undroppable, because with no counted effect it never entered
        # the candidate map, so the most worthless card on the team was the one card
        # the budget could never reclaim an orb from. That is the whole of the 29%.
        for p in buffers:
            if not stats.get(p.slot) and p.slot not in unpriced:
                candidates[p.slot] = 0.0
        if not candidates:
            return None
        return min(candidates, key=lambda slot: (candidates[slot], slot))

    def _skipped_buffers(self, battle: Any) -> set[str]:
        """Buffers that must not cast this burst: redundant by construction, plus the
        one surplus buffer an orb-bound team cannot afford (see ``_surplus_buffer``)."""
        skipped = self._dominated_buffers(battle)
        if _s.FORCED_SKIP:
            # A benched slot must also leave the buffs-first wait and the opening
            # sync, or the carries wait on a buffer that never casts: benching Ohina
            # alone left Odairi at 1 cast in 300s instead of 16.
            skipped = skipped | _s.FORCED_SKIP
        st = getattr(battle, "_cadence", None)
        surplus = st.get("skip") if isinstance(st, dict) else None
        if isinstance(surplus, set):
            return skipped | surplus
        return (skipped | {surplus}) if surplus else skipped

    def _waiting_for_buffs(self, battle: Any, unit: Any) -> bool:
        """Should this carry hold until the buffs cast this opening have LANDED?

        A buff applies its caster's own delay after the cast (animation asset, e.g.
        Orihime 1.0s, Tsukuyomi 0.5s; see Battle.skill_effect_delay_for),
        so a carry firing in the same tick as its buffers gets none of them. That is
        not how the fight is played -- the player casts the buffers, waits ~1s, then
        the carry -- and modelling the delay WITHOUT the wait is strictly worse than
        modelling neither: it keeps the unrealistic simultaneous cast and then strips
        the buffs off it.

        Inert when the delay is 0, which is the default.
        """
        delay = float(getattr(battle.config, "skill_effect_delay", 0.0) or 0.0)
        if delay <= 0 or unit is None or getattr(unit, "skill", None) is None:
            return False
        if not skill_flags(unit.skill, unit)["damage"]:
            return False  # buffers open the window, they never wait on it
        for key in ("_group_st", "_cadence", "_ramp_burst"):
            st = getattr(battle, key, None)
            if isinstance(st, dict) and "buff_land_at" in st:
                # Each buff lands after its caster's own delay (animation asset);
                # the carry waits for the slowest one cast this opening.
                return battle.current_time < st["buff_land_at"]
        return False

    def _amp_still_running(
        self, attacker: Any, battle: Any, target: Any, enemy_only: bool = False
    ) -> bool:
        """Is this unit's damage-amp debuff already running with time to spare?

        The amp is capped (it sits at the -75% shield floor from a single cast), so
        re-applying it while it still has plenty of duration left buys no magnitude
        and no meaningful coverage -- it just burns an orb. True means "wait": the
        debuff would outlive this unit's next turn, so casting now is pure waste.

        Shared by CadenceScheduler and GroupScheduler. It used to be inlined in
        CadenceScheduler.should_cast; GroupScheduler needs the identical judgment
        and a second copy is exactly the drift this package keeps getting bitten by.

        **It does not apply to a CARRY.** "Pure waste" is only true for a support
        whose cast is nothing but the debuff. A carry whose skill both nukes and amps
        (Hikoboshi: "Deals {value} DMG ... Targets take {delay1} more DMG") loses far
        more by waiting than the orb is worth -- held until the window lapses, it then
        fires with the amp DOWN and misses the damage cap on its own nuke. Measured on
        the player's Hinoto team, duplicate Hikoboshi in slots P4/P5: the second copy
        capped 12.5% of its casts with the stagger on and 80-94% with it off, which is
        what the player reports seeing in play.
        """
        if getattr(attacker, "skill", None) is not None:
            if skill_flags(attacker.skill, attacker)["damage"]:
                return False
        try:
            gap = float(attacker.get_attack_interval())
        except Exception:
            gap = 2.0
        for e in amp_effects(attacker):
            if e.is_permanent or e.mod_type is None:
                continue
            # `enemy_only` restricts this to debuffs on the target -- the capped
            # damage-amp this was written for. Ally buffs stack ADDITIVELY within
            # their bucket, so two different buffers are not redundant: Mira and
            # Orihime take one carry 145% -> 300.2% -> 383.4%. Measuring "is a DAMAGE
            # modifier running on the recipient" cannot tell those apart, and held
            # Orihime for the whole 8s window behind Mira.
            if enemy_only and not e.on_enemy:
                continue
            recipient = target if e.on_enemy else attacker
            if recipient is None:
                continue
            if _buff_remains(battle, recipient, e.mod_type.name) > gap:
                return True
        return False

    def _project_crit(self, unit: Any, battle: Any, target: Any) -> float:
        """Forced-crit skill projection, maintaining two peaks.

        ``_carry_peak`` is per-cycle (cleared each burst) and drives the *timing*
        gate, so a transient — e.g. the enemy's shield break — can't leave a stale
        unreachable peak that deadlocks the window check.

        ``_carry_peak_life`` is the battle-lifetime max and drives *selection*.
        Using the per-cycle peak for selection leaks: the dict is empty at every
        cycle boundary, so whichever unit projects first compares against only
        itself (``team_best == own_peak``) and always clears the gate — letting a
        utility damage skill (an AoE chip, a healer's nuke) spend an orb that
        belonged to a real carry. Shorter cycles reset more often and leak more:
        measured 4 carry casts vs 6 junk casts at cycle=15, against 25 vs 3 at
        cycle=30. Splitting the two roles closes it at every cycle length.
        """
        f = skill_flags(unit.skill, unit) if getattr(unit, "skill", None) else None
        if not f or not f["damage"] or target is None:
            return 0.0
        crit = float(
            battle.calculate_action_damage(
                unit,
                target,
                is_skill=True,
                force_crit=True,
                exceed_pct=APL_PROJECTION_EXCEED,
            ).final_damage
        )
        peak = getattr(battle, "_carry_peak", None)
        if peak is None:
            peak = {}
            battle._carry_peak = peak
        if crit > peak.get(unit.slot, 0.0):
            peak[unit.slot] = crit
        life = getattr(battle, "_carry_peak_life", None)
        if life is None:
            life = {}
            battle._carry_peak_life = life
        if crit > life.get(unit.slot, 0.0):
            life[unit.slot] = crit
        return crit

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        if _s.FORCED_SKIP and attacker.slot in _s.FORCED_SKIP:
            return False
        # End-of-fight dump: spend everything affordable before the bell.
        if battle.effective_time_limit - battle.current_time <= self.end_dump:
            return True
        st = self._burst(battle)
        if getattr(attacker, "skill", None) is None:
            return False
        # Cost gate: hold until this unit's escalated orb cost has decayed back to
        # `cost_target`. This is what the tuned ~21.5s cadence was really expressing.
        if not self._cost_ready(attacker, battle):
            return False
        if _pure_buffer(attacker):
            return self._buffer_cast(attacker, battle, st)
        return self._carry_cast(attacker, battle, target, st)

    def _burst(self, battle: Any) -> dict:
        """This cycle's burst state, opening a fresh one every `cycle` seconds.

        Reset the per-unit crit peaks each cycle: the forced-crit projection includes
        the enemy's transient shield-break, so a peak captured right after a carry
        applied SHIELD<-75%> is unreachable once that shield decays -- which would
        deadlock the window gate and starve carries for the rest of the fight. A
        per-cycle peak keeps the window relative to what's achievable *this* burst
        (buffs-first still holds carries for the buffs).
        """
        st = getattr(battle, "_cadence", None)
        if st is None or battle.current_time - st["start"] >= scaled_cycle(
            self.cycle, battle
        ):
            st = {"start": battle.current_time, "buffed": set(), "nc": {}}
            battle._cadence = st
            battle._carry_peak = {}
            st["skip"] = self._surplus_buffer(battle)
        return st

    def _pending_buffers(self, battle: Any, st: dict) -> list:
        """Worthwhile buffers still owed a cast this burst: live, not skipped, not a
        ramp (which runs its own cadence -- see `_buffer_cast`)."""
        skipped = self._skipped_buffers(battle)
        return [
            p
            for p in battle.players
            if p.is_alive
            and _pure_buffer(p)
            and p.slot not in st["buffed"]
            and p.slot not in skipped
            and not _ramp_profile(p)[0]
        ]

    def _buffer_cast(self, attacker: Any, battle: Any, st: dict) -> bool:
        """Buffers cast once per burst (synced), refreshed every cycle. Redundant
        buffers whose stat a better buffer already covers on >= targets are skipped."""
        if attacker.slot in self._skipped_buffers(battle):
            return False
        # A ramp-shaped buffer (permanent no-duration stack -- Nimbus[Awakened])
        # does not need to land INSIDE the group's burst window: its main payoff
        # never expires, so syncing it costs the team a sync-block orb and an
        # extra name on the carry's buffs-first wait-list for zero timing benefit.
        # Measured on a 3-buffer Anima team: folding it into the shared sync
        # (like every other buffer) held the lone carry behind all three buffers
        # every cycle and taxed the opening block at 4 orbs instead of 3, costing
        # ~12% versus manually pulling it into its own group. Casting it purely
        # off its own cost-decay gate reproduces that manual split automatically.
        if _ramp_profile(attacker)[0]:
            return True
        if attacker.slot in st["buffed"]:
            return False
        # Opening sync: do not start a burst the pool cannot see through to its
        # first nuke. Checked only while the burst is still closed -- once a
        # buffer has cast the window is running and stalling mid-burst would
        # waste the buffs already spent. Ramp buffers are excluded (see above).
        if not st["buffed"] and not self._opening_funded(
            battle, len(self._pending_buffers(battle, st))
        ):
            return False
        st["buffed"].add(attacker.slot)
        _note_buff(st, battle, attacker)
        return True

    def _carry_cast(self, attacker: Any, battle: Any, target: Any, st: dict) -> bool:
        """Damage units: wait for the buffs cast this cycle to LAND, then the
        relative selection + timing gates."""
        if self._waiting_for_buffs(battle, attacker):
            return False
        crit = self._project_crit(attacker, battle, target)
        if crit <= 0.0:
            return False
        # Selection off the battle-lifetime peak — a weak carry can never qualify
        # merely by being the first to project in a freshly-cleared cycle.
        life = battle._carry_peak_life
        if life.get(attacker.slot, crit) < self.carry_select_frac * max(life.values()):
            return False
        own_peak = battle._carry_peak.get(attacker.slot, crit)
        # Timing: only fire inside this carry's own buff window.
        if crit < self.window_frac * own_peak:
            return False
        # Redundant-amp stagger: the debuff is capped, so re-applying it while it still
        # has plenty of time left is pure waste. Wait unless it would lapse before this
        # unit's next turn (a unit is only asked once per attack interval). Only a
        # debuff-only support can trip it here: it never holds a damage caster.
        if self.stagger_amp and self._amp_still_running(attacker, battle, target):
            return False
        # Buffs-first: hold the carry until every *worthwhile* buffer has cast
        # this burst (dominated/redundant buffers never cast, so don't wait on
        # them; a ramp buffer runs its own independent cadence, so don't wait on
        # it either -- see `_buffer_cast`).
        if self._pending_buffers(battle, st):
            return False
        if st["nc"].get(attacker.slot, 0) < self.casts_per_carry:
            st["nc"][attacker.slot] = st["nc"].get(attacker.slot, 0) + 1
            return True
        return False
