"""PlanScheduler: picks the rotation shape from the kit (what the team search runs)."""

from __future__ import annotations

import math

from dataclasses import dataclass
from typing import Any
from ..payload import skill_payload
from ..scheduler import (
    _AMP_TAGS,
    _DEFENSIVE_ON_ALLY,
    _ramp_profile,
    _unit_amps,
    _unit_atk,
    blocking_cc_per_min,
    chain_rotation,
    next_cc_risk,
    rotation_timeline,
    scaled_cycle,
)
from ..state import APL_PROJECTION_EXCEED, _source_matches, skill_flags
from .cadence import CadenceScheduler
from .chain import ChainScheduler, TimelineScheduler
from .group import GroupScheduler
from .replay import ReplayScheduler
from .. import scheduler as _s


class AmpKeeper:
    """A burst plus debuff keepers that only fill the gaps in the boss's amp.

    A low-damage debuffer gains nothing inside the ally buff window (its own hit is
    small and the ranked buffs skip it), so its one job is amp uptime: it casts, at
    cost 1, when the amp running on the boss would lapse by the time its own lands.
    The burst (buffers + carries, ``late_carry`` chaining the amp carries) plays as
    usual. The chain falls out of that: the burst's amps cover ~16s, the keeper the
    next 8, and a CC-slid cast just moves the gap the keeper fills (user, 2026-11-03).
    """

    def __init__(
        self, burst: Any, keepers: list, end_dump: float = 8.0, dodge: tuple = ()
    ) -> None:
        self.burst = burst
        self.keepers = set(keepers)
        self.end_dump = end_dump
        self.dodge = dodge  # (horizon s, risk): hold while a boss CC is about to land

    @staticmethod
    def _cover(battle: Any, now: float) -> float:
        """When the amp now on the boss (landed, or cast and in flight) runs out."""
        end = getattr(battle, "_amp_in_flight", now)
        for t, sid, exp in getattr(battle, "_active_buffs", None) or ():
            if (
                exp > end
                and t.is_enemy
                and sid.startswith("skill_")
                and sid.split("_")[2:3] != ["E1"]
                and any(_source_matches(sid, k) for k in _AMP_TAGS)
            ):
                end = exp
        return end

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        now = battle.current_time
        lag = battle.skill_effect_delay_for(attacker)
        if attacker.slot not in self.keepers:
            ok = self.burst.should_cast(attacker, battle, target)
        elif battle.effective_time_limit - now <= self.end_dump:
            ok = True  # orbs are worthless after the bell
        elif int(getattr(attacker, "need_cast_point", 1)) > 1:
            ok = False
        else:
            step = float(getattr(battle.config, "skill_tick_rate", 0.5) or 0.5)
            ok = self._cover(battle, now) <= now + lag + step
            if (
                ok
                and self.dodge
                and next_cc_risk(battle, self.dodge[0]) >= self.dodge[1]
            ):
                ok = False
        if ok and skill_flags(attacker.skill, attacker)["debuff"]:
            # Covered until the debuff shows up in _active_buffs, so the keeper does
            # not double up on a carry's amp that is still in flight.
            battle._amp_in_flight = max(
                getattr(battle, "_amp_in_flight", 0.0), now + lag + 0.5
            )
        return ok


@dataclass
class _PlanRoles:
    """PlanScheduler's read of a team at plan time (``PlanScheduler._classify``)."""

    team: list
    units: dict
    dmg: list
    amp: set
    carries: list
    debuffers: list
    by_atk: list
    reach: dict
    ranked_reach: dict


class PlanScheduler(CadenceScheduler):
    """Budget then timing: pick who gets the ~4 orbs a cycle, then the shape to cast in.

    Built from two measured rotations (boss 3, 2026-10-15). Both follow one timing
    rule -- a buff target casts inside its buff, opening the debuff early or casting
    late in the overlap; a carry no buffer reaches keeps the debuff going through the
    downtime -- and differ only in which casters are funded:

    - Senji/Andromeda/Dora: Senji's ranked buff reaches only Dora, so both
      Andromedas are *debuff keepers* -> chain (``ChainScheduler``), and Mira's team
      buff is dropped (an 8s window over spread-out casts covers one of them).
    - Hikoboshi x2 + Orihime: Orihime's top-2 buff reaches both carries, so there
      are no keepers -> burst (``GroupScheduler``: buffers, then carries), funding
      the buffers that reach the most carries with a stat that is not capped
      (Mira, Orihime; Tsukuyomi's crit is already capped).

    Carries are damage skills whose projected skill hit (forced crit) is at least
    ``carry_frac`` of the team's best -- not ATK: an AoE skill hits each target for
    far less. Low-hit damage-up casters are supports, funded on value. The budget is the orbs one cycle earns. The plan is fixed
    at the first cast check of each battle and stored on the battle.
    """

    def __init__(
        self,
        cycle: float = 20.5,
        carry_frac: float = 0.5,
        long_cycle: float = 40.5,
        perm_windows: float = 5.0,
        force: str = "",
        replan: bool = False,
        groups: list | None = None,
        late_carry: float = 1.0,
        cycle_switch_at: float | None = None,
        cycle_need: int = 0,
        cycle_switch_cap: str = "both:1.2+bank",
        cycle_drop: str = "",
        cc_dodge: tuple = (3.0, 0.18),
        group_kw: dict | None = None,
        chain: str = "timeline",
        chain_margin: float = 0.5,
        keeper_dodge: tuple = (),
        chain_recover: str = "skip:4+dump",
        chain_close: bool = True,
        chain_swap_k: float = 16.0,
    ) -> None:
        super().__init__(cycle=cycle)
        # Debuffer teams: "timeline" (chain_rotation, fixed offsets), "keeper"
        # (AmpKeeper: the debuffer fills amp gaps around the burst), "" / "0" = off.
        self.chain = "" if chain in ("0", "", False) else str(chain)
        self.chain_margin = chain_margin  # timeline slack before each amp lapses
        self.keeper_dodge = keeper_dodge  # (horizon s, risk): keeper waits out CC
        # TimelineScheduler "<recover>[:late][+dump]"; "" / "0" = ReplayScheduler grid.
        # Default (2026-11-03, 80 chain teams x 12 boss/levels): a cast CC holds > 4s
        # has missed its slot -- skip it, spend banked orbs in the final burst.
        self.chain_recover = "" if chain_recover in ("0", "") else chain_recover
        self.chain_close = chain_close  # cycle closes the chain on landing times
        self.chain_swap_k = chain_swap_k  # CC s/min that zero a debuffer's value
        self.late_carry = late_carry  # passed to the burst's GroupScheduler
        # Long-cycle switch: a fixed time, or a bank threshold other than the plan's.
        self.cycle_switch_at, self.cycle_need = cycle_switch_at, cycle_need
        # Default (2026-10-20): leave the cost-1 phase once the repeated carries are
        # within x1.2 of both caps OR their hits stopped growing, and the long cycle
        # is banked. 147 boss-3 cycle teams: +0.04% mean, 0 significant losses;
        # Odairi team +1.6%. "off" = bank only (the old rule).
        self.cycle_switch_cap = "" if cycle_switch_cap == "off" else cycle_switch_cap
        self.cycle_drop = set(cycle_drop.split(",")) - {""}
        # Defaults (2026-10-21): skip_after 10 (8 dropped a CC'd member's casts)
        # and don't open a burst into a boss CC cast due within 3s at >= 0.18
        # risk. 400 teams x fresh seeds: boss 4 +0.68%, bosses 2/3 0.00%.
        self.cc_dodge = tuple(cc_dodge)
        self.group_kw = {"skip_after": 10.0, **(group_kw or {})}
        self.carry_frac = carry_frac
        self.long_cycle = long_cycle
        # "short" / "long": override the projected pick (measuring near-ties).
        self.force = force
        # Re-fill the long cycle from the live state at each of its starts.
        self.replan = replan
        # Player groups (calculator): WHO casts and which casts go together is the
        # player's; order, carry repeats and cycle length are planned. One group ->
        # burst or long cycle; several -> a chain, one link per group, in order.
        # The planner's own layout fed back in rebuilds the same executor.
        self.groups = [list(g) for g in groups or [] if g]
        # ponytail: a permanent stack counts as `perm_windows` 8s windows of its t=0
        # gain, a flat stand-in for its diminishing worth as caps bind. Calibrated
        # against phantom-cast measurements, not derived.
        self.perm_windows = perm_windows

    def plan(self, battle: Any, target: Any) -> tuple[str, list]:
        """Classify the team, then pick a layout: player chain, keeper chain, long
        cycle, amp chain (or its spare-buffer burst), else burst."""
        r = self._classify(battle, target)
        if len(self.groups) >= 2:
            # Each player group is a chain link: its buffers (ranked first), then
            # its carries -- the order the planner's own head link uses.
            cs = {c.slot for c in r.carries}

            def order(g: list) -> list:
                bufs = [s for s in g if s not in cs]
                bufs.sort(key=lambda s: s not in r.ranked_reach)
                return bufs + [s for s in g if s in cs]

            return "chain", [order(g) for g in self.groups]
        targeted = {t.slot for ts in r.ranked_reach.values() for t in ts}
        keepers = [c for c in r.carries if c.slot not in targeted and c.slot in r.amp]
        head = [b for b in r.ranked_reach] + [
            c.slot for c in r.carries if c.slot in targeted
        ]
        # A chain needs three 8s links to cover a ~22.5s cycle; with two it leaves a
        # gap a burst does better with (Sengen/Beelzebub teams, -3 to -8%).
        # What a simulation-in-the-loop probe needs to build alternative layouts.
        battle._plan_meta = {
            "carries": [c.slot for c in r.carries],
            "cands": list(r.reach) + r.debuffers,
            "buffers": list(r.reach),
            # Damage casters that leave a damage-up: candidate chain links.
            "amp": [p.slot for p in r.dmg if p.slot in r.amp],
            "dmg": [p.slot for p in r.dmg],
        }
        if not self.groups and keepers and len(keepers) + bool(head) >= 3:
            return "chain", [head] + [[k.slot] for k in keepers]
        regen = float(getattr(battle, "skill_points_regen_cd", 5.0) or 5.0)
        short, cycle = self._plan_cycles(battle, target, r, regen)
        if cycle is not None:
            return "cycle", cycle
        if self.chain and not self.groups:
            layout = self._plan_amp_chain(battle, r, short, regen)
            if layout is not None:
                return layout
        return "burst", [short]

    def _classify(self, battle: Any, target: Any) -> "_PlanRoles":
        """Who casts, who carries, who leaves a damage-up, and whom each buff reaches."""
        team = [p for p in battle.players if p.skill is not None]
        chosen = {s for g in self.groups for s in g}
        if chosen:
            team = [p for p in team if p.slot in chosen]
        atk = _unit_atk
        dmg = [p for p in team if skill_flags(p.skill, p)["damage"]]
        # Carries are picked by what one skill cast hits for (forced crit), not ATK:
        # an AoE skill (Kashinkoji) has a far smaller per-target multiplier.
        hit = (
            {
                p.slot: float(
                    battle.calculate_action_damage(
                        p,
                        target,
                        is_skill=True,
                        force_crit=True,
                        exceed_pct=APL_PROJECTION_EXCEED,
                    ).final_damage
                )
                for p in dmg
            }
            if target is not None
            else {p.slot: atk(p) for p in dmg}
        )
        top = max(hit.values(), default=0.0)
        battle._plan_hits = hit
        amp = {p.slot for p in dmg if _unit_amps(p)}
        carries = sorted(
            (p for p in dmg if hit[p.slot] >= self.carry_frac * top),
            key=atk,
            reverse=True,
        )
        # Low-ATK damage casters that leave a damage-up: supports, funded on value.
        debuffers = [p.slot for p in dmg if p.slot in amp and p not in carries]
        # Who each buffer reaches: a ranked buff the top `count` carries, else all.
        reach: dict[str, list[Any]] = {}
        ranked_reach: dict[str, list[Any]] = {}
        by_atk = sorted(
            (p for p in battle.players if p.is_alive), key=atk, reverse=True
        )
        for p in team:
            if skill_flags(p.skill, p)["damage"]:
                continue
            ranked = "max_atk" in str(getattr(p.skill, "target_selector", ""))
            n = int(getattr(p.skill, "target_count", 5) or 5)
            # A ranked buff picks the top-n of the WHOLE team: a support that
            # out-ATKs a carry takes its share (the buff-steal case).
            top_n = by_atk[:n]
            reach[p.slot] = top_n if ranked and n < 5 else by_atk
            if ranked and n < 5:
                ranked_reach[p.slot] = [c for c in carries if c in top_n]
        return _PlanRoles(
            team=team,
            units={p.slot: p for p in team},
            dmg=dmg,
            amp=amp,
            carries=carries,
            debuffers=debuffers,
            by_atk=by_atk,
            reach=reach,
            ranked_reach=ranked_reach,
        )

    def _plan_cycles(
        self, battle: Any, target: Any, r: "_PlanRoles", regen: float
    ) -> tuple[list, list | None]:
        """Fund the short (everyone at cost 1) and long (carries recast at escalated
        cost) cycles. Returns the short cast list, and the long cycle's layout when
        it out-rates the short one (else None)."""
        carries, units, reach, by_atk = r.carries, r.units, r.reach, r.by_atk
        budget = max(len(carries), int(scaled_cycle(self.cycle, battle) / regen))

        def value(b: str, nukes: dict | None, given: list = ()) -> float:
            # Only carries cast nukes in the plan; everyone else counts autos only.
            planned = nukes if nukes is not None else {c.slot: 1 for c in carries}
            prior = [(units[g], reach.get(g, by_atk)) for g in given]
            return self._buff_gain(
                battle, target, units[b], reach.get(b, by_atk), planned, prior
            )

        cands = list(reach) + r.debuffers
        ev = {c.slot: self._expected(battle, c, target, True) for c in carries}
        # The player's buffers are all kept: only repeats and the cycle are planned.
        forced = cands if self.groups else None
        # Short cycle: everyone at cost 1. Long cycle: the cost-decay window (3 -> 1
        # takes 40s) lets carries recast at escalated cost. Keep the better per second.
        v1, bufs1, _, n1 = self._fill(value, ev, cands, carries, budget, False, forced)
        budget2 = min(10, int(scaled_cycle(self.long_cycle, battle) / regen))
        v2, bufs2, nukes2, n2 = self._fill(
            value, ev, cands, carries, budget2, True, forced
        )
        rate1 = v1 / max(scaled_cycle(self.cycle, battle), n1 * regen)
        rate2 = v2 / max(self.long_cycle, n2 * regen)
        battle._plan_values = {b: value(b, None) for b in cands}
        battle._plan_rates = (rate1, rate2, nukes2)
        short = bufs1 + [c.slot for c in carries]
        pick_long = rate2 > rate1 if not self.force else self.force == "long"
        if not (pick_long and any(n > 1 for n in nukes2.values())):
            return short, None
        long = bufs2 + [c.slot for c in carries for _ in range(nukes2[c.slot])]

        def refill(b: Any) -> tuple[list, int]:
            """The long cycle re-filled from the live state (stacks, deaths)."""
            live = [c for c in carries if c.is_alive]
            if not live:
                return long, n2
            ev_now = {c.slot: self._expected(b, c, target, True) for c in live}
            _, bufs, nukes, n = self._fill(value, ev_now, cands, live, budget2, True)
            return bufs + [c.slot for c in live for _ in range(nukes[c.slot])], n

        battle._plan_refill = refill if self.replan else None
        # Phase 1 casts the long cycle's members once each, so the pool banks
        # toward it; the short plan's extra buffers would spend every orb.
        return short, [list(dict.fromkeys(long)), long, [n2]]

    def _plan_amp_chain(
        self, battle: Any, r: "_PlanRoles", short: list, regen: float
    ) -> tuple[str, list] | None:
        """A debuffer team's layout: keeper, amp-chain timeline, or a burst with the
        spare buffer when boss CC devalues the chain. None = no chain applies."""
        carries, units, amp = r.carries, r.units, r.amp
        # A pure debuffer opens an amp chain the burst can't play. A weak copy of
        # a carry (below carry_frac at plan time) is one too -- a low-damage
        # caster gains nothing from the buff window -- UNLESS a teammate ramps
        # it: a permanent ally stack (Nimbus[Awakened]) lands on the weakest
        # carry, so the copy becomes a real carry over the fight. 63 copy teams,
        # 16 seeds (2026-11-03): with a ramp, chaining it -4.5..-11.7% (48/48
        # worse); without, +1..+5.6% (Andromeda/Dragon Princess/Titania +4%).
        ramp = any(_ramp_profile(p)[0] for p in r.team)
        names = {units[c.slot].model.name for c in carries} if ramp else set()
        pure = [
            s for s in r.debuffers if s in short and units[s].model.name not in names
        ]
        amp_carries = [c.slot for c in carries if c.slot in amp]
        if not (pure and amp_carries):
            return None
        if self.chain == "keeper":
            burst = [s for s in short if s not in pure and s not in _s.FORCED_SKIP]
            return "keeper", [burst, [s for s in pure if s not in _s.FORCED_SKIP]]
        slots = [s for s in short if s not in _s.FORCED_SKIP]
        # Chain or burst with the spare buffer? Boss CC that blocks casting
        # delays chain links so the nukes miss the amp; a buffer's ally buff
        # gains nothing from timing. Discount the debuffer's planned value by
        # blocked seconds/min over chain_swap_k and burst with the best uncast
        # buffer when it is worth more. 60 chain teams x 20 boss/level cells
        # (2026-11-03): fires 4/60 at boss 4 Lv15+ (6.5-6.7 s/min) +4.5..+5.4%,
        # no losses there; ~1/60 elsewhere, +-2%. Race: only the boss 4 Lv30
        # #8 Amanojaku/Orihime/Hikoboshi x2 changes, +6.9%. k=13 cost a roster
        # team 7.7%, k=10 lost on 9 teams.
        if self.chain_swap_k:
            vals = getattr(battle, "_plan_values", {}) or {}
            spare = sorted(
                (b for b in r.reach if b not in slots and b not in _s.FORCED_SKIP),
                key=lambda b: -vals.get(b, 0.0),
            )
            keep = 1.0 - blocking_cc_per_min(battle) / self.chain_swap_k
            if spare and vals.get(spare[0], 0.0) >= vals.get(pure[0], 0.0) * keep:
                cs = [c.slot for c in carries if c.slot in slots]
                rest = [s for s in slots if s not in pure and s not in cs]
                return "burst", [[spare[0]] + rest + cs]
        rot = chain_rotation(
            [c.slot for c in carries],
            list(amp),
            pure,
            slots,
            regen,
            2.5,
            margin=self.chain_margin,
            delays=(
                {s: battle.skill_effect_delay_for(units[s]) for s in slots}
                if self.chain_close
                else None
            ),
        )
        battle._plan_rotation = rot  # {cycle, t0, off}: what the UI shows
        return "timeline", [rotation_timeline(rot, float(battle.effective_time_limit))]

    @staticmethod
    def _expected(battle: Any, u: Any, boss: Any, skill: bool) -> float:
        """Expected (crit-weighted) damage of one hit, caps included. Fixed exceed, so
        the probe draws no random numbers and cannot shift the battle's rolls."""
        c = min(1.0, max(0.0, float(u.stat.final_crit)))
        hi = battle.calculate_action_damage(
            u, boss, is_skill=skill, force_crit=True, exceed_pct=APL_PROJECTION_EXCEED
        )
        lo = battle.calculate_action_damage(
            u, boss, is_skill=skill, force_crit=False, exceed_pct=APL_PROJECTION_EXCEED
        )
        return c * float(hi.final_damage) + (1 - c) * float(lo.final_damage)

    def _window_damage(
        self, battle: Any, boss: Any, carries: list, nukes: dict | None = None
    ) -> float:
        """Damage ``units`` deal in one 8s window: their planned skill casts
        (``nukes`` per slot; None = one each) plus their autos. Healers heal
        instead of attacking, so their autos count for nothing."""
        total = 0.0
        for t in carries:
            try:
                autos = 8.0 / float(t.get_attack_interval())
            except Exception:
                autos = 4.0
            n = 1 if nukes is None else nukes.get(t.slot, 0)
            if n:
                total += n * self._expected(battle, t, boss, True)
            if getattr(getattr(t, "model", None), "unit_type", 1) != 3:
                total += autos * self._expected(battle, t, boss, False)
        return total

    @staticmethod
    def _effects(u: Any) -> list:
        """The damage-relevant timed and permanent effects one cast of ``u`` applies."""
        return [
            e
            for e in skill_payload(u)
            if e.mod_type is not None
            and e.duration > 0
            and (e.on_enemy or e.raw_type not in _DEFENSIVE_ON_ALLY)
        ]

    def _probe(self, battle: Any, boss: Any, layers: list, nukes: dict | None) -> float:
        """Team window damage with each ``(effects, recipients)`` layer applied, then
        taken off again. Each modifier gets its own source id: two effects of one
        type on one unit must stack, not replace each other."""
        applied = []
        for effs, reach in layers:
            for e in effs:
                for h in [boss] if e.on_enemy else reach:
                    sid = f"_plan_probe{len(applied)}"
                    h.stat.add_modify(e.mod_type, e.magnitude, sid)
                    applied.append((h, e.mod_type, sid))
        try:
            team = [p for p in battle.players if p.is_alive]
            return self._window_damage(battle, boss, team, nukes)
        finally:
            for h, m, sid in applied:
                h.stat.get_modifier(m).remove_modify(sid)

    def _buff_gain(
        self,
        battle: Any,
        boss: Any,
        u: Any,
        reach: list,
        nukes: dict | None = None,
        given: list = (),
    ) -> float:
        """Extra team damage from one cast of ``u`` ON TOP OF the ``given``
        ``(unit, recipients)`` casts, by the damage formula: one 8s window (``nukes``
        skill casts per carry inside it). Puts ATK%, crit, crit damage and boss
        damage-taken on one scale, with dilution and caps -- and, because the given
        buffs are applied first, with additive buckets already part-filled: a second
        +DMG buff beside Mira's, or a second speed buff at the cap, is worth less.

        A permanent effect (Nimbus's crit-damage stack) keeps paying after the window,
        so its window gain counts ``perm_windows`` times.
        """
        effs = self._effects(u)
        if boss is None or not effs:
            return 0.0
        base = [(self._effects(g), r) for g, r in given]
        total = 0.0
        for group, weight in (
            ([e for e in effs if e.duration < math.inf], 1.0),
            ([e for e in effs if e.duration == math.inf], self.perm_windows),
        ):
            if group:
                before = self._probe(battle, boss, base, nukes)
                after = self._probe(battle, boss, base + [(group, reach)], nukes)
                total += weight * max(0.0, after - before)
        return total

    def _fill(
        self,
        value: Any,
        ev: dict,
        cands: list,
        carries: list,
        budget: int,
        multi: bool,
        forced: list | None = None,
    ) -> tuple[float, list, dict, int]:
        """Spend ``budget`` orbs greedily on the cast worth most per orb.

        Every carry's first cast is funded. A buffer is valued on top of the buffers
        already chosen (``value(b, nukes, given)``), so overlapping buffs are not
        double-counted. With ``multi`` a carry may cast again at its escalated cost
        (the k-th cast costs min(k, 3)), which only pays while its hit beats the next
        buffer per orb; each escalation also raises the buffers' worth, since more
        nukes land in their windows. ``forced`` buffers are always cast (a player's
        choice). The result is ordered and totalled the same way whichever path
        chose it, so a player who enters the planner's own layout gets its result.
        """
        nukes = {c.slot: 1 for c in carries}
        bufs = list(forced) if forced is not None else []
        spent = len(carries) + len(bufs)
        while True:
            opts = []
            if forced is None:
                for b in cands:
                    if b not in bufs and spent + 1 <= budget:
                        v = value(b, nukes, bufs)
                        if v > 0:
                            opts.append((v, 1, b))
            if multi:
                for c in carries:
                    k = nukes[c.slot] + 1
                    if k <= 5 and spent + min(k, 3) <= budget:
                        opts.append((ev[c.slot], min(k, 3), c.slot))
            if not opts:
                break
            v, cost, slot = max(opts, key=lambda o: o[0] / o[1])
            spent += cost
            if slot in nukes:
                nukes[slot] += 1
            else:
                bufs.append(slot)
        # Cast order (and the total) depend only on the chosen set: best alone first.
        bufs.sort(key=lambda b: -value(b, nukes, []))
        total = sum(ev[c] * n for c, n in nukes.items())
        total += sum(value(b, nukes, bufs[:i]) for i, b in enumerate(bufs))
        return total, bufs, nukes, spent

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        d = getattr(battle, "_plan_delegate", None)
        if d is None:
            kind, groups = self.plan(battle, target)
            if kind == "chain":
                d = ChainScheduler(links=groups, cycle=self.cycle)
            elif kind == "timeline" and self.chain_recover:
                mode, _, dump = self.chain_recover.partition("+")
                mode, _, late = mode.partition(":")
                d = TimelineScheduler(
                    battle._plan_rotation,
                    float(battle.effective_time_limit),
                    recover=mode,
                    late=float(late or 99),
                    dump_all=dump == "dump",
                )
            elif kind == "timeline":
                d = ReplayScheduler(groups[0])
            elif kind == "keeper":
                d = AmpKeeper(
                    GroupScheduler(
                        groups=[groups[0]],
                        cycle=self.cycle,
                        late_carry=self.late_carry,
                        cc_dodge=self.cc_dodge,
                        **self.group_kw,
                    ),
                    groups[1],
                    dodge=self.keeper_dodge,
                )
            elif kind == "cycle":
                short, long, (need,) = groups
                long = [x for x in long if x not in self.cycle_drop]
                d = CycleScheduler(
                    [(self.cycle, short), (self.long_cycle, long)],
                    need=self.cycle_need or need,
                    refill=getattr(battle, "_plan_refill", None),
                    switch_at=self.cycle_switch_at,
                    switch_cap=self.cycle_switch_cap,
                )
            else:
                d = GroupScheduler(
                    groups=groups,
                    cycle=self.cycle,
                    late_carry=self.late_carry,
                    cc_dodge=self.cc_dodge,
                    **self.group_kw,
                )
            battle._plan_delegate = d
            battle._plan = (kind, groups)
        return d.should_cast(attacker, battle, target)


class CycleScheduler:
    """Two-phase fixed sequence: ``phases[0]`` every short cycle until the orb pool
    can fund one ``phases[1]`` cycle (``need`` orbs), then ``phases[1]`` for good.

    The player rotation for single-carry Nimbus teams (Discord guide, 2026-07-15):
    Nimbus, Mikado, carry once per 20s until 8 orbs bank, then Nimbus, Mikado, carry
    x3 per 40s: 1+1+1+2+3 = 8 orbs, exactly 40s of income, and 40s is what the
    carry's cost 3 takes to decay back to 1. In each sequence a slot's first cast
    waits for cost 1; its repeats pay the escalated cost. Scanned over 20-60s cycles
    and 1-6 carry casts, 40s x3 was best (Odairi team, Hinoto Lv30: 50.95M cadence
    -> 53.9M; dummy 54.2M -> 58.7M).
    """

    GROWTH = 0.005  # a cycle-on-cycle hit gain below this counts as "not ramping"

    def __init__(
        self,
        phases: list,
        need: int,
        skip_after: float = 8.0,
        repeat_wait: float = 25.0,
        end_dump: float = 8.0,
        refill: Any = None,
        switch_at: float | None = None,
        switch_cap: str = "",
    ) -> None:
        self.phases = phases
        self.need = min(10, need)
        # Switch at the first cycle start at/after this time instead of on the bank.
        self.switch_at = switch_at
        # "auto:1.1" / "skill:1.2" / "both:1.1" / "either:1.1": switch once the long cycle's
        # repeated carries' unrolled crit hit x ratio reaches the cap (exceed rolls
        # x1.0-1.2, so 1.0 = every roll caps, 1.2 = only the best roll does).
        # A "+bank" suffix also waits for the long cycle's orbs (the default trigger).
        self.switch_bank = switch_cap.endswith("+bank")
        kind, _, r = switch_cap.removesuffix("+bank").partition(":")
        self.switch_cap = (kind, float(r or 1.0)) if kind else None
        self.refill = refill  # battle -> (long sequence, orbs it needs)
        self.skip_after, self.repeat_wait = skip_after, repeat_wait
        self.end_dump = end_dump
        self.slots = {s for _, seq in phases for s in seq}

    def _switch_ready(self, battle: Any, st: dict) -> bool:
        """Has the short phase stopped paying? True once the long cycle's repeated
        carries are capped (``switch_cap`` kind/ratio) OR their projected hits have
        stopped growing since the previous cycle start -- i.e. nothing permanent
        (Nimbus's crit-damage stack) is still being built into them, so waiting
        buys nothing and the bank alone decides."""
        kind, ratio = self.switch_cap
        enemy = next((e for e in battle.enemies if e.is_alive), None)
        seq = self.phases[1][1]
        carries = [p for p in battle.players if p.is_alive and seq.count(p.slot) > 1]
        if enemy is None or not carries:
            return True
        # ponytail: read at a cycle start, when the last burst's 8s buffs are down;
        # a buff kept up across the boundary would read early.
        hits = {}
        for p in carries:
            for k in ("normal", "skill"):
                r = battle.calculate_action_damage(
                    p, enemy, is_skill=k == "skill", force_crit=True, exceed_pct=0.0
                )
                hits[(p.slot, k)] = float(r.after_defense)
        # One reading per cycle start: should_cast runs every tick until it casts.
        if st.get("hits_at") != st["anchor"]:
            st["prev_hits"], st["hits"], st["hits_at"] = (
                st.get("hits"),
                hits,
                st["anchor"],
            )
        prev = st.get("prev_hits")
        growing = prev is None or any(
            v > prev.get(key, v) * (1 + self.GROWTH) for key, v in st["hits"].items()
        )
        # "both" = the later of the two caps, "either" = the earlier.
        two = kind in ("both", "either")
        need = ("normal", "skill") if two else (kind.replace("auto", "normal"),)
        caps = {
            "normal": battle.config.damage_cap,
            "skill": battle.config.skill_damage_cap,
        }
        ok = [v * ratio >= caps[k] for (slot, k), v in st["hits"].items() if k in need]
        capped = any(ok) if kind == "either" else all(ok)
        return capped or not growing

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        now = battle.current_time
        if battle.effective_time_limit - now <= self.end_dump:
            return attacker.slot in self.slots  # orbs are worthless after the bell
        st = getattr(battle, "_cycle_st", None)
        if st is None:
            st = battle._cycle_st = {"phase": 0, "anchor": 0.0, "pos": 0, "wait": 0.0}
        if now < st["anchor"]:
            return False
        if self.switch_cap and st["phase"] == 0 and st["pos"] == 0:
            due = self._switch_ready(battle, st) and (
                not self.switch_bank or battle.skill_points >= self.need
            )
        elif self.switch_at is not None:
            due = now >= self.switch_at
        else:
            due = battle.skill_points >= self.need
        if st["phase"] == 0 and st["pos"] == 0 and due:
            st["phase"] = 1  # checked before this cycle spends anything
        if st["phase"] == 1 and st["pos"] == 0 and self.refill and not st.get("filled"):
            seq, need = self.refill(battle)
            self.phases[1] = (self.phases[1][0], seq)
            self.need = min(10, need)
            st["filled"] = True
        cycle, seq = self.phases[st["phase"]]
        if st["pos"] >= len(seq):
            st.update(pos=0, anchor=st["anchor"] + cycle, wait=0.0, filled=False)
            return False
        if not st["wait"]:
            st["wait"] = now
        want = seq[st["pos"]]
        first = want not in seq[: st["pos"]]
        if attacker.slot != want:
            # A slot that cannot cast (dead, CC'd, starved) is skipped, not waited on.
            if now - st["wait"] > (self.skip_after if first else self.repeat_wait):
                st.update(pos=st["pos"] + 1, wait=now)
            return False
        if first and int(getattr(attacker, "need_cast_point", 1)) > 1:
            return False  # its first cast of the cycle waits for cost decay
        st.update(pos=st["pos"] + 1, wait=now)
        return True
