"""
Shared state and helpers for the team-level schedulers in ``apl.schedulers``.

Kit reading (buffer signatures, ramp profiles, amp chains), boss CC look-ahead,
cap checks and the fixed rotation timelines live here. So does ``FORCED_SKIP``:
scripts rebind ``scheduler.FORCED_SKIP`` and the schedulers read it through this
module at call time, so keep it here.
"""

from __future__ import annotations

import math
import re
from typing import Any

from .payload import amp_effects
from .state import skill_flags

# Stats whose ALLY-side version is defensive and worth no damage; only the
# enemy-side (negative) version is a damage amplifier.
_DEFENSIVE_ON_ALLY = ("SHIELD", "DEF", "DEFENSE")
_TEAM_SIZE = 5

# Slots that never cast under CadenceScheduler -- the player's "this card sits out"
# decision, made per TEAM by measurement (scripts/medium_sweep.py tries each slot)
# rather than mid-fight by a rule. Two in-fight rules (value trim, starvation-gated
# trim) each helped some teams +40% and cost others -10% (2026-10-02).
FORCED_SKIP: set[str] = set()

# Parse a buff/debuff effect token: TYPE<base%,scale%,dur>  ->  (TYPE, base).
_BUFF_EFF_RE = re.compile(r"([A-Z_]+)<(-?[\d.]+)(%?),")


def _buffer_signature(unit: Any) -> tuple[dict[str, float], int]:
    """(stat -> base magnitude%, target_count) for a buff-skill unit.

    Only percentage buffs are kept (a real stat buff, not a flat/duration token).
    Used to spot *dominated* buffers: a single-target buff whose stat is already
    provided to more targets at >= magnitude by another buffer is redundant.
    """
    sig: dict[str, float] = {}
    skill = getattr(unit, "skill", None)
    if skill is None:
        return sig, 1
    for eff in list(getattr(skill, "buff_effects", []) or []) + list(
        getattr(skill, "debuff_effects", []) or []
    ):
        m = _BUFF_EFF_RE.match(eff.strip())
        if not m or not m.group(3):  # require '%' — skip flat/CC tokens
            continue
        stat, mag = m.group(1), float(m.group(2))
        if mag > sig.get(stat, float("-inf")):
            sig[stat] = mag
    return sig, int(getattr(skill, "target_count", 1) or 1)


# The cycle constants below (20.5s) were tuned at the 5.0s orb regen of normal
# content, where a cycle funds ~4.1 casts. World boss regens every 5.5s, so a
# fixed 20.5s cycle opens bursts the pool cannot fund and trims a buffer from
# teams that fit. Scaling by regen keeps the ORB budget per cycle constant
# (20.5s -> 22.55s at 5.5s); at 5.0s it is the identity, so the dummy is unchanged.
# Measured on boss 2 Lv30 (v2 team, 12 seeds): 20.5s 59.67M, 22.5s 60.47M,
# 23s 61.58M, 24s 59.87M.
REFERENCE_REGEN = 5.0


def scaled_cycle(cycle: float, battle: Any) -> float:
    """``cycle`` expressed at the battle's orb regen (seconds per orb)."""
    regen = float(getattr(battle, "skill_points_regen_cd", REFERENCE_REGEN) or 0)
    return cycle * (regen / REFERENCE_REGEN) if regen > 0 else cycle


def _note_buff(st: dict, battle: Any, caster: Any) -> None:
    """Record a buff cast and when its effect will land (per-caster delay)."""
    now = battle.current_time
    st["last_buff_at"] = now
    delay_for = getattr(battle, "skill_effect_delay_for", None)
    delay = delay_for(caster) if delay_for else 0.0
    st["buff_land_at"] = max(st.get("buff_land_at", now), now + delay)


def _pure_buffer(u: Any) -> bool:
    """A cast that buffs and deals no damage -- what cadence syncs into its burst."""
    if getattr(u, "skill", None) is None:
        return False
    f = skill_flags(u.skill, u)
    return f["buff"] and not f["damage"]


_BLOCK_KINDS = ("STUN", "FROZEN", "FREEZE", "STONE", "SILENCE", "SLEEP")


def blocking_cc_per_min(battle: Any) -> float:
    """Expected seconds per minute each unit cannot cast, from the boss rotation:
    sum over CC casts of land chance x share of the team hit x duration. NUMB is
    left out (it only fizzles autos)."""
    v = getattr(battle, "_block_cc_min", None)
    if v is not None:
        return v
    boss = getattr(battle, "boss", None)
    rot = boss.s_rotation if boss is not None else ()
    v = 0.0
    if rot:
        alive = max(1, len(battle.players))
        for _, sid in rot:
            sk = boss.skills.get(sid)
            effs = (
                list(sk.debuff_effects or []) + list(sk.buff_effects or [])
                if sk
                else []
            )
            blk = [e for e in effs if e.split("<")[0] in _BLOCK_KINDS]
            if not blk:
                continue
            p = battle._extract_hit_proc_rate(effs, boss.level)
            n = min(int(getattr(sk, "target_count", 1) or 1), alive) / alive
            dur = float(re.split(r"[<,>]", blk[0])[1])
            v += p * n * dur
        v *= 60.0 / rot[-1][0]
    battle._block_cc_min = v
    return v


def next_cleanse_in(battle: Any) -> float | None:
    """Battle seconds until the boss's next scheduled self-cleanse, or None.

    Walks the same timeline `Battle._boss_phase` fires from (boss clock, looping).
    ponytail: ignores boss CC delaying the cast and state changes (enrage) in between.
    """
    boss = getattr(battle, "boss", None)
    if boss is None or not boss.cleanse_skills:
        return None
    rotation = boss.rotation(battle._boss_state)
    if not rotation:
        return None
    rate = boss.timing.clock_rate
    cycle = rotation[-1][0]
    idx = battle._boss_cast_idx
    for k in range(idx, idx + len(rotation)):
        at, sid = rotation[k % len(rotation)]
        if sid in boss.cleanse_skills:
            due = battle._boss_rotation_base + (k // len(rotation)) * cycle + at
            return due / rate - battle.current_time
    return None


_CC_KINDS = ("STUN", "FROZEN", "FREEZE", "NUMB", "STONE", "SILENCE", "SLEEP")


def next_cc_risk(battle: Any, horizon: float) -> float:
    """Expected share of the team CC'd by boss casts due within ``horizon`` s.

    Sum over each scheduled CC cast of land chance x (targets / living units), from
    the same looping timeline `next_cleanse_in` walks. A full-team 37% stun counts
    0.37; a 1-target 54% stone on a 5-card team counts 0.108.
    ponytail: ignores role priority (`prof<>` aims some CC at carries) and delays.
    """
    boss = getattr(battle, "boss", None)
    if boss is None:
        return 0.0
    rotation = boss.rotation(battle._boss_state)
    if not rotation:
        return 0.0
    info = getattr(battle, "_cc_info", None)
    if info is None:
        info = battle._cc_info = {}
        for sid, sk in boss.skills.items():
            effs = list(sk.debuff_effects or []) + list(sk.buff_effects or [])
            if any(e.split("<")[0] in _CC_KINDS for e in effs):
                p = battle._extract_hit_proc_rate(effs, boss.level)
                info[sid] = (p, int(getattr(sk, "target_count", 1) or 1))
    if not info:
        return 0.0
    alive = max(1, sum(1 for u in battle.players if u.is_alive))
    rate = boss.timing.clock_rate
    cycle = rotation[-1][0]
    idx = battle._boss_cast_idx
    risk = 0.0
    for k in range(idx, idx + len(rotation)):
        at, sid = rotation[k % len(rotation)]
        due = battle._boss_rotation_base + (k // len(rotation)) * cycle + at
        dt = due / rate - battle.current_time
        if dt > horizon:
            break
        if dt >= 0 and sid in info:
            p, n = info[sid]
            risk += p * min(n, alive) / alive
    return risk


def _channel_capped(battle: Any, is_skill: bool) -> bool:
    """Is some living ally's *baseline* hit on this channel already at its cap?

    The two channels cap at different numbers (99,999 autos, 999,999 skills) and
    saturate at different times, so "is this buff still buying anything" has a
    different answer for each. A crit-damage stack is spent once the channel it
    feeds is capped, and that is what a retire condition is really asking about.
    """
    enemy = next((e for e in battle.enemies if e.is_alive), None)
    if enemy is None:
        return False
    cap = battle.config.skill_damage_cap if is_skill else battle.config.damage_cap
    for p in battle.players:
        if not p.is_alive:
            continue
        if is_skill and getattr(p, "skill", None) is None:
            continue
        # exceed_pct=0 is the floor of the roll: a stack is only definitively
        # waste when even the worst hit is capped. Anything higher retires the
        # ramp while the low rolls are still gaining.
        dmg = battle.calculate_action_damage(
            p, enemy, is_skill=is_skill, force_crit=True, exceed_pct=0.0
        ).final_damage
        if dmg >= cap:
            return True
    return False


def skills_capped(battle: Any) -> bool:
    """Is some living ally's baseline SKILL hit already at the skill damage cap?"""
    return _channel_capped(battle, True)


# Retire conditions a player can choose between. Both channels are offered because
# they saturate independently: a team can cap its autos while its nukes still scale,
# or the reverse, and which one a retiring card was feeding decides when its cast
# stops being worth an orb.
SWAP_CONDITIONS = ("autos", "skills", "either", "both")


def swap_triggered(battle: Any, when: str) -> bool:
    if when == "skills":
        return skills_capped(battle)
    if when == "either":
        return autos_capped(battle) or skills_capped(battle)
    if when == "both":
        return autos_capped(battle) and skills_capped(battle)
    return autos_capped(battle)


def autos_capped(battle: Any) -> bool:
    """Is some living ally's *baseline* auto attack already at the damage cap?

    The stop condition for a ramp buffer (Nimbus): once a carry's autos cap,
    further permanent crit-damage stacks are pure waste. Used by
    GroupScheduler so there is one definition of "capped", not two.

    Read it only when the team's timed buffs are DOWN -- between bursts, or at the
    ramp's own cast moment. Inside a buff window it reports the buffed peak, which
    caps far earlier than the baseline and retires the ramp too soon.
    """
    enemy = next((e for e in battle.enemies if e.is_alive), None)
    if enemy is None:
        return False
    cap = battle.config.damage_cap
    for p in battle.players:
        if not p.is_alive:
            continue
        dmg = battle.calculate_action_damage(
            p, enemy, is_skill=False, force_crit=True, exceed_pct=0.0
        ).final_damage
        if dmg >= cap:
            return True
    return False


def _ramp_profile(unit: Any) -> tuple[bool, float]:
    """(is_ramp_buffer, crit_rate_window_seconds) for a unit.

    A *ramp buffer* carries an on-skill (``attack_skill``) ability granting a
    PERMANENT crit-damage stack — ``CHIT_ATK`` with ``duration == 0``. Nimbus
    [Awakened] 514's ability 51402 is the only card in the game with this shape,
    and the missing duration is a real game bug: the +60% crit damage never
    expires, so it compounds once per cast for the whole battle. Detected by
    signature rather than by card id so any future card with the same shape is
    picked up.

    The same ability's ``CHIT`` (crit *rate*) half DOES have a duration (4s on
    Nimbus). That short window is a hard deadline — a carry skill has to land
    inside it to bank a guaranteed crit — so it is returned alongside.
    """
    is_ramp = False
    window = 0.0
    for ab in getattr(unit, "abilities", []) or []:
        trig = getattr(ab, "trigger", None)
        if getattr(trig, "value", trig) != "attack_skill":
            continue
        for eff in getattr(ab, "effects", []) or []:
            name = getattr(getattr(eff, "effect_type", None), "name", None)
            dur = float(getattr(eff, "duration", 0) or 0)
            if name == "CHIT_ATK" and dur == 0:
                is_ramp = True
            elif name == "CHIT" and dur > 0:
                window = max(window, dur)
    return is_ramp, window


def derive_chain(players: list[Any]) -> tuple[list[list[str]], float]:
    """(links, gap) for a damage-up chain, or ([], 0) when the team cannot chain.

    Chain carries are units whose skill deals damage AND leaves a timed damage-up
    on the boss (negative SHIELD/DEF, or a DAMAGE debuff). A team needs two of them
    to chain -- one amp can only cover its own window. Carries go in ranked-ATK
    order, because a ranked (``max_atk``) single-target buffer lands on the top one,
    so those buffers join link 0 just ahead of it. Team-wide buffers are left out:
    an AoE buff cast costs a chain link its orb (Mira on the Senji/Andromeda team,
    -3.7%). ``gap`` is the shortest amp duration, so no link opens a hole.
    """

    def atk(u: Any) -> float:
        st = getattr(u, "stat", None)
        if st is None:
            return 0.0
        return float(st.base_atk) * float(st.normal_dmg_modifier.get_modifier_total())

    carries, buffers, durs = [], [], []
    for u in players:
        sk = getattr(u, "skill", None)
        if sk is None:
            continue
        fl = skill_flags(sk, u)
        amps = [
            e
            for e in amp_effects(u)
            if e.on_enemy and e.magnitude < 0 and 0 < e.duration < math.inf
        ]
        if fl["damage"] and amps:
            carries.append(u)
            durs.append(min(e.duration for e in amps))
        elif not fl["damage"] and "max_atk" in str(
            getattr(sk, "target_selector", "") or ""
        ):
            buffers.append(u)
    if len(carries) < 2:
        return [], 0.0
    carries.sort(key=atk, reverse=True)
    links = [[b.slot for b in buffers] + [carries[0].slot]]
    links += [[c.slot] for c in carries[1:]]
    return links, min(durs)


# Timed effects that raise a carry's damage when an ally puts them on it.
_DMG_BUFF_TAGS = ("DAMAGE", "ATK", "CRIT", "CRIT_DMG", "SKILL_DMG", "NORMAL_DMG")
# Timed effects on the boss that raise everyone's damage taken.
_AMP_TAGS = ("SHIELD", "DEF", "DEFENSE", "DAMAGE")


def _unit_atk(u: Any) -> float:
    """Post-setup ATK in the normal bucket: what ``max_atk`` targeting ranks on."""
    st = getattr(u, "stat", None)
    if st is None:
        return 0.0
    return float(st.base_atk) * float(st.normal_dmg_modifier.get_modifier_total())


def _unit_amps(u: Any) -> list:
    """The timed damage-taken debuffs ``u``'s skill puts on the boss."""
    return [
        e
        for e in amp_effects(u)
        if e.on_enemy and e.magnitude < 0 and 0 < e.duration < math.inf
    ]


ROTATION_STEP, ROTATION_DUMP = 0.5, 8.0


def chain_rotation(
    carries: list,
    amp: list,
    debuffers: list,
    slots: list,
    regen: float,
    t0: float,
    margin: float = 0.5,
    delays: dict | None = None,
) -> dict:
    """Amp-chain rotation: ``{cycle, t0, off: {slot: s}}``, one cost-1 cast each.

    Every boss amp (SHIELD debuff) at Lv90 reaches the -75% floor on its own, so
    overlap is waste and only uptime counts. ``debuffers`` (amp casters too weak to
    carry, e.g. Amanojaku[Strife]) open the cycle; each amp carry picks the amp up as
    the previous one ends; the ally buffers go just before the first carry so their
    8s window covers every nuke, which caps the carry spread. The cycle is one cast
    per orb tick. Boss 4 Lv1, 2026-11-02, 64 fresh seeds: +5..+13% over the burst on
    all 8 debuffer + amp-carry teams of the top 30, matching or beating a per-team
    timing search (scripts/rotation_search.py).
    """
    dur, lag = 8.0, 0.9 + 0.8  # buff landing + Hikoboshi-class hit delay
    carries = [s for s in carries if s in slots]
    debuff = [s for s in debuffers if s in slots and s not in carries]
    bufs = [s for s in slots if s not in carries and s not in debuff]
    off, t = {}, 0.0
    for s in debuff:
        off[s] = t
        t += dur - margin
    first = t if debuff else 1.0  # no debuffer: carries follow the buffers
    amp_carries = [c for c in carries if c in amp]
    k = len(amp_carries)
    room = dur - margin if not bufs else dur - lag - margin
    step = min(dur - margin, room / (k - 1)) if k > 1 else 0.0
    for i, c in enumerate(amp_carries):
        off[c] = first + i * step
    for c in carries:
        off.setdefault(c, first)
    for b in bufs:
        off[b] = max(0.0, first - 1.0)
    lo = min(off.values())
    q = ROTATION_STEP
    off = {s: round((o - lo) / q) * q for s, o in off.items()}
    cycle = round(len(off) * regen / q) * q  # one cast per orb tick
    if delays and debuff and amp_carries:
        # Close the chain on LANDING times (cast + the caster's effect delay): the
        # next cycle's debuffer should land as the last carry's amp lapses. Cast
        # offsets alone assume Hikoboshi's 0.8s, so an Andromeda chain (0.35s)
        # lapses 0.55s every cycle; one cast tick shorter closes it, +1..+4% on 13
        # boss 4 Lv1 ledger teams (2026-11-03). Only a lapse that one tick closes:
        # under a tick (Behemoth, 0.35s) the overshoot and orb drift cost more
        # (-3.9% at Lv30); over two (a slow debuffer, or one amp carry) a tick
        # shorter leaves a hole anyway (-1.3..-2.7%). 21.0s starves the pool.
        last = max(off[c] + delays.get(c, 0.0) for c in amp_carries)
        lapse = cycle - (last + dur - delays.get(debuff[0], 0.0))
        if q - 1e-9 <= lapse < 2 * q:
            cycle -= q
    return {"cycle": cycle, "t0": t0, "off": off}


def rotation_timeline(rot: dict, horizon: float) -> dict:
    """``{cycle, t0, off}`` -> a ``ReplayScheduler`` timeline: every cast waits for
    cost 1, then each slot dumps once in the last ``ROTATION_DUMP`` seconds."""
    c = {s: [] for s in rot["off"]}
    t = rot["t0"]
    end = horizon - ROTATION_DUMP
    while t < end:
        for s, o in rot["off"].items():
            if t + o < end:
                c[s].append([round(t + o, 1), 1])
        t += rot["cycle"]
    for s in c:
        c[s].append([end, 99])
    return c
