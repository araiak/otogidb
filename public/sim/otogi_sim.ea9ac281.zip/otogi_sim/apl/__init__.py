"""Skill-casting policy for the battle simulator.

``get_engine().should_cast(attacker, battle, target)`` asks the installed team-level
scheduler (``apl.schedulers``); ``apl.install`` picks one from ``MC_SCHEDULER``.
"""

from .engine import AplEngine, get_engine

__all__ = ["AplEngine", "get_engine"]
