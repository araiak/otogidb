"""
Otogi Battle Simulator

Lifecycle-accurate combat simulation, modelled on behaviour observed in game.
Supports 5-wave, 1-wave, and defensive evaluation modes.

Usage:
    # Simulate a team battle
    python -m otogi_sim simulate --team 1,15,733 --mode 5wave

    # Replay captured hits through the engine
    python -m otogi_sim compare
"""

# Core models
from .models import DamageResult, ActionType, CritType

# Lifecycle classes (NEW)
from .lifecycle import MonsterModel, MonsterStat, MonsterComponent, ModifierType

# Data loading (NEW)
from .data_loader import GameDataLoader, get_loader, build_monster

# Battle simulation (NEW)
from .battle import Battle, BattleConfig, BattleEvent

# Simulation modes (NEW)
from .modes import (
    FiveWaveSimulator,
    OneWaveSimulator,
    DefenseSimulator,
    SimulationResult,
    run_simulation,
)

__version__ = "2.0.0"
__all__ = [
    # Core models
    "DamageResult",
    "ActionType",
    "CritType",
    # Lifecycle
    "MonsterModel",
    "MonsterStat",
    "MonsterComponent",
    "ModifierType",
    # Data loading
    "GameDataLoader",
    "get_loader",
    "build_monster",
    # Battle
    "Battle",
    "BattleConfig",
    "BattleEvent",
    # Simulation modes
    "FiveWaveSimulator",
    "OneWaveSimulator",
    "DefenseSimulator",
    "SimulationResult",
    "run_simulation",
]
