"""JSON in, JSON out -- the only surface the browser calls.

The website used to carry its own damage model (``otogidb/src/lib/team-calc.ts``),
a closed-form DPS estimate with no battle loop. It disagreed with this engine on
defense (flat-and-last here, a capped percentage there), on the attribute triangle,
on LB exceed keys, and on 19 of 29 effect types. Keeping two models of the same game
in sync is not a maintenance problem, it is a category error -- so the browser now
runs *this* engine under Pyodide and there is no second implementation left to drift.

Everything here is plumbing. Scoring goes through ``spec.score`` -- the same contract
the tier lists use -- so this module cannot become a second scoring path.
"""

from __future__ import annotations

import json
import secrets
from pathlib import Path
from typing import Any, Optional

from .battle import SKILL_EFFECT_DELAY
from .data_loader import GameDataLoader, set_loader
from .spec import Scenario, TeamSpec, score, simulate
from .apl.scheduler import SWAP_CONDITIONS

_SLOTS = ("P1", "P2", "P3", "P4", "P5")

_loader: Optional[GameDataLoader] = None


def init(data_dir: str) -> str:
    """Point the engine at the game data and load it once.

    Separate from ``run`` so the browser can pay the JSON parse cost during its
    loading spinner rather than inside the first simulation.
    """
    global _loader
    _loader = GameDataLoader(Path(data_dir))
    _loader.load_all()
    # The singleton too, not just our handle: modes.DamageBenchmark calls get_loader()
    # itself, and in the browser REPO_ROOT points at a virtual path with no data there.
    set_loader(_loader)
    return json.dumps(
        {"cards": len(_loader._cards), "abilities": len(_loader._abilities)}
    )


def _team(cfg: dict) -> TeamSpec:
    """Browser slot layout -> TeamSpec.

    The site thinks in 5 battle slots + 2 reserves; the contract splits the 5 into
    4 active plus a helper, because the helper is borrowed and scoped separately for
    overlay abilities. Same seven cards either way.
    """
    ids = [int(x or 0) for x in cfg.get("cards", [])][:7]
    ids += [0] * (7 - len(ids))
    assists = [int(x or 0) for x in cfg.get("assists", [])][:7]
    assists += [0] * (7 - len(assists))
    return TeamSpec(
        active=tuple(ids[0:4]),
        helper=ids[4],
        reserve=tuple(ids[5:7]),
        active_assists=tuple(assists[0:4]),
        helper_assist=assists[4],
        reserve_assists=tuple(assists[5:7]),
        level=int(cfg.get("level", 90)),
        lb=int(cfg.get("lb", 4)),
        bonds=_bonds(cfg.get("bonds")),
    )


def _bonds(raw: Any) -> tuple:
    """[[["normal",7.5],["skill",5]], ...] -> the tuple-of-tuples TeamSpec hashes.

    Seven entries in slot order, padded, so a short list from the UI cannot silently
    shift one card's bonds onto another.
    """
    rows = list(raw or [])[:7]
    rows += [[]] * (7 - len(rows))
    return tuple(tuple((str(k), float(v)) for k, v in (row or [])) for row in rows)


# Policies the browser may ask for. Deliberately a short list, not "whatever the
# caller typed": an unknown name would install NO scheduler, which does not fail --
# it silently scores about a third of the real damage.
_WEB_SCHEDULERS = ("group", "cadence")

# The calculator used to carry its own delay while the engine defaulted to 0.0. It no
# longer diverges: both run the measured value from SKILL_EFFECT_DELAY.
_WEB_EFFECT_DELAY = SKILL_EFFECT_DELAY


def _scenario(cfg: dict) -> Scenario:
    """Fight config, including the player's cast groups and cast policy.

    Groups ride one JSON env var because the layout is structured; ``scheduler_params``
    is folded into ``Scenario.key()``, so two runs with different groups are correctly
    different scenarios rather than one silently reusing the other's policy.

    ``scheduler`` picks between the rotation the player authored (``group``) and the
    one the engine discovers for itself (``cadence``, what the tier lists run). Groups
    are still passed under cadence so switching back and forth does not lose them, and
    they stay in the key so the two runs remain distinct scenarios.
    """
    groups = cfg.get("groups") or []
    params: list[tuple[str, Any]] = [("MC_GROUPS", json.dumps(groups))]
    # A player-authored retire-and-replace: {retiring_slot: replacement_slot}. It is
    # NOT inferred -- the scheduler used to decide this for itself off `autos_capped`
    # and measured -1.8% on the team it was written for, because the retiring card's
    # skill was still delivering an unsaturated speed buff. So it is the player's to
    # state and test. In `scheduler_params`, hence in the Scenario key, or two runs
    # differing only by the swap would collide in the cache.
    swap = cfg.get("swap") or {}
    if swap:
        params.append(("MC_GROUP_SWAP", json.dumps(swap)))
        # Which damage channel must saturate before the retiring card stands down.
        # The two cap independently (99,999 autos, 999,999 skills), so a card feeding
        # only one of them is spent as soon as THAT one is capped.
        when = str(cfg.get("swap_when") or "autos").lower()
        params.append(
            ("MC_GROUP_SWAP_WHEN", when if when in SWAP_CONDITIONS else "autos")
        )
    scheduler = str(cfg.get("scheduler") or "group").lower()
    if scheduler not in _WEB_SCHEDULERS:
        scheduler = "group"
    boss_id = cfg.get("boss_id")
    return Scenario(
        # Overridable per request; the default is the measured value the whole engine
        # now runs.
        skill_effect_delay=float(cfg.get("skill_effect_delay", _WEB_EFFECT_DELAY)),
        time_limit=float(cfg.get("time_limit", 300.0)),
        boss_id=int(boss_id) if boss_id else None,
        boss_level=int(cfg.get("boss_level", 30)),
        # A boss fight is only meaningful with mortal players -- that is the whole
        # difference between it and the dummy.
        immortal_players=not boss_id,
        scheduler=scheduler,
        scheduler_params=tuple(params),
    )


def _stats(battle: Any) -> list[dict]:
    """Per-card stats as they stood at the OPENING of the fight.

    `battle.opening_stats` is captured after entry/wave/reserve abilities land and
    before anyone acts, so this is what the team actually starts with -- level
    scaling, limit breaks, bonds, assists and passives folded in, no combat buff yet.
    Reading the stats at the END instead would show whatever buffs happened to still
    be ticking when the bell rang.
    """
    opening = getattr(battle, "opening_stats", {}) or {}
    out = []
    for p in battle.players:
        snap = opening.get(p.slot) or battle.stat_snapshot(p)
        out.append(
            {
                "slot": p.slot,
                # Identity lives on the model, not the component.
                "card_id": int(getattr(p.model, "card_id", 0) or 0) if p.model else 0,
                "name": getattr(p.model, "name", "") if p.model else "",
                "alive": bool(p.is_alive),
                **snap,
            }
        )
    return out


# Events a player can act on. Auto-attacks, DoT ticks and auto-heals are deliberately
# left out: there are thousands of them and none is a decision. (A healer heals on its
# own every turn an ally is hurt -- its CAST still shows, which is the part you time.)
_TIMELINE_KINDS = {"buff", "debuff", "cc", "death", "boss_cast", "wave_start"}


def _timeline(battle: Any) -> list[dict]:
    """Flatten the traced battle into something a player can follow in game.

    The cast log says a skill fired; this says what it PUT on whom and for how long,
    which is the part you have to reproduce by hand at the right moment.
    """
    # Skill damage is on the attack event, but the authoritative cast is the gate
    # event, so pair them up by (actor, time) instead of reading casts off attacks.
    hits = {
        (e.attacker, round(e.time, 2)): e
        for e in battle.events
        if e.event_type == "attack" and e.was_skill
    }

    out: list[dict] = []
    for e in battle.events:
        d = e.details or {}
        if e.event_type == "cast":
            hit = hits.get((e.attacker, round(e.time, 2)))
            out.append(
                {
                    "t": round(e.time, 1),
                    "kind": "cast",
                    "actor": e.attacker,
                    "target": hit.target if hit else None,
                    "damage": int(hit.damage) if hit else None,
                    "crit": bool(
                        hit and getattr(hit.crit_type, "name", "NONE") != "NONE"
                    ),
                    "cost": d.get("cost"),
                }
            )
        elif e.event_type in _TIMELINE_KINDS:
            out.append(
                {
                    "t": round(e.time, 1),
                    "kind": e.event_type,
                    "actor": e.attacker,
                    "target": e.target,
                    "stat": d.get("stat") or d.get("kind"),
                    "value": d.get("value"),
                    "duration": d.get("duration", 0.0),
                    "permanent": bool(d.get("permanent", False)),
                    "damage": int(e.damage) or None,
                    # Modifier total before and after this effect landed, so the UI
                    # can show the change rather than just the effect's own value.
                    "before": d.get("before"),
                    "after": d.get("after"),
                    "snapshot": d.get("snapshot"),
                }
            )
    out.sort(key=lambda x: x["t"])
    return out


def _damage_split(battle: Any) -> dict:
    """Per-slot auto vs skill damage: count, total, min, max, mean.

    A single mean hides what a player needs to know. A carry whose skill reads
    "mean 799k" may be capping at 999,999 half the time and landing 114k the rest
    because a cast fell outside a crit window -- same mean, completely different
    problem. The range is what makes that visible.

    Only the traced battle has per-hit events, so this describes seed 0, not the mean
    across runs.
    """
    acc: dict = {}
    for e in battle.events:
        if e.event_type != "attack" or not e.attacker or e.attacker.startswith("E"):
            continue
        bucket = acc.setdefault(e.attacker, {"auto": [], "skill": []})
        bucket["skill" if e.was_skill else "auto"].append(int(e.damage))

    out: dict = {}
    for slot, kinds in acc.items():
        row = {}
        for kind, hits in kinds.items():
            if not hits:
                continue
            row[kind] = {
                "n": len(hits),
                "total": sum(hits),
                "min": min(hits),
                "max": max(hits),
                "mean": round(sum(hits) / len(hits)),
            }
        out[slot] = row
    return out


def run(payload: str, progress: Any = None) -> str:
    """Score one team and return everything the calculator UI renders.

    ``progress(done, total)`` is optional and is forwarded to ``spec.score``; the
    browser passes a JS function so a long run can say which seed it is on. The extra
    detail battle is reported as one final step, because it is a real battle and the
    user should not watch the counter sit at 10/10 while it runs.
    """
    cfg = json.loads(payload)
    team, scenario = _team(cfg), _scenario(cfg)
    iters = max(1, int(cfg.get("iters", 5)))
    # The seed block is the run's identity: a battle is deterministic in
    # (team, scenario, seed), so reporting it back is what lets a player re-run a
    # result they are looking at, or hand someone else the exact fight. It used to
    # be hardcoded to range(iters) -- every run in every browser fought the same
    # five battles, which reads as "this IS the number" rather than "this is one
    # sample", and hid seed-to-seed spread that is ~2-4% on a boss fight.
    # Unset means a fresh random block, so a re-run is a genuine second opinion.
    raw_seed = cfg.get("seed")
    base = int(raw_seed) if raw_seed not in (None, "") else secrets.randbelow(1_000_000)
    seeds = list(range(base, base + iters))

    steps = iters + 1  # the scored seeds, plus the traced battle below
    result = score(
        team,
        scenario,
        seeds=seeds,
        loader=_loader,
        progress=(lambda d, _t: progress(d, steps)) if progress else None,
    )

    # One extra battle on seeds[0] for the per-card breakdown and cast timeline.
    # simulate() is deterministic in (team, scenario, seed), so this reproduces the
    # first scored battle exactly rather than being a separate sample.
    detail = simulate(
        team, scenario, seeds[0], trace=True, record_casts=True, loader=_loader
    )
    if progress:
        progress(steps, steps)
    b = detail.battle
    split = _damage_split(b)

    return json.dumps(
        {
            "mean": result.mean,
            "sd": result.sd,
            "seed": base,
            "per_seed": result.per_seed,
            "iters": result.n,
            "effective_time": detail.effective_time,
            "wiped": detail.wiped,
            "deaths": detail.deaths,
            "survival_time": detail.survival_time,
            "per_card": [
                {
                    "slot": s,
                    "damage": int(b.get_unit_damage(s)),
                    **{k: v for k, v in (split.get(s) or {}).items()},
                }
                for s in _SLOTS
            ],
            "casts": {s: list(b.skill_cast_log.get(s, [])) for s in _SLOTS},
            "timeline": _timeline(b),
            "stats": _stats(b),
        }
    )


def suggest_groups(payload: str, progress: Any = None) -> str:
    """Pick the cast group for this team and say why.

    Same payload as `run` -- the browser already has one, and the answer depends on
    the whole team (assists, bonds, the boss), not on the card list alone. Fewer
    seeds than a scored run by default: this ranks candidates against each other
    under common random numbers, where paired differences are far tighter than the
    ~1% per-battle spread, so 3 seeds separates them and 10 would only be slower.
    """
    from .suggest import suggest as _suggest

    cfg = json.loads(payload)
    team, scenario = _team(cfg), _scenario(cfg)
    iters = max(1, int(cfg.get("suggest_iters", 3)))
    raw_seed = cfg.get("seed")
    base = int(raw_seed) if raw_seed not in (None, "") else secrets.randbelow(1_000_000)
    r = _suggest(
        team,
        scenario,
        seeds=list(range(base, base + iters)),
        loader=_loader,
        progress=progress,
    )
    return json.dumps(
        {
            "groups": r["groups"],
            "swap": r["swap"],
            "score": r["score"],
            "cap": r["cap"],
            "dropped": r["dropped"],
            "info": r["info"],
            "notes": r.get("notes", []),
            "trace": r["trace"],
            "seed": base,
        }
    )
