"""Which skills belong in the cast group.

The group SIZE is arithmetic, not a search. A skill's orb cost decays back to 1
every ``skill_minus_cost_cd`` (20s) and the team earns one orb every
``skill_points_regen_cd`` (5s), so a group of N members costs N orbs per 20s
against an income of 4. Measured on the three verified teams: at N=4 the income
is exactly spent (0.96 orbs per 5s against an income of 1.00) and every member
still casts on its 20s floor; at N=5 the total cast count does not move -- orbs
are still the ceiling -- but the beat stretches to ~26s, so the fifth member's
casts come straight out of the carries'. On `mira_1631_1720_1721_hinoto` that is
35 carry casts becoming 28, and 71.4M becoming 67.6M.

So above the budget a member is pure redistribution from the best cards to the
worst, and the cap is `skill_minus_cost_cd / skill_points_regen_cd`.

Only the RANKING needs the simulator, because a skill's worth depends on the
group it joins rather than on the skill: on `mira_nimbus_ohina_odairi` a buffer
worth +1.2M beside the bare carry is -2.1M once the real group is there, having
eaten the orb a stronger buffer would have spent. So each candidate is measured
at the margin, against the group chosen so far.

ponytail: greedy, not exhaustive. Greedy matched brute force to within 0.16% on
all three verified teams (inside the ~1% seed noise) for 7 scored groups instead
of 31. Enumerate if a team ever shows a real gap.
"""

from __future__ import annotations

import json
from typing import Any, Callable, Optional, Sequence

from .apl.scheduler import _ramp_profile, skill_flags
from .spec import Scenario, TeamSpec, score, simulate

SLOTS = ("P1", "P2", "P3", "P4", "P5")

# Stats a buff has to move to be worth an orb in a damage race. A skill that only
# heals or shields scores 0 here and sorts to the back, which is where the measured
# ranking put them too.
_OFFENSIVE = ("ATK", "CHIT", "CHIT_ATK", "DAMAGE", "NORM_ATK", "SKILL_ATK", "SPD")
_EFFECT = __import__("re").compile(r"([A-Z_]+)<\s*(-?[\d.]+)")


def prior(info: dict[str, dict], skills: dict[str, Any]) -> list[str]:
    """Cheap ranking of the non-carry slots, best first. No battles.

    Magnitude times the number of CARRIES the buff reaches -- not times its target
    count. Measured on `mira_1631_1720_1721_hinoto`, raw target count inverts the
    answer: Mira buffs +20% ATK to all five allies and scores worst of the three
    (100 by target count, last by measurement) because three of those five deal no
    damage, while Orihime's +35% to the top two by ATK lands entirely on the carries.

    A duplicate of a card already counted scores 0: a second copy of the same buff
    refreshes it rather than stacking, which is the engine's own `_dominated_buffers`
    rule arrived at from the other side.
    """
    carries = [s for s in info if info[s]["damage"]]
    seen: set[Any] = set()
    ranked = []
    for slot, i in info.items():
        if i["damage"]:
            continue
        sk = skills.get(slot)
        cid = i.get("card_id")
        if sk is None or (cid is not None and cid in seen):
            ranked.append((0.0, slot))
            continue
        seen.add(cid)
        n = int(getattr(sk, "target_count", 1) or 1)
        sel = str(getattr(sk, "target_selector", "") or "")
        # `max_atk` picks the top-ATK allies, which is where the carries are; an
        # untargeted count<n> sprays across the whole team instead.
        hits = min(len(carries), n) if "max_atk" in sel else len(carries) * n / 5.0
        mag = 0.0
        for text in getattr(sk, "effects", None) or []:
            for name, val in _EFFECT.findall(str(text)):
                if name in _OFFENSIVE:
                    mag += abs(float(val))
        # The durationless-stack bug compounds all fight instead of lapsing after 8s,
        # so a ramp buffer is worth far more than its printed magnitude. Ranked top
        # outright rather than with a fudge factor -- it is a different kind of card.
        ranked.append((float("inf") if i["ramp"] else mag * hits, slot))
    ranked.sort(reverse=True)
    return [s for _v, s in ranked]


def budget(scenario: Scenario, loader: Any = None) -> int:
    """How many members a group can fund per cost-decay window."""
    from .battle import BattleConfig

    defaults = BattleConfig()
    decay = float(defaults.skill_minus_cost_cd)
    regen = float(scenario.regen_cd or defaults.skill_points_regen_cd)
    return max(1, int(decay // regen))


def classify(team: TeamSpec, scenario: Scenario, loader: Any = None) -> dict[str, dict]:
    """Per-slot skill shape, read off a real opening battle state.

    One battle, not a data-file lookup: whether a slot can cast at all depends on
    assists, bonds and passives that only exist once the team is built.
    """
    battle = simulate(team, scenario, 0, record_casts=True, loader=loader).battle
    out: dict[str, dict] = {}
    for p in battle.players:
        if getattr(p, "skill", None) is None:
            continue
        is_ramp, _window = _ramp_profile(p)
        out[p.slot] = {
            "name": getattr(getattr(p, "model", None), "name", p.slot),
            "card_id": getattr(getattr(p, "model", None), "card_id", None),
            "damage": bool(skill_flags(p.skill, p)["damage"]),
            "ramp": bool(is_ramp),
        }
    return out


def classify_with_skills(
    team: TeamSpec, scenario: Scenario, loader: Any = None
) -> tuple[dict[str, dict], dict[str, Any]]:
    """`classify`, plus the raw skill object per slot, for the static prior."""
    battle = simulate(team, scenario, 0, record_casts=True, loader=loader).battle
    info, skills = {}, {}
    for p in battle.players:
        if getattr(p, "skill", None) is None:
            continue
        is_ramp, _w = _ramp_profile(p)
        info[p.slot] = {
            "name": getattr(getattr(p, "model", None), "name", p.slot),
            "card_id": getattr(getattr(p, "model", None), "card_id", None),
            "damage": bool(skill_flags(p.skill, p)["damage"]),
            "ramp": bool(is_ramp),
        }
        skills[p.slot] = p.skill
    return info, skills


def _score(
    team: TeamSpec,
    scenario: Scenario,
    group: Sequence[str],
    seeds: Sequence[int],
    loader: Any,
    swap: Optional[dict[str, str]] = None,
) -> float:
    params: list[tuple[str, Any]] = [("MC_GROUPS", json.dumps([list(group)]))]
    if swap:
        params.append(("MC_GROUP_SWAP", json.dumps(swap)))
    sc = Scenario(
        **{
            k: v
            for k, v in vars(scenario).items()
            if k not in ("scheduler", "scheduler_params")
        },
        scheduler="group",
        scheduler_params=tuple(params),
    )
    return score(team, sc, seeds=seeds, loader=loader).mean


def notes_for(info: dict[str, dict], swap: dict[str, str]) -> list[str]:
    """Caveats the suggested groups cannot express, so the number is read honestly.

    A ramp buffer (Nimbus [Awakened] 514, the one card whose on-cast crit-damage
    stack has no duration and so compounds all fight) saturates PART WAY: once the
    carry's autos hit the damage cap the stack is worth nothing more, but the same
    cast also carries SPD +26% and a ~4s crit-rate window, and neither of those
    saturates. So the play is a priority shift, not a retirement.

    Measured on the player's single-Odairi team, where Odairi is capped on 231 of
    254 autos and the four supports still deal 29.4% of total damage uncapped:
    retiring Nimbus at cap scores -1.8%, and demoting it to its own bucket -0.4%,
    against simply leaving it in the burst. What a flat group CANNOT express is the
    thing worth expressing -- that post-saturation an all-team speed buff (Ohina,
    20% to 5) overtakes Nimbus's single-target 26%, because under Mira's team ATK
    buff every slot's autos are live: 0.20 x 1.00 beats 0.26 x 0.70.
    """
    out: list[str] = []
    for slot, i in info.items():
        if not i.get("ramp"):
            continue
        name = i.get("name", slot)
        msg = (
            f"{name} ({slot}) is a ramp buffer: its crit-damage stack never expires, "
            "so it saturates once your carry's autos cap -- but the same cast also "
            "buffs attack speed, which never saturates. Keep casting it (retiring it "
            "measured -1.8%); what a cast group cannot express is the priority shift "
            "afterwards, when a team-wide speed buff overtakes it. This score is a "
            "floor for this team."
        )
        if swap.get(slot):
            msg += (
                f" The search did find a retire-for-{swap[slot]} swap that beat "
                "leaving it in, which is unusual -- worth checking by hand."
            )
        out.append(msg)
    return out


def _score2(
    team: TeamSpec,
    scenario: Scenario,
    groups: Sequence[Sequence[str]],
    seeds: Sequence[int],
    loader: Any,
) -> float:
    """Score a multi-group layout. Priority is left to right; a later group casts
    only while no earlier one holds the floor."""
    sc = Scenario(
        **{
            k: v
            for k, v in vars(scenario).items()
            if k not in ("scheduler", "scheduler_params")
        },
        scheduler="group",
        scheduler_params=(("MC_GROUPS", json.dumps([list(g) for g in groups])),),
    )
    return score(team, sc, seeds=seeds, loader=loader).mean


def suggest(
    team: TeamSpec,
    scenario: Optional[Scenario] = None,
    seeds: Sequence[int] = (0, 1, 2),
    loader: Any = None,
    progress: Optional[Callable[[int, int], None]] = None,
) -> dict:
    """Greedy group selection. Returns the group, an optional ramp swap, and a trace.

    The trace is the point as much as the answer: a player who is told "drop Mira"
    and shown what each candidate was worth at the margin can disagree with it.
    """
    scenario = scenario or Scenario()
    info = classify(team, scenario, loader)
    carries = [s for s in SLOTS if info.get(s, {}).get("damage")]
    rest = [s for s in SLOTS if s in info and s not in carries]
    cap = min(len(info), budget(scenario))

    # Every caster competes on the same scale, including the damage skills. Treating
    # `damage=True` as "always cast" is the same mistake as treating a stat label as
    # a value: card 734 Ibaraki Doji is fielded for two PASSIVE abilities (+25% crit
    # rate to Phantasma as leader, +15% skill damage at wave start) that fire whether
    # or not it ever casts, while its skill is an 888-base AoE -- one weak hit on a
    # single boss, against 2905 for Hikoboshi. Its orb is better spent elsewhere, so
    # the search has to be allowed to leave it out.
    group: list[str] = []
    rest = [s for s in SLOTS if s in info]

    steps = 1 + sum(range(max(1, len(rest)) + 1)) + len(rest) + 1
    done = 0

    def tick() -> None:
        nonlocal done
        done += 1
        if progress:
            progress(min(done, steps), steps)

    # Baseline: nobody casts at all. Autos alone, and a skill has to beat that to
    # earn its slot -- which is the comparison a passive-carried card like 734 fails.
    current = _score(team, scenario, [], seeds, loader)
    tick()
    trace = [{"group": [], "score": current, "added": None}]

    def lay(members: Sequence[str]) -> list[str]:
        """Supports first, then damage. The one ordering rule that is not close:
        putting the carries first measured -21% and -22% on the two Hinoto teams."""
        chosen = [s for s in members]
        return [s for s in chosen if s not in carries] + [
            s for s in chosen if s in carries
        ]

    while rest and len(group) < cap:
        scored = []
        for c in rest:
            scored.append((_score(team, scenario, lay(group + [c]), seeds, loader), c))
            tick()
        best, pick = max(scored)
        if best <= current:
            trace.append({"group": None, "score": best, "rejected": pick})
            break
        group = group + [pick]
        rest.remove(pick)
        current = best
        trace.append({"group": lay(group), "score": best, "added": pick})
    group = lay(group)

    # Overflow bucket. The orb budget caps the BURST, not the fight: a team whose
    # main group is smaller than the budget still earns income the burst does not
    # spend. A second, lower-priority group casts only while group 1 is not holding
    # the floor, so it soaks up that surplus without joining the burst and stretching
    # its cadence -- which is what being IN group 1 would do.
    #
    # Measured on the player's single-Odairi config: [[P3,P1,P4],[P2]] scores 61.4M
    # against 58.6M for the best single group, +4.7%. Framing the choice as
    # in-group-or-silent could not express it, and the player's own rotation was
    # unreachable.
    overflow: list[str] = []
    for c in list(rest):
        cand = [group, [c]]
        v = _score2(team, scenario, cand, seeds, loader)
        tick()
        if v > current:
            overflow, current = [c], v
            rest.remove(c)
            trace.append({"group": list(group), "overflow": [c], "score": v})
            break

    # The ramp special case. Nimbus [Awakened] 514 is the only card in the game whose
    # on-cast buff has no duration (a real game bug: the +60% crit damage never
    # expires), so it does not want a permanent group slot -- it wants one until its
    # stacks cap a carry's autos, after which every further stack is waste. That is
    # what MC_GROUP_SWAP expresses, so offer it the best card the cap left out.
    swap: dict[str, str] = {}
    ramp = next((s for s in group if info.get(s, {}).get("ramp")), None)
    if ramp and rest:
        cand = {ramp: rest[0]}
        v = _score(team, scenario, group, seeds, loader, swap=cand)
        tick()
        if v > current:
            swap, current = cand, v
            trace.append({"group": list(group), "score": v, "swap": cand})
    if progress:
        progress(steps, steps)

    return {
        "groups": [group] + ([overflow] if overflow else []),
        "swap": swap,
        "score": current,
        "cap": cap,
        "dropped": rest,
        "info": info,
        "notes": notes_for(info, swap),
        "trace": trace,
    }


def suggest_fast(
    team: TeamSpec,
    scenario: Optional[Scenario] = None,
    seeds: Sequence[int] = (0, 1, 2),
    loader: Any = None,
    progress: Optional[Callable[[int, int], None]] = None,
) -> dict:
    """Two battles instead of seven: cadence, then one group the prior proposes.

    For scoring one team the full greedy search is cheap. For scoring every team in
    the game it is seven times the bill, so this is the layered version: rank the
    buffers statically, fill the group to the orb budget, run it once, and report
    whichever of the two policies actually won.

    The best-of is not a tie-breaker, it is the safety net. The prior cannot tell a
    worthless buffer from a good one -- on `mira_nimbus_ohina_odairi` it proposes a
    group including Ohina, whose casts are worth less than the carry tempo they
    displace, and that group scores 57.9M against cadence's 60.4M. Taking the better
    of the two returns cadence there and the better group everywhere else, so the
    layered answer is never worse than the cadence baseline it started from.
    """
    scenario = scenario or Scenario()
    info, skills = classify_with_skills(team, scenario, loader)
    carries = [s for s in SLOTS if info.get(s, {}).get("damage")]
    cap = min(len(info), budget(scenario))
    ranked = prior(info, skills)
    keep = ranked[: max(0, cap - len(carries))]
    group = keep + carries

    # Supports before carries is the ordering rule that matters and it is not close:
    # putting the carries first measured -21% on hinoto, -22% on hinoto_v2. Order
    # WITHIN the supports is worth ~1% and is not derivable -- it flips direction
    # between hinoto (Tsukuyomi first, +1.4%) and hinoto_v2 (Orihime first, +0.7%),
    # which are the same five cards with different bonds. So spend one extra battle
    # on the swap rather than trying to predict it.
    alts = [group]
    if len(keep) >= 2:
        alts.append([keep[1], keep[0], *keep[2:]] + carries)

    steps = 1 + len(alts)
    cad_scen = Scenario(
        **{
            k: v
            for k, v in vars(scenario).items()
            if k not in ("scheduler", "scheduler_params")
        },
        scheduler="cadence",
    )
    cadence = score(team, cad_scen, seeds=seeds, loader=loader).mean
    if progress:
        progress(1, steps)
    scored = []
    for i, g in enumerate(alts):
        scored.append((_score(team, scenario, g, seeds, loader) if g else 0.0, i))
        if progress:
            progress(2 + i, steps)
    grouped, best_i = max(scored)
    group = alts[best_i]

    won = "group" if grouped > cadence else "cadence"
    return {
        "groups": [group],
        "swap": {},
        "score": max(grouped, cadence),
        "scheduler": won,
        "cap": cap,
        "dropped": [s for s in ranked if s not in keep],
        "info": info,
        "notes": notes_for(info, {}),
        "trace": [
            {"group": None, "score": cadence, "added": None, "policy": "cadence"},
            *[
                {"group": list(alts[i]), "score": v, "added": None, "policy": "group"}
                for v, i in sorted(scored, reverse=True)
            ],
        ],
    }
