import os

"""
Simulation configuration for the Otogi Battle Simulator.

Provides predefined configurations for different simulation modes.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional
from enum import Enum


class SimulationMode(Enum):
    """Available simulation modes."""

    FIVE_WAVE = "5wave"  # Conquest-style 5-wave battle
    ONE_WAVE = "1wave"  # Single wave burst evaluation
    DEFENSE = "defense"  # Defensive value comparison


@dataclass
class EnemyProfile:
    """Enemy configuration for simulation."""

    # Stats
    hp: int = 10000
    atk: int = 100
    speed: float = 1000.0
    crit: float = 10.0

    # Scaling
    hp_scaling: float = 1.0
    atk_scaling: float = 1.0

    # Behavior
    has_abilities: bool = False
    is_boss: bool = False


@dataclass
class WaveConfig:
    """Configuration for a single wave."""

    enemy_count: int = 3
    enemies: List[EnemyProfile] = field(default_factory=list)
    hp_scaling: float = 1.0

    def get_enemies(self) -> List[EnemyProfile]:
        """Get enemies for this wave, applying scaling."""
        if self.enemies:
            return self.enemies

        # Generate default enemies
        return [
            EnemyProfile(hp_scaling=self.hp_scaling) for _ in range(self.enemy_count)
        ]


@dataclass
class SimulationConfig:
    """Master configuration for battle simulation."""

    # Mode
    mode: SimulationMode = SimulationMode.FIVE_WAVE

    # Wave configuration
    waves: List[WaveConfig] = field(default_factory=list)

    # Combat settings
    tick_rate: float = 0.1  # Seconds per simulation tick
    turn_limit: int = 1000  # Max turns per wave
    is_pvp: bool = False

    # Caps (from validated constants)
    crit_max: float = 1.0  # 100% crit cap
    shield_max: float = 0.85  # 85% damage reduction cap
    damage_cap: int = 99999  # Normal attack damage cap
    skill_damage_cap: int = 999999  # Skill damage cap

    # Energy system (Observed in game)
    skill_energy_min: int = 5
    skill_energy_max: int = 18
    skill_energy_damage_mult: int = 10
    # Decoupled skill-cast cadence (seconds). 0 = legacy: a cast can only happen on a
    # unit's attack turn and consumes that turn's auto attack. The real game does NOT
    # couple them (in-game observation 2026-08-25), so 0.5 is the accurate setting.
    #
    # default_factory, not a plain default: a bare `float(os.environ.get(...))`
    # is evaluated when the class is created (import time), so setting
    # MC_SKILL_TICK afterwards did nothing -- including when Scenario replayed a
    # recorded MC_SKILL_TICK, which is the one thing Scenario exists to do.
    skill_tick_rate: float = field(
        default_factory=lambda: float(os.environ.get("MC_SKILL_TICK") or 0.5)
    )
    skill_minus_cost_cd: float = 20.0  # Seconds for cost decay

    # LB exceed (5% per level)
    lb_exceed_rate: float = 0.05

    # Wave recovery
    wave_recover: float = 0.05  # 5% HP recovery

    # Combo bonuses — DISPROVEN (2026-01-16), all zero.
    #
    # These were the `combo_effect_2/3/4/5` constants from constants.json. They
    # exist in game data but the game never retrieves
    # them during combat (0 of 77 constants accessed), no damage function
    # references a combo multiplier, and a controlled in-game observation test had Momotaro deal
    # exactly 871 damage at combo 1, 3 and 5+ with no variation. The "+30%" that
    # was originally attributed to combo turned out to be the full-Divina race
    # bonus. See docs/battle/COMBO.md.
    #
    # BattleConfig (battle.py) was zeroed when that was established; this copy was
    # missed and is the one DamageBenchmark actually passes, so the simulator was
    # applying up to x1.30 to every hit. Measured effect of the stale values on a
    # world-boss team: 73.1M -> 60.9M (+20.1% inflation), and — because it sat
    # right at the boundary — it made 17 of 29 carry skill casts appear to reach
    # the 999,999 cap when in truth none of them do (794k average, matching the
    # community damage calculator's 769k).
    combo_bonus: Dict[int, float] = field(
        default_factory=lambda: {1: 0.0, 2: 0.0, 3: 0.0, 4: 0.0, 5: 0.0}
    )

    # Team settings
    # Orbs the team holds at the opening bell. Measured in play: a world-boss
    # fight starts at 2, and the pool caps at 10. This used to be 10 -- a full
    # pool -- which let a five-card team fire its whole opening rotation in the
    # first tick and then run ~25% above orb income for the next minute. It is
    # carried on every BattleConfig via combat_constants so one harness cannot
    # open richer than another.
    team_skill_points: int = 2
    auto_skill: bool = True  # AUTO mode enabled

    # Tracing
    trace_enabled: bool = False

    @property
    def wave_count(self) -> int:
        return len(self.waves) if self.waves else 5


def combat_constants(sim_cfg: "SimulationConfig") -> dict:
    """The combat constants every `BattleConfig` must carry, in one place.

    Three sites built this block by hand -- `FiveWaveSimulator._create_battle`,
    `build_benchmark_config`, and `evaluate._run_team_battles` -- and they had
    already drifted: the five-wave one omitted `skill_tick_rate`, so it ignored
    `MC_SKILL_TICK` entirely and silently ran the legacy coupled-cast model that
    the env var exists to turn off. It matched only because the field's default
    happens to equal the env default.

    That is the failure this codebase keeps repeating: a harness compared only to
    itself. `apl.inspect` built a bare config with no caps and reported a skill
    setting as +13.9% when it was +16.9%; benchmark and MC once fought different
    fights and landed ~2x apart. Add a combat constant HERE and every fight gets
    it, or nowhere and no fight does.

    `tick_rate` and `turn_limit` are deliberately excluded -- they legitimately
    differ per mode (the benchmark runs unbounded turns and stops on the clock).
    """
    return dict(
        is_pvp=sim_cfg.is_pvp,
        crit_max=sim_cfg.crit_max,
        shield_max=sim_cfg.shield_max,
        damage_cap=sim_cfg.damage_cap,
        skill_damage_cap=sim_cfg.skill_damage_cap,
        skill_energy_min=sim_cfg.skill_energy_min,
        skill_energy_max=sim_cfg.skill_energy_max,
        skill_energy_damage_mult=sim_cfg.skill_energy_damage_mult,
        skill_minus_cost_cd=sim_cfg.skill_minus_cost_cd,
        skill_tick_rate=sim_cfg.skill_tick_rate,
        lb_exceed_rate=sim_cfg.lb_exceed_rate,
        wave_recover=sim_cfg.wave_recover,
        combo_bonus=sim_cfg.combo_bonus,
        starting_skill_points=sim_cfg.team_skill_points,
    )


# =============================================================================
# PRESET CONFIGURATIONS
# =============================================================================


def get_5wave_config() -> SimulationConfig:
    """Get preset configuration for 5-wave conquest simulation."""
    return SimulationConfig(
        mode=SimulationMode.FIVE_WAVE,
        waves=[
            WaveConfig(enemy_count=3, hp_scaling=1.0),  # Wave 1
            WaveConfig(enemy_count=4, hp_scaling=1.2),  # Wave 2
            WaveConfig(enemy_count=4, hp_scaling=1.4),  # Wave 3
            WaveConfig(enemy_count=5, hp_scaling=1.6),  # Wave 4
            WaveConfig(
                enemy_count=1,
                hp_scaling=3.0,
                enemies=[EnemyProfile(hp=30000, is_boss=True)],
            ),  # Boss wave
        ],
        turn_limit=1000,
    )


def get_1wave_config() -> SimulationConfig:
    """Get preset configuration for single-wave burst evaluation."""
    return SimulationConfig(
        mode=SimulationMode.ONE_WAVE,
        waves=[
            WaveConfig(enemy_count=5, hp_scaling=1.0),
        ],
        turn_limit=100,  # Shorter for burst eval
    )


def get_defense_config() -> SimulationConfig:
    """Get preset configuration for defensive evaluation."""
    return SimulationConfig(
        mode=SimulationMode.DEFENSE,
        waves=[
            WaveConfig(
                enemy_count=5,
                hp_scaling=1.0,
                enemies=[
                    EnemyProfile(hp=5000, atk=500),  # High-damage enemies
                    EnemyProfile(hp=5000, atk=500),
                    EnemyProfile(hp=5000, atk=500),
                    EnemyProfile(hp=5000, atk=500),
                    EnemyProfile(hp=5000, atk=500),
                ],
            ),
        ],
        turn_limit=500,
    )


def get_config(mode: str) -> SimulationConfig:
    """
    Get configuration for specified mode.

    Args:
        mode: "5wave", "1wave", or "defense"

    Returns:
        SimulationConfig preset
    """
    configs = {
        "5wave": get_5wave_config,
        "1wave": get_1wave_config,
        "defense": get_defense_config,
    }

    factory = configs.get(mode)
    if factory:
        return factory()

    # Default to 5-wave
    return get_5wave_config()


# =============================================================================
# DEFAULT ENEMY TEMPLATES
# =============================================================================


# Standard mob for testing
DEFAULT_MOB = EnemyProfile(
    hp=10000,
    atk=100,
    speed=1000.0,
    crit=10.0,
)

# Tanky mob
TANKY_MOB = EnemyProfile(
    hp=30000,
    atk=50,
    speed=800.0,
    crit=5.0,
)

# Fast mob
FAST_MOB = EnemyProfile(
    hp=5000,
    atk=150,
    speed=1500.0,
    crit=20.0,
)

# Boss template
BOSS_TEMPLATE = EnemyProfile(
    hp=50000,
    atk=200,
    speed=1200.0,
    crit=15.0,
    is_boss=True,
)


# =============================================================================
# BASELINE TEAM FOR COMPARISON
# =============================================================================


# Default baseline team for defense comparisons
# Card IDs of commonly strong units (can be adjusted)
BASELINE_TEAM_IDS = [1, 15, 733, 450, 210]

# Team settings
DEFAULT_TEAM_LEVEL = 90
DEFAULT_TEAM_LB = 5  # Full limit break
