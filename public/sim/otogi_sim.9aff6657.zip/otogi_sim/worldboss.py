"""World bosses 1-4, straight from game config.

The MC benchmark fights an immortal dummy, which makes survivability
unmeasurable. This module supplies the real thing: HP/defense from ``wbLv``, the
five per-boss skills from ``wbSkill`` (same ``ie``/``ts``/``de`` grammar the card
skills use), the two cast timelines, and the fight's state machine.

Everything here is pure data plus one pure state function -- no engine imports --
so the rotation and the state machine can be tested without building a Battle.
The engine side lives in ``Battle._boss_phase``.

Boss behaviour (state transitions, rotation wrap, the damage check) is
documented under ``docs/`` -- see the World Boss timing and skills notes.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Dict, List, Optional, Tuple

from .data_loader import GameDataLoader, SkillData, get_loader

# Names are not in config -- they come from the drama/NPC ids and are hardcoded
# in otogidb/src/lib/worldBossParser.ts. Mirror that map so the sim and the site
# agree. (docs/data/WORLD_BOSS_SKILLS.md says "Kanoe" for boss 4; the site says
# "Kanoto" and is what users actually see.)
BOSS_NAMES = {1: "Kinoe", 2: "Hinoto", 3: "Mizunoe", 4: "Kanoto"}

# The boss has no ATK column anywhere in config -- not in wbLv, not in monster,
# not in npc. Every point of its damage comes from a scheduled cast's own `ie`
# value, so the default is no auto-attack at all.
#
# The bench dummy's ATK 3500 is NOT a survival-calibrated number: it was only
# ever measured against immortal players. Handing it to the boss makes every
# team wipe inside 45s of a 300s fight (measured: 42.1s), which is the mode's
# own failure sanity-check.
#
# CONFIRMED by live observation 2026-09-09 (244s against boss 2/4 at lv16-30):
# the boss never swings a normal attack -- it deals damage only through its
# scheduled casts, and its attack timer never advances. --boss-auto-atk is for
# what-if runs only. See the World Boss timing notes under docs/.
DEFAULT_BOSS_AUTO_ATK = 0
DEFAULT_BOSS_SPEED = 1300


class BossState(IntEnum):
    """The five states the boss moves through during a 5-minute fight."""

    NORMAL = 1
    CRAZY_PREPARE = 2
    CRAZYING = 3
    CRAZY = 4
    KILL_ALL = 5


@dataclass(frozen=True)
class BossTiming:
    """The wb_* constants that drive the state machine. Seconds, except damage."""

    kill_skill_start: float = 265.2  # wb_kill_skill_start (4.42 minutes)
    kill_countdown: float = 10.0  # wb_kill_countdown
    kill_skill_time: float = 4.0  # wb_kill_skill_time
    kill_interrupt: float = 60000.0  # wb_kill_interrupt, in damage
    # wb_kill_skill_atk. Inferred from data: a PERCENT added to the boss's own
    # damage modifier the instant it enrages, and never removed. Both enrage
    # branches (the `ks` loop and the kill-all failure branch) apply it.
    #
    # This is the ONLY source of damage growth on bosses 2 and 4, whose fifth
    # skill is a self-cleanse rather than the self-buff bosses 1 and 3 carry
    # (`ATK<30.00%,0.99%,15>` and `ATK<70.00%,0.99%,8>`). Without it their damage
    # is identical at t=0 and t=350 and enrage changes only cast frequency.
    #
    # Not yet measured in play. The value sits on a knife edge, which is itself
    # corroborating -- on the reference team against boss 2 Lv30, 300 seeds:
    # +0% kills nobody (0/300), +50% kills 27/300, +100% wipes every seed.
    kill_skill_atk: float = 50.0

    @classmethod
    def from_constants(cls, constants: Dict[str, str]) -> "BossTiming":
        def num(name: str, default: float) -> float:
            try:
                return float(constants[name])
            except (KeyError, TypeError, ValueError):
                return default

        return cls(
            kill_skill_start=num("wb_kill_skill_start", 4.42) * 60.0,
            kill_countdown=num("wb_kill_countdown", 10.0),
            kill_skill_time=num("wb_kill_skill_time", 4.0),
            kill_interrupt=num("wb_kill_interrupt", 60000.0),
            kill_skill_atk=num("wb_kill_skill_atk", 50.0),
        )


@dataclass(frozen=True)
class BossSpec:
    """One world boss at one level: what it is and what it does."""

    boss_id: int
    level: int
    name: str
    hp: int
    defense: float
    skills: Dict[int, SkillData]
    s_rotation: Tuple[Tuple[float, int], ...]
    ks_rotation: Tuple[Tuple[float, int], ...]
    # Skills whose `ie` is ERASE_DEBUFF: bosses 2 and 4 cleanse themselves
    # instead of self-buffing. Not expressible as a stat modifier, so the engine
    # special-cases these ids.
    cleanse_skills: frozenset[int] = frozenset()
    timing: BossTiming = field(default_factory=BossTiming)
    auto_atk: int = DEFAULT_BOSS_AUTO_ATK
    speed: int = DEFAULT_BOSS_SPEED

    def rotation(self, state: "BossState") -> Tuple[Tuple[float, int], ...]:
        """`ks` once enraged, `s` before that."""
        if state in (BossState.CRAZY, BossState.KILL_ALL):
            return self.ks_rotation
        return self.s_rotation

    def key(self) -> tuple:
        """Identity for a Scenario key. Level pins hp/defense/rotations."""
        return (self.boss_id, self.level, self.auto_atk, self.speed)


def parse_rotation(spec: str) -> Tuple[Tuple[float, int], ...]:
    """``"5,1;10,2"`` -> ``((5.0, 1), (10.0, 2))``, sorted by time."""
    out: List[Tuple[float, int]] = []
    for part in (spec or "").split(";"):
        part = part.strip()
        if not part:
            continue
        t, _, sid = part.partition(",")
        out.append((float(t), int(sid)))
    return tuple(sorted(out))


def ie_damage(ie: str) -> Tuple[int, int]:
    """``"ATK<6000,0>"`` -> ``(6000, 0)``. A non-damage `ie` gives ``(0, 0)``.

    VALIDATED 2026-09-09 by paired live measurements: boss skill damage lands on
    the `ie` value exactly -- ATK<1000> hit for 1000, ATK<6000> for 6000, with no
    card-skill-style slv1 correction (cards are ie 1300 vs slv1 1550, ~1.19x;
    wbSkill is not). Do not "scale here" -- it is already right.
    See the World Boss timing notes under docs/.
    """
    if not ie or ie == "none":
        return (0, 0)
    m = re.match(r"ATK<(-?[\d.]+),(-?[\d.]+)>\s*$", ie.strip())
    if not m:  # a percentage is a self-buff, not damage
        return (0, 0)
    return (int(float(m.group(1))), int(float(m.group(2))))


def parse_target_spec(ts: str) -> Tuple[int, Optional[List[int]]]:
    """``ts`` -> ``(target_count, prof_priority_order)``.

    ``count<N>`` and ``range_front<N.N>`` both give the count (front-N is the
    first N slots). ``prof<a,b,c>`` on a boss skill is a *priority order*, not
    the membership filter the card-side ``_apply_target_filter`` treats it as --
    boss rows list all three roles, so filtering on it is a no-op and would
    silently discard the targeting the skill actually describes.
    """
    count = 1
    m = re.search(r"count<(\d+)>", ts)
    if m:
        count = int(m.group(1))
    else:
        m = re.search(r"range_front<([\d.]+)>", ts)
        if m:
            count = int(float(m.group(1)))
    prof = re.search(r"prof<([\d,]+)>", ts)
    order = [int(x) for x in prof.group(1).split(",")] if prof else None
    return count, order


def load_boss(
    boss_id: int,
    level: int = 30,
    auto_atk: Optional[int] = None,
    loader: Optional[GameDataLoader] = None,
) -> BossSpec:
    """Build a BossSpec from output/data/wbLv.json + wbSkill.json."""
    loader = loader or get_loader()
    row = loader.get_wb_level(boss_id, level)
    if row is None:
        raise ValueError(f"no wbLv row for boss {boss_id} level {level}")

    skills: Dict[int, SkillData] = {}
    cleanse: List[int] = []
    for skill_id, raw in loader.get_wb_skills(boss_id).items():
        sd = loader.skill_from_raw(skill_id, raw)
        sd.slv1, sd.slvup = ie_damage(raw.get("ie", "none"))
        sd.target_count, _ = parse_target_spec(raw.get("ts", ""))
        skills[skill_id] = sd
        if str(raw.get("ie", "")).startswith("ERASE_DEBUFF"):
            cleanse.append(skill_id)

    return BossSpec(
        boss_id=boss_id,
        level=level,
        name=BOSS_NAMES.get(boss_id, f"Boss {boss_id}"),
        hp=int(row["hp"]),
        defense=float(row["defense"]),
        skills=skills,
        s_rotation=parse_rotation(row.get("s", "")),
        ks_rotation=parse_rotation(row.get("ks", "")),
        cleanse_skills=frozenset(cleanse),
        timing=BossTiming.from_constants(loader._constants),
        auto_atk=DEFAULT_BOSS_AUTO_ATK if auto_atk is None else auto_atk,
    )


def next_boss_state(
    state: BossState,
    t_state: float,
    t_total: float,
    damage_since_prepare: float,
    timing: BossTiming,
) -> BossState:
    """The fight's state machine. Returns the state for this instant.

    The whole mechanic is one damage check. The boss telegraphs
    (CRAZY_PREPARE, 10s), goes down (CRAZYING, 4s -- it casts nothing, which is
    a free damage window), and then either enrages onto a looping `ks` rotation
    because the team cleared ``wb_kill_interrupt`` damage during the
    prepare+crazying window, or wipes the team with KILL_ALL because it did not.

    CRAZY is terminal in practice: it loops `ks` until the battle timer ends.
    KILL_ALL is the failure branch, NOT a timeout out of CRAZY, and there is no
    path back to NORMAL.
    """
    if state == BossState.NORMAL:
        if t_total >= timing.kill_skill_start:
            return BossState.CRAZY_PREPARE
    elif state == BossState.CRAZY_PREPARE:
        if t_state >= timing.kill_countdown:
            return BossState.CRAZYING
    elif state == BossState.CRAZYING:
        if t_state >= timing.kill_skill_time:
            if damage_since_prepare >= timing.kill_interrupt:
                return BossState.CRAZY
            return BossState.KILL_ALL
    return state
