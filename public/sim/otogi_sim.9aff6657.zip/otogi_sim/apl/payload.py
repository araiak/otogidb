"""Shared accessor for what a cast actually *does* — magnitude, duration, targets.

The nominal duration of a cast ("if I cast now, how long does the effect last") was not
exposed anywhere in the simulator. It exists only inside raw effect strings shaped
``TYPE<base,scale,dur>`` and was re-parsed by four private regexes that had drifted:

    apl/window_value.py   _SKILL_EFF_RE / _skill_effect_mults
    apl/planner.py        _EFF_RE
    apl/scheduler.py      _buffer_signature, _ramp_profile
    battle.py             _apply_skill_effects   <- the one that actually applies them

This module is the single source of truth, and it deliberately mirrors
``battle._apply_skill_effects`` (battle.py:1330-1395): same regex, same ``%``-suffix
rule, same ``mod_map``. If the two ever disagree, a planner would optimise a payload the
battle does not deliver, so keep them in lockstep.

Duration semantics follow the battle exactly:
  * an explicit third field  -> that many seconds
  * absent on a stat effect  -> PERMANENT (battle._track_buff skips duration <= 0),
                                reported here as ``math.inf``, NOT 8
  * absent on a CC/DoT       -> 10s for POISON/BURN, else 3s

That permanent case is why this returns ``inf`` rather than 0: a planner asking "how
much *new* coverage does this cast buy" must not treat a permanent stack as expired.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Any, List, Optional

from ..lifecycle import EFFECT_TO_MODIFIER as _MOD_MAP, ModifierType

# Same pattern as battle._apply_skill_effects. The '%' groups matter: values without a
# percent suffix are raw game units on a x100 scale.
_PARAM_RE = re.compile(r"(\w+)<(-?[\d.]+)(%?),(-?[\d.]+)(%?),?(\d+)?>")
_SIMPLE_RE = re.compile(r"^([A-Z_]+)$")

# Mirrors battle._apply_skill_effects mod_map.

_CC_TYPES = {"STUN", "FROZEN", "SLEEP", "NUMB", "STONE", "POISON", "BURN"}


@dataclass(frozen=True)
class Effect:
    """One resolved effect of a cast."""

    raw_type: str  # "SHIELD", "ATK", "STUN", ...
    mod_type: Optional[ModifierType]  # None for CC/DoT
    magnitude: float  # signed, in percent-points (e.g. -49.48)
    duration: float  # seconds; math.inf == permanent
    on_enemy: bool  # True if applied to the target, False if to allies
    target_count: int

    @property
    def is_permanent(self) -> bool:
        return self.duration == math.inf

    @property
    def is_cc(self) -> bool:
        return self.mod_type is None


def _parse(effect_str: str, level: int, on_enemy: bool, target_count: int):
    """Parse one raw effect string exactly as battle._apply_skill_effects would."""
    s = (effect_str or "").strip()
    if not s:
        return None

    m = _PARAM_RE.match(s)
    if m:
        raw = m.group(1).upper()
        base = float(m.group(2))
        has_pct = bool(m.group(3))
        scale = float(m.group(4))
        has_dur = bool(m.group(6))
        # No explicit duration on a stat effect means permanent: battle._track_buff
        # returns early for duration <= 0, so nothing ever removes it.
        duration = float(m.group(6)) if has_dur else math.inf
        # DEFENSE is flat damage points, not a percentage -- see battle._apply_skill_effect.
        if not has_pct and raw not in ("DEF", "DEFENSE"):
            base /= 100.0
            scale /= 100.0
        return Effect(
            raw_type=raw,
            mod_type=_MOD_MAP.get(raw),
            magnitude=base + scale * (level - 1),
            duration=duration,
            on_enemy=on_enemy,
            target_count=target_count,
        )

    sm = _SIMPLE_RE.match(s.upper())
    if sm and sm.group(1) in _CC_TYPES:
        raw = sm.group(1)
        return Effect(
            raw_type=raw,
            mod_type=None,
            magnitude=0.0,
            duration=10.0 if raw in ("POISON", "BURN") else 3.0,
            on_enemy=on_enemy,
            target_count=target_count,
        )
    return None


def skill_payload(unit: Any, level: Optional[int] = None) -> List[Effect]:
    """Every timed effect a cast by ``unit`` would apply, right now.

    Folds the skill's own de/ie effect strings together with the unit's on-skill
    (``attack_skill``) abilities, which ride along on every cast and are invisible to
    anything that only reads ``skill.buff_effects``.
    """
    skill = getattr(unit, "skill", None)
    if skill is None:
        return []

    if level is None:
        model = getattr(unit, "model", None)
        level = int(getattr(model, "effective_level", 1) or 1) if model else 1

    count = int(getattr(skill, "target_count", 1) or 1)
    out: List[Effect] = []

    # Recipient rule mirrors battle._apply_skill_effects (battle.py:1238-1277).
    # NB `debuff_effects` is the raw `de` (delay-effect) list -- it holds buffs as well
    # as debuffs. Side is decided by is_buff_skill, NOT by which list the string is in:
    #   de: buff skill -> allies (target_count);  damage skill -> the damage target
    #   ie: buff skill -> allies (target_count);  damage skill -> the caster
    is_buff = bool(getattr(skill, "is_buff_skill", False))
    for s in getattr(skill, "debuff_effects", None) or []:
        e = _parse(s, level, on_enemy=not is_buff, target_count=count)
        if e:
            out.append(e)
    for s in getattr(skill, "buff_effects", None) or []:
        # In the `ie` position a value with no % suffix is the skill's DAMAGE payload
        # (e.g. Kashinkoji "ATK<300,7>"), not a buff. data_loader already filters these
        # (data_loader.py:264), but do not depend on that -- parsing one would invent a
        # permanent +3% damage buff out of a damage number.
        if "%" not in s:
            continue
        e = _parse(s, level, on_enemy=False, target_count=1 if not is_buff else count)
        if e:
            out.append(e)

    # On-skill abilities fire with the cast (e.g. Nimbus's permanent crit-damage stack).
    for ab in getattr(unit, "abilities", None) or []:
        trig = getattr(ab, "trigger", None)
        if getattr(trig, "value", trig) != "attack_skill":
            continue
        for ae in getattr(ab, "effects", None) or []:
            name = getattr(getattr(ae, "effect_type", None), "name", None)
            if not name:
                continue
            dur = float(getattr(ae, "duration", 0) or 0)
            out.append(
                Effect(
                    raw_type=name,
                    mod_type=_MOD_MAP.get(name),
                    # AbilityEffect values are already percent-points.
                    magnitude=getattr(ae, "value", 0.0)
                    + getattr(ae, "scale", 0.0) * (level - 1),
                    # abilities.py only registers expiry when duration > 0.
                    duration=dur if dur > 0 else math.inf,
                    on_enemy=False,
                    target_count=count,
                )
            )
    return out


def amp_effects(unit: Any, level: Optional[int] = None) -> List[Effect]:
    """Just the effects that multiply damage — what uptime planning cares about."""
    return [
        e
        for e in skill_payload(unit, level)
        if e.mod_type
        in (
            ModifierType.DAMAGE,
            ModifierType.SHIELD,
            ModifierType.DEFENSE,
            ModifierType.SKILL_DMG,
            ModifierType.NORMAL_DMG,
            ModifierType.CRIT,
            ModifierType.CRIT_DMG,
        )
    ]
