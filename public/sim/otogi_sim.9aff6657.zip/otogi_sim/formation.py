"""
Battlefield formation: which slot each card stands in, and who the enemy can reach.

The engine's default enemy targeting is a pure ROLE priority (melee > healer >
assist > ranged), which lets every enemy on the field walk past the frontline and
converge on a backline healer. That wipes teams the real game does not wipe.

The real layout is two columns of three, enemies to the right:

        5   3
        4   1      <- enemies
        6   2

So slots 1, 2, 3 are the FRONT column and 4, 5, 6 the BACK column. An auto-attack
takes a front-column target while one is alive and only reaches the back column
once the front is gone. A skill with its own `ts` targeting still overrides this --
formation governs autos, not scripted targeting.

Slot filling (from play observation):

- melee fills        1, (3), 2, 5, 6   -- slot 3 only when the team has 3+ melees
- ranged/healer fills 1,  2,  4, 5, 6
- cards are placed in team order, melee first (melee wins a contested slot)
- the friend/helper unit lands in 2 (melee) or 6 (ranged/healer)

Irrelevant to world boss and the benchmark dummy -- one enemy, one column -- which
is why this is opt-in via `BattleConfig.use_formation` and off by default: turning
it on globally would move every tier list and the golden corpus.
"""

from typing import List, Optional, Sequence

from .constants import ROLE_MELEE as TYPE_MELEE

FRONT_SLOTS = (1, 2, 3)
BACK_SLOTS = (4, 5, 6)

_MELEE_FILL = (1, 3, 2, 5, 6)
_OTHER_FILL = (1, 2, 4, 5, 6)

_HELPER_MELEE_SLOT = 2
_HELPER_OTHER_SLOT = 6

# A melee card only takes the third front slot on a melee-heavy team.
_SLOT3_MELEE_THRESHOLD = 3


def assign_positions(
    unit_types: Sequence[int], helper_index: Optional[int] = None
) -> List[int]:
    """Map each active card to its formation slot (1-6), in the order given.

    Args:
        unit_types: each card's `type` (1 melee, 2 ranged, 3 healer, 4 assist)
        helper_index: index of the borrowed friend unit, if the team has one

    Returns:
        One slot number per input card. 0 means the card did not fit on the field.
    """
    positions = [0] * len(unit_types)
    taken: set = set()

    melee_count = sum(1 for t in unit_types if t == TYPE_MELEE)
    allow_slot3 = melee_count >= _SLOT3_MELEE_THRESHOLD

    def fill_order(unit_type: int) -> Sequence[int]:
        if unit_type != TYPE_MELEE:
            return _OTHER_FILL
        return _MELEE_FILL if allow_slot3 else tuple(s for s in _MELEE_FILL if s != 3)

    def place(index: int) -> None:
        for slot in fill_order(unit_types[index]):
            if slot not in taken:
                taken.add(slot)
                positions[index] = slot
                return

    # The friend goes first: its slot is fixed, so reserving it up front is what
    # pushes a third melee out to the back column rather than into slot 2.
    if helper_index is not None and 0 <= helper_index < len(unit_types):
        slot = (
            _HELPER_MELEE_SLOT
            if unit_types[helper_index] == TYPE_MELEE
            else _HELPER_OTHER_SLOT
        )
        taken.add(slot)
        positions[helper_index] = slot

    # Melee take priority for contested slots, then everyone else, both in team order.
    for melee_pass in (True, False):
        for i, unit_type in enumerate(unit_types):
            if positions[i] or (unit_type == TYPE_MELEE) != melee_pass:
                continue
            place(i)

    return positions


def reachable(targets: Sequence) -> List:
    """The front column while any of it lives, else whatever is left.

    Units with no position assigned (position 0) count as front, so a caller that
    forgot to assign positions degrades to "everyone is reachable" rather than to
    "nobody is".
    """
    front = [t for t in targets if getattr(t, "position", 0) not in BACK_SLOTS]
    return front or list(targets)


def demo() -> None:
    """Self-check: the fill orders in the module docstring, exactly."""
    melee, ranged, healer = TYPE_MELEE, 2, 3

    # One melee + backline: melee takes 1, the rest fill 2, 4, 5.
    assert assign_positions([melee, ranged, healer, ranged]) == [1, 2, 4, 5]

    # Three melees unlocks slot 3, so the front column is all melee.
    assert assign_positions([melee, melee, melee, ranged]) == [1, 3, 2, 4]

    # Two melees do NOT unlock slot 3; the second melee takes 2 instead.
    assert assign_positions([melee, melee, ranged, healer]) == [1, 2, 4, 5]

    # Melee wins a contested slot even when a ranged card is earlier in team order.
    assert assign_positions([ranged, melee]) == [2, 1]

    # A melee helper takes slot 2, pushing the team's second melee to the back.
    assert assign_positions([melee, melee, ranged, healer, melee], helper_index=4) == [
        1,
        3,
        4,
        5,
        2,
    ]

    # A ranged helper takes slot 6.
    assert assign_positions([melee, ranged, healer, ranged], helper_index=3) == [
        1,
        2,
        4,
        6,
    ]

    class Unit:
        def __init__(self, position):
            self.position = position

    front, back, unplaced = Unit(1), Unit(5), Unit(0)
    assert reachable([front, back]) == [front]
    assert reachable([back]) == [back]  # back column once the front is gone
    assert reachable([unplaced, back]) == [unplaced]  # position 0 counts as front
    print("formation demo ok")


if __name__ == "__main__":
    demo()
