"""Which skills belong in the cast group.

The group SIZE is arithmetic, not a search. A skill's orb cost decays back to 1
every ``skill_minus_cost_cd`` (20s) and the team earns one orb every
``skill_points_regen_cd`` (5s), so a group of N members costs N orbs per 20s
against an income of 4. Measured on the three verified teams: at N=4 the income
is exactly spent (0.96 orbs per 5s against an income of 1.00) and every member
still casts on its 20s floor; at N=5 the total cast count does not move -- orbs
are still the ceiling -- but the beat stretches to ~26s, so the fifth member's
casts come straight out of the carries'. On `mira_1631_1720_1721_hinoto` that is
35 carry casts becoming 28, and 71.4M becoming 67.6M.

So above the budget a member is pure redistribution from the best cards to the
worst, and the cap is `skill_minus_cost_cd / skill_points_regen_cd`.

Only the RANKING needs the simulator, because a skill's worth depends on the
group it joins rather than on the skill: on `mira_nimbus_ohina_odairi` a buffer
worth +1.2M beside the bare carry is -2.1M once the real group is there, having
eaten the orb a stronger buffer would have spent. So each candidate is measured
at the margin, against the group chosen so far.

ponytail: greedy, not exhaustive. Greedy matched brute force to within 0.16% on
all three verified teams (inside the ~1% seed noise) for 7 scored groups instead
of 31. Enumerate if a team ever shows a real gap.
"""

from __future__ import annotations

import json
from typing import Any, Callable, Optional, Sequence

from .apl.scheduler import _ramp_profile, skill_flags
from .apl.window_value import _DMG_MULT_WEIGHT
from .spec import Scenario, TeamSpec, score, simulate

SLOTS = ("P1", "P2", "P3", "P4", "P5")

# Stats a buff has to move to be worth an orb in a damage race, and what each is
# worth. Shared with the cadence trim rather than kept as a second opinion: SPD used
# to be absent here (scored 0) and present in this file at an implicit 1.0, i.e. the
# same as ATK -- two incompatible prices for one stat, in code that ranks the same
# buffers. A skill that only heals or shields still scores 0 and sorts to the back.
_OFFENSIVE = dict(_DMG_MULT_WEIGHT)
_OFFENSIVE.setdefault("DAMAGE", 1.0)
_EFFECT = __import__("re").compile(r"([A-Z_]+)<\s*(-?[\d.]+)")


def prior(
    info: dict[str, dict],
    skills: dict[str, Any],
    recipients: dict[str, list[str]] | None = None,
) -> list[str]:
    """Cheap ranking of the non-carry slots, best first. No battles.

    Magnitude times the number of CARRIES the buff reaches -- not times its target
    count. Measured on `mira_1631_1720_1721_hinoto`, raw target count inverts the
    answer: Mira buffs +20% ATK to all five allies and scores worst of the three
    (100 by target count, last by measurement) because three of those five deal no
    damage, while Orihime's +35% to the top two by ATK lands entirely on the carries.

    A duplicate of a card already counted scores 0: a second copy of the same buff
    refreshes it rather than stacking, which is the engine's own `_dominated_buffers`
    rule arrived at from the other side.
    """
    carries = [s for s in info if info[s]["damage"]]
    seen: set[Any] = set()
    ranked = []
    for slot, i in info.items():
        if i["damage"]:
            continue
        sk = skills.get(slot)
        cid = i.get("card_id")
        if sk is None or (cid is not None and cid in seen):
            ranked.append((0.0, slot))
            continue
        seen.add(cid)
        n = int(getattr(sk, "target_count", 1) or 1)
        rec = (recipients or {}).get(slot)
        if rec is not None:
            # Who the buff REALLY lands on, resolved through the engine's own
            # `_apply_target_filter`. The count that matters is how many CARRIES are
            # among them -- a five-target buff that reaches one carry is worth less
            # than a two-target one that reaches both.
            hits = len([r for r in rec if r in carries]) if rec else len(carries)
        else:
            # Fallback when no battle was available to resolve against. Assumes a
            # ranked buff finds the carries, which is exactly the assumption that
            # breaks when a support out-ATKs them -- so it is a last resort.
            sel = str(getattr(sk, "target_selector", "") or "")
            hits = min(len(carries), n) if "max_atk" in sel else len(carries) * n / 5.0
        mag = 0.0
        for text in getattr(sk, "effects", None) or []:
            for name, val in _EFFECT.findall(str(text)):
                w = _OFFENSIVE.get(name)
                if w is not None:
                    mag += w * abs(float(val))
        # The durationless-stack bug compounds all fight instead of lapsing after 8s,
        # so a ramp buffer is worth far more than its printed magnitude. Ranked top
        # outright rather than with a fudge factor -- it is a different kind of card.
        ranked.append((float("inf") if i["ramp"] else mag * hits, slot))
    ranked.sort(reverse=True)
    return [s for _v, s in ranked]


def budget(scenario: Scenario, loader: Any = None) -> int:
    """How many members a group can fund per cost-decay window."""
    from .battle import BattleConfig

    defaults = BattleConfig()
    decay = float(defaults.skill_minus_cost_cd)
    regen = float(scenario.regen_cd or defaults.skill_points_regen_cd)
    return max(1, int(decay // regen))


def classify(team: TeamSpec, scenario: Scenario, loader: Any = None) -> dict[str, dict]:
    """Per-slot skill shape, read off a real opening battle state.

    One battle, not a data-file lookup: whether a slot can cast at all depends on
    assists, bonds and passives that only exist once the team is built.
    """
    battle = simulate(team, scenario, 0, record_casts=True, loader=loader).battle
    out: dict[str, dict] = {}
    for p in battle.players:
        if getattr(p, "skill", None) is None:
            continue
        is_ramp, _window = _ramp_profile(p)
        out[p.slot] = {
            "name": getattr(getattr(p, "model", None), "name", p.slot),
            "card_id": getattr(getattr(p, "model", None), "card_id", None),
            "damage": bool(skill_flags(p.skill, p)["damage"]),
            "ramp": bool(is_ramp),
        }
    return out


def classify_with_skills(
    team: TeamSpec, scenario: Scenario, loader: Any = None
) -> tuple[dict[str, dict], dict[str, Any], dict[str, list[str]]]:
    """`classify`, the raw skill per slot, and who each skill really targets."""
    battle = simulate(team, scenario, 0, record_casts=True, loader=loader).battle
    info, skills = {}, {}
    for p in battle.players:
        if getattr(p, "skill", None) is None:
            continue
        is_ramp, _w = _ramp_profile(p)
        info[p.slot] = {
            "name": getattr(getattr(p, "model", None), "name", p.slot),
            "card_id": getattr(getattr(p, "model", None), "card_id", None),
            "damage": bool(skill_flags(p.skill, p)["damage"]),
            "ramp": bool(is_ramp),
        }
        skills[p.slot] = p.skill
    return info, skills, resolve_recipients(battle)


def resolve_recipients(battle: Any) -> dict[str, list[str]]:
    """Who each buff skill ACTUALLY lands on, per slot.

    `prior` and the cadence trim used to string-match `"max_atk" in selector` and
    assume the recipients were the carries. That is the assumption this whole file
    exists to stop making: a ranked buff follows the ATK leader, and when a support
    out-ATKs the carry -- a 2.2% margin on the 2026-09 boss-2 roster -- the buff goes
    to a card that cannot convert it while the heuristic still credits the carry.

    Uses `AbilityManager._apply_target_filter`, the one real implementation, exactly
    as `Battle._apply_skill_effects` does: filter the living allies, then take
    `target_count` off the front.
    """
    mgr = getattr(battle, "ability_manager", None)
    alive = [p for p in getattr(battle, "players", []) if getattr(p, "is_alive", True)]
    out: dict[str, list[str]] = {}
    for p in battle.players:
        sk = getattr(p, "skill", None)
        if sk is None:
            continue
        if str(getattr(sk, "target_type", "")) == "enemy":
            out[p.slot] = []  # lands on the boss; the caller treats it as team-wide
            continue
        cand = list(alive)
        filt = getattr(sk, "target_filter", None)
        if filt and cand and mgr is not None:
            cand = mgr._apply_target_filter(cand, filt, p) or cand
        n = int(getattr(sk, "target_count", 1) or 1)
        out[p.slot] = [t.slot for t in cand[:n]]
    return out


def atk_ranking(team: TeamSpec, scenario: Scenario, loader: Any = None) -> list[dict]:
    """Slots ordered exactly as a ranked (`max_atk`) buff will target them.

    The key is `base_atk * normal_dmg_modifier`, which is literally the expression
    `abilities._apply_target_filter` sorts on. Both inputs are fixed before the first
    action and never change in combat, so this ordering holds for the whole wave --
    which is why the margin below needs no simulation to interpret.

    `normal_dmg_modifier` is where a NORMAL stat bond lands, so bonds are the lever
    that decides who receives a ranked buff.
    """
    battle = simulate(team, scenario, 0, record_casts=True, loader=loader).battle
    rows = []
    for p in battle.players:
        st = getattr(p, "stat", None)
        if st is None:
            continue
        atk = float(st.base_atk) * float(st.normal_dmg_modifier.get_modifier_total())
        sk = getattr(p, "skill", None)
        rows.append(
            {
                "slot": p.slot,
                "name": getattr(getattr(p, "model", None), "name", p.slot),
                "atk": atk,
                "damage": bool(sk is not None and skill_flags(sk, p)["damage"]),
                "ranked_buff": bool(
                    sk is not None
                    and "max_atk" in str(getattr(sk, "target_selector", "") or "")
                ),
            }
        )
    rows.sort(key=lambda r: -r["atk"])
    return rows


def atk_margin(rows: list[dict]) -> dict:
    """How safely the carry owns the top of the ATK table.

    A ranked buff follows the ATK leader. If the intended carry leads by a hair, the
    next base-stat increase -- or one ATK bond on the wrong card -- hands every ranked
    buff to a support, and the team's score collapses for a reason that is an artifact
    rather than card weakness. Measured on the 2026-09 boss-2 roster: the carry led by
    2.2% and a +15% bump on any support cost ~11%.

    Returns margin = (carry_atk - best_other_atk) / carry_atk, NEGATIVE when the carry
    does not lead at all. `relevant` is False when no one on the team casts a ranked
    buff, in which case the ordering buys nothing and the margin is noise.
    """
    carry = next((r for r in rows if r["damage"]), None)
    if carry is None:
        return {"relevant": False, "margin": None, "carry": None, "rival": None}
    rival = next((r for r in rows if r["slot"] != carry["slot"]), None)
    margin = (
        (carry["atk"] - rival["atk"]) / carry["atk"]
        if rival and carry["atk"] > 0
        else None
    )
    return {
        "relevant": any(r["ranked_buff"] for r in rows),
        "margin": margin,
        "carry": carry["slot"],
        "carry_name": carry["name"],
        "rival": rival["slot"] if rival else None,
        "rival_name": rival["name"] if rival else None,
        "leads": bool(rival is None or carry["atk"] >= rival["atk"]),
    }


def carry_and_thief(team: TeamSpec, scenario: Scenario, loader: Any = None) -> dict:
    """Which slot should hold the normal bonds, and which one steals them if it does.

    Carry = the highest-ATK slot that actually carries a damage skill. Thief = the
    highest-ATK slot that is not the carry. Both read the `max_atk` sort key, so this
    costs one battle rather than the N of a marginal-ATK probe -- and the probe would
    answer a different question anyway, since what routes a ranked buff is the sort
    key itself.

    `base_atk` alone is not enough: in the failure case the ATK leader IS the thief,
    so both arms would bond the same card and the sweep would fall silent on exactly
    the teams it exists to expose. The damage flag separates "biggest number" from
    "where the team's damage comes from".

    `flip` answers the question the band is actually for: does moving the bonds change
    who the ranked buffs land on? If not, the spread is just bond worth on a different
    card and must NOT be read as fragility.
    """
    rows = atk_ranking(team, scenario, loader)
    carry = next((r for r in rows if r["damage"]), None)
    if carry is None:
        return {"carry": None, "thief": None, "flip": False, "rows": rows}
    thief = next((r for r in rows if r["slot"] != carry["slot"]), None)
    if thief is None:
        return {"carry": carry["slot"], "thief": None, "flip": False, "rows": rows}
    # Would the bonds actually move the top of the table? Arithmetic, no battle: the
    # profile multiplies normal_dmg_modifier, and both arms apply the same mass.
    bump = 1.0 + sum(pct for _k, pct in _PROFILE_FOR_FLIP) / 100.0
    top_best = max(rows, key=lambda r: r["atk"] * (bump if r is carry else 1.0))
    top_worst = max(rows, key=lambda r: r["atk"] * (bump if r is thief else 1.0))
    return {
        "carry": carry["slot"],
        "carry_name": carry["name"],
        "thief": thief["slot"],
        "thief_name": thief["name"],
        "flip": top_best["slot"] != top_worst["slot"],
        "ranked": any(r["ranked_buff"] for r in rows),
        "rows": rows,
    }


# The mass one arm applies, used only for the arithmetic flip check above.
_PROFILE_FOR_FLIP = (("normal", 7.5), ("normal", 7.5))


def _score(
    team: TeamSpec,
    scenario: Scenario,
    group: Sequence[str],
    seeds: Sequence[int],
    loader: Any,
    swap: Optional[dict[str, str]] = None,
) -> float:
    params: list[tuple[str, Any]] = [("MC_GROUPS", json.dumps([list(group)]))]
    if swap:
        params.append(("MC_GROUP_SWAP", json.dumps(swap)))
    sc = Scenario(
        **{
            k: v
            for k, v in vars(scenario).items()
            if k not in ("scheduler", "scheduler_params")
        },
        scheduler="group",
        scheduler_params=tuple(params),
    )
    return score(team, sc, seeds=seeds, loader=loader).mean


def margin_note(m: dict) -> list[str]:
    """Warn when the carry has already lost its grip on the ranked buffs.

    A `max_atk` buff follows the ATK leader, and that order is fixed before the fight
    starts. If a support outranks the carry, every ranked buff on the team lands on a
    card that does not convert it -- and the team scores low for a reason that is a
    targeting artifact, not card weakness. Base stats inflate patch over patch, so a
    thin lead today is a broken team after the next release.

    ponytail: only the already-lost case warns. A thin-but-leading margin was noise
    on every real team -- add the threshold back if a patch actually flips one.
    """
    if not m.get("relevant") or m.get("margin") is None:
        return []
    pct = m["margin"] * 100.0
    if not m.get("leads"):
        return [
            f"{m['rival_name']} ({m['rival']}) out-ATKs your carry "
            f"{m['carry_name']} ({m['carry']}) by {-pct:.1f}%, so every ranked "
            "(max_atk) buff on this team is landing on the wrong card. Move normal "
            "bonds onto the carry, or this score is measuring the wrong rotation."
        ]
    return []


def notes_for(info: dict[str, dict], swap: dict[str, str]) -> list[str]:
    """Caveats the suggested groups cannot express, so the number is read honestly.

    A ramp buffer (Nimbus [Awakened] 514, the one card whose on-cast crit-damage
    stack has no duration and so compounds all fight) saturates PART WAY: once the
    carry's autos hit the damage cap the stack is worth nothing more, but the same
    cast also carries SPD +26% and a ~4s crit-rate window, and neither of those
    saturates. So the play is a priority shift, not a retirement.

    Measured on the player's single-Odairi team, where Odairi is capped on 231 of
    254 autos and the four supports still deal 29.4% of total damage uncapped:
    retiring Nimbus at cap scores -1.8%, and demoting it to its own bucket -0.4%,
    against simply leaving it in the burst. What a flat group CANNOT express is the
    thing worth expressing -- that post-saturation an all-team speed buff (Ohina,
    20% to 5) overtakes Nimbus's single-target 26%, because under Mira's team ATK
    buff every slot's autos are live: 0.20 x 1.00 beats 0.26 x 0.70.
    """
    out: list[str] = []
    for slot, i in info.items():
        if not i.get("ramp"):
            continue
        name = i.get("name", slot)
        msg = (
            f"{name} ({slot}) is a ramp buffer: its crit-damage stack never expires, "
            "so it stops paying once your carry's autos cap -- but the same cast also "
            "buffs attack speed, which never caps. Retiring it is worth about +2% "
            "ONLY if the replacement can actually cast; hand its slot to a card "
            "already covered by someone else and you simply lose the orbs."
        )
        if swap.get(slot):
            msg += f" The search found a retire-for-{swap[slot]} swap worth taking."
        out.append(msg)
    return out


def _score2(
    team: TeamSpec,
    scenario: Scenario,
    groups: Sequence[Sequence[str]],
    seeds: Sequence[int],
    loader: Any,
    swap: Optional[dict[str, str]] = None,
    swap_when: str = "autos",
) -> float:
    """Score a multi-group layout. Priority is left to right; a later group casts
    only while no earlier one holds the floor."""
    params: list[tuple[str, Any]] = [
        ("MC_GROUPS", json.dumps([list(g) for g in groups]))
    ]
    if swap:
        params.append(("MC_GROUP_SWAP", json.dumps(swap)))
        params.append(("MC_GROUP_SWAP_WHEN", swap_when))
    sc = Scenario(
        **{
            k: v
            for k, v in vars(scenario).items()
            if k not in ("scheduler", "scheduler_params")
        },
        scheduler="group",
        scheduler_params=tuple(params),
    )
    return score(team, sc, seeds=seeds, loader=loader).mean


def suggest(
    team: TeamSpec,
    scenario: Optional[Scenario] = None,
    seeds: Sequence[int] = (0, 1, 2),
    loader: Any = None,
    progress: Optional[Callable[[int, int], None]] = None,
) -> dict:
    """Greedy group selection. Returns the group, an optional ramp swap, and a trace.

    The trace is the point as much as the answer: a player who is told "drop Mira"
    and shown what each candidate was worth at the margin can disagree with it.
    """
    scenario = scenario or Scenario()
    info = classify(team, scenario, loader)
    carries = [s for s in SLOTS if info.get(s, {}).get("damage")]
    rest = [s for s in SLOTS if s in info and s not in carries]
    cap = min(len(info), budget(scenario))

    # Every caster competes on the same scale, including the damage skills. Treating
    # `damage=True` as "always cast" is the same mistake as treating a stat label as
    # a value: card 734 Ibaraki Doji is fielded for two PASSIVE abilities (+25% crit
    # rate to Phantasma as leader, +15% skill damage at wave start) that fire whether
    # or not it ever casts, while its skill is an 888-base AoE -- one weak hit on a
    # single boss, against 2905 for Hikoboshi. Its orb is better spent elsewhere, so
    # the search has to be allowed to leave it out.
    group: list[str] = []
    rest = [s for s in SLOTS if s in info]

    steps = 1 + sum(range(max(1, len(rest)) + 1)) + len(rest) + 4 * len(rest) + 1
    done = 0

    def tick() -> None:
        nonlocal done
        done += 1
        if progress:
            progress(min(done, steps), steps)

    # Baseline: nobody casts at all. Autos alone, and a skill has to beat that to
    # earn its slot -- which is the comparison a passive-carried card like 734 fails.
    current = _score(team, scenario, [], seeds, loader)
    tick()
    trace = [{"group": [], "score": current, "added": None}]

    def lay(members: Sequence[str]) -> list[str]:
        """Supports first, then damage. The one ordering rule that is not close:
        putting the carries first measured -21% and -22% on the two Hinoto teams."""
        chosen = [s for s in members]
        return [s for s in chosen if s not in carries] + [
            s for s in chosen if s in carries
        ]

    while rest and len(group) < cap:
        scored = []
        for c in rest:
            scored.append((_score(team, scenario, lay(group + [c]), seeds, loader), c))
            tick()
        best, pick = max(scored)
        if best <= current:
            trace.append({"group": None, "score": best, "rejected": pick})
            break
        group = group + [pick]
        rest.remove(pick)
        current = best
        trace.append({"group": lay(group), "score": best, "added": pick})
    group = lay(group)

    # Overflow bucket. The orb budget caps the BURST, not the fight: a team whose
    # main group is smaller than the budget still earns income the burst does not
    # spend. A second, lower-priority group casts only while group 1 is not holding
    # the floor, so it soaks up that surplus without joining the burst and stretching
    # its cadence -- which is what being IN group 1 would do.
    #
    # Measured on the player's single-Odairi config: [[P3,P1,P4],[P2]] scores 61.4M
    # against 58.6M for the best single group, +4.7%. Framing the choice as
    # in-group-or-silent could not express it, and the player's own rotation was
    # unreachable.
    overflow: list[str] = []
    for c in list(rest):
        cand = [group, [c]]
        v = _score2(team, scenario, cand, seeds, loader)
        tick()
        if v > current:
            overflow, current = [c], v
            rest.remove(c)
            trace.append({"group": list(group), "overflow": [c], "score": v})
            break

    # The ramp special case. Nimbus [Awakened] 514 is the only card in the game whose
    # on-cast buff has no duration (a real game bug: the +60% crit damage never
    # expires), so it does not want a permanent group slot -- it wants one until its
    # stacks cap a carry's autos, after which every further stack is waste. That is
    # what MC_GROUP_SWAP expresses, so offer it the best card the cap left out.
    swap: dict[str, str] = {}
    swap_when = "autos"
    ramp = next((s for s in group if info.get(s, {}).get("ramp")), None)
    if ramp and rest:
        # Score the swap against the SAME layout the rest of the search settled on,
        # overflow bucket included. Scoring it against the main group alone compared
        # a 1-group layout to a 2-group `current` and the swap could never win on a
        # team that had an overflow, whatever its merit.
        # The replacement has to be IN the group, adjacent to the card it replaces --
        # that is how MC_GROUP_SWAP is specified, and a candidate left in no group
        # simply never casts, which makes every swap look like a pure orb loss.
        def with_replacement(rep: str) -> list[list[str]]:
            main = [x for x in group if x != rep]
            main.insert(main.index(ramp) + 1, rep)
            return [main] + ([[x for x in overflow if x != rep]] if overflow else [])

        # Both channels, because they saturate independently: a card feeding only the
        # skill channel is spent when THAT caps, which can be long before the autos do
        # (or never). Every candidate replacement is tried; there are rarely >2.
        for cand_slot in rest:
            for when in ("autos", "skills", "either", "both"):
                cand = {ramp: cand_slot}
                layout = [g for g in with_replacement(cand_slot) if g]
                v = _score2(team, scenario, layout, seeds, loader, cand, when)
                tick()
                if v > current:
                    swap, swap_when, current = cand, when, v
                    group, overflow = layout[0], (layout[1] if len(layout) > 1 else [])
                    trace.append(
                        {
                            "group": list(group),
                            "score": v,
                            "swap": cand,
                            "swap_when": when,
                        }
                    )
    if progress:
        progress(steps, steps)

    return {
        "groups": [group] + ([overflow] if overflow else []),
        "swap": swap,
        "swap_when": swap_when,
        "score": current,
        "cap": cap,
        # Recomputed from the final layout, not carried from the search: the swap
        # probe pulls a candidate back INTO the group, and a stale leftover list then
        # reports the same slot as both kept and dropped.
        "dropped": [
            x
            for x in info
            if x not in group and x not in overflow and x not in swap.values()
        ],
        "info": info,
        "notes": notes_for(info, swap)
        + margin_note(atk_margin(atk_ranking(team, scenario, loader))),
        "trace": trace,
    }


def suggest_fast(
    team: TeamSpec,
    scenario: Optional[Scenario] = None,
    seeds: Sequence[int] = (0, 1, 2),
    loader: Any = None,
    progress: Optional[Callable[[int, int], None]] = None,
) -> dict:
    """Two battles instead of seven: cadence, then one group the prior proposes.

    For scoring one team the full greedy search is cheap. For scoring every team in
    the game it is seven times the bill, so this is the layered version: rank the
    buffers statically, fill the group to the orb budget, run it once, and report
    whichever of the two policies actually won.

    The best-of is not a tie-breaker, it is the safety net. The prior cannot tell a
    worthless buffer from a good one -- on `mira_nimbus_ohina_odairi` it proposes a
    group including Ohina, whose casts are worth less than the carry tempo they
    displace, and that group scores 57.9M against cadence's 60.4M. Taking the better
    of the two returns cadence there and the better group everywhere else, so the
    layered answer is never worse than the cadence baseline it started from.
    """
    scenario = scenario or Scenario()
    info, skills, recipients = classify_with_skills(team, scenario, loader)
    carries = [s for s in SLOTS if info.get(s, {}).get("damage")]
    cap = min(len(info), budget(scenario))
    ranked = prior(info, skills, recipients)
    keep = ranked[: max(0, cap - len(carries))]
    group = keep + carries

    # Supports before carries is the ordering rule that matters and it is not close:
    # putting the carries first measured -21% on hinoto, -22% on hinoto_v2. Order
    # WITHIN the supports is worth ~1% and is not derivable -- it flips direction
    # between hinoto (Tsukuyomi first, +1.4%) and hinoto_v2 (Orihime first, +0.7%),
    # which are the same five cards with different bonds. So spend one extra battle
    # on the swap rather than trying to predict it.
    alts = [group]
    if len(keep) >= 2:
        alts.append([keep[1], keep[0], *keep[2:]] + carries)

    steps = 1 + len(alts)
    cad_scen = Scenario(
        **{
            k: v
            for k, v in vars(scenario).items()
            if k not in ("scheduler", "scheduler_params")
        },
        scheduler="cadence",
    )
    cadence = score(team, cad_scen, seeds=seeds, loader=loader).mean
    if progress:
        progress(1, steps)
    scored = []
    for i, g in enumerate(alts):
        scored.append((_score(team, scenario, g, seeds, loader) if g else 0.0, i))
        if progress:
            progress(2 + i, steps)
    grouped, best_i = max(scored)
    group = alts[best_i]

    won = "group" if grouped > cadence else "cadence"
    return {
        "groups": [group],
        "swap": {},
        "score": max(grouped, cadence),
        "scheduler": won,
        "cap": cap,
        "dropped": [s for s in ranked if s not in keep],
        "info": info,
        "notes": notes_for(info, {}),
        "trace": [
            {"group": None, "score": cadence, "added": None, "policy": "cadence"},
            *[
                {"group": list(alts[i]), "score": v, "added": None, "policy": "group"}
                for v, i in sorted(scored, reverse=True)
            ],
        ],
    }
