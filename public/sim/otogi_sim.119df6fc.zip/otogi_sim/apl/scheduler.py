"""
Pool-and-burst rotation scheduler (the 40s-rotation model).

The community rotation is: pool orbs, then burst — cast the buffs together, then
dump the carry skills while the buffs are peaked — then pool again. A reactive
per-unit APL can't express "wait for orbs then fire the whole group", so this is
a small team-level state machine consulted in place of the APL rules.

Phases (hysteresis on the team orb pool):
  POOL   : hold everything until team orbs >= pool_target.
  BURST  : buffers cast (peak the buffs); carries cast only when their projected
           crit is near cap (which is only true once the buffs have landed, so
           carries naturally fire AFTER the buffers). Continue until orbs drain
           to burst_floor, then return to POOL.

Tunable + meta-aware: buffers/carries are identified from each unit's own skill
flags, and the thresholds are params so we can min-max per team.
"""

from __future__ import annotations

import re
from typing import Any

from .payload import amp_effects
from .state import _buff_remains, _team_buff_remains, skill_flags
from .window_value import value_per_orb

# Parse a buff/debuff effect token: TYPE<base%,scale%,dur>  ->  (TYPE, base).
_BUFF_EFF_RE = re.compile(r"([A-Z_]+)<(-?[\d.]+)(%?),")


def _buffer_signature(unit: Any) -> tuple[dict[str, float], int]:
    """(stat -> base magnitude%, target_count) for a buff-skill unit.

    Only percentage buffs are kept (a real stat buff, not a flat/duration token).
    Used to spot *dominated* buffers: a single-target buff whose stat is already
    provided to more targets at >= magnitude by another buffer is redundant.
    """
    sig: dict[str, float] = {}
    skill = getattr(unit, "skill", None)
    if skill is None:
        return sig, 1
    for eff in list(getattr(skill, "buff_effects", []) or []) + list(
        getattr(skill, "debuff_effects", []) or []
    ):
        m = _BUFF_EFF_RE.match(eff.strip())
        if not m or not m.group(3):  # require '%' — skip flat/CC tokens
            continue
        stat, mag = m.group(1), float(m.group(2))
        if mag > sig.get(stat, float("-inf")):
            sig[stat] = mag
    return sig, int(getattr(skill, "target_count", 1) or 1)


class ScriptedRotation:
    """Execute a fixed cast sequence per cycle (test a known human rotation).

    sequence: ordered list of slots to cast, e.g.
        ['P1','P4','P3','P3','P5','P5']  = Sola, Orihime, HikoA x2, HikoB x2
    The current sequence slot casts as soon as it can afford (the engine gates on
    orbs + energy before calling this), then the position advances. When the
    sequence finishes it waits until `cycle_time` has elapsed since the cycle
    start (pooling orbs), then repeats. A slot that can't cast for `skip_after`
    seconds is skipped so the rotation doesn't deadlock.
    """

    def __init__(
        self, sequence: list[str], cycle_time: float = 40.0, skip_after: float = 8.0
    ) -> None:
        self.sequence = sequence
        self.cycle_time = cycle_time
        self.skip_after = skip_after
        self.pos = 0
        self.cycle_start = 0.0
        self._waiting_since = 0.0

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        now = battle.current_time
        # Sequence finished -> pool until the cycle window elapses, then restart.
        if self.pos >= len(self.sequence):
            if now - self.cycle_start >= self.cycle_time:
                self.pos = 0
                self.cycle_start = now
                self._waiting_since = now
            else:
                return False
        want = self.sequence[self.pos]
        if attacker.slot != want:
            # Deadlock guard: if the wanted slot has been stuck too long, skip it.
            if now - self._waiting_since > self.skip_after:
                self.pos += 1
                self._waiting_since = now
            return False
        # It's this slot's turn and it can afford (engine already checked).
        self.pos += 1
        self._waiting_since = now
        return True


class CadenceScheduler:
    """Time-cadence generalization of the human "buff then dump carries" rotation.

    Every ``cycle`` seconds a fresh burst opens: cast each buffer once
    (``buff & !damage``, synced by construction), then fire each *true carry* up
    to ``casts_per_carry`` times. In the last ``end_dump`` seconds everything is
    dumped (orbs are worthless after the bell).

    A carry is gated by two **relative** thresholds — no absolute damage number,
    so the policy puts *every* team in its best light and can't be gamed by
    absolute-damage inflation (a fixed floor let mediocre cards + strong assists
    clear a magic number and spam; the score then reflected the exploit, not the
    cards). The two roles a floor plays are split:

    - **Selection** — a unit is a spam-carry only if its peak projected crit is at
      least ``carry_select_frac`` of the *team's best* carry peak. This drops
      utility damage skills (a debuffer that merely *has* a damage skill) whose
      ceiling sits far below the real carries, on any team, at any magnitude.
    - **Timing** — a selected carry fires only when its *current* projected crit is
      at least ``window_frac`` of *its own* running peak, i.e. it is inside its
      buff window. Between bursts (buffs expired) its crit falls below that and it
      holds; the next buff refresh lifts it back and it fires.

    Peaks are per-unit running maxima of the forced-crit skill projection, tracked
    on the battle (``_carry_peak``); the projection reuses
    ``Battle.calculate_action_damage(force_crit=True)`` — no new damage math.

    Why time-cadence rather than an orb threshold: the orb pool caps (~10), so
    pooling to a high threshold leaks regen; a fixed cadence keeps orbs churning
    and spends the full ~72-orb budget. Affordability is still gated by the engine
    before ``should_cast`` is consulted, so this only expresses judgment.

    Per-burst state lives on the battle so one instance is safe to share across
    battles. Tuned on the Sola/Orihime + 2x Hikoboshi worldboss team.
    """

    def __init__(
        self,
        cycle: float = 20.5,
        casts_per_carry: int = 1,
        carry_select_frac: float = 0.5,
        window_frac: float = 0.85,
        end_dump: float = 8.0,
        cost_target: int = 1,
        scarcity_order: bool = False,
        reserve_orbs: bool = False,
        stagger_amp: bool = True,
    ) -> None:
        self.cycle = cycle
        self.casts_per_carry = casts_per_carry
        self.carry_select_frac = carry_select_frac
        self.window_frac = window_frac
        self.end_dump = end_dump
        self.cost_target = cost_target
        self.scarcity_order = scarcity_order
        self.reserve_orbs = reserve_orbs
        # Hold a carry whose damage-amp debuff is ALREADY running on the target until
        # it is about to lapse, instead of re-applying it inside its own window.
        #
        # Why this matters: a duplicated carry (e.g. Hikoboshi in the active team AND
        # as the helper) fires both copies in the same burst, 0.3s apart. The amp is
        # already at the -75% shield floor from one cast, so the second adds no
        # magnitude -- it only refreshes a full window, buying ~0s of extra coverage.
        # Spacing the second cast to just before expiry roughly doubles amp uptime for
        # the same two orbs. Buff timing and the burst structure are untouched.
        self.stagger_amp = stagger_amp

    # -- orb-cost economy ---------------------------------------------------
    def _cost_ready(self, unit: Any, battle: Any) -> bool:
        """Has this unit's escalated orb cost decayed back to ``cost_target``?

        Skill cost escalates 1 -> 2 -> 3 per cast (``MonsterComponent.add_cast_cost``)
        and decays one step per ``BattleConfig.skill_minus_cost_cd`` (20s). So casting
        a unit ONCE per ~21s keeps every cast at 1 orb, while casting it twice inside a
        burst immediately pays 1+2 and then 2+3 on the following cycle.

        Measured on a world-boss team: the cliff sits exactly on the 20s constant —
        cycle 20 scores 45.9M, cycle 21 scores 69.98M, because at 21s every cast is
        affordable at 1 orb and the carries get 38 casts instead of 29.

        Gating on the *cost itself* rather than on a tuned cycle length means the
        rotation stays correct if ``skill_minus_cost_cd`` changes, and a unit whose
        cost has drifted to 2-3 simply waits one decay step instead of paying triple.
        """
        if int(getattr(unit, "need_cast_point", 1)) <= self.cost_target:
            return True
        # Safety valve: only hold if waiting can actually help. `do_minus_cast_cost`
        # clears `minus_cost_pending` after a SINGLE step, so decay is armed by a
        # cast rather than running continuously. If a unit ever ends up above
        # cost_target with no decay pending, its cost is as low as it will get and
        # holding would be an indefinite lockout, so let it cast.
        #
        # Not currently reachable in normal play — every unit re-arms decay each
        # time it casts, and the reference team casts cleanly once per cycle
        # (Sola 20, Orihime 20, Hikoboshi 40 over 19 cycles). Kept as a guard.
        return not bool(getattr(unit, "minus_cost_pending", False))

    # -- opening sync -------------------------------------------------------
    def _sync_block(self, battle: Any, pending_buffers: int) -> int:
        """Orbs the opening of a burst costs: every buffer still owing a cast,
        plus ONE carry.

        A buff lasts ~8s and orb income is 1 per 5s, so a burst that opens on a
        thin pool spends its orbs on buffs and then leaves the first nuke waiting
        for income until the window it was buffed for has lapsed. Measured on the
        reference world-boss team with the corrected 2-orb opening: the two
        buffers cast at 0.5s, the carry could not afford to cast until 10.2s, and
        the 8s crit window it was supposed to fire inside was already gone.

        Only the FIRST carry is counted. A second copy is free to lag -- the
        `window_frac` timing gate already refuses to let it fire outside its buff
        window, so delaying it buys amp uptime rather than losing the window.

        Clamped to the pool cap: a team whose opening block is larger than the
        pool could never open at all, and a burst that fires late beats one that
        never fires.
        """
        # Read the carry off the team's SKILLS, not off `_carry_peak_life`: that
        # dict is populated by projections, so it is empty on the opening tick --
        # exactly the moment this gate has to be right.
        carries = (
            1
            if any(
                p.is_alive
                and getattr(p, "skill", None) is not None
                and skill_flags(p.skill, p)["damage"]
                for p in battle.players
            )
            else 0
        )
        cap = int(getattr(battle, "skill_points_max", 10) or 10)
        return min(pending_buffers + carries, cap)

    def _opening_funded(self, battle: Any, pending_buffers: int) -> bool:
        return battle.skill_points >= self._sync_block(battle, pending_buffers)

    def _turn_rate(self, unit: Any) -> float:
        """Lower = acts less often. Used to let scarce actors claim orbs first.

        OFF BY DEFAULT (``scarcity_order=False``) — measured neutral-to-negative.
        The theory was sound: on the reference world-boss team Sola takes 36 turns
        over 390s against Hikoboshi's 325, and casts only 10 of a possible 18
        cycles, so a window she misses looks unrecoverable. But letting her claim
        orbs first does not change her cast count and costs ~0.4% overall
        (cycle 20: 71.67M with the ordering off vs 71.37M on). Retained behind a
        flag because it may matter on teams with more competing slow buffers;
        do not enable it without re-measuring.

        ``stat.final_speed`` is an attack *interval* (higher is slower), so a healer at
        ~4370 acts far less than a ranged carry at ~2795. Measured over 390s: Sola took
        36 turns against Hikoboshi's 325, so a window Sola misses is one she cannot get
        back, while a carry has hundreds of chances.
        """
        st = getattr(unit, "stat", None)
        spd = float(getattr(st, "final_speed", 0.0) or 0.0) if st else 0.0
        return 1.0 / spd if spd > 0 else 0.0

    def _orbs_reserved(self, battle: Any, st: dict, exclude: str) -> int:
        """Orbs owed by units that still have a cast pending this burst.

        OFF BY DEFAULT (``reserve_orbs=False``) — measured neutral-to-negative,
        same as ``scarcity_order`` (cycle 20: 71.57M on vs 71.76M with both off).
        The cost gate already prevents the starvation this was meant to fix: once
        every unit casts at 1 orb, the pool is deep enough that a carry taking an
        orb early does not deny a buffer later. Kept behind a flag for team shapes
        with a tighter orb budget; re-measure before enabling.

        Without this a carry spends the orb a buffer is waiting on: Sola casts only 10
        of a possible 18 cycles despite having enough turns, because she is last in line
        and her cost had escalated. Reservation is skipped once the cycle is nearly over
        so a unit that cannot act (dead, silenced, no turn left) never deadlocks the pool.
        """
        if not self.reserve_orbs:
            return 0
        if battle.current_time - st["start"] > self.cycle * 0.75:
            return 0  # late in the burst — let anyone spend
        owed = 0
        dominated = self._dominated_buffers(battle)
        for p in battle.players:
            if not p.is_alive or p.slot == exclude or p.skill is None:
                continue
            if p.slot in st["buffed"] or p.slot in dominated:
                continue
            f = skill_flags(p.skill, p)
            if f["buff"] and not f["damage"] and self._cost_ready(p, battle):
                owed += int(getattr(p, "need_cast_point", 1))
        return owed

    def _dominated_buffers(self, battle: Any) -> set[str]:
        """Slots of buffers that are redundant this battle — a same-stat buff is
        already provided to >= targets at >= magnitude by another live buffer, so
        casting them just burns orbs (e.g. Classic Alice's single-target ATK buff
        when Orihime gives the same 35% ATK to two targets). Cached per battle."""
        cached = getattr(battle, "_dominated_buffers_cache", None)
        if cached is not None:
            return cached
        buffers = []
        for p in battle.players:
            if not p.is_alive or p.skill is None:
                continue
            f = skill_flags(p.skill, p)
            if f["buff"] and not f["damage"]:
                sig, tc = _buffer_signature(p)
                if sig:
                    buffers.append((p.slot, sig, tc))
        dominated: set[str] = set()
        for slot, sig, tc in buffers:
            for oslot, osig, otc in buffers:
                if oslot == slot:
                    continue
                # o covers every stat of this buffer at >= magnitude and >= targets
                covers = all(
                    stat in osig and osig[stat] >= mag for stat, mag in sig.items()
                )
                if not covers or otc < tc:
                    continue
                strictly_better = otc > tc or any(
                    osig[stat] > mag for stat, mag in sig.items()
                )
                # Strictly-better dominates; exact ties broken by slot so identical
                # buffers don't mutually cancel (keep the lower slot, drop the rest).
                if strictly_better or oslot < slot:
                    dominated.add(slot)
                    break
        battle._dominated_buffers_cache = dominated
        return dominated

    def _amp_still_running(
        self, attacker: Any, battle: Any, target: Any, enemy_only: bool = False
    ) -> bool:
        """Is this unit's damage-amp debuff already running with time to spare?

        The amp is capped (it sits at the -75% shield floor from a single cast), so
        re-applying it while it still has plenty of duration left buys no magnitude
        and no meaningful coverage -- it just burns an orb. True means "wait": the
        debuff would outlive this unit's next turn, so casting now is pure waste.

        Shared by CadenceScheduler and GroupScheduler. It used to be inlined in
        CadenceScheduler.should_cast; GroupScheduler needs the identical judgment
        and a second copy is exactly the drift this package keeps getting bitten by.
        """
        try:
            gap = float(attacker.get_attack_interval())
        except Exception:
            gap = 2.0
        for e in amp_effects(attacker):
            if e.is_permanent or e.mod_type is None:
                continue
            # `enemy_only` restricts this to debuffs on the target -- the capped
            # damage-amp this was written for. Ally buffs stack ADDITIVELY within
            # their bucket, so two different buffers are not redundant: Mira and
            # Orihime take one carry 145% -> 300.2% -> 383.4%. Measuring "is a DAMAGE
            # modifier running on the recipient" cannot tell those apart, and held
            # Orihime for the whole 8s window behind Mira.
            if enemy_only and not e.on_enemy:
                continue
            recipient = target if e.on_enemy else attacker
            if recipient is None:
                continue
            if _buff_remains(battle, recipient, e.mod_type.name) > gap:
                return True
        return False

    def _project_crit(self, unit: Any, battle: Any, target: Any) -> float:
        """Forced-crit skill projection, maintaining two peaks.

        ``_carry_peak`` is per-cycle (cleared each burst) and drives the *timing*
        gate, so a transient — e.g. the enemy's shield break — can't leave a stale
        unreachable peak that deadlocks the window check.

        ``_carry_peak_life`` is the battle-lifetime max and drives *selection*.
        Using the per-cycle peak for selection leaks: the dict is empty at every
        cycle boundary, so whichever unit projects first compares against only
        itself (``team_best == own_peak``) and always clears the gate — letting a
        utility damage skill (an AoE chip, a healer's nuke) spend an orb that
        belonged to a real carry. Shorter cycles reset more often and leak more:
        measured 4 carry casts vs 6 junk casts at cycle=15, against 25 vs 3 at
        cycle=30. Splitting the two roles closes it at every cycle length.
        """
        f = skill_flags(unit.skill, unit) if getattr(unit, "skill", None) else None
        if not f or not f["damage"] or target is None:
            return 0.0
        crit = float(
            battle.calculate_action_damage(
                unit, target, is_skill=True, force_crit=True
            ).final_damage
        )
        peak = getattr(battle, "_carry_peak", None)
        if peak is None:
            peak = {}
            battle._carry_peak = peak
        if crit > peak.get(unit.slot, 0.0):
            peak[unit.slot] = crit
        life = getattr(battle, "_carry_peak_life", None)
        if life is None:
            life = {}
            battle._carry_peak_life = life
        if crit > life.get(unit.slot, 0.0):
            life[unit.slot] = crit
        return crit

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        # End-of-fight dump: spend everything affordable before the bell.
        if battle.effective_time_limit - battle.current_time <= self.end_dump:
            return True

        # Open a fresh burst every `cycle` seconds (state on the battle). Reset
        # the per-unit crit peaks each cycle: the forced-crit projection includes
        # the enemy's transient shield-break, so a peak captured right after a
        # carry applied SHIELD<-75%> is unreachable once that shield decays —
        # which would deadlock the window gate and starve carries for the rest of
        # the fight. A per-cycle peak keeps the window relative to what's
        # achievable *this* burst (buffs-first still holds carries for the buffs).
        st = getattr(battle, "_cadence", None)
        if st is None or battle.current_time - st["start"] >= self.cycle:
            st = {"start": battle.current_time, "buffed": set(), "nc": {}}
            battle._cadence = st
            battle._carry_peak = {}

        f = (
            skill_flags(attacker.skill, attacker)
            if getattr(attacker, "skill", None)
            else None
        )
        if f is None:
            return False

        # Cost gate: hold until this unit's escalated orb cost has decayed back to
        # `cost_target`. This is what the tuned ~21.5s cadence was really expressing.
        if not self._cost_ready(attacker, battle):
            return False

        # Buffers: cast once per burst (synced), refreshed every cycle. Skip
        # redundant buffers whose stat a better buffer already covers on >= targets.
        if f["buff"] and not f["damage"]:
            if attacker.slot in self._dominated_buffers(battle):
                return False
            if attacker.slot in st["buffed"]:
                return False
            # Opening sync: do not start a burst the pool cannot see through to its
            # first nuke. Checked only while the burst is still closed -- once a
            # buffer has cast the window is running and stalling mid-burst would
            # waste the buffs already spent.
            if not st["buffed"]:
                pending = sum(
                    1
                    for p in battle.players
                    if p.is_alive
                    and getattr(p, "skill", None) is not None
                    and p.slot not in self._dominated_buffers(battle)
                    and (lambda pf: pf["buff"] and not pf["damage"])(
                        skill_flags(p.skill, p)
                    )
                )
                if not self._opening_funded(battle, pending):
                    return False
            # Scarcity order: a rarely-acting unit (healer) claims orbs before a
            # frequently-acting one, since a window it misses is unrecoverable.
            if self.scarcity_order:
                mine = self._turn_rate(attacker)
                dominated = self._dominated_buffers(battle)
                for p in battle.players:
                    if not p.is_alive or p.slot == attacker.slot or p.skill is None:
                        continue
                    if p.slot in st["buffed"] or p.slot in dominated:
                        continue
                    pf = skill_flags(p.skill, p)
                    if not (pf["buff"] and not pf["damage"]):
                        continue
                    if not self._cost_ready(p, battle):
                        continue
                    # Someone scarcer than me still owes a cast — yield to them.
                    if self._turn_rate(p) < mine:
                        return False
            st["buffed"].add(attacker.slot)
            return True

        # Damage units: relative selection + timing gates.
        crit = self._project_crit(attacker, battle, target)
        if crit <= 0.0:
            return False
        # Selection off the battle-lifetime peak — a weak carry can never qualify
        # merely by being the first to project in a freshly-cleared cycle.
        life = battle._carry_peak_life
        if life.get(attacker.slot, crit) < self.carry_select_frac * max(life.values()):
            return False
        own_peak = battle._carry_peak.get(attacker.slot, crit)
        # Timing: only fire inside this carry's own buff window.
        if crit < self.window_frac * own_peak:
            return False
        # Redundant-amp stagger: the debuff is capped, so re-applying it while it still
        # has plenty of time left is pure waste. Wait unless it would lapse before this
        # unit's next turn (a unit is only asked once per attack interval).
        if self.stagger_amp and self._amp_still_running(attacker, battle, target):
            return False
        # Buffs-first: hold the carry until every *worthwhile* buffer has cast
        # this burst (dominated/redundant buffers never cast, so don't wait on them).
        dominated = self._dominated_buffers(battle)
        for p in battle.players:
            if not p.is_alive or p.skill is None:
                continue
            pf = skill_flags(p.skill, p)
            if (
                pf["buff"]
                and not pf["damage"]
                and p.slot not in st["buffed"]
                and p.slot not in dominated
            ):
                return False
        # Orb reservation: don't spend an orb a still-pending buffer needs. A buffer
        # that misses its window costs the whole team's next burst, whereas a carry
        # has hundreds of turns and will simply fire a moment later.
        reserved = self._orbs_reserved(battle, st, attacker.slot)
        if (
            reserved
            and battle.skill_points - int(getattr(attacker, "need_cast_point", 1))
            < reserved
        ):
            return False
        if st["nc"].get(attacker.slot, 0) < self.casts_per_carry:
            st["nc"][attacker.slot] = st["nc"].get(attacker.slot, 0) + 1
            return True
        return False


class GroupScheduler(CadenceScheduler):
    """Player-authored cast groups: the policy the web calculator drives.

    The player drags cards into ordered groups. Priority is left to right; any slot
    in no group never casts at all (the "do not cast" bucket). A group *opens* when
    every one of its eligible members can cast at cost 1, and once open it stays the
    active group until all of them have fired -- that is what makes a group fire
    *together* rather than dribbling out as orbs trickle in.

    This is deliberately less optimal than ``cadence``. Cadence discovers a rotation;
    this one executes the rotation the player asked for, so they can compare two
    teams under a policy they can reason about. Three of cadence's judgments are
    kept because they are about waste, not optimisation:

    - **cost 1 only** (``_cost_ready``): skill cost escalates 1 -> 2 -> 3 and decays
      one step per 20s, so a group that re-fires too early pays double and triple.
      This gate is what produces the natural ~20s group cadence -- no cycle constant.
    - **dominated buffers** (``_dominated_buffers``): a buff another member already
      supplies to more targets at higher magnitude is skipped. It neither casts nor
      blocks its group.
    - **amp stagger** (``_amp_still_running``): a duplicate damage-amp debuff that is
      already running is skipped for this opening rather than refreshed into itself.

    ``skip_after`` is the deadlock guard: a member held by CC (or by a lapsing amp)
    for that many seconds is passed over so one stunned unit cannot lock the group.
    """

    def __init__(
        self,
        groups: list[list[str]],
        cost_target: int = 1,
        skip_after: float = 8.0,
        stagger_amp: bool = True,
        cycle: float = 20.5,
    ) -> None:
        super().__init__(cost_target=cost_target, stagger_amp=stagger_amp)
        # Drop empty groups so an empty UI row can't stall the rotation.
        self.groups = [list(g) for g in groups if g]
        self.skip_after = skip_after
        # The beat a group tries to keep. Openings are scheduled on a FIXED grid
        # (due, due+cycle, due+2*cycle, ...) rather than measured from the previous
        # cast, because the latter compounds: a cast delayed by CC, a stagger hold or
        # plain turn timing pushes the next opening, which pushes the one after that.
        # Measured on a real team, that drift walked the carries out of an 8s crit
        # window by 66s and never recovered -- 5 of 31 casts landed with no crit for
        # ~150k instead of ~950k. A fixed grid lets a late cycle catch up instead.
        self.cycle = cycle

    # -- membership ---------------------------------------------------------
    def _group_of(self, slot: str) -> int | None:
        for i, g in enumerate(self.groups):
            if slot in g:
                return i
        return None

    def _unit(self, battle: Any, slot: str) -> Any:
        for p in battle.players:
            if p.slot == slot:
                return p
        return None

    def _eligible(self, battle: Any, slot: str) -> bool:
        """Can this slot ever cast this battle? Dead/skill-less/dominated cannot."""
        u = self._unit(battle, slot)
        if u is None or not u.is_alive or getattr(u, "skill", None) is None:
            return False
        return slot not in self._dominated_buffers(battle)

    def _can_act(self, battle: Any, slot: str) -> bool:
        """Cost has decayed back to 1 and no CC is stopping this unit casting.

        Deliberately does NOT include the amp-stagger check. Stagger is a judgment
        about one unit wasting its own orb; folding it in here made a single carry
        whose debuff was still running hold the ENTIRE group at the gate, which
        measured -20% and left the orb pool pinned at its cap of 10 with income
        overflowing. Stagger belongs to the caster, not to the group.
        """
        u = self._unit(battle, slot)
        if u is None:
            return False
        if u.is_cast_blocked(battle.current_time):
            return False
        return self._cost_ready(u, battle)

    def _ready(self, battle: Any, slot: str, target: Any) -> bool:
        """`_can_act` plus the caster's own amp-stagger skip. Applied to the unit
        actually asking to cast, never to the group as a whole."""
        if not self._can_act(battle, slot):
            return False
        u = self._unit(battle, slot)
        if self.stagger_amp and self._amp_still_running(
            u, battle, target, enemy_only=True
        ):
            return False
        return True

    # -- rotation -----------------------------------------------------------
    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        gi = self._group_of(attacker.slot)
        if gi is None:
            return False  # "do not cast" bucket

        now = battle.current_time
        st = getattr(battle, "_group_st", None)

        # Retire the active group once everyone eligible has fired, or once it has
        # been stuck past skip_after (a chain-CC'd member must not lock the team out).
        if st is not None:
            members = [
                s
                for s in self.groups[st["gi"]]
                if self._eligible(battle, s) and s not in st["fired"]
            ]
            # A member that CAN act but is being held by the amp stagger is waiting on
            # purpose. Timing the group out on it is how the duplicate carry ended up
            # never casting at all, so the clock does not run against it.
            held = any(
                self._can_act(battle, s) and not self._ready(battle, s, target)
                for s in members
            )
            if not members or (now - st["opened"] > self.skip_after and not held):
                # Next opening is one cycle after the time this one was DUE, not after
                # the time it actually happened -- so a cycle that ran late does not
                # push every cycle after it.
                due = getattr(battle, "_group_due", None)
                if due is None:
                    due = {}
                    battle._group_due = due
                due[st["gi"]] = st.get("due", st["opened"]) + self.cycle
                st = None
                battle._group_st = None

        # No group active: open the highest-priority one whose LEAD member can act.
        #
        # Requiring every member to be ready simultaneously was too strong. Orb income
        # is 1 per 5s -- 4 per 20s, enough to fund a four-card group each cycle -- but
        # lockstep paced the group to its slowest member, so it fired 13 times instead
        # of 17 and the pool sat pinned at its cap of 10 with the surplus evaporating.
        # Opening on the lead card starts the window on time; the rest join as their
        # turns come, and anyone CC'd or still paying an escalated cost is passed over
        # rather than holding the window shut.
        if st is None:
            due = getattr(battle, "_group_due", None)
            if due is None:
                due = {}
                battle._group_due = due
            for i, g in enumerate(self.groups):
                elig = [s for s in g if self._eligible(battle, s)]
                if not elig:
                    continue
                if now < due.get(i, 0.0):
                    continue  # not yet on this group's beat
                # Opening sync: the group's lead block is everyone up to and
                # including its first damage dealer -- they must fire inside one
                # buff window, so do not open until the pool can fund all of them.
                # Members after the first nuke may lag; `_amp_still_running` and
                # the player's own ordering handle those.
                lead_block = 0
                for s_ in elig:
                    lead_block += 1
                    u_ = self._unit(battle, s_)
                    uf = skill_flags(u_.skill, u_) if u_ is not None else None
                    if uf is not None and uf["damage"]:
                        break
                cap = int(getattr(battle, "skill_points_max", 10) or 10)
                if battle.skill_points < min(lead_block, cap):
                    continue
                if self._can_act(battle, elig[0]):
                    st = {
                        "gi": i,
                        "fired": set(),
                        "opened": now,
                        "due": due.get(i, now),
                    }
                    battle._group_st = st
                    break
            if st is None:
                return False

        if st["gi"] != gi:
            return False  # a higher-priority group holds the floor

        # One cast per member per opening. Without this a healer whose skill carries a
        # buff (Sola, Ameno Uzume, Classic Alice) casts TWICE in the same tick: the
        # engine offers it a cast on both the heal path and the attack path, and the
        # in-order loop below breaks at the attacker immediately, re-approving it.
        if attacker.slot in st["fired"]:
            return False

        # Re-check THIS unit at cast time. `_ready` was previously consulted only when
        # opening the group, so once open a member could cast at an escalated cost --
        # the one thing this policy promises never to do. The engine gate only asks
        # whether the orbs are affordable, not whether the cost is still 1, so nothing
        # downstream would have caught it.
        if not self._can_act(battle, attacker.slot):
            return False

        # Amp stagger is a DELAY, not a veto: a duplicated carry holds while its own
        # debuff is still running with time to spare, then fires as that window is
        # about to lapse -- which extends the debuff rather than re-applying it into
        # itself. `_ready` carries that check, and the retire rule below refuses to
        # time out on a member that is only being held, so the delay always resolves.
        if self.stagger_amp and self._amp_still_running(
            self._unit(battle, attacker.slot), battle, target, enemy_only=True
        ):
            return False

        # Cast in the player's listed order within the group. An earlier member holds
        # the queue only while it CAN act and simply has not had its turn yet -- one
        # that is stunned, silenced or still paying an escalated cost is stepped over,
        # so a single CC cannot cost the whole group its window.
        for s in self.groups[gi]:
            if s == attacker.slot:
                break
            if s in st["fired"] or not self._eligible(battle, s):
                continue
            if not self._ready(battle, s, target):
                continue  # blocked or deliberately held -- step over it
            return False  # an earlier member still owes its cast

        st["fired"].add(attacker.slot)
        return True


class SurvivalScheduler(CadenceScheduler):
    """Cadence, adapted to a fight where the team can actually die.

    ``cadence`` was tuned against the immortal dummy, where nothing interrupts
    the rotation and healing changes nothing. Against a real world boss both
    assumptions break:

    - **CC shreds the burst.** Every boss but one leans on STUN / SILENCE /
      FROZEN / STONE / NUMB. A burst that opens while the buffers are stunned is
      spent: the buffers never cast, and the carries fire naked. Worse, CC also
      pauses skill-cost decay, so a unit caught mid-burst comes back at cost 2-3
      and pays triple on the next cycle.
    - **A dead carry deals no damage.** Holding a heal to keep the rotation tidy
      is a good trade when nobody can die and a bad one when the boss is about to
      delete your highest-ATK unit. Measured against Kinoe (which snipes
      ``max_atk`` with a 6000 nuke twice per rotation), the reference team loses
      three of five units and scores 26% of its dummy damage.

    So this subclass changes one thing and inherits the rest:

    **Burst hold** -- do not open a fresh burst while any living unit with a
    skill is cast-blocked, or (with ``hold_on_cost``) still above
    ``cost_target``. The cycle slides rather than being spent, so the team fires
    together once the CC clears and the costs have decayed. ``max_hold`` caps the
    wait so a chain-CC'd unit cannot lock the other four out for the rest of the
    fight.

    Measured on the reference team (Mira[4th]/Orihime/Hikoboshi/Kashinkoji +
    Hikoboshi helper), 6 paired CRN seeds, 300s, bosses at Lv30:

    ========  =============  ==============  =============  =============
    policy    Kinoe          Hinoto          Mizunoe        Kanoto
    ========  =============  ==============  =============  =============
    cadence   20.7M / 3.2d   60.5M / 0.0d    44.4M / 1.3d   42.1M / 0.0d
    hold      17.9M / 3.2d   65.3M / 0.0d    45.9M / 0.7d   45.9M / 0.0d
    ========  =============  ==============  =============  =============

    So the cost half of the hold wins on three of four bosses on *both* axes --
    Mizunoe halves its deaths while scoring more -- and loses only on Kinoe,
    which kills the carries early enough that a synced rotation has nobody left
    to sync. It costs **16% on the immortal dummy** (79.0M -> 66.2M), because
    there a stretched cadence is just fewer casts with no upside; that is why
    this is a separate policy and not a flag on ``CadenceScheduler``. The CC half
    alone is inert on the dummy (79.0M) and worth up to +5.7% (Kanoto).

    **Panic heal is off by default (``panic_hp=0``) -- measured negative.** The
    idea was to let a healer jump the rotation when an ally is about to die. It
    loses damage at every threshold tried and does not reliably buy survival:

    ========  =============  =============
    panic_hp  Kinoe          Mizunoe
    ========  =============  =============
    0 (off)   17.9M / 3.2d   45.9M / 0.7d
    0.10      14.0M / 3.2d   43.0M / 0.8d
    0.20      14.1M / 3.3d   29.4M / 1.7d
    0.35      12.8M / 2.8d   34.6M / 1.5d
    ========  =============  =============

    The reason is that healers already heal without casting: ``_should_healer_heal``
    heals the most injured ally on every turn any ally is damaged, so the *skill*
    cast adds little healing and costs the orbs a carry needed. Kept as a knob
    (``MC_SURVIVAL_PANIC_HP``) with the numbers recorded, rather than deleted, so
    nobody re-derives it.

    Kept as a separate policy rather than options on ``CadenceScheduler`` so the
    dummy benchmark, the tier list and the golden corpus keep fighting exactly
    the fight they were generated with.
    """

    def __init__(
        self,
        *args: Any,
        panic_hp: float = 0.0,  # off: measured negative, see the class docstring
        max_hold: float = 10.0,
        hold_on_cost: bool = True,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, **kwargs)
        self.panic_hp = panic_hp
        self.max_hold = max_hold
        self.hold_on_cost = hold_on_cost

    # -- panic heal ---------------------------------------------------------
    @staticmethod
    def _can_heal(unit: Any) -> bool:
        """Healer by role, or any unit whose skill carries a HEAL effect."""
        model = getattr(unit, "model", None)
        if model is not None and getattr(model, "unit_type", 0) == 3:
            return True
        skill = getattr(unit, "skill", None)
        if skill is None:
            return False
        for eff in list(getattr(skill, "buff_effects", [])) + list(
            getattr(skill, "debuff_effects", [])
        ):
            if eff.split("<")[0].strip() in ("HEAL", "HEAL_DOT"):
                return True
        return False

    @staticmethod
    def _hp_frac(unit: Any) -> float:
        stat = getattr(unit, "stat", None)
        if stat is None:
            return 1.0
        try:
            cap = float(stat.hp_modifier.final_value)
        except Exception:
            return 1.0
        return stat.current_hp / cap if cap > 0 else 1.0

    def _panic(self, attacker: Any, battle: Any) -> bool:
        """True when an ally is low enough that the rotation stops mattering."""
        if self.panic_hp <= 0.0:
            return False  # off by default -- measured negative
        if getattr(battle.config, "immortal_players", False):
            return False  # nothing can die; a panic heal would be pure noise
        if not self._can_heal(attacker):
            return False
        return any(
            p.is_alive and self._hp_frac(p) <= self.panic_hp for p in battle.players
        )

    # -- burst hold ---------------------------------------------------------
    def _team_ready(self, battle: Any) -> bool:
        """Can the team actually execute a burst right now?

        A unit that is stunned or silenced cannot cast at all, and one whose orb
        cost has not decayed back would pay 2-3 for the privilege. Either way the
        burst is better spent a moment later, together.
        """
        now = battle.current_time
        for p in battle.players:
            if not p.is_alive or getattr(p, "skill", None) is None:
                continue
            if p.is_cast_blocked(now):
                return False
            if self.hold_on_cost and not self._cost_ready(p, battle):
                return False
        return True

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        if self._panic(attacker, battle):
            return True

        st = getattr(battle, "_cadence", None)
        due = st is None or battle.current_time - st["start"] >= self.cycle
        if due and not self._team_ready(battle):
            held = getattr(battle, "_survival_hold", None)
            if held is None:
                battle._survival_hold = battle.current_time
                return False
            # Give up holding after max_hold: a unit chain-CC'd for the rest of
            # the fight must not lock the other four out of casting entirely.
            if battle.current_time - held < self.max_hold:
                return False
        battle._survival_hold = None
        return super().should_cast(attacker, battle, target)


def _ramp_profile(unit: Any) -> tuple[bool, float]:
    """(is_ramp_buffer, crit_rate_window_seconds) for a unit.

    A *ramp buffer* carries an on-skill (``attack_skill``) ability granting a
    PERMANENT crit-damage stack — ``CHIT_ATK`` with ``duration == 0``. Nimbus
    [Awakened] 514's ability 51402 is the only card in the game with this shape,
    and the missing duration is a real game bug: the +60% crit damage never
    expires, so it compounds once per cast for the whole battle. Detected by
    signature rather than by card id so any future card with the same shape is
    picked up.

    The same ability's ``CHIT`` (crit *rate*) half DOES have a duration (4s on
    Nimbus). That short window is a hard deadline — a carry skill has to land
    inside it to bank a guaranteed crit — so it is returned alongside.
    """
    is_ramp = False
    window = 0.0
    for ab in getattr(unit, "abilities", []) or []:
        trig = getattr(ab, "trigger", None)
        if getattr(trig, "value", trig) != "attack_skill":
            continue
        for eff in getattr(ab, "effects", []) or []:
            name = getattr(getattr(eff, "effect_type", None), "name", None)
            dur = float(getattr(eff, "duration", 0) or 0)
            if name == "CHIT_ATK" and dur == 0:
                is_ramp = True
            elif name == "CHIT" and dur > 0:
                window = max(window, dur)
    return is_ramp, window


class RampRotation:
    """Ordered burst on the cost-decay cadence: ramp -> buffers -> carries.

    Models the human world-boss rotation rather than a reactive per-unit policy.
    Every ``cycle`` seconds (default 20s — ``BattleConfig.skill_minus_cost_cd``,
    the interval over which each unit's escalated orb cost decays back toward 1)
    a burst opens and the team casts *in order*:

        1. the ramp buffer (Nimbus), banking a permanent crit-damage stack
        2. the remaining buffers (Orihime, ...)
        3. each carry, up to ``casts_per_carry`` times (Hiko x2)

    Two things distinguish this from CadenceScheduler:

    **Front-loading.** CadenceScheduler casts each buffer once per 30s cycle, so a
    ramp buffer fires only ~12 times across a 330s fight and the carry does not
    finish capping its autos until the final bucket. The same casts spent earlier
    convert the whole back half of the fight to capped autos at no extra orb cost.

    **Knowing when to stop.** Once the ramp's target caps its auto attacks, further
    stacks are pure waste, so the ramp drops out of the sequence and its orbs go to
    the carries instead. Saturation is measured at the moment the ramp would cast —
    which, because the ramp casts *first* in the burst, is exactly when the timed
    team buffs are down. So the check reads the carry's *baseline*, not its buffed
    peak, and won't stop the ramp early just because the carry caps inside a window.

    The buffs-first gate is deliberately not absolute: the ramp's crit-*rate* half
    lasts only ~4s, so once the ramp has cast, a carry may preempt any still-pending
    buffers rather than miss that window (``crit_window_grace``).
    """

    def __init__(
        self,
        cycle: float = 20.5,
        slip: float = 5.0,
        casts_per_carry: int = 1,
        carry_select_frac: float = 0.5,
        window_frac: float = 0.85,
        end_dump: float = 8.0,
        ramp_stop: bool = True,
        crit_window_grace: float = 0.5,
    ) -> None:
        self.cycle = cycle
        self.slip = slip
        self.casts_per_carry = casts_per_carry
        self.carry_select_frac = carry_select_frac
        self.window_frac = window_frac
        self.end_dump = end_dump
        self.ramp_stop = ramp_stop
        self.crit_window_grace = crit_window_grace

    # -- role classification ------------------------------------------------
    def _roles(self, battle: Any) -> dict[str, int]:
        """slot -> stage (0 ramp, 1 buffer, 2 carry). Cached per battle."""
        cached = getattr(battle, "_ramp_roles", None)
        if cached is not None:
            return cached
        roles: dict[str, int] = {}
        for p in battle.players:
            if getattr(p, "skill", None) is None:
                continue
            f = skill_flags(p.skill, p)
            is_ramp, _ = _ramp_profile(p)
            if is_ramp:
                roles[p.slot] = 0
            elif f["buff"] and not f["damage"]:
                roles[p.slot] = 1
            elif f["damage"]:
                roles[p.slot] = 2
        battle._ramp_roles = roles
        return roles

    def _crit_window(self, battle: Any) -> float:
        cached = getattr(battle, "_ramp_window", None)
        if cached is not None:
            return float(cached)
        w = 0.0
        for p in battle.players:
            is_ramp, win = _ramp_profile(p)
            if is_ramp:
                w = max(w, win)
        battle._ramp_window = w
        return w

    # -- saturation ---------------------------------------------------------
    def _ramp_saturated(self, battle: Any) -> bool:
        """Is some ally's *baseline* auto attack already at the damage cap?

        Evaluated live (not sticky) at the ramp's cast moment. Uses the same
        force-crit projection the carry gating uses, so no new damage math.
        """
        if not self.ramp_stop:
            return False
        enemy = next((e for e in battle.enemies if e.is_alive), None)
        if enemy is None:
            return False
        cap = battle.config.damage_cap
        for p in battle.players:
            if not p.is_alive:
                continue
            dmg = battle.calculate_action_damage(
                p, enemy, is_skill=False, force_crit=True
            ).final_damage
            if dmg >= cap:
                return True
        return False

    def _project_crit(self, unit: Any, battle: Any, target: Any) -> float:
        """Forced-crit skill projection, maintaining TWO peaks.

        CadenceScheduler keeps one per-cycle peak and uses it for both carry
        *selection* and *timing*. That leaks: the peak dict is cleared at every
        cycle boundary, so whichever unit projects first in a fresh cycle compares
        against only itself (``team_best == own_peak``) and always clears the
        selection gate — letting a utility damage skill (Ibaraki's AoE, a healer's
        chip) spend an orb that belonged to a real carry. The shorter the cycle,
        the more often the gate is open: measured 4 Andromeda casts vs 6 junk casts
        at cycle=15, against 25 vs 3 at cycle=30.

        So the two jobs are split:
          * ``_carry_peak_life`` — battle-lifetime max, never reset. Used for
            SELECTION, so a weak carry can never qualify just by going first.
          * ``_carry_peak`` — per-cycle, reset each burst. Used for TIMING, so the
            window gate stays reachable when a transient (e.g. a shield break)
            inflates one projection and then decays.
        """
        f = skill_flags(unit.skill, unit) if getattr(unit, "skill", None) else None
        if not f or not f["damage"] or target is None:
            return 0.0
        crit = float(
            battle.calculate_action_damage(
                unit, target, is_skill=True, force_crit=True
            ).final_damage
        )
        peak = getattr(battle, "_carry_peak", None)
        if peak is None:
            peak = {}
            battle._carry_peak = peak
        if crit > peak.get(unit.slot, 0.0):
            peak[unit.slot] = crit
        life = getattr(battle, "_carry_peak_life", None)
        if life is None:
            life = {}
            battle._carry_peak_life = life
        if crit > life.get(unit.slot, 0.0):
            life[unit.slot] = crit
        return crit

    # -- main ---------------------------------------------------------------
    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        now = battle.current_time
        # Orbs are worthless after the bell — dump everything affordable.
        if battle.effective_time_limit - now <= self.end_dump:
            return True

        roles = self._roles(battle)
        stage = roles.get(attacker.slot)
        if stage is None:
            return False

        st = getattr(battle, "_ramp_burst", None)
        if st is None:
            st = {"start": now, "done": set(), "nc": {}, "ramp_at": None}
            battle._ramp_burst = st
            battle._carry_peak = {}
        else:
            # A new burst opens on the cadence once the previous one finished, or
            # after `slip` extra seconds if it stalled waiting on orbs.
            elapsed = now - st["start"]
            pending = self._pending(battle, st, 3)
            if elapsed >= self.cycle and (
                not pending or elapsed >= self.cycle + self.slip
            ):
                st = {"start": now, "done": set(), "nc": {}, "ramp_at": None}
                battle._ramp_burst = st
                battle._carry_peak = {}

        # Stage 0 — ramp buffer.
        if stage == 0:
            if attacker.slot in st["done"]:
                return False
            if self._ramp_saturated(battle):
                st["done"].add(attacker.slot)  # retire it for this burst
                return False
            st["done"].add(attacker.slot)
            st["ramp_at"] = now
            return True

        # Everything else waits for the ramp to resolve this burst.
        # (_pending(.., n) = "any unit in a stage strictly below n still owes a
        # cast", so waiting on the ramp — stage 0 — is a query for n = 1.)
        if self._pending(battle, st, 1):
            return False

        # Stage 1 — remaining buffers, once each per burst. Skip redundant ones
        # whose stat a better buffer already covers on >= targets (same reasoning
        # as CadenceScheduler: casting them just burns orbs the carries want).
        if stage == 1:
            if attacker.slot in self._dominated_buffers(battle):
                return False
            if attacker.slot in st["done"]:
                return False
            st["done"].add(attacker.slot)
            return True

        # Stage 2 — carries.
        crit = self._project_crit(attacker, battle, target)
        if crit <= 0.0:
            return False
        # Selection off the battle-lifetime peak (a weak carry can never qualify
        # by being first in a fresh cycle); timing off the per-cycle peak.
        life = battle._carry_peak_life
        if life.get(attacker.slot, crit) < self.carry_select_frac * max(life.values()):
            return False
        own_peak = battle._carry_peak.get(attacker.slot, crit)
        if crit < self.window_frac * own_peak:
            return False
        # Buffs-first, EXCEPT the ramp's crit-rate window is closing: a guaranteed
        # crit on a carry skill is worth more than a still-pending buffer.
        if self._pending(battle, st, 2):
            ramp_at = st.get("ramp_at")
            win = self._crit_window(battle)
            closing = (
                ramp_at is not None
                and win > 0.0
                and now - ramp_at >= max(0.0, win - self.crit_window_grace)
            )
            if not closing:
                return False
        if st["nc"].get(attacker.slot, 0) < self.casts_per_carry:
            st["nc"][attacker.slot] = st["nc"].get(attacker.slot, 0) + 1
            return True
        return False

    def _pending(self, battle: Any, st: dict, stage: int) -> bool:
        """Any live unit in a stage *strictly below* `stage` that still owes a cast?

        So "has the ramp (stage 0) resolved?" is `_pending(.., 1)`, and "have the
        ramp and all buffers resolved?" is `_pending(.., 2)`.
        """
        roles = self._roles(battle)
        dominated = self._dominated_buffers(battle)
        for p in battle.players:
            if not p.is_alive:
                continue
            r = roles.get(p.slot)
            if r is None or r >= stage:
                continue
            if r == 2:
                if st["nc"].get(p.slot, 0) < self.casts_per_carry:
                    return True
            elif p.slot not in st["done"] and p.slot not in dominated:
                # Dominated buffers never cast, so nothing should wait on them.
                return True
        return False

    # Borrowed verbatim — identical semantics to CadenceScheduler.
    # (_project_crit is NOT borrowed: this class defines its own above, which
    # additionally maintains the battle-lifetime peak used for carry selection.)
    _dominated_buffers = CadenceScheduler._dominated_buffers


class PlannerScheduler:
    """Uptime-first scheduler: hold each cast until just before its effect lapses.

    `CadenceScheduler` fires on a fixed cadence and models neither effect duration nor
    orb inventory, so a unit whose damage comes from *maintaining* a debuff casts far
    too early. Measured on 549/1720/1721/1615: Hikoboshi casts once per ~21s cycle, so
    its 8s SHIELD amp covers ~38% of the fight -- while ~74% is reachable. That matters
    because 63% of that team's damage is auto attacks hitting into the amp.

    The rule here follows from `window_value`'s (now marginal) uptime term: re-applying
    a running effect only buys coverage past its current expiry, so value climbs
    monotonically as the effect decays. "Wait" therefore always beats "cast now" until
    the effect is about to lapse -- which makes the decision simply:

        cast when  remaining_coverage <= time_until_my_next_turn

    The pre-compensation is essential and is why this cannot be expressed as "cast at
    expiry": a unit is only asked once per its own attack interval (~1-4s), so waiting
    for exact expiry opens a gap of up to one interval. Firing at the last opportunity
    *before* expiry keeps coverage continuous. `unit.next_attack_time` /
    `get_attack_interval()` give this exactly, and no existing scheduler uses them.

    Units with no timed payload (pure nukes) can't be timed this way, so they fall back
    to a value gate and simply spend spare orbs.

    All per-battle state lives on `battle` (never on self), so one instance is safe to
    share across battles and worker processes -- the same convention CadenceScheduler
    uses, and the reason `ScriptedRotation` is not process-safe.
    """

    def __init__(
        self,
        end_dump: float = 8.0,
        value_floor: float = 0.0,
        lookahead_pad: float = 0.0,
        require_buffs: bool = True,
    ):
        # Seconds before the bell where leftover orbs are worthless, so cost stops
        # mattering. Defaults to 8s == the standard buff duration, so the final buffs
        # and the dump coincide; widening it makes buffs expire mid-dump.
        self.end_dump = end_dump
        # Minimum value-per-orb for a *pure damage* cast (no timed payload).
        self.value_floor = value_floor
        # Extra slack added to the pre-compensation window (tuning knob).
        self.lookahead_pad = lookahead_pad
        # Hold amp carries until the team's damage buffs are up.
        self.require_buffs = require_buffs

    # -- helpers ---------------------------------------------------------------

    @staticmethod
    def _next_turn_gap(unit: Any, battle: Any) -> float:
        """Seconds until this unit can be asked to cast again."""
        try:
            nxt = float(getattr(unit, "next_attack_time", 0.0)) - battle.current_time
            if nxt > 0:
                return nxt
            return float(unit.get_attack_interval())
        except Exception:
            return 2.0

    def _coverage_slack(self, attacker: Any, battle: Any, target: Any) -> float | None:
        """Least remaining coverage across this cast's timed damage effects.

        Returns None when the skill has no timed damage payload (a pure nuke), which
        means uptime scheduling does not apply to it.
        """
        effs = [
            e
            for e in amp_effects(attacker)
            # A permanent effect never lapses, so it can never be "about to expire";
            # scheduling it on uptime would hold it forever.
            if not e.is_permanent
        ]
        if not effs:
            return None
        worst = None
        for e in effs:
            recipient = target if e.on_enemy else attacker
            if recipient is None or e.mod_type is None:
                continue
            rem = _buff_remains(battle, recipient, e.mod_type.name)
            worst = rem if worst is None else min(worst, rem)
        return worst

    @staticmethod
    def _team_damage_buff_up(battle: Any) -> bool:
        """Is any team-wide damage buff currently running?"""
        return _team_buff_remains(battle, "DAMAGE") > 0.0

    # -- decision --------------------------------------------------------------

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        # End of fight: orbs left over at the bell are worth zero, so spend whatever is
        # affordable regardless of escalated cost. (The caller has already checked the
        # unit can pay.)
        if battle.effective_time_limit - battle.current_time <= self.end_dump:
            return True

        skill = getattr(attacker, "skill", None)
        if skill is None:
            return False

        slack = self._coverage_slack(attacker, battle, target)

        # No timed payload -> uptime is meaningless. Spend spare orbs on it when it is
        # worth more than the floor, and only once the buffs it wants are up.
        if slack is None:
            if self.require_buffs and not self._team_damage_buff_up(battle):
                return False
            try:
                return value_per_orb(attacker, battle, target) > self.value_floor
            except Exception:
                return True

        gap = self._next_turn_gap(attacker, battle) + self.lookahead_pad

        # Still covered, and I get another turn before it lapses -> waiting strictly
        # buys more marginal uptime.
        if slack > gap:
            return False

        # About to lapse. Hold an amp carry for the team buffs *only* while that does
        # not cost coverage -- an amp that has already lapsed is refreshed immediately.
        if self.require_buffs and slack > 0 and not self._team_damage_buff_up(battle):
            f = skill_flags(skill, attacker)
            if f["damage"]:
                return False

        return True
