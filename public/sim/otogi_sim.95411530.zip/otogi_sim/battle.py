"""
Battle simulation engine for the Otogi Battle Simulator.

Implements the full combat lifecycle, in the order the game runs it:
1. Battle setup     - install teams, enemies and ability data
2. Unit setup       - roll up stats, then apply entry abilities
3. Combat loop      - tick-based attack execution
4. Damage           - the pipeline in `calculate_action_damage`

Evidence tiers used throughout this package:
  Measured in play      - reproduced from an observed battle (numbers quoted).
  Inferred from data    - derived from shipped game data, not yet seen in play.
  Assumed               - a modelling choice; says so and explains the choice.
"""

import copy
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Callable
from enum import Enum, auto
import random

from .lifecycle import (
    EFFECT_TO_MODIFIER,
    MonsterModel,
    MonsterStat,
    MonsterComponent,
    UnitState,
    ModifierType,
    DebuffType,
)
from .abilities import AbilityManager, AbilityTrigger
from .models import ActionType, CritType, DamageResult
from .data_loader import get_skill
from .apl import get_engine
from .worldboss import BossSpec, BossState, next_boss_state, parse_target_spec
from . import formation

# Default targeting priority by role: melee (1) > healer (3) > assist (4) > ranged (2)
# This matches observed game behavior - enemies target frontline/squishy first
DEFAULT_ROLE_PRIORITY = [1, 3, 4, 2]


class BattlePhase(Enum):
    """Battle state machine phases."""

    INIT = auto()
    WAVE_START = auto()
    COMBAT = auto()
    WAVE_END = auto()
    VICTORY = auto()
    DEFEAT = auto()


@dataclass
class BattleConfig:
    """Configuration for battle simulation."""

    # Wave configuration
    wave_count: int = 5
    enemies_per_wave: List[int] = field(default_factory=lambda: [3, 4, 4, 5, 1])
    enemy_hp_scaling: List[float] = field(
        default_factory=lambda: [1.0, 1.2, 1.4, 1.6, 3.0]
    )

    # Combat settings
    tick_rate: float = 0.1  # Seconds per tick
    turn_limit: int = 1000  # Max turns per wave
    time_limit: float = 0.0  # Max time in seconds (0 = no limit)
    # Per-wave time limits in seconds, from the game's `tl` column (one entry per
    # wave, 0 = no limit). The real game budgets time PER WAVE, not per battle;
    # when this is set it overrides `time_limit`. Empty = legacy whole-battle limit.
    wave_time_limits: List[float] = field(default_factory=list)
    is_pvp: bool = False

    # Caps (from constants)
    crit_max: float = 1.0
    shield_max: float = 0.85
    # Seconds between a skill CAST and its buff/debuff actually landing. Measured in
    # play 2026-09-17: 15 casts, median 0.666s (range 0.633-0.932). It matters because
    # two skills can be cast at the same moment and BOTH resolve before either one's
    # buffs apply -- so a carry firing alongside its buffer does not get that buff.
    # Default 0.0 keeps the historical behaviour; see the note in otogi_sim/CLAUDE.md.
    skill_effect_delay: float = 0.0

    damage_cap: int = 99999
    skill_damage_cap: int = 999999

    # Energy settings
    skill_energy_min: int = 5
    skill_energy_max: int = 18
    skill_energy_damage_mult: int = 10
    skill_minus_cost_cd: float = 20.0

    # Team skill-orb income: 1 orb every skill_points_regen_cd seconds.
    # Real single-round income is 1 orb / 5 s (= 8 orbs / 40 s) — the rate manual
    # rotations are built around. NOTE: the extracted config value `skill_pts_cd:10`
    # is the AUTO-battle throttle (stops auto-logic overfiring one skill), NOT the
    # real orb economy. Wave-bonus orbs exist but are not modeled. World boss's 5%
    # DR is small enough that the immortal dummy stays a valid proxy.
    skill_points_regen_cd: float = 5.0
    starting_skill_points: int = 0  # 0 = keep the existing wave-start grant
    # Seconds between decoupled skill-cast opportunities. 0 disables the phase, so a
    # cast can only happen on a unit's attack turn (the legacy behaviour).
    #
    # In the real game skills are NOT tied to the attack timer. In-game observation 2026-08-25
    # (card 740, auto cadence ~2.45s): an auto landed 0.91s and 0.96s after a skill,
    # far inside the interval, and the auto rhythm continued underneath. Coupling them
    # costs an auto per cast -- material when 63% of a team's damage is autos -- and
    # forces the rotation to wait on slow units (a 2.3-speed healer can only act every
    # ~3.4s). 0.5s also approximates the in-game habit of waiting a beat after a buff
    # lands before casting into it.
    skill_tick_rate: float = 0.5

    # Benchmark mode: players cannot die, so survivability doesn't truncate the
    # damage measurement (a pure-DPS benchmark). Enemy still attacks (for HP/
    # taken-damage triggers); player HP is floored at 1.
    immortal_players: bool = False

    # Place cards in the game's 3x2 formation and make enemy autos take a FRONT
    # column target while one lives (see formation.py). Off by default: the
    # benchmark dummy and the world boss are single enemies where position means
    # nothing, and switching it on globally would move every existing tier list.
    use_formation: bool = False

    # LB exceed (5% per level)
    lb_exceed_rate: float = 0.05

    # Wave recovery
    wave_recover: float = 0.05

    # Record per-unit skill-cast timestamps (see Battle.skill_cast_log).
    # Off by default — the MC hot path pays nothing; enable for analysis/replay.
    record_casts: bool = False

    # World Boss: a slow on the BOSS suppresses its single-target casts outright.
    # OBSERVED in game (boss 2, lv16-30, two runs on 2026-09-09 and 2026-09-10 --
    # both produced the identical hit/miss sequence, cast for cast):
    #   no slow            : skill 3 dealt damage on 4/4 casts, skill 4 on 2/2
    #   Kanesada (690) on  : skill 3 on 6/12, skill 4 on 4/8; skill 1 (AoE) 19/19
    # The slow was card 690's "Refreshing belle", a flat SPD -30% with scale 0 and
    # no other SPD source on the team -- so -30% in CARD units is the measured
    # point, and this threshold is in those same units. (The game's internal
    # internal speed field read -0.400 for that -30% debuff, a clean 4/3; where that
    # factor comes from is unexplained and does not affect this model.)
    # The cast is still ISSUED on schedule -- the 60s wall clock never slides -- but
    # it resolves no targets and deals nothing. The drop is decided before target
    # selection, and it is NOT a simple busy-timer: a plain "busy until cast+D"
    # rule mispredicts 2 of the 20 observed casts.
    #
    # ponytail: two data points support a step, not a curve. Modelled as "at or past
    # the threshold, every other cast OF EACH SKILL ID is dropped" -- deterministic,
    # so it costs no CRN variance, and it reproduces both observed points exactly.
    # Per skill id, not pooled: each skill owns its own casting flag, and the
    # observed alternation is per skill and independent of the gap between casts.
    #
    # THE SUPPRESSION IS A BINARY SWITCH, and the 50% is an ARTEFACT, not a rate.
    # The only thing that clears the action's "currently casting" flag is a
    # callback registered at the very LAST instant of the animation clip (frame
    # index -1, i.e. clip length), while the damage/impact callback sits at an
    # interior frame. While slowed the clip-end callback never fires at all, so the
    # flag sticks; the next cast of that skill is dropped, and the drop clears the
    # flag itself, so the one after lands. A 100% failure therefore shows up as
    # exact alternation, independent of the gap between casts (5s, 15s, 40s and 45s
    # all alternated). Stacking more slow past the threshold buys NOTHING: the clear
    # is already failing every time. A -45% card is worth no more than a -30% one.
    # The only open question is where the switch sits, and there are two live
    # readings:
    #   (a) ANY nonzero slow trips it for a skill with a non-instant animation
    #       -> set this to something tiny (0.01) and a -5% card is as good as -30%
    #   (b) it takes a minimum slow -> the value below is that minimum
    # Nothing in the code supports (b): the clip-end trigger time is captured once and
    # cached, the poll compares `<=` against it with a latch, and no term anywhere is
    # proportional to slow magnitude, clip length, or cast spacing. The failure is in
    # the engine's own end-of-clip sampling, which is not readable from the client --
    # so (a) FITS the data and (b) is merely SAFE. Neither is established.
    #
    # ponytail: shipping (b) at 0.30, the only magnitude ever observed to trip it
    # (card 690's flat SPD -30%). THE REAL THRESHOLD MAY BE MUCH LOWER, possibly zero.
    # Erring high only under-credits cheap slow cards; erring low would inflate every
    # team holding one, so high is the safe direction to be wrong in. To confirm: one
    # World Boss run carrying a -10% card (297, 340, 376, 567, 1719) or a -15% one
    # (737, 1312, 1389) and check whether its single-target casts still alternate. If
    # they do, drop this to ~0.01 and re-run the tier lists -- it would re-rank every
    # World Boss team that holds a small slow. Until then do not read intermediate
    # values here as measured. 0 disables suppression entirely.
    wb_slow_suppress_at: float = 0.30

    # Combo bonuses - DISPROVEN (2026-01-16)
    # Combo is purely cosmetic and does NOT affect damage.
    # Kept for backwards compatibility but all values are 0.
    combo_bonus: Dict[int, float] = field(
        default_factory=lambda: {1: 0.0, 2: 0.0, 3: 0.0, 4: 0.0, 5: 0.0}
    )


@dataclass(slots=True)
class BattleEvent:
    """Record of a battle event for tracing."""

    tick: int
    time: float
    event_type: str
    attacker: Optional[str] = None
    target: Optional[str] = None
    damage: int = 0
    crit_type: CritType = CritType.NONE
    was_skill: bool = False
    combo: int = 1
    details: Dict = field(default_factory=dict)


class Battle:
    """
    Main battle simulation class.

    Follows the game's combat lifecycle:
    1. Configure the battle (teams, enemies, ability data)
    2. Initialise units and apply entry abilities
    3. Begin combat
    4. Execute attacks until the wave ends
    """

    def __init__(self, config: Optional[BattleConfig] = None):
        """Initialize battle with optional configuration."""
        self.config = config or BattleConfig()

        # Units
        self.players: List[MonsterComponent] = []
        self.enemies: List[MonsterComponent] = []

        # Reserve cards - contribute abilities only, don't fight
        # Max 2 reserve slots, same card cannot appear twice
        self.reserve: List[MonsterComponent] = []

        # Battle state
        self.phase: BattlePhase = BattlePhase.INIT
        self.current_wave: int = 0
        self.current_tick: int = 0
        self.current_time: float = 0.0
        self.combo_counter: int = 0

        # Team resources - skill orbs
        self.skill_points: int = 0  # Team skill orbs
        self.skill_points_max: int = 10  # Max skill orbs
        self.skill_points_timer: float = 0.0  # Timer for orb regen
        self._skill_tick_timer: float = 0.0  # Timer for the decoupled skill phase
        # 1 orb per skill_points_regen_cd seconds (game data says 10, but that is
        # the auto-battle throttle; observed world-boss income is ~1 per 5s)
        self.skill_points_regen_cd: float = self.config.skill_points_regen_cd

        # Overlay tracking (o: false abilities). The team and the helper are
        # tracked SEPARATELY because the game scopes the once-per-battle rule to
        # each side independently: a helper copy is never blocked by a team copy.
        # Observed in play -- Ninetails Fox on your team AND on the helper gives
        # +20% battle time, i.e. both copies land.
        # Entries are the ability id, or (ability_id, wave_num) for wave abilities
        # so those still fire once per wave rather than once per battle.
        self._team_overlay_abilities: set[object] = set()
        self._helper_overlay_abilities: set[object] = set()

        # Per-cast counter used to generate unique source_ids for stackable
        # attack-triggered overlay abilities (o=True). Keyed by
        # (caster.slot, ability.id, modifier_type) and incremented every
        # time such an ability applies a stat modifier. See
        # Ability._apply_single_effect for the consumer side.
        self._ability_cast_counter: dict[tuple[str, int, "ModifierType"], int] = {}

        # Per-cast counter for SKILL stat buffs. Skills always stack (unlike
        # abilities, which may refresh): each cast gets a unique source_id so
        # repeated casts accumulate. Keyed by (caster.slot, skill_id, type_name).
        self._skill_cast_counter: dict[tuple[str, int, str], int] = {}

        # World boss (None = the immortal DPS dummy, the historical default).
        # See worldboss.py; the driver is _boss_phase.
        self.boss: Optional["BossSpec"] = None
        self._boss_state = BossState.NORMAL
        self._boss_t_state: float = 0.0
        self._boss_cast_idx: int = 0
        self._boss_dmg_at_prepare: float = 0.0
        self._boss_rotation_base: float = 0.0
        self._boss_cast_busy: dict[int, bool] = {}

        # Managers
        self.ability_manager = AbilityManager()

        # Party card IDs for ability checks (mns field)
        # Includes both main team AND reserve cards
        self.party_card_ids: List[int] = []

        # Running player damage total — incremented on every player attack,
        # regardless of trace_enabled.  Used by MC scoring to avoid O(n)
        # event-list scan at the end of each battle iteration.
        self.player_damage_total: float = 0.0

        # Time limit tracking (additive stacking)
        self.time_limit_extension_pct: float = 0.0
        self.base_time_limit: float = self.config.time_limit
        # Wall-clock at which the current wave started, for per-wave `tl` budgets.
        self._wave_start_time: float = 0.0
        # Why the battle ended: "" while running / on victory, else "wiped",
        # "timeout" or "turn_limit". Lets callers tell a wipe from a slow clear.
        self.defeat_reason: str = ""

        # Event log for tracing
        self.events: List[BattleEvent] = []
        self.trace_enabled: bool = False

        # Per-unit skill-cast timeline {slot: [game_time, ...]}, populated only
        # when config.record_casts is True. Export maps slot -> card_id.
        self.skill_cast_log: Dict[str, List[float]] = {}
        # (apply_at, caster, targets, effect_str, level, proc_rate)
        self._pending_effects: List[tuple] = []
        # Per-slot stats captured at wave start (see start_wave). Trace-gated.
        self.opening_stats: Dict[str, Dict] = {}

        # Always-on: game time each slot last cast its skill. Cheap (one dict
        # write per cast); powers APL sync/offset vars (team.last_cast.<slot>.age).
        self._last_skill_cast: Dict[str, float] = {}

        # Debug: per-cast stat snapshot (populated when config.record_casts).
        # Each entry: time, slot, card_id, was_skill, effective_level, dmg_pct,
        # crit_dmg_pct, crit_rate, skill_dmg_pct, damage. Lets us inspect whether
        # buffs reach their expected magnitudes at cast time.
        self.cast_debug: List[dict] = []

        # Callbacks
        self.on_damage: Optional[Callable] = None
        self.on_death: Optional[Callable] = None
        self.on_wave_end: Optional[Callable] = None
        # Exact per-wave enemy rosters for a real level (levels.py). None = the
        # synthetic modes' flat `_enemy_pool` slicing.
        self._wave_models: Optional[List[List[MonsterModel]]] = None

        # Defense mode settings
        self.defense_mode: bool = False
        self.defense_target_priority: List[int] = (
            []
        )  # Role priority [1, 3, 2] = melee > healer > ranged
        self.defense_escalation_rate: float = 0.10  # +10% per interval
        self.defense_escalation_interval: int = 5  # Every N attacks
        self.defense_enemy_attack_count: int = 0  # Track enemy attacks for escalation

        # Combat bonuses
        self.race_team_bonus: float = (
            0.0  # CaucalRaceOverTeamBonus: DO NOT IMPLEMENT unless explicitly asked.
        )

    @property
    def effective_time_limit(self) -> float:
        """Battle time limit including TIME-ability extension (base × (1+ext%)).

        The single source of truth benchmark loops must break on, so time extends
        (e.g. Ninetails Fox) actually lengthen the scored window."""
        if self.base_time_limit > 0:
            return self.base_time_limit * (1.0 + self.time_limit_extension_pct / 100.0)
        return self.config.time_limit

    def set_battle_data(
        self,
        player_models: List[MonsterModel],
        enemy_models: List[MonsterModel],
        ability_data: Dict[str, dict],
        reserve_models: Optional[List[MonsterModel]] = None,
    ) -> None:
        """
        Initialize battle with teams.

        Install the teams, enemies and ability data for this battle.

        Args:
            player_models: Main team (5 slots, fight in combat)
            enemy_models: Enemy pool for wave spawning
            ability_data: Ability definitions
            reserve_models: Reserve team (2 slots, abilities only)
        """
        self.phase = BattlePhase.INIT

        # Create player units (including reserve)
        self.create_players(player_models, ability_data, reserve_models)

        # Benchmark mode: make active players unkillable.
        if self.config.immortal_players:
            for p in self.players:
                p.immortal = True

        # Store enemy models for wave spawning
        self._enemy_pool = enemy_models
        self._ability_data = ability_data

    def create_players(
        self,
        models: List[MonsterModel],
        ability_data: Dict[str, dict],
        reserve_models: Optional[List[MonsterModel]] = None,
    ) -> None:
        """
        Create player units from models, including reserve.

        Build the player-side units, mirroring the game's setup order.

        Two-phase initialization:
        1. Create all components (so party list is complete)
        2. Apply entry abilities (which may target other party members)

        Reserve cards:
        - Contribute passive abilities to main team
        - Do NOT participate in combat
        - Included in party_card_ids for mns ability checks
        """
        self.players = []
        self.reserve = []

        # Extract party card IDs for ability mns checks
        # Include BOTH main team AND reserve cards
        self.party_card_ids = [model.card_id for model in models]
        if reserve_models:
            self.party_card_ids.extend([model.card_id for model in reserve_models])

        # De-alias duplicate slots BEFORE resetting per-battle state.  CardPool
        # and AssistPool are caches keyed by card (and card+assist), so running
        # the same card twice — e.g. an active Hikoboshi plus the helper
        # Hikoboshi — hands both slots the SAME MonsterModel object.  Each unit
        # then applies its own LEVEL ability to that shared object, so the
        # bonuses double: Hikoboshi reached effective level 140 (90 +15 +10
        # twice) where the correct value is 115, inflating every duplicate-card
        # team.  Give each repeated slot its own shallow copy so per-unit
        # mutable state (effective_level) can't alias.  Only duplicates are
        # copied, so single-occurrence teams are untouched.
        seen_models: set[int] = set()

        def _dealias(model_list: List[MonsterModel]) -> List[MonsterModel]:
            out: List[MonsterModel] = []
            for model in model_list:
                if id(model) in seen_models:
                    model = copy.copy(model)
                seen_models.add(id(model))
                out.append(model)
            return out

        models = _dealias(models)
        if reserve_models:
            reserve_models = _dealias(reserve_models)

        # Reset per-battle mutable model state. LEVEL abilities (Sola, Hikoboshi,
        # Orihime) raise model.effective_level via _apply_level_bonus; because the
        # Monte-Carlo CardPool caches and REUSES the same MonsterModel objects
        # across battles, that bonus would otherwise accumulate (90 -> 105 -> 120
        # ...), inflating skill damage every evaluation. effective_level starts
        # == level and the LEVEL abilities re-apply fresh each battle, so snap it
        # back to the card's natural level here. (A 1-shot sim builds fresh models,
        # so it never hit this — the bug was garbage-in from model reuse.)
        for model in models:
            model.effective_level = model.level
        if reserve_models:
            for model in reserve_models:
                model.effective_level = model.level

        # Phase 1: Create all main team components
        for i, model in enumerate(models):
            component = MonsterComponent()
            component.slot = f"P{i + 1}"
            component.initialize(model, is_enemy=False)

            # Load skill
            if model.skill_id > 0:
                component.skill = get_skill(model.skill_id)

            # Load abilities (but don't apply yet)
            self.ability_manager.load_abilities_for_unit(component, ability_data)

            self.players.append(component)

        # Place the active team in the 3x2 formation. The helper is the 5th battle
        # slot by this codebase's convention, and it lands in 2 or 6.
        if self.config.use_formation:
            helper_index = 4 if len(self.players) >= 5 else None
            slots = formation.assign_positions(
                [p.model.unit_type if p.model else 1 for p in self.players],
                helper_index=helper_index,
            )
            for component, slot in zip(self.players, slots):
                component.position = slot

        # Phase 1b: Create reserve components
        # Reserve cards are created but marked - they don't fight
        if reserve_models:
            for i, model in enumerate(reserve_models):
                component = MonsterComponent()
                component.slot = f"R{i + 1}"  # R1, R2 for reserve
                component.initialize(model, is_enemy=False)
                component.is_reserve = True  # Mark as reserve

                # Reserve cards don't need skills (they don't attack)
                # But load their abilities - these apply to main team
                self.ability_manager.load_abilities_for_unit(component, ability_data)

                self.reserve.append(component)

        # Phase 1.5: Apply permanent setup abilities (LEVEL)
        # These modify base stats before ANY standard entry abilities or logic.
        # Mirrors TeamRepressBonusData.ApplyMonsterLevelBonus
        self.ability_manager.apply_setup_abilities(
            self.players, party_card_ids=self.party_card_ids, battle=self
        )
        if self.reserve:
            self.ability_manager.apply_setup_abilities(
                self.reserve, party_card_ids=self.party_card_ids, battle=self
            )

        # Phase 2: Apply entry abilities from main team
        for i, component in enumerate(self.players):
            is_leader = i == 0
            self.ability_manager.apply_entry_abilities(
                component,
                is_leader,
                party_card_ids=self.party_card_ids,
                party=self.players,  # Pass full party for target resolution
                battle=self,  # Pass battle for TIME abilities
            )

        # Phase 2b: Apply entry abilities from reserve cards
        # Reserve abilities apply to the main team, not to themselves
        for reserve_component in self.reserve:
            self.ability_manager.apply_reserve_abilities(
                reserve_component,
                party_card_ids=self.party_card_ids,
                party=self.players,  # Target main team, not reserve
                battle=self,  # Pass battle for TIME abilities
            )

    def create_enemies(
        self, models: List[MonsterModel], ability_data: Dict[str, dict]
    ) -> None:
        """
        Create enemy units from models.

        Build the enemy-side units, mirroring the game's setup order.
        """
        self.enemies = []

        # Apply wave scaling
        hp_scale = self.config.enemy_hp_scaling[
            min(self.current_wave, len(self.config.enemy_hp_scaling) - 1)
        ]

        for i, model in enumerate(models):
            component = MonsterComponent()
            component.slot = f"E{i + 1}"
            component.initialize(model, is_enemy=True)

            # Apply HP scaling
            if component.stat:
                component.stat.current_hp = int(component.stat.current_hp * hp_scale)

            self.ability_manager.load_abilities_for_unit(component, ability_data)
            self.ability_manager.apply_entry_abilities(component)

            self.enemies.append(component)

    def start_battle(self) -> None:
        """
        Start the battle.

        Mirrors Battle.StartBattle.
        """
        self.phase = BattlePhase.WAVE_START
        self.current_wave = 0
        # Reset per-battle state for buff tracking
        self._active_buffs: list = []
        self._applied_overlay_abilities: set = set()
        self.start_wave()

    def start_wave(self) -> None:
        """
        Start a new wave.

        Spawns enemies and applies wave-start abilities.
        """
        # Wave start: gain 1-3 random skill orbs (or a fixed count if configured,
        # e.g. world boss starts with 3).
        if self.config.starting_skill_points > 0 and self.current_wave == 0:
            wave_shards = self.config.starting_skill_points
        else:
            wave_shards = random.randint(1, 3)
        self.skill_points = min(self.skill_points + wave_shards, self.skill_points_max)
        self.skill_points_timer = 0.0  # Reset regen timer

        self._wave_start_time = self.current_time

        # Spawn enemies for this wave. Real levels (see levels.py) hand us the exact
        # roster per wave; the synthetic modes still slice a flat pool.
        wave_models = getattr(self, "_wave_models", None)
        if wave_models:
            wave_enemies = (
                wave_models[self.current_wave]
                if self.current_wave < len(wave_models)
                else []
            )
        else:
            enemy_count = self.config.enemies_per_wave[
                min(self.current_wave, len(self.config.enemies_per_wave) - 1)
            ]
            # Select enemies from pool (simple: take first N)
            wave_enemies = (
                self._enemy_pool[:enemy_count] if hasattr(self, "_enemy_pool") else []
            )
        if wave_enemies:
            self.create_enemies(wave_enemies, getattr(self, "_ability_data", {}))

        # Apply wave abilities
        # Pass wave_num to enable stacking (e.g., "+5% DMG per wave" accumulates)
        is_last_wave = self.current_wave == self.config.wave_count - 1

        # Apply wave abilities from main team
        for player in self.players:
            if player.is_alive:
                self.ability_manager.apply_wave_abilities(
                    player,
                    is_last_wave,
                    wave_num=self.current_wave,
                    party_card_ids=self.party_card_ids,
                    party=self.players,
                    enemies=self.enemies,
                    battle=self,
                )

        # Apply wave abilities from reserve cards to main team
        # Reserve cards don't attack but their passive abilities still apply
        # E.g., Cu Sith's +10% crit to Phantasma, Sabionari's +15% DMG to all
        for reserve_unit in self.reserve:
            self.ability_manager.apply_wave_abilities(
                reserve_unit,
                is_last_wave,
                wave_num=self.current_wave,
                party_card_ids=self.party_card_ids,
                party=self.players,  # Buffs target main team
                enemies=self.enemies,
                battle=self,
            )

        # Initialize attack timing for all units
        # Stagger first attacks to avoid all units attacking at t=0
        # This simulates the game's move-in animation and attack initialization
        for i, unit in enumerate(self.players):
            if unit.is_alive:
                # Stagger based on slot: first unit at t=0.5s, then 0.1s apart
                stagger = 0.5 + (i * 0.1)
                unit.next_attack_time = self.current_time + stagger
        for i, unit in enumerate(self.enemies):
            if unit.is_alive:
                # Enemies also stagger, starting slightly later
                stagger = 0.7 + (i * 0.1)
                unit.next_attack_time = self.current_time + stagger

        # Reset combo
        self.combo_counter = 0

        self.phase = BattlePhase.COMBAT

        # Snapshot every card AFTER entry/wave/reserve abilities have landed but
        # BEFORE anyone acts. This is the "what am I actually starting with" table --
        # level scaling, limit breaks, bonds, assists and passives all folded in, and
        # no combat buff yet. Trace-gated so the MC hot loop pays nothing.
        if self.trace_enabled or self.config.record_casts:
            self.opening_stats = {
                u.slot: self.stat_snapshot(u) for u in self.players if u.is_alive
            }

        self._log_event("wave_start", details={"wave": self.current_wave + 1})

    def simulate_tick(self) -> bool:
        """
        Simulate one tick of combat.

        Returns True if battle should continue, False if ended.
        """
        if self.phase != BattlePhase.COMBAT:
            return False

        self.current_tick += 1
        self.current_time += self.config.tick_rate

        # Land any skill effects whose application delay has elapsed. Before expiry,
        # so an effect landing this tick gets its full duration.
        if self._pending_effects:
            self._drain_pending_effects()

        # Expire buffs that have timed out
        self._expire_buffs()

        # Process debuffs (expiration and DoT damage)
        self._process_debuffs()

        # Regenerate skill orbs (1 per 5 seconds)
        self.skill_points_timer += self.config.tick_rate
        if self.skill_points_timer >= self.skill_points_regen_cd:
            self.skill_points_timer = 0.0
            if self.skill_points < self.skill_points_max:
                self.skill_points += 1

        # Decoupled skill phase: in the real game a cast is not tied to the attack
        # timer, so give everyone a cast opportunity on its own cadence.
        if self.config.skill_tick_rate > 0:
            self._skill_tick_timer += self.config.tick_rate
            if self._skill_tick_timer >= self.config.skill_tick_rate:
                self._skill_tick_timer = 0.0
                self._skill_phase()
                if self._check_wave_end():
                    return self._handle_wave_end()

        # World boss casts on a wall-clock schedule of its own, not on the
        # player orb economy, so it gets its own phase.
        if self.boss is not None:
            self._boss_phase()
            if self._check_wave_end():
                return self._handle_wave_end()

        # Get all living units sorted by speed (faster units act first)
        all_units = self._get_units_by_speed()

        for unit in all_units:
            if not unit.is_alive:
                continue

            # Update skill cost decay
            unit.update_cast_cost(
                self.config.tick_rate,
                self.config.skill_minus_cost_cd,
                self.current_time,
            )

            # Check if unit can act (attack or heal)
            if unit.can_attack(self.current_time):
                self._execute_turn(unit)

                # Check for wave/battle end
                if self._check_wave_end():
                    return self._handle_wave_end()

        if self.current_tick >= self.config.turn_limit:
            self._log_event("turn_limit_reached")
            self.phase = BattlePhase.DEFEAT  # Time/turn out = defeat
            self.defeat_reason = "turn_limit"
            return False

        # Check time limit (respects TIME-ability extension). Per-wave `tl` budgets
        # win when present, since that is what the game actually enforces.
        wave_limit = self._current_wave_time_limit()
        if wave_limit > 0:
            elapsed = self.current_time - self._wave_start_time
            if elapsed >= wave_limit:
                self._log_event(
                    "time_limit_reached",
                    details={"time": elapsed, "limit": wave_limit},
                )
                self.phase = BattlePhase.DEFEAT  # Time out = defeat
                self.defeat_reason = "timeout"
                return False
        elif self.base_time_limit > 0:
            current_limit = self.effective_time_limit
            if self.current_time >= current_limit:
                self._log_event(
                    "time_limit_reached",
                    details={"time": self.current_time, "limit": current_limit},
                )
                self.phase = BattlePhase.DEFEAT  # Time out = defeat
                self.defeat_reason = "timeout"
                return False

        return True

    def _current_wave_time_limit(self) -> float:
        """This wave's `tl` budget in seconds, scaled by TIME abilities. 0 = none."""
        limits = self.config.wave_time_limits
        if not limits:
            return 0.0
        tl = limits[min(self.current_wave, len(limits) - 1)]
        return tl * (1.0 + self.time_limit_extension_pct / 100.0)

    def simulate_wave(self) -> bool:
        """
        Simulate entire wave until completion.

        Returns True if players won, False if defeated.
        """
        while self.simulate_tick():
            pass

        return self.phase == BattlePhase.WAVE_END or self.phase == BattlePhase.VICTORY

    def run_until_time_limit(
        self,
        max_ticks: int,
        stop_when: "Optional[Callable[[Battle], bool]]" = None,
        after_tick: "Optional[Callable[[Battle], bool]]" = None,
    ) -> "Battle":
        """Tick until the effective time limit, or until ``stop_when`` says stop.

        Every timed mode needs this loop, and each hand-rolled copy had to
        remember one non-obvious rule: TIME abilities ("+10% battle time") raise
        ``time_limit_extension_pct``, NOT ``config.time_limit``. Reading the limit
        once before the loop silently discards the extension, so it must be
        re-read from ``effective_time_limit`` every tick. Three copies each
        rediscovered that; this is the one place it now lives.

        ``stop_when`` covers the part that legitimately differs between modes --
        a DPS benchmark stops on VICTORY/DEFEAT, a survival benchmark stops when
        the team wipes. ``after_tick`` is the same idea for checks that can only
        be made once a tick has happened (projecting a final score from the pace
        so far, to abandon hopeless candidates early).
        """
        for _ in range(max_ticks):
            if self.current_time >= self.effective_time_limit:
                break
            if stop_when is not None and stop_when(self):
                break
            self.simulate_tick()
            if after_tick is not None and after_tick(self):
                break
        return self

    def simulate_battle(self) -> bool:
        """
        Simulate entire battle (all waves).

        Returns True if players won, False if defeated.
        """
        self.start_battle()

        while self.phase not in (BattlePhase.VICTORY, BattlePhase.DEFEAT):
            self.simulate_wave()

            if self.phase == BattlePhase.WAVE_END:
                # Start next wave
                self.current_wave += 1
                if self.current_wave < self.config.wave_count:
                    self._recover_between_waves()
                    self.start_wave()
                else:
                    self.phase = BattlePhase.VICTORY

        return self.phase == BattlePhase.VICTORY

    def _get_units_by_speed(self) -> List[MonsterComponent]:
        """Get all units sorted by speed (descending)."""
        all_units = self.players + self.enemies
        return sorted(
            all_units,
            key=lambda u: u.stat.final_speed if u.stat else 0,
            reverse=True,
        )

    def _get_defense_target(
        self, targets: List[MonsterComponent]
    ) -> Optional[MonsterComponent]:
        """
        Get target based on defense mode priority.

        Priority list is role-based (e.g., [1, 3, 2] = melee > healer > ranged).
        Returns first available target matching highest priority role.
        """
        if not targets:
            return None

        for role in self.defense_target_priority:
            for target in targets:
                if target.model and target.model.unit_type == role:
                    return target

        # Fallback to first available
        return targets[0]

    def _get_target_by_role_priority(
        self, targets: List[MonsterComponent], priority: List[int] = None
    ) -> Optional[MonsterComponent]:
        """
        Get target based on role priority.

        Default priority: melee (1) > healer (3) > assist (4) > ranged (2)
        This matches observed game AI behavior where enemies prioritize frontline.

        Args:
            targets: List of potential targets
            priority: Role priority list, or DEFAULT_ROLE_PRIORITY if None

        Returns:
            Target matching highest priority role, or first available if none match
        """
        if not targets:
            return None

        if priority is None:
            priority = DEFAULT_ROLE_PRIORITY

        for role in priority:
            for target in targets:
                if target.model and target.model.unit_type == role:
                    return target

        # Fallback to first available
        return targets[0]

    def _get_defense_damage_multiplier(self) -> float:
        """
        Calculate damage multiplier based on enemy attack count.

        Damage increases by escalation_rate every escalation_interval attacks.
        """
        if not self.defense_mode:
            return 1.0

        escalations = (
            self.defense_enemy_attack_count // self.defense_escalation_interval
        )
        return 1.0 + (escalations * self.defense_escalation_rate)

    def _skill_phase(self) -> None:
        """Give every unit a chance to cast, independent of its attack turn.

        Reuses the normal cast path; `skill_only` makes it a no-op when the unit does
        not actually cast, so no auto attack is consumed and `next_attack_time` is
        untouched (it is set by _execute_turn, not here).
        """
        for unit in self._get_units_by_speed():
            # Only the conditions `_try_cast_skill` does NOT cover. Being
            # action-blocked is one of them: the ordinary attack path never
            # checks it, so dropping this would let a stunned unit cast.
            if not unit.is_alive or unit.skill is None:
                continue
            if unit.is_cast_blocked(self.current_time):
                continue
            if self._should_healer_heal(unit):
                self._execute_heal(unit, skill_only=True)
            else:
                self._execute_attack(unit, skill_only=True)

    # ------------------------------------------------------------------
    # World boss
    # ------------------------------------------------------------------

    def install_boss(self, boss: "BossSpec") -> None:
        """Put a real world boss in the enemy slot. Call after start_wave().

        The boss's flat defense is a stat modifier, so it can only be applied to
        a built unit -- same constraint as modes.apply_bench_target_defense.
        """
        self.boss = boss
        self._boss_state = BossState.NORMAL
        self._boss_t_state = 0.0
        self._boss_cast_idx = 0
        self._boss_dmg_at_prepare = 0.0
        self._boss_rotation_base = 0.0
        self._boss_cast_busy = {}

    def _boss_unit(self) -> Optional[MonsterComponent]:
        for e in self.enemies:
            if e.is_alive:
                return e
        return None

    def _boss_phase(self) -> None:
        """Advance the boss state machine and fire any scheduled cast.

        The boss does not use the player orb economy, so this is deliberately
        NOT routed through `_try_cast_skill`. Timing is fire-and-forget: the
        schedule is wall-clock, so a cast is never delayed by a previous one
        still resolving -- only by the boss being CC'd.
        """
        boss = self.boss
        unit = self._boss_unit()
        if boss is None or unit is None:
            return

        self._boss_t_state += self.config.tick_rate
        prev = self._boss_state
        state = next_boss_state(
            prev,
            self._boss_t_state,
            self.current_time,
            self.player_damage_total - self._boss_dmg_at_prepare,
            boss.timing,
        )
        if state != prev:
            self._boss_state = state
            self._boss_t_state = 0.0
            if state == BossState.CRAZY_PREPARE:
                # The interrupt check counts damage from the telegraph onward.
                self._boss_dmg_at_prepare = self.player_damage_total
            elif state == BossState.CRAZYING:
                # The boss goes down for wb_kill_skill_time: a free damage
                # window. Modelled as a real STUN so the auto-attack path
                # (can_attack -> is_action_blocked) stops it too.
                unit.apply_debuff(
                    DebuffType.STUN,
                    boss.timing.kill_skill_time,
                    self.current_time,
                    "wb_crazying",
                )
            if state in (BossState.CRAZY, BossState.KILL_ALL):
                # ks restarts from the top; the skill clock is not reset.
                self._boss_cast_idx = 0
                self._boss_rotation_base = self.current_time
                # Enrage damage buff: +wb_kill_skill_atk PERCENT onto the boss's
                # own damage modifier, permanently. Both enrage branches apply
                # it, which is why this sits under the shared arm.
                #
                # Without it bosses 2 and 4 are completely flat for the whole
                # fight -- their skill-5 slot is a self-cleanse, not the self-ATK
                # ramp bosses 1 and 3 carry -- so enrage changed nothing but cast
                # frequency. `ATK` is this engine's token for the DAMAGE modifier
                # (lifecycle.EFFECT_TO_MODIFIER), which is the bucket this lands
                # in. No duration field = permanent, which is what the game does.
                if boss.timing.kill_skill_atk:
                    self._apply_skill_effect(
                        unit,
                        [unit],
                        f"ATK<{boss.timing.kill_skill_atk:.2f}%,0%>",
                        boss.level,
                    )

        rotation = boss.rotation(self._boss_state)
        if not rotation or unit.is_action_blocked(self.current_time):
            return

        base = self._boss_rotation_base
        # Rotations wrap to index 0 at the end, so a fight longer than the 60s
        # timeline loops the same pattern.
        cycle = rotation[-1][0]
        loop = self._boss_cast_idx // len(rotation)
        due_at = base + loop * cycle + rotation[self._boss_cast_idx % len(rotation)][0]
        if self.current_time >= due_at:
            self._boss_cast(unit, rotation[self._boss_cast_idx % len(rotation)][1])
            self._boss_cast_idx += 1

    def _boss_select_targets(self, ts: str, count: int) -> List[MonsterComponent]:
        """Resolve a boss skill's `ts` against the living players."""
        living = [p for p in self.players if p.is_alive]
        if not living:
            return []

        _, prof_order = parse_target_spec(ts)
        if "max_atk" in ts or "min_hp" in ts or "max_hp" in ts:
            living = self.ability_manager._apply_target_filter(living, ts, living[0])
        elif prof_order:
            # prof<a,b,c> is a PRIORITY ORDER here, not a membership filter:
            # every boss row lists all three roles, so filtering on it selects
            # nothing at all. Rank by position in the list.
            #
            # Ties are broken RANDOMLY, not by slot. The sort is stable, so ranking
            # alone meant the lowest slot of the top-priority role was picked every
            # single cast: Hinoto's STONE (prof<2,3,1>) hit the same ranged card 16
            # times out of 16, and its NUMB (prof<3,2,1>) the same healer 10 out of
            # 10. In game the CC moves around the cards that share a role. Shuffling
            # first and then stable-sorting keeps the role priority exact while
            # spreading the pick across equals.
            rank = {t: i for i, t in enumerate(prof_order)}
            random.shuffle(living)
            living.sort(
                key=lambda u: rank.get(
                    u.model.unit_type if u.model else 0, len(prof_order)
                )
            )
        # No selector left = front-N, which is already slot order.
        return living[:count]

    def _boss_cast_suppressed(self, unit: MonsterComponent, skill) -> bool:
        """Is this boss cast dropped by a slow on the boss? See wb_slow_suppress_at.

        Mirrors the observed flag dance. Each skill id owns one attack-action
        object with one "currently casting" flag. A cast that lands sets it and
        (while slowed) nothing clears it; the NEXT cast of that same skill is
        dropped, and the drop itself releases the flag, so the one after that
        lands. Hence strict alternation PER SKILL ID -- and, because the flag has
        no timer, it holds no matter how far apart the casts are. Observed gaps of
        5s, 15s, 40s and 45s all alternated.
        """
        threshold = self.config.wb_slow_suppress_at
        # `target_count == 1` is a PROXY for "this skill plays a custom animation
        # instead of dealing its damage instantly". The real discriminator is the
        # cast->impact lag: the skill observed at 0.00s lag was never suppressed,
        # the two at 1.77s and 2.00s always were. Across all four bosses the
        # count<1> rows are exactly the big ATK 5500-6000 nukes and the
        # multi-target rows are the small 900-2000 swipes, so the proxy and the
        # real rule coincide everywhere we can check.
        # UNVALIDATED: the count<2> mid-size rows (boss 3 skill 4, boss 4 skills
        # 1-2). If any of those animates, this under-credits slow on those bosses.
        if threshold <= 0 or skill.target_count != 1 or skill.slv1 <= 0:
            return False

        busy = self._boss_cast_busy.get(skill.id, False)
        if busy:
            # A flag left set by an earlier cast stays set: nothing clears it except
            # this drop. Deliberately NOT conditional on the boss still being slowed
            # -- with an intermittent slow (a skill-applied one, or a cleansed one)
            # the window can lapse between the cast that stuck the flag and the cast
            # that pays for it, and the drop still happens.
            self._boss_cast_busy[skill.id] = False
            return True

        # This cast lands. Strictly, whether it leaves the flag stuck depends on the
        # boss being slowed when the CLIP ENDS, not right now -- the clear is pinned
        # to the last instant of the animation. Checking at cast time is a DELIBERATE
        # simplification, not an oversight: for the slows that matter it is exact.
        # 690's is permanent, and 725's nominal 8s is refreshed by every normal attack
        # (autos land every ~2-2.5s), so both are continuously present and the two
        # moments coincide. Only a bare cast-driven 8s skill slow (e.g. 1526) can have
        # its window end inside a clip, and the clip length is unmeasured anyway, so
        # there is nothing better to check against. Revisit only if a capture ever
        # pins the clip length.
        spd_pct = unit.stat.speed_modifier.get_modifier_total() - 1.0
        if spd_pct > -threshold:
            return False
        # NOT a 50% chance. While slowed the completion event never fires AT ALL, so
        # this landed cast leaves the flag set; the next cast of that skill is dropped
        # and clears it. Alternation is a consequence of a 100% failure, which is why
        # it is exact and gap-free.
        self._boss_cast_busy[skill.id] = True
        return False

    def _boss_cast(self, unit: MonsterComponent, skill_id: int) -> None:
        """Fire one boss skill: damage, then its `de` payload."""
        boss = self.boss
        if boss is None:
            return
        skill = boss.skills.get(skill_id)
        if skill is None:  # unknown id -> skipped, pattern continues
            return

        if self._boss_cast_suppressed(unit, skill):
            # Issued on schedule, but no AttackAction is ever created: no targets,
            # no damage, no `de` payload. The rotation index has already advanced.
            self._log_event("boss_cast_suppressed", attacker=unit.slot, was_skill=True)
            return

        level = boss.level
        # calculate_action_damage and _apply_skill_effect both read caster.skill.
        # Set it only for the duration of the cast: a persistent .skill would put
        # the boss into the player orb economy via _skill_phase.
        prev_skill = unit.skill
        unit.skill = skill
        try:
            if skill.target_type == "self":
                if skill_id in boss.cleanse_skills:
                    # ERASE_DEBUFF. Measured 2026-09-09 (live, boss 2):
                    #   TIMED debuffs from a SKILL are stripped -- a SHIELD -20%
                    #     with 8s duration was killed 3.3s in, twice, losing 59%
                    #     of its window.
                    #   PERMANENT debuffs from an ABILITY survive -- card 661's
                    #     ATK -30% / SHIELD -30% were still reducing boss damage
                    #     at the end of a full fight.
                    # `_active_buffs` is exactly that split: `_track_buff` returns
                    # early for duration <= 0, so permanent modifiers are never in
                    # it. Cleansing it reproduces the observed behaviour.
                    unit.active_debuffs.clear()
                    self._cleanse_timed_modifiers(unit)
                    unit.state = UnitState.IDLE
                for effect_str in skill.debuff_effects:
                    self._apply_skill_effect(unit, [unit], effect_str, level)
                self._log_event("boss_cast", attacker=unit.slot, was_skill=True)
                return

            targets = self._boss_select_targets(
                skill.target_selector, skill.target_count
            )
            if not targets:
                return

            if skill.slv1 > 0:
                for target in targets:
                    dmg = self.calculate_action_damage(unit, target, is_skill=True)
                    died = target.take_damage(dmg.final_damage, attacker=unit)
                    target.evaluate_conditionals()
                    self._log_event(
                        "attack",
                        attacker=unit.slot,
                        target=target.slot,
                        damage=dmg.final_damage,
                        was_skill=True,
                    )
                    if died:
                        self._log_event("death", target=target.slot)
                        if self.on_death:
                            self.on_death(target)

            if skill.debuff_effects:
                proc = self._extract_hit_proc_rate(skill.debuff_effects, level)
                alive = [t for t in targets if t.is_alive]
                for effect_str in skill.debuff_effects:
                    self._apply_skill_effect(
                        unit, alive, effect_str, level, proc_rate=proc
                    )
        finally:
            unit.skill = prev_skill

    def _try_cast_skill(
        self, unit: MonsterComponent, target: Optional[MonsterComponent]
    ) -> bool:
        """Decide whether `unit` casts, and if so charge for it. Returns the verdict.

        THE single skill-cast gate. `_execute_attack` and `_execute_heal` used to
        each own a copy of this four-condition test plus the four-line commit
        (deduct orbs, escalate cast cost, stamp `_last_skill_cast`, append to
        `skill_cast_log`), and they had already drifted apart in what they passed
        to `should_cast`. Two copies of an orb-economy transaction is how you get
        a cast that is logged but not charged.

        `target` is what the APL sees as the enemy for its damage/overcap terms.
        The heal path passes the first living enemy, which is `None` in a fight
        with no living enemies -- preserved here rather than fixed, because this
        extraction is meant to be behaviour-preserving. `apl/state.py` already
        tolerates a `None` enemy; changing it is a separate, scoreable decision.
        """
        if not unit.auto_cast_skill or not unit.can_cast_skill():
            return False
        if self.skill_points < unit.need_cast_point:
            return False
        if not get_engine().should_cast(unit, self, target):
            return False

        cost = int(unit.need_cast_point)
        self.skill_points -= unit.need_cast_point
        unit.add_cast_cost()
        self._last_skill_cast[unit.slot] = self.current_time
        if self.config.record_casts:
            self.skill_cast_log.setdefault(unit.slot, []).append(self.current_time)
        # Trace only. Logged HERE rather than on the attack path because a healer's
        # cast goes out through `_execute_heal` and produces no attack event at all --
        # deriving casts from attack events silently loses every healer cast.
        self._log_event(
            "cast",
            attacker=unit.slot,
            was_skill=True,
            details={"cost": cost, "orbs_left": int(self.skill_points)},
        )
        return True

    def _execute_turn(self, unit: MonsterComponent) -> None:
        """
        Execute a unit's turn action.

        This is the main turn handler that decides what action to take:
        - Healers: Heal most injured ally if any ally is damaged, otherwise attack
        - Other units: Attack enemies

        After action, schedules the next attack time based on speed.
        """
        # Check if healer should heal instead of attack
        if self._should_healer_heal(unit):
            self._execute_heal(unit)
        else:
            self._execute_attack(unit)

        unit.next_attack_time = self.current_time + unit.get_attack_interval()

    def _should_healer_heal(self, unit: MonsterComponent) -> bool:
        """
        Check if a healer unit should heal instead of attack.

        Healers heal the most injured ally when any ally is damaged.
        If all allies are at full HP, they attack instead.

        Unit types from game data:
        - 1 = Melee
        - 2 = Ranged
        - 3 = Healer
        - 4 = Support
        """
        if unit.model is None:
            return False

        # Check if unit is a healer (type 3)
        if unit.model.unit_type != 3:
            return False

        # Find allies (same side)
        allies = self.players if not unit.is_enemy else self.enemies

        # Check if any ally is injured (HP < max HP)
        for ally in allies:
            if ally.is_alive and ally.stat:
                max_hp = int(ally.stat.hp_modifier.final_value)
                if ally.stat.current_hp < max_hp:
                    return True

        return False

    def _find_most_injured_ally(
        self, unit: MonsterComponent
    ) -> Optional[MonsterComponent]:
        """
        Find the ally with the lowest HP percentage.

        Returns None if no allies need healing.
        """
        allies = self.players if not unit.is_enemy else self.enemies

        most_injured = None
        lowest_hp_pct = 1.0

        for ally in allies:
            if ally.is_alive and ally.stat:
                max_hp = int(ally.stat.hp_modifier.final_value)
                if max_hp > 0:
                    hp_pct = ally.stat.current_hp / max_hp
                    if hp_pct < lowest_hp_pct:
                        lowest_hp_pct = hp_pct
                        most_injured = ally

        return most_injured

    def _execute_heal(self, healer: MonsterComponent, skill_only: bool = False) -> None:
        """
        Execute a heal action for a healer unit.

        Heals ally based on healer's ATK or skill targeting.
        - Normal heal: targets most injured ally
        - Skill heal: uses skill's target_filter from skills.json (e.g., max_atk)

        Heal formula Observed in game:
        - Base heal = ATK * Heal_attack_x (90%) + ATK * Heal_attack_y (20%)
        - Simplified: heal = ATK * 1.1 (110% of ATK)

        Constants from server config:
        - Heal_attack_x = 90
        - Heal_attack_y = 20
        """
        if healer.stat is None:
            return

        # Check for skill cast FIRST (determines targeting). Healers with a buff
        # skill (heal + buff, e.g. Sola) are routed through the APL just like
        # attackers — we treat any buff skill as a buff skill (the heal is
        # irrelevant under immortal-benchmark scoring). should_cast projects
        # against an enemy for damage/overcap terms.
        enemy_target = next((e for e in self.enemies if e.is_alive), None)
        is_skill = self._try_cast_skill(healer, enemy_target)

        if skill_only and not is_skill:
            # Skill phase and no cast -> do nothing, so the healer does not get a free
            # extra heal-tick outside its normal turn.
            return

        # Determine target based on skill or normal heal
        if is_skill and healer.skill:
            # Skill heal: use skill's targeting logic from skills.json
            candidates = [p for p in self.players if p.is_alive]
            if healer.skill.target_filter:
                candidates = self.ability_manager._apply_target_filter(
                    candidates, healer.skill.target_filter, healer
                )
            target = candidates[0] if candidates else None
        else:
            # Normal heal: target most injured ally
            target = self._find_most_injured_ally(healer)

        if target is None or target.stat is None:
            # No one to heal. The cast has ALREADY been charged and logged by
            # `_try_cast_skill` above, so its effects must still land -- returning here
            # without applying them spends an orb on nothing.
            if is_skill and healer.skill:
                if healer.skill.has_buff_effects or healer.skill.has_debuff_effects:
                    self._apply_skill_effects(healer, healer)
                self.ability_manager.apply_attack_abilities(
                    healer, True, [healer], self, party_card_ids=self.party_card_ids
                )
                return
            self._execute_attack(healer)
            return

        # Skill effects are applied AFTER the heal below, matching the damage path:
        # a cast does not benefit from the effects it applies. The heal amount itself
        # is not ATK-scaled for skills, so this rarely changes the heal -- but the
        # buffs a healer-skill hands out (e.g. Sola, Ameno Uzume) must not retroactively
        # boost the cast that granted them.

        # Calculate heal amount
        # Formula: ATK * 0.9 + ATK * 0.2 = ATK * 1.1
        # Skills use slv1 + (level-1) * slvup for heal value
        if is_skill and healer.skill and healer.model:
            # Skill heal amount from skill data
            heal_amount = healer.skill.calculate_damage(healer.model.effective_level)
        else:
            # Normal heal: ATK * 1.1
            heal_amount = int(healer.stat.base_atk * 1.1)

        # Apply heal
        max_hp = int(target.stat.hp_modifier.final_value)
        old_hp = target.stat.current_hp
        target.stat.current_hp = min(target.stat.current_hp + heal_amount, max_hp)
        actual_heal = target.stat.current_hp - old_hp

        # Skill effects land now, after the heal. See the note above the heal
        # calculation.
        #
        # `has_debuff_effects` belongs here as much as `has_buff_effects`: a healer's
        # buff often lives in the skill's `de` field, not `ie` -- Campanella is
        # `ie='none'`, `de='CHIT<13.80%,0.47%,8>'` -- and `_apply_skill_effects` routes
        # a buff skill's `de` to ALLIES. Testing only `has_buff_effects` meant such a
        # cast paid its orb, logged, and then did NOTHING whenever the skill phase
        # happened to route the healer here instead of down the attack path. Measured
        # on a world-boss team: 9 of Campanella's 16 casts applied no crit buff at all,
        # which dropped the carries out of guaranteed crit and cost ~800k per affected
        # nuke. The attack path has always tested both.
        if (
            is_skill
            and healer.skill
            and (healer.skill.has_buff_effects or healer.skill.has_debuff_effects)
        ):
            self._apply_skill_effects(healer, target)

        # Apply attack_skill abilities (like Senji's +crit to skill targets)
        if is_skill:
            self.ability_manager.apply_attack_abilities(
                healer, is_skill, [target], self, party_card_ids=self.party_card_ids
            )

        # Energy gain (Action gives energy even if healing)
        if healer.stat:
            healer.add_energy(15)

        # Log event
        self._log_event(
            "heal",
            attacker=healer.slot,
            target=target.slot,
            damage=actual_heal,  # Using damage field for heal amount
            was_skill=is_skill,
            details={
                "heal_amount": heal_amount,
                "actual_heal": actual_heal,
                "target_hp": target.stat.current_hp,
                "target_max_hp": max_hp,
                "was_skill": is_skill,
            },
        )

    def _execute_attack(
        self, attacker: MonsterComponent, skill_only: bool = False
    ) -> None:
        """Execute an attack for a unit."""
        # Find target using role-based priority
        if attacker.is_enemy:
            targets = [p for p in self.players if p.is_alive]
            # The frontline is what the enemy can actually reach. Without this the
            # role priority walks every enemy past the front column onto a backline
            # healer, which wipes teams the real game does not.
            if self.config.use_formation:
                targets = formation.reachable(targets)
            # Defense mode: use custom priority if set, otherwise default role priority
            if self.defense_mode and self.defense_target_priority:
                target = self._get_defense_target(targets)
            else:
                target = self._get_target_by_role_priority(targets)
        else:
            targets = [e for e in self.enemies if e.is_alive]
            # Player attacks also use role priority (target melee > healer > assist > ranged)
            target = self._get_target_by_role_priority(targets)

        if not target:
            return

        # Check for skill
        skill_targets = [target]  # Default to the enemy being attacked
        is_skill = self._try_cast_skill(attacker, target)
        if not is_skill and skill_only:
            # Skill phase and no cast -> do nothing. Falling through would hand the
            # unit a free extra auto attack every skill tick.
            return

        # A skill only deals damage when its `ie` has an ATK head. 438 of the 996
        # skills in the game have no ATK head (290 `none`, 148 `HEAL`), and the engine
        # used to hit for slv1 + (level-1)*slvup on every cast regardless -- inventing
        # damage for every pure buff and every heal. Orihime is the clean case:
        # ie='none', ts='self;count<2>;max_atk', so her targeting selects ALLIES; the
        # phantom hit would have landed on her own team if the game did not gate it.
        is_skill_damage = is_skill
        if is_skill and attacker.skill and not attacker.skill.deals_damage:
            if skill_only:
                # Skill phase: the cast happens, the effects land, nothing is hit.
                if attacker.skill.has_buff_effects or attacker.skill.has_debuff_effects:
                    skill_targets = self._apply_skill_effects(attacker, target)
                # On-skill abilities still fire -- the cast happened.
                self.ability_manager.apply_attack_abilities(
                    attacker,
                    True,
                    skill_targets,
                    self,
                    party_card_ids=self.party_card_ids,
                )
                return
            # Attack turn: the support cast rides along, but the swing is an ordinary
            # auto. Effects still land AFTER the damage below, so the caster's own hit
            # does not benefit from the buff it just applied.
            is_skill_damage = False

        # NOTE: skill effects are applied AFTER the damage below, not here.
        # A cast does NOT benefit from the amplification it applies.
        #
        # Measured 2026-08-25 with Shuten Doji 3rd anniv. (740, skill lv 35), whose
        # skill deals damage AND applies SHIELD -25 - 0.72/lv to the target:
        #   seq=174  740's own cast   -> shield x1.15     (baseline only)
        #   seq=201  a hit 7.78s later -> shield x1.6448  (baseline + the -49.48 debuff)
        # Both on the same target, inside the 8s debuff window. The delta of -49.48
        # matches -25 + (-0.72 * 34) exactly, so the debuff demonstrably lands after
        # the casting hit is resolved.
        #
        # This used to run before calculate_action_damage, which handed the cast its
        # own amp -- worth up to +43% on that hit and enough to push a predicted
        # world-boss nuke to the 999,999 cap that the real game never reaches.

        damage_result = self.calculate_action_damage(attacker, target, is_skill_damage)

        # Apply defense mode escalation for enemy attacks
        final_damage = damage_result.final_damage
        if attacker.is_enemy and self.defense_mode:
            self.defense_enemy_attack_count += 1
            escalation_mult = self._get_defense_damage_multiplier()
            final_damage = int(damage_result.final_damage * escalation_mult)

        # Apply damage (pass attacker for REVENGE counter-attack)
        died = target.take_damage(final_damage, attacker=attacker)

        # Skill effects land now -- after this cast's damage has been resolved, so they
        # only affect subsequent hits. See the note above the damage calculation.
        if (
            is_skill
            and attacker.skill
            and (attacker.skill.has_buff_effects or attacker.skill.has_debuff_effects)
        ):
            # Capture actual targets (may be allies for buff skills)
            skill_targets = self._apply_skill_effects(attacker, target)

        # Debug: snapshot the caster's stat state at this cast (buffs currently
        # applied) so we can compare to the calculator's expected magnitudes.
        if self.config.record_casts and not attacker.is_enemy and attacker.stat:
            st = attacker.stat
            self.cast_debug.append(
                {
                    "time": round(self.current_time, 1),
                    "slot": attacker.slot,
                    "card_id": attacker.model.card_id if attacker.model else None,
                    "was_skill": is_skill,
                    "effective_level": (
                        attacker.model.effective_level if attacker.model else None
                    ),
                    "dmg_pct": round(st.damage_modifier.get_percentage_sum(), 1),
                    "crit_dmg_pct": round(st.crit_dmg_modifier.get_percentage_sum(), 1),
                    "crit_rate": round(st.final_crit, 3),
                    "skill_dmg_pct": round(
                        st.skill_dmg_modifier.get_percentage_sum(), 1
                    ),
                    "damage": final_damage,
                }
            )

        # Re-evaluate conditional effects after HP changes
        target.evaluate_conditionals()
        attacker.evaluate_conditionals()  # May have taken REVENGE counter damage

        # Apply lifesteal (VAMP) - applies to both normal attacks and skills
        if attacker.stat and attacker.stat.vamp_percent > 0:
            heal_amount = int(damage_result.final_damage * attacker.stat.vamp_percent)
            if heal_amount > 0:
                max_hp = int(attacker.stat.hp_modifier.final_value)
                old_hp = attacker.stat.current_hp
                attacker.stat.current_hp = min(
                    attacker.stat.current_hp + heal_amount, max_hp
                )
                actual_heal = attacker.stat.current_hp - old_hp
                if actual_heal > 0:
                    self._log_event(
                        "lifesteal",
                        attacker=attacker.slot,
                        details={
                            "damage": damage_result.final_damage,
                            "vamp_percent": attacker.stat.vamp_percent,
                            "heal": actual_heal,
                        },
                    )
                    # Re-evaluate after lifesteal healing
                    attacker.evaluate_conditionals()

        # Energy gain
        if attacker.stat and target.stat:
            energy = self._calculate_damage_energy(
                damage_result.final_damage,
                target.stat.current_hp + damage_result.final_damage,
            )
            attacker.add_energy(energy)

        # Update combo
        if not attacker.is_enemy:
            self.combo_counter += 1

        # Apply attack abilities (using skill targets if it was a skill)
        self.ability_manager.apply_attack_abilities(
            attacker, is_skill, skill_targets, self, party_card_ids=self.party_card_ids
        )

        # Accumulate player damage for fast MC scoring (no event-list scan needed)
        if not attacker.is_enemy:
            self.player_damage_total += final_damage

        # Log event
        self._log_event(
            "attack",
            attacker=attacker.slot,
            target=target.slot,
            damage=final_damage,
            crit_type=damage_result.crit_mult > 1.0
            and CritType.NORMAL
            or CritType.NONE,
            # `is_skill_damage`, not `is_skill`: a support cast riding along on an
            # attack turn still swings as an ordinary auto, and labelling that hit as
            # a skill made Orihime -- whose skill is `ie='none'` and deals no damage at
            # all -- report "skill 2x 9.2K". The cast is still a cast for abilities and
            # effects below; only the HIT is an auto.
            was_skill=is_skill_damage,
            combo=self.combo_counter,
            details={
                "base": damage_result.base_damage,
                "exceed": damage_result.exceed_mult,
                "combo": damage_result.combo_mult,
                "mods": damage_result.modifier_mult,
                "crit": damage_result.crit_mult,
                "shield": damage_result.shield_mult,
            },
        )

        # Handle death
        if died:
            self._log_event("death", target=target.slot)
            if not attacker.is_enemy:
                # Killing bonus: +1 full team skill orb
                self._add_team_energy(1)
            if self.on_death:
                self.on_death(target)

    def _add_team_energy(self, amount: int) -> None:
        """Add full skill orbs to the team pool."""
        self.skill_points = min(self.skill_points + amount, self.skill_points_max)

    def _add_team_energy_shards(self, shards: int) -> None:
        """Deprecated: Dealing damage no longer generates orbs."""
        pass

        if self.on_damage:
            self.on_damage(attacker, target, damage_result)

    def calculate_action_damage(
        self,
        attacker: MonsterComponent,
        target: MonsterComponent,
        is_skill: bool = False,
        force_crit: Optional[bool] = None,
    ) -> DamageResult:
        """
        Calculate damage for an attack.

        The observed damage pipeline, in order:
        1. Base damage = ATK × 1.0
        2. Exceed (LB bonus)
        3. Combo bonus
        4. Modifiers (damage + skill/normal)
        5. Crit check and multiplier
        6. Shield reduction
        7. Clamp to caps
        """
        result = DamageResult()

        if attacker.stat is None or target.stat is None:
            return result

        # 1. Base damage
        if is_skill and attacker.skill is not None and attacker.model is not None:
            # Skill damage = slv1 + (cardLevel - 1) * slvup (matches description value)
            # Skill bond is multiplicative on skill base (like ATK bond on ATK stat)
            result.base_damage = (
                float(attacker.skill.calculate_damage(attacker.model.effective_level))
                * attacker.stat.skill_bond_mult
            )
        else:
            # Normal attack uses ATK stat
            result.base_damage = float(attacker.stat.base_atk)

        # 2. Exceed (LB bonus)
        if attacker.model and attacker.model.lb_level > 0:
            result.after_exceed, result.exceed_mult = attacker.calculate_exceed_value(
                result.base_damage
            )
            result.exceed_mult = result.after_exceed / result.base_damage
        else:
            result.after_exceed = result.base_damage
            result.exceed_mult = 1.0

        # 3. Combo bonus - DISPROVEN (2026-01-16)
        # Combo is purely cosmetic. The counter is kept for UI purposes only.
        # All combo_bonus values are 0, so combo_mult is always 1.0
        combo = min(self.combo_counter + 1, 5)  # Cap at 5 (cosmetic only)
        result.combo_mult = 1.0 + self.config.combo_bonus.get(combo, 0.0)  # Always 1.0
        result.after_combo = result.after_exceed * result.combo_mult

        # 4. Damage Modifiers (General ATK buff)
        # Applied to both normal and skill attacks
        result.modifier_mult = attacker.stat.damage_modifier.get_modifier_total()
        result.after_modifiers = result.after_combo * result.modifier_mult

        # 5. Crit check and Crit Multiplier
        # force_crit != None => deterministic projection (no RNG), used by the
        # APL overcap check. force_crit is None => normal RNG battle path.
        if force_crit is None:
            crit_rate = min(attacker.stat.final_crit, self.config.crit_max)
            is_crit = random.random() < crit_rate
        else:
            is_crit = force_crit

        if is_crit:
            result.crit_mult = 2.0  # Base Crit Multiplier
            # Crit damage bonus applies to the ALREADY-DOUBLED number and is
            # multiplicative, not additive: (damage × 2.0) × (1 + pct_sum/100).
            # So a +110% crit-damage buff gives 2.0 × 2.1 = 4.2x, not 3.1x.
            crit_dmg_sum = attacker.stat.crit_dmg_modifier.get_percentage_sum()
            result.crit_dmg_mult = crit_dmg_sum / 100.0

            # crit_mult=2.0, bonus=(1 + pct/100): e.g. 2.0 × (1+1.1) = 4.2× not 3.1×
            final_crit_mult = result.crit_mult * (1.0 + result.crit_dmg_mult)
            result.after_crit = result.after_modifiers * final_crit_mult
        else:
            result.crit_mult = 1.0
            result.crit_dmg_mult = 0.0
            result.after_crit = result.after_modifiers

        # 6. Type-Specific Modifiers (Multiplicative with previous steps)
        if is_skill:
            # Skill Damage bonus
            result.skill_dmg_mult = (
                attacker.stat.skill_dmg_modifier.get_modifier_total()
            )
            result.after_type_mod = result.after_crit * result.skill_dmg_mult
        else:
            # Normal Attack bonus
            result.normal_dmg_mult = (
                attacker.stat.normal_dmg_modifier.get_modifier_total()
            )
            result.after_type_mod = result.after_crit * result.normal_dmg_mult

        # 7. Target Multipliers (Multiplicative between buckets)
        # BUGFIX (2026-04-26): Clamp shield/defense and use correct type_mod base.
        # Shield reduction. Range: [-75%, 85%] per shield_min/shield_max constants.
        # The game's own shield-limit check guards ally shield APPLICATION, not
        # this damage path, which is why the clamp is applied here instead.
        target_shield_pct = target.stat.shield_modifier.get_percentage_sum()
        clamped_shield = max(-75.0, min(85.0, target_shield_pct)) / 100.0
        result.shield_mult = 1.0 - clamped_shield
        result.after_shield = result.after_type_mod * result.shield_mult

        # Defense is a FLAT SUBTRACTION applied last, not a percentage.
        # Measured in play 2026-08-25 (n=207 world-boss hits): a hit went in at
        # 4024.663 and came out at 3524.663 -- exactly -500 -- and across the whole
        # run the only distinct (in - out) values were {500.0, 0.0}. A percentage
        # would have spread across the damage range; a flat cost does not.
        # Because it is flat and applied last it does NOT scale with damage: it
        # hurts small hits hard and is negligible on large ones, and shield/defense
        # are therefore no longer commutative.
        target_def_flat = target.stat.defense_modifier.get_percentage_sum()
        result.after_defense = result.after_shield - target_def_flat
        # Kept for the breakdown/reporting surface, which expects a multiplier.
        result.defense_mult = (
            (result.after_defense / result.after_shield) if result.after_shield else 1.0
        )

        # 8. Clamp to Caps
        cap = self.config.skill_damage_cap if is_skill else self.config.damage_cap
        result.final_damage = max(1, min(int(result.after_defense), cap))
        result.was_capped = result.final_damage == cap
        if result.was_capped:
            result.cap_applied = cap

        # Trigger callback (skip in projection mode to keep it side-effect-free)
        if self.on_damage and force_crit is None:
            self.on_damage(attacker, target, result)

        return result

    def _calculate_damage_energy(self, damage: int, target_hp: int) -> int:
        """
        Calculate energy gain from damage.

        Observed in game (CalculateDamageEnergy):
        energy = clamp((damage / targetHP) * 10, 5, 18)
        """
        if target_hp <= 0:
            return self.config.skill_energy_max

        ratio = damage / target_hp
        energy = int(ratio * self.config.skill_energy_damage_mult)

        return max(
            self.config.skill_energy_min,
            min(energy, self.config.skill_energy_max),
        )

    def _apply_skill_effects(
        self, caster: MonsterComponent, damage_target: Optional[MonsterComponent] = None
    ) -> List[MonsterComponent]:
        """
        Apply skill effects to appropriate targets.
        Returns the list of targets the effects were applied to.
        """
        if caster.skill is None or caster.model is None:
            return []

        skill = caster.skill
        level = caster.model.effective_level  # skill-effect magnitudes scale with level
        all_targets = []

        # Apply buff effects from 'ie' field to allies
        if skill.buff_effects:
            if skill.is_buff_skill:
                # Buff skill targets allies
                candidates = [p for p in self.players if p.is_alive]
                if skill.target_filter:
                    candidates = self.ability_manager._apply_target_filter(
                        candidates, skill.target_filter, caster
                    )
                buff_targets = candidates[: skill.target_count]
            else:
                # Damage skill with buff component - applies to self
                buff_targets = [caster]

            for effect_str in skill.buff_effects:
                self._defer_skill_effect(caster, buff_targets, effect_str, level)
            all_targets.extend(buff_targets)

        # Handle 'de' field effects based on skill type
        if skill.debuff_effects:
            # Extract HIT proc rate from effects (if present)
            # HIT can appear before or after the debuff it modifies
            proc_rate = self._extract_hit_proc_rate(skill.debuff_effects, level)

            if skill.is_buff_skill:
                # BUFF SKILL: 'de' field contains buffs to apply to ALLIES
                candidates = [p for p in self.players if p.is_alive]
                if skill.target_filter:
                    candidates = self.ability_manager._apply_target_filter(
                        candidates, skill.target_filter, caster
                    )
                buff_targets = candidates[: skill.target_count]
                for effect_str in skill.debuff_effects:
                    self._defer_skill_effect(caster, buff_targets, effect_str, level)
                all_targets.extend(buff_targets)
            elif damage_target is not None:
                # DAMAGE SKILL: 'de' field contains debuffs for enemy target
                debuff_targets = [damage_target]
                for effect_str in skill.debuff_effects:
                    self._defer_skill_effect(
                        caster, debuff_targets, effect_str, level, proc_rate=proc_rate
                    )
                all_targets.extend(debuff_targets)

        unique_targets = []
        for t in all_targets:
            if t not in unique_targets:
                unique_targets.append(t)
        return unique_targets

    def _extract_hit_proc_rate(self, effects: List[str], level: int) -> float:
        """
        Extract HIT proc rate from effect list.

        HIT<base%,scale%> specifies proc chance for adjacent debuffs.
        Returns proc rate as decimal (0.0-1.0), or 1.0 if no HIT found.
        """
        import re

        for effect_str in effects:
            if effect_str.startswith("HIT<"):
                match = re.match(r"HIT<(-?[\d.]+)%?,(-?[\d.]+)%?>", effect_str)
                if match:
                    base = float(match.group(1))
                    scale = float(match.group(2))
                    total_rate = base + scale * (level - 1)
                    return min(total_rate / 100.0, 1.0)  # Cap at 100%

        return 1.0  # No HIT = always applies

    def _apply_skill_buffs(self, caster: MonsterComponent) -> None:
        """Deprecated: Use _apply_skill_effects instead."""
        self._apply_skill_effects(caster, None)

    def _defer_skill_effect(
        self,
        caster: MonsterComponent,
        targets: List[MonsterComponent],
        effect_str: str,
        level: int,
        proc_rate: float = 1.0,
    ) -> None:
        """Apply now, or queue for ``config.skill_effect_delay`` seconds from now.

        TARGETS ARE RESOLVED NOW and only the application waits -- the game picks who
        a skill hits at cast time, and deferring selection too would let a `max_atk`
        ranked buff re-aim itself at whoever the intervening casts left on top.

        Returned `skill_targets` are likewise unchanged, so on-skill abilities still
        fire against the cast's real targets at the moment of the cast.
        """
        if self.config.skill_effect_delay <= 0:
            self._apply_skill_effect(caster, targets, effect_str, level, proc_rate)
            return
        self._pending_effects.append(
            (
                self.current_time + self.config.skill_effect_delay,
                caster,
                list(targets),
                effect_str,
                level,
                proc_rate,
            )
        )

    def _drain_pending_effects(self) -> None:
        """Land every queued effect whose time has come, in the order cast."""
        now = self.current_time
        due = [e for e in self._pending_effects if e[0] <= now]
        if not due:
            return
        self._pending_effects = [e for e in self._pending_effects if e[0] > now]
        for _at, caster, targets, effect_str, level, proc_rate in due:
            # A target that died while the effect was in flight is skipped; the
            # caster dying does not cancel it, the cast already happened.
            live = [t for t in targets if t.is_alive]
            if live:
                self._apply_skill_effect(caster, live, effect_str, level, proc_rate)

    def _apply_skill_effect(
        self,
        caster: MonsterComponent,
        targets: List[MonsterComponent],
        effect_str: str,
        level: int,
        proc_rate: float = 1.0,
    ) -> None:
        """
        Parse and apply a single skill effect.
        """
        import re

        # Skip HIT effects - they're processed separately for proc rate
        if effect_str.startswith("HIT<"):
            return

        # 1. Parse the effect string
        effect_type = ""
        base_value = 0.0
        scale_value = 0.0
        duration = 8  # Default (CC fallback only)
        has_duration = False  # True only when the data gives an explicit duration

        # Check for simple debuffs (e.g. "STUN")
        simple_match = re.match(r"^([A-Z_]+)$", effect_str.strip().upper())
        # Check for parameterized effects (e.g. "ATK<10%,1%,8>" or "DEFENSE<-500,-14,8>")
        # Capture the % suffix separately — raw game unit values (no %) need /100 conversion
        param_match = re.match(
            r"(\w+)<(-?[\d.]+)(%?),(-?[\d.]+)(%?),?(\d+)?>", effect_str
        )

        # Single-argument CC, e.g. "STUN<5>" / "SILENCE<8>". These matched
        # neither pattern above (no comma for param_match, angle brackets for
        # simple_match) and were silently dropped, so every scripted stun in the
        # game -- card and boss alike -- did nothing.
        cc_match = re.match(r"^([A-Z_]+)<(\d+(?:\.\d+)?)>$", effect_str.strip().upper())

        if param_match:
            effect_type = param_match.group(1).upper()
            base_value = float(param_match.group(2))
            has_percent = bool(param_match.group(3))
            scale_value = float(param_match.group(4))
            has_duration = bool(param_match.group(6))
            duration = int(param_match.group(6)) if has_duration else 8
            # Raw game units are on a ×100 scale vs add_modify's 0-100% -- EXCEPT
            # DEFENSE, which is not a percentage at all. It is flat damage points
            # subtracted after crit (formula.calculate_damage), and the boss's own
            # defense goes onto the same field as raw 500.0 (modes.py). Dividing it
            # made every "reduces DEF" debuff in the game 100x too weak: boss 2's
            # DEFENSE<-400,-10,10> landed as -6.9 instead of -690.
            if not has_percent and effect_type not in ("DEF", "DEFENSE"):
                base_value /= 100.0
                scale_value /= 100.0
        elif cc_match:
            effect_type = cc_match.group(1)
            duration = int(float(cc_match.group(2)))
            has_duration = True
        elif simple_match:
            effect_type = simple_match.group(1)
            duration = 10 if effect_type in ("POISON", "BURN") else 3
        else:
            return

        final_value = base_value + scale_value * (level - 1)

        # 2. Map to internal types
        mod_map = EFFECT_TO_MODIFIER

        debuff_map = {
            "STUN": DebuffType.STUN,
            "FROZEN": DebuffType.FROZEN,
            "SLEEP": DebuffType.SLEEP,
            "NUMB": DebuffType.NUMB,
            "STONE": DebuffType.STONE,
            "POISON": DebuffType.POISON,
            "BURN": DebuffType.BURN,
            "SILENCE": DebuffType.SILENCE,
        }

        mod_type = mod_map.get(effect_type)
        debuff_type = debuff_map.get(effect_type)

        if not mod_type and not debuff_type:
            return

        # 3. Generate Type-Specific Source ID
        # Using type_name ensures different stats from the same source don't overwrite durations
        type_name = mod_type.name if mod_type else debuff_type.name
        base_source = (
            f"skill_{caster.skill.id}_{caster.slot}_{type_name}"
            if caster.skill
            else f"base_{type_name}"
        )

        # Skills ALWAYS stack (unlike abilities, which may refresh). Give each
        # cast a unique source_id via a per-cast counter so repeated casts
        # accumulate instead of overwriting. Combined with permanence below, a
        # no-duration stat buff compounds for the rest of the battle.
        cast_source = base_source
        if mod_type:
            skill_id = caster.skill.id if caster.skill else 0
            key = (caster.slot, skill_id, type_name)
            n = self._skill_cast_counter.get(key, 0) + 1
            self._skill_cast_counter[key] = n
            cast_source = f"{base_source}_cast{n}"

        # 4. Apply to targets
        for target in targets:
            if not target.is_alive or not target.stat:
                continue

            if mod_type:
                # Trace only: the modifier total before and after, so the UI can say
                # "crit rate 24% -> 39%" rather than just naming the effect.
                before = (
                    target.stat.get_modifier(mod_type).get_percentage_sum()
                    if (self.trace_enabled and target.stat)
                    else None
                )
                target.stat.add_modify(mod_type, final_value, cast_source)
                # Respect the data's duration: only track expiry when the data
                # gave one. No duration => permanent (never registered for
                # expiry, so it lasts the whole battle).
                if has_duration:
                    self._track_buff(target, cast_source, duration)
                # Trace only -- `_log_event` returns immediately when tracing is
                # off, so the MC hot loop pays nothing for this. It exists so a
                # player can be told WHEN a buff landed and how long it lasts,
                # which the cast log alone cannot say.
                self._log_event(
                    "debuff" if target.is_enemy else "buff",
                    attacker=caster.slot,
                    target=target.slot,
                    was_skill=True,
                    details={
                        "stat": type_name,
                        "value": final_value,
                        "duration": float(duration) if has_duration else 0.0,
                        "permanent": not has_duration,
                        "before": (round(before, 2) if before is not None else None),
                        "after": (
                            round(
                                target.stat.get_modifier(mod_type).get_percentage_sum(),
                                2,
                            )
                            if (self.trace_enabled and target.stat)
                            else None
                        ),
                        "snapshot": (
                            self.stat_snapshot(target) if self.trace_enabled else None
                        ),
                    },
                )
            elif debuff_type:
                # Roll proc chance
                if proc_rate >= 1.0 or random.random() < proc_rate:
                    target.apply_debuff(
                        debuff_type, float(duration), self.current_time, base_source
                    )
                    self._log_event(
                        "cc",
                        attacker=caster.slot,
                        target=target.slot,
                        was_skill=True,
                        details={
                            "kind": debuff_type.name,
                            "duration": float(duration),
                        },
                    )

    def _track_buff(
        self, target: MonsterComponent, source_id: str, duration: float
    ) -> None:
        """
        Track buff for expiration.
        Duration 0 = permanent, no tracking needed.
        """
        if duration <= 0:
            return

        expire_time = self.current_time + duration
        if not hasattr(self, "_active_buffs"):
            self._active_buffs: List[tuple] = []

        # Check if this source already has an active buff on this target
        # If so, refresh the duration instead of adding a new entry
        for i, (t, sid, _) in enumerate(self._active_buffs):
            if t is target and sid == source_id:
                # Refresh: update expiration time
                self._active_buffs[i] = (target, source_id, expire_time)
                return

        # New buff from this source
        self._active_buffs.append((target, source_id, expire_time))

    def _cleanse_timed_modifiers(self, unit: MonsterComponent) -> None:
        """Strip `unit`'s TIMED stat modifiers. Permanent ones survive.

        Mirrors `_expire_buffs`, but expires every tracked modifier on one unit
        at once instead of the ones whose clock ran out. Only timed modifiers are
        tracked in `_active_buffs`, so permanent ability debuffs are untouched --
        which is what the game does (see `_boss_phase`).

        ponytail: every timed modifier a player can put on a boss is a debuff, so
        this does not filter by sign. If a boss ever gains a timed self-buff, note
        that ERASE_DEBUFF should not remove it (ERASE_BUFF is a separate effect).
        """
        remaining = []
        for target, source_id, expire_time in getattr(self, "_active_buffs", []):
            if target is unit:
                if unit.stat:
                    for mod_type in ModifierType:
                        unit.stat.get_modifier(mod_type).remove_modify(source_id)
            else:
                remaining.append((target, source_id, expire_time))
        self._active_buffs = remaining

    def _expire_buffs(self) -> None:
        """Remove expired buffs."""
        if not hasattr(self, "_active_buffs"):
            return

        still_active = []
        for target, source_id, expire_time in self._active_buffs:
            if self.current_time >= expire_time:
                # Remove buff from all modifier types
                if target.stat:
                    for mod_type in ModifierType:
                        target.stat.get_modifier(mod_type).remove_modify(source_id)
            else:
                still_active.append((target, source_id, expire_time))
        self._active_buffs = still_active

    def _process_debuffs(self) -> None:
        """
        Process debuffs for all units.

        Handles:
        1. Expiring debuffs that have timed out
        2. DoT damage for POISON/BURN (999 damage per tick)
        """
        all_units = self.players + self.enemies

        for unit in all_units:
            if not unit.is_alive:
                continue

            # Clear expired debuffs
            unit.clear_expired_debuffs(self.current_time)

            # Process DoT damage
            dot_debuffs = {DebuffType.POISON, DebuffType.BURN}
            for debuff in unit.active_debuffs:
                if debuff.debuff_type in dot_debuffs:
                    # Check if it's time for a damage tick
                    if self.current_time >= debuff.next_tick_time:
                        # Apply 999 damage per tick (simplified)
                        dot_damage = 999
                        died = unit.take_damage(dot_damage)

                        # Re-evaluate conditional effects after HP change
                        unit.evaluate_conditionals()

                        # Log the DoT damage
                        self._log_event(
                            "dot_damage",
                            target=unit.slot,
                            damage=dot_damage,
                            details={
                                "debuff_type": debuff.debuff_type.name,
                                "source": debuff.source_id,
                            },
                        )

                        debuff.next_tick_time = self.current_time + debuff.tick_interval

                        if died:
                            self._log_event(
                                "death", target=unit.slot, details={"cause": "dot"}
                            )
                            if self.on_death:
                                self.on_death(unit)

            # Process HoT healing (HEAL_DOT abilities)
            healed = unit.process_hot_ticks(self.current_time)
            if healed > 0:
                # Re-evaluate conditional effects after HP change
                unit.evaluate_conditionals()
                self._log_event(
                    "hot_heal",
                    target=unit.slot,
                    details={"healed": healed},
                )

    def _check_wave_end(self) -> bool:
        """Check if current wave has ended."""
        # All enemies dead = wave end
        if all(not e.is_alive for e in self.enemies):
            return True

        # All players dead = defeat
        if all(not p.is_alive for p in self.players):
            return True

        return False

    def _handle_wave_end(self) -> bool:
        """Handle wave end state."""
        if all(not p.is_alive for p in self.players):
            self.phase = BattlePhase.DEFEAT
            self.defeat_reason = "wiped"
            self._log_event("defeat")
            return False

        self.phase = BattlePhase.WAVE_END
        self._log_event("wave_end", details={"wave": self.current_wave + 1})

        if self.on_wave_end:
            self.on_wave_end(self.current_wave)

        return True

    def _recover_between_waves(self) -> None:
        """Apply between-wave recovery."""
        for player in self.players:
            if player.is_alive and player.stat:
                # Recover HP
                recovery = int(player.stat.base_hp * self.config.wave_recover)
                player.stat.current_hp = min(
                    player.stat.current_hp + recovery, player.stat.base_hp
                )

    def stat_snapshot(self, unit: MonsterComponent) -> Dict:
        """Every number a player would want to see for one card, right now.

        The percentages are the *modifier* sums, which is what the damage pipeline
        multiplies by -- `damage_modifier` 59.7 means the `(1 + DamageModifer)` stage
        is running at 1.597. Crit rate is the resolved final rate, capped the way the
        battle caps it, not the raw card stat.
        """
        st = unit.stat
        if st is None:
            return {}
        return {
            # Display ATK is internal x10, and it includes the Attack-bond
            # contribution -- the SAME value `_apply_target_filter` ranks `max_atk`
            # on (`base_atk * normal_dmg_modifier`). It used to report bare
            # `base_atk`, so a card carrying bonds showed an ATK below the one the
            # engine was actually sorting by, and the panel named the wrong
            # recipient for a ranked buff like Orihime's top-2. Most visible on the
            # helper, which usually carries the assist that is not duplicated
            # anywhere else on the team.
            "atk": int(st.base_atk * st.normal_dmg_modifier.get_modifier_total()) * 10,
            "atk_base": int(st.base_atk) * 10,
            "hp": int(st.hp_modifier.final_value),
            # Speed is reported three ways because the raw stat alone is useless and
            # actively misleading: it is INVERTED (higher = slower), and it was being
            # read off `speed_modifier.final_value`, which is the modifier, not the
            # stat -- printing 5,290 for a card whose base is 2,300.
            #
            # `interval` is what a player can act on. `speed_mod` is the modifier as a
            # percentage, and `speed_capped` says it has hit the +/-100% clamp in
            # `get_attack_interval` -- past that, more speed buys nothing. A team
            # stacking Phoenix x2 + Ono no Komachi sits at +105% to +130%, i.e. every
            # card already at the floor of half its base interval.
            "speed": int(st.base_speed),
            "speed_mod": round((st.speed_modifier.get_modifier_total() - 1.0) * 100, 1),
            "speed_capped": abs(st.speed_modifier.get_modifier_total() - 1.0) >= 1.0,
            "interval": round(float(unit.get_attack_interval()), 2),
            "crit_rate": round(min(st.final_crit, self.config.crit_max) * 100, 2),
            "crit_dmg": round(st.crit_dmg_modifier.get_percentage_sum(), 2),
            "dmg": round(st.damage_modifier.get_percentage_sum(), 2),
            "normal_dmg": round(st.normal_dmg_modifier.get_percentage_sum(), 2),
            "skill_dmg": round(st.skill_dmg_modifier.get_percentage_sum(), 2),
            "skill_bond": round(float(st.skill_bond_mult), 4),
            "shield": round(st.shield_modifier.get_percentage_sum(), 2),
        }

    def _log_event(
        self,
        event_type: str,
        attacker: Optional[str] = None,
        target: Optional[str] = None,
        damage: int = 0,
        crit_type: CritType = CritType.NONE,
        was_skill: bool = False,
        combo: int = 1,
        details: Optional[Dict] = None,
    ) -> None:
        """Log a battle event if tracing is enabled."""
        if not self.trace_enabled:
            return

        event = BattleEvent(
            tick=self.current_tick,
            time=self.current_time,
            event_type=event_type,
            attacker=attacker,
            target=target,
            damage=damage,
            crit_type=crit_type,
            was_skill=was_skill,
            combo=combo,
            details=details or {},
        )
        self.events.append(event)

    # Summary methods
    def get_total_damage(self) -> int:
        """Get total damage dealt by players."""
        return sum(
            e.damage for e in self.events if e.attacker and e.attacker.startswith("P")
        )

    def get_total_player_damage_taken(self) -> int:
        """Get total damage taken by players."""
        return sum(
            e.damage for e in self.events if e.target and e.target.startswith("P")
        )

    def get_unit_damage(self, slot: str) -> int:
        """Get total damage dealt by a specific unit (e.g., 'P1')."""
        return sum(
            e.damage
            for e in self.events
            if e.event_type == "attack" and e.attacker == slot
        )

    def get_unit_healing(self, slot: str) -> int:
        """Get total healing done by a specific unit (e.g., 'P1')."""
        return sum(
            e.damage
            for e in self.events
            if e.event_type == "heal" and e.attacker == slot
        )

    def get_crit_rate(self) -> float:
        """Get actual crit rate from combat."""
        attacks = [
            e
            for e in self.events
            if e.event_type == "attack" and e.attacker and e.attacker.startswith("P")
        ]
        if not attacks:
            return 0.0
        crits = sum(1 for a in attacks if a.crit_type != CritType.NONE)
        return crits / len(attacks)

    def get_average_damage(self) -> float:
        """Get average damage per attack."""
        attacks = [
            e
            for e in self.events
            if e.event_type == "attack" and e.attacker and e.attacker.startswith("P")
        ]
        if not attacks:
            return 0.0
        return sum(a.damage for a in attacks) / len(attacks)
