"""
Simulation modes for the Otogi Battle Simulator.

Provides high-level simulation runners for different evaluation scenarios:
- FiveWaveSimulator: Conquest-style 5-wave sustained DPS evaluation
- OneWaveSimulator: Single wave burst damage evaluation
- DefenseSimulator: Defensive value comparison vs baseline
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
from statistics import mean, stdev

from .lifecycle import MonsterModel, ModifierType
from .battle import SKILL_EFFECT_DELAY, Battle, BattleConfig, BattlePhase, BattleEvent
from .config import (
    SimulationConfig,
    EnemyProfile,
    combat_constants,
    get_5wave_config,
    get_1wave_config,
    get_defense_config,
    DEFAULT_MOB,
)
from .constants import ATTR_NEUTRAL
from .data_loader import get_loader
from .worldboss import BossSpec


@dataclass
class SimulationResult:
    """Results from a simulation run."""

    # Outcome
    victory: bool = False
    waves_completed: int = 0
    total_ticks: int = 0
    total_time: float = 0.0

    # Damage stats
    total_damage: int = 0
    total_damage_taken: int = 0
    average_damage_per_attack: float = 0.0
    dps: float = 0.0

    # Combat stats
    total_attacks: int = 0
    crit_count: int = 0
    crit_rate: float = 0.0
    skill_uses: int = 0

    # Per-unit breakdown
    unit_damage: Dict[str, int] = field(default_factory=dict)
    unit_deaths: Dict[str, int] = field(default_factory=dict)

    # Scoring
    score: float = 0.0

    def __str__(self) -> str:
        return (
            f"SimulationResult(victory={self.victory}, "
            f"waves={self.waves_completed}, "
            f"damage={self.total_damage:,}, "
            f"DPS={self.dps:.1f}, "
            f"score={self.score:.1f})"
        )


class BaseSimulator:
    """Base class for simulation modes."""

    def __init__(self, config: Optional[SimulationConfig] = None):
        """Initialize simulator with optional configuration."""
        self.config = config or SimulationConfig()
        self.data_loader = get_loader()
        self.last_battle: Optional[Battle] = None

    def build_team(
        self,
        card_ids: List[int],
        levels: Optional[List[int]] = None,
        lb_levels: Optional[List[int]] = None,
    ) -> List[MonsterModel]:
        """Build a team from card IDs."""
        return self.data_loader.build_team(card_ids, levels, lb_levels)

    def build_enemies(
        self, profiles: List[EnemyProfile], wave: int = 0
    ) -> List[MonsterModel]:
        """Build enemy units from profiles."""
        enemies = []
        for i, profile in enumerate(profiles):
            model = MonsterModel(
                card_id=-(wave * 100 + i + 1),  # Negative IDs for enemies
                level=1,
                lb_level=0,
                attack=int(profile.atk * profile.atk_scaling),
                hp=int(profile.hp * profile.hp_scaling),
                speed=profile.speed,
                critical=profile.crit,
                name=f"Enemy {i + 1}" if not profile.is_boss else "Boss",
            )
            enemies.append(model)
        return enemies

    def _create_battle(self) -> Battle:
        """Create a Battle instance from config."""
        battle_config = BattleConfig(
            wave_count=self.config.wave_count,
            tick_rate=self.config.tick_rate,
            turn_limit=self.config.turn_limit,
            **combat_constants(self.config),
        )

        battle = Battle(battle_config)
        # Always enable tracing for result extraction
        battle.trace_enabled = True

        return battle

    def _extract_result(self, battle: Battle) -> SimulationResult:
        """Extract SimulationResult from completed battle."""
        result = SimulationResult(
            victory=battle.phase == BattlePhase.VICTORY,
            waves_completed=(
                battle.current_wave + 1
                if battle.phase == BattlePhase.VICTORY
                else battle.current_wave
            ),
            total_ticks=battle.current_tick,
            total_time=battle.current_time,
        )

        # Calculate damage stats from events
        attacks = [e for e in battle.events if e.event_type == "attack"]
        player_attacks = [
            a for a in attacks if a.attacker and a.attacker.startswith("P")
        ]

        result.total_attacks = len(player_attacks)
        result.total_damage = sum(a.damage for a in player_attacks)
        result.total_damage_taken = sum(
            a.damage for a in attacks if a.target and a.target.startswith("P")
        )

        if player_attacks:
            result.average_damage_per_attack = result.total_damage / len(player_attacks)
            result.crit_count = sum(1 for a in player_attacks if a.crit_type.value > 0)
            result.crit_rate = result.crit_count / len(player_attacks)

        # Calculate DPS
        if result.total_time > 0:
            result.dps = result.total_damage / result.total_time

        # Per-unit breakdown
        for attack in player_attacks:
            if attack.attacker:
                result.unit_damage[attack.attacker] = (
                    result.unit_damage.get(attack.attacker, 0) + attack.damage
                )

        # Skill uses
        result.skill_uses = sum(1 for a in player_attacks if a.was_skill)

        return result

    def _run_one_wave(
        self,
        card_ids: List[int],
        levels: Optional[List[int]] = None,
        lb_levels: Optional[List[int]] = None,
    ) -> SimulationResult:
        """Build a team, fight one wave, return the result. THE single-wave path.

        `OneWaveSimulator.run` and `DefenseSimulator._run_team` were line-for-line
        the same ten-step sequence (load abilities, build team and enemies,
        set_battle_data, _create_battle, start_wave, simulate_wave, extract) --
        different comments were all that separated them, which is why a
        token-based clone scan walked past it.

        The danger in a hand-rolled copy is not the duplication, it is that a copy
        can quietly omit a step: the sibling `_create_battle` dropped
        `skill_tick_rate` and silently ran the legacy coupled-cast model. Subclasses
        that need a different fight (multi-wave) override `run` instead --
        they are genuinely different sequences, not copies of this one.
        """
        team = self.build_team(card_ids, levels, lb_levels)
        if not team:
            return SimulationResult()

        wave_config = self.config.waves[0] if self.config.waves else None
        if wave_config:
            enemies = self.build_enemies(wave_config.get_enemies())
        else:
            enemies = self.build_enemies([DEFAULT_MOB] * 5)

        self.data_loader.load_all()
        ability_data = self.data_loader._abilities

        battle = self._create_battle()
        battle.set_battle_data(team, enemies, ability_data)

        battle.phase = BattlePhase.WAVE_START
        battle.start_wave()

        battle.simulate_wave()
        self.last_battle = battle

        return self._extract_result(battle)

    def run(
        self,
        card_ids: List[int],
        levels: Optional[List[int]] = None,
        lb_levels: Optional[List[int]] = None,
    ) -> SimulationResult:
        """Run simulation with specified team. Override in subclasses."""
        raise NotImplementedError


class FiveWaveSimulator(BaseSimulator):
    """
    5-wave conquest-style simulation.

    Evaluates sustained DPS over multiple waves with:
    - Enemy HP scaling per wave
    - Combo reset between waves
    - Wave recovery (5% HP)
    - Boss wave at the end

    Scoring: Total damage × completion bonus
    """

    def __init__(self, config: Optional[SimulationConfig] = None):
        super().__init__(config or get_5wave_config())

    def run(
        self,
        card_ids: List[int],
        levels: Optional[List[int]] = None,
        lb_levels: Optional[List[int]] = None,
    ) -> SimulationResult:
        """Run 5-wave simulation."""
        team = self.build_team(card_ids, levels, lb_levels)
        if not team:
            return SimulationResult()

        # Build enemy pool (all waves combined for simplicity)
        enemy_pool = []
        for wave_config in self.config.waves:
            enemies = wave_config.get_enemies()
            wave_enemies = self.build_enemies(enemies, len(enemy_pool))
            enemy_pool.extend(wave_enemies)

        # Get ability data
        self.data_loader.load_all()
        ability_data = self.data_loader._abilities

        # Create and run battle
        battle = self._create_battle()
        battle.set_battle_data(team, enemy_pool[:5], ability_data)  # First wave enemies
        battle._enemy_pool = enemy_pool  # Store for spawning
        battle._ability_data = ability_data

        # Run full simulation
        victory = battle.simulate_battle()
        self.last_battle = battle

        # Extract results
        result = self._extract_result(battle)

        # Calculate score: Total damage × (1 + 0.1 × waves_beyond_1)
        wave_bonus = 1.0 + 0.1 * (result.waves_completed - 1)
        completion_bonus = 1.5 if result.victory else 1.0
        result.score = result.total_damage * wave_bonus * completion_bonus

        return result


class OneWaveSimulator(BaseSimulator):
    """
    Single-wave burst evaluation.

    Evaluates burst damage output in a short fight:
    - Single wave of enemies
    - Short turn limit (100)
    - No wave recovery concerns

    Scoring: Total damage / time
    """

    def __init__(self, config: Optional[SimulationConfig] = None):
        super().__init__(config or get_1wave_config())

    def run(
        self,
        card_ids: List[int],
        levels: Optional[List[int]] = None,
        lb_levels: Optional[List[int]] = None,
    ) -> SimulationResult:
        """Run single-wave simulation, scored as DPS."""
        result = self._run_one_wave(card_ids, levels, lb_levels)
        result.score = result.dps
        return result


class DefenseSimulator(BaseSimulator):
    """
    Defensive value comparison simulator.

    Compares damage taken when swapping a unit into a baseline team.
    Lower damage taken = higher defensive value.

    Scoring: Baseline damage taken - test damage taken
    """

    def __init__(
        self,
        config: Optional[SimulationConfig] = None,
        baseline_ids: Optional[List[int]] = None,
    ):
        super().__init__(config or get_defense_config())
        self.baseline_ids = baseline_ids or [1, 15, 733, 450]  # 4 units

    def run(
        self,
        card_ids: List[int],
        levels: Optional[List[int]] = None,
        lb_levels: Optional[List[int]] = None,
    ) -> SimulationResult:
        """
        Run defensive comparison.

        Runs baseline team, then swaps in test card and compares.
        """
        # First run baseline
        baseline_result = self._run_team(self.baseline_ids)
        baseline_damage_taken = baseline_result.total_damage_taken

        # Then run with test card replacing last baseline unit
        test_team_ids = self.baseline_ids[:3] + card_ids[:1]
        test_result = self._run_team(test_team_ids, levels, lb_levels)
        test_damage_taken = test_result.total_damage_taken

        # Calculate defensive value
        result = test_result
        result.score = baseline_damage_taken - test_damage_taken

        return result

    def _run_team(
        self,
        card_ids: List[int],
        levels: Optional[List[int]] = None,
        lb_levels: Optional[List[int]] = None,
    ) -> SimulationResult:
        """Run simulation for a team."""
        return self._run_one_wave(card_ids, levels, lb_levels)


# --- World-boss bench target (single source of truth) ---------------------------
# monte_carlo imports these; do not fork a second copy there. The two harnesses
# MUST fight the same dummy or their scores are not comparable -- they silently
# diverged once (bench used ATK 50 + mortal players while MC used ATK 3500 +
# immortal, a ~2x score gap on the same team).
BENCH_TARGET_HP = 1_000_000_000
BENCH_TARGET_ATK = 3500  # internal (display 35000)
BENCH_TARGET_SPEED = 1300
# Flat subtraction per hit, measured off a live world-boss capture (distinct
# values were {500.0, 0.0} only). battle.py:1240 reads it via
# defense_modifier.get_percentage_sum() and subtracts it flat.
BENCH_TARGET_DEFENSE = 500.0


def apply_bench_target_defense(
    battle: Battle, defense: float = BENCH_TARGET_DEFENSE
) -> None:
    """Give every enemy the world boss's flat defense.

    Must run after start_wave(): defense lives on the MonsterStat of the built
    unit, and MonsterModel has no defense field to carry it through.
    """
    if not defense:
        return
    for enemy in battle.enemies:
        enemy.stat.add_modify(ModifierType.DEFENSE, defense, "bench_target_defense")


def build_benchmark_config(
    benchmark_time: float,
    regen_cd: Optional[float] = None,
    record_casts: bool = False,
    immortal_players: bool = True,
    skill_effect_delay: float = SKILL_EFFECT_DELAY,
) -> BattleConfig:
    """The world-boss DPS config: one wave, immortal players, time-limited.

    wave_count=1 makes wave 0 the *last* wave so last-wave-entry abilities fire;
    immortal_players keeps the score a measure of damage rather than survival.
    """
    sim_cfg = get_5wave_config()  # source of the shared combat constants
    cfg = BattleConfig(
        wave_count=1,
        immortal_players=immortal_players,
        record_casts=record_casts,
        tick_rate=sim_cfg.tick_rate,
        turn_limit=999999,  # no turn limit; we stop by time
        time_limit=benchmark_time,  # TIME abilities extend this
        **combat_constants(sim_cfg),
    )
    if regen_cd is not None:
        cfg.skill_points_regen_cd = regen_cd
    cfg.skill_effect_delay = skill_effect_delay
    return cfg


def run_benchmark_battle(
    player_models: List[MonsterModel],
    ability_data: Optional[Dict] = None,
    reserve_models: Optional[List[MonsterModel]] = None,
    benchmark_time: float = 300.0,
    target_defense: float = BENCH_TARGET_DEFENSE,
    score_threshold: float = 0.0,
    abort_pace: float = 0.0,
    abort_at: float = 0.5,
    trace: bool = False,
    regen_cd: Optional[float] = None,
    record_casts: bool = False,
    tick_headroom: float = 2.0,
    boss: Optional["BossSpec"] = None,
    target_hp: int = BENCH_TARGET_HP,
    target_atk: int = BENCH_TARGET_ATK,
    target_speed: int = BENCH_TARGET_SPEED,
    target_attribute: int = ATTR_NEUTRAL,
    immortal_players: bool = True,
    skill_effect_delay: float = SKILL_EFFECT_DELAY,
) -> Battle:
    """Run one world-boss DPS battle and return the finished Battle.

    THE single benchmark battle loop. Both entry points -- Monte Carlo's
    ``_run_team_battles(mode="benchmark")`` and ``DamageBenchmark.run()`` -- go
    through here so a team cannot score differently depending on which harness
    asked. They used to each own a copy and drifted (bench fought an ATK-50
    mortal fight, MC an ATK-3500 immortal one: ~2x apart on the same team).

    ``score_threshold``/``abort_pace`` are Monte Carlo's early-outs; left at 0
    the battle always runs the full duration.
    """
    sim_cfg = get_5wave_config()
    # A real boss makes players mortal -- that is the whole point of boss mode.
    # The battle then ends on a wipe (DEFEAT), which the stop_when below already
    # handles, so survivability shows up as lost damage uptime.
    if boss is not None:
        immortal_players = False
        target_hp = boss.hp
        target_atk = boss.auto_atk
        target_speed = boss.speed
        target_defense = boss.defense
    battle = Battle(
        build_benchmark_config(
            benchmark_time,
            regen_cd,
            record_casts,
            immortal_players,
            skill_effect_delay,
        )
    )
    # Tracing costs time per event, so Monte Carlo leaves it off; anything that
    # wants a per-attack breakdown (crit rate, attack counts) must opt in.
    battle.trace_enabled = trace
    battle.base_time_limit = benchmark_time

    dummy = MonsterModel(
        card_id=-999,
        level=1,
        lb_level=0,
        attack=target_atk,
        hp=target_hp,
        speed=target_speed,
        critical=0,  # no crits from the dummy
        name=boss.name if boss else "Dummy",
        attribute=target_attribute,  # neutral by default: no advantage either way
    )
    battle.set_battle_data(
        player_models=player_models,
        enemy_models=[dummy],
        ability_data=ability_data or {},
        reserve_models=reserve_models,
    )
    battle.phase = BattlePhase.WAVE_START
    battle.start_wave()
    apply_bench_target_defense(battle, target_defense)
    if boss is not None:
        battle.install_boss(boss)

    # Headroom for TIME-ability extension; the loop still breaks on the
    # *effective* (extended) limit, so extra ticks are only a ceiling.
    max_ticks = int(benchmark_time * tick_headroom / sim_cfg.tick_rate) + 1
    # Early-abort projections run AFTER a tick, so they ride the after_tick hook.
    # Both are one-shot: they fire once at a fraction of the way through and then
    # stop checking, so a hopeless candidate is abandoned without paying a
    # projection on every tick.
    state = {"mercy_done": False, "abort_done": False}

    def _abandon_if_hopeless(b: Battle) -> bool:
        """True to stop: this team cannot reach a score worth finishing for."""
        if (
            not state["abort_done"]
            and abort_pace > 0.0
            and b.current_time >= benchmark_time * abort_at
        ):
            state["abort_done"] = True
            pace = b.player_damage_total / max(b.current_time, 1e-6)
            if pace * b.effective_time_limit < abort_pace:
                return True
        if (
            not state["mercy_done"]
            and score_threshold > 0.0
            and b.current_time >= benchmark_time * 0.5
        ):
            state["mercy_done"] = True
            if b.player_damage_total * 2.0 < score_threshold * 0.5:
                return True
        return False

    battle.run_until_time_limit(
        max_ticks,
        stop_when=lambda b: b.phase in (BattlePhase.VICTORY, BattlePhase.DEFEAT),
        after_tick=_abandon_if_hopeless,
    )

    return battle


class DamageBenchmark(BaseSimulator):
    """
    Damage benchmark against immortal target.

    Measures total damage output over fixed time period:
    - 1B HP target (never dies, always times out)
    - Immortal players, so the score is pure DPS and not survival
    - 5 minute time limit
    - Score = total damage dealt

    Use for comparing team damage output without kill/wave complexity.
    """

    # Benchmark configuration -- see BENCH_TARGET_* above.
    TARGET_HP = BENCH_TARGET_HP
    TARGET_ATK = BENCH_TARGET_ATK
    TARGET_SPEED = BENCH_TARGET_SPEED
    TARGET_DEFENSE = BENCH_TARGET_DEFENSE  # set to 0.0 to score without defense
    TIME_LIMIT = 300.0  # 5 minutes game time

    def __init__(self, config: Optional[SimulationConfig] = None):
        """Initialize damage benchmark."""
        if config is None:
            config = SimulationConfig(
                turn_limit=9999,  # No turn limit, use time
            )
        super().__init__(config)

    def run(
        self,
        card_ids: List[int],
        levels: Optional[List[int]] = None,
        lb_levels: Optional[List[int]] = None,
        assist_ids: Optional[List[int]] = None,
        reserve_ids: Optional[List[int]] = None,
        reserve_assist_ids: Optional[List[int]] = None,
    ) -> SimulationResult:
        """
        Run damage benchmark.

        Args:
            card_ids: Team card IDs
            levels: Card levels (default: max level)
            lb_levels: LB levels (default: 4 for MLB)
            assist_ids: Parallel list of assist card IDs (0 = no assist)
            reserve_ids: Reserve card IDs (up to 2)
            reserve_assist_ids: Assist IDs for reserve cards

        Returns:
            SimulationResult with total damage as score
        """
        # Default to MLB (level 90, LB4) if not specified
        if levels is None:
            levels = [90] * len(card_ids)
        if lb_levels is None:
            lb_levels = [4] * len(card_ids)

        # Build player team (with assists if provided)
        if assist_ids:
            team = self.data_loader.build_team_with_assists(
                card_ids, assist_ids, levels, lb_levels
            )
        else:
            team = self.build_team(card_ids, levels, lb_levels)
        if not team:
            return SimulationResult()

        # Build reserve team at same level/LB as main team (defaults to 90/5 MLB)
        reserves: Optional[List[MonsterModel]] = None
        if reserve_ids:
            reserve_levels = [levels[0]] * len(reserve_ids) if levels else None
            reserve_lb = [lb_levels[0]] * len(reserve_ids) if lb_levels else None
            reserves = self.data_loader.build_team_with_assists(
                reserve_ids, reserve_assist_ids, reserve_levels, reserve_lb
            )

        # Get ability data
        self.data_loader.load_all()
        ability_data = self.data_loader._abilities

        # One shared loop with Monte Carlo -- see run_benchmark_battle.
        battle = run_benchmark_battle(
            player_models=team,
            ability_data=ability_data,
            reserve_models=reserves,
            benchmark_time=self.TIME_LIMIT,
            target_defense=self.TARGET_DEFENSE,
            trace=True,  # this path reports a per-attack breakdown
        )
        self.last_battle = battle

        # Extract results
        result = self._extract_result(battle)

        # Score off player_damage_total, the same counter Monte Carlo scores on.
        # _extract_result re-sums battle.events instead, which is zero whenever
        # tracing is off and can drift from the battle's own total.
        result.score = float(battle.player_damage_total)

        return result

    def run_single_unit(
        self,
        card_id: int,
        level: int = 90,
        lb_level: int = 4,
    ) -> SimulationResult:
        """
        Run benchmark with single unit for formula validation.

        Useful for checking damage per attack matches expected formula.
        """
        return self.run([card_id], [level], [lb_level])


def build_simulator(mode: str, trace: bool = False) -> BaseSimulator:
    """The simulator for a mode name. One dispatch table, not one per caller.

    Exists so a caller that needs the *battle* as well as the score (a trace, a
    breakdown) can keep them from the same run. `cmd_simulate --trace` used to
    call `run_simulation` for the numbers and then build a second simulator and
    fight the battle AGAIN for the trace -- so the events printed under a result
    came from a different battle with different rolls. It reported
    "Crit Rate: 0.0%" directly above two lines ending in "CRIT!".
    """
    simulators = {
        "5wave": FiveWaveSimulator,
        "1wave": OneWaveSimulator,
        "defense": DefenseSimulator,
        "benchmark": DamageBenchmark,
    }
    simulator = simulators.get(mode, FiveWaveSimulator)()
    simulator.config.trace_enabled = trace
    return simulator


def run_simulation(
    mode: str,
    card_ids: List[int],
    levels: Optional[List[int]] = None,
    lb_levels: Optional[List[int]] = None,
    trace: bool = False,
    assist_ids: Optional[List[int]] = None,
    reserve_ids: Optional[List[int]] = None,
    reserve_assist_ids: Optional[List[int]] = None,
    simulator: Optional[BaseSimulator] = None,
) -> SimulationResult:
    """
    Run simulation in specified mode.

    Args:
        mode: "5wave", "1wave", "defense", or "benchmark"
        card_ids: List of card IDs for the team
        levels: Optional list of levels (defaults to max)
        lb_levels: Optional list of LB levels (defaults to 0)
        trace: Enable event tracing
        assist_ids: Assist card IDs (benchmark mode only)
        reserve_ids: Reserve card IDs (benchmark mode only)
        reserve_assist_ids: Assist IDs for reserves (benchmark mode only)
        simulator: Run on this simulator instead of a fresh one, so the caller
            keeps `last_battle` for the run it is about to report on.

    Returns:
        SimulationResult with stats and score
    """
    if simulator is None:
        simulator = build_simulator(mode, trace)

    if mode == "benchmark" and (assist_ids or reserve_ids):
        return simulator.run(
            card_ids,
            levels,
            lb_levels,
            assist_ids=assist_ids,
            reserve_ids=reserve_ids,
            reserve_assist_ids=reserve_assist_ids,
        )
    return simulator.run(card_ids, levels, lb_levels)


def run_multiple(
    mode: str,
    card_ids: List[int],
    iterations: int = 10,
    levels: Optional[List[int]] = None,
    lb_levels: Optional[List[int]] = None,
    assist_ids: Optional[List[int]] = None,
    reserve_ids: Optional[List[int]] = None,
    reserve_assist_ids: Optional[List[int]] = None,
) -> Tuple[float, float, List[SimulationResult]]:
    """
    Run multiple simulations and return statistics.

    Returns:
        Tuple of (average_score, std_dev, all_results)
    """
    results = []

    for _ in range(iterations):
        result = run_simulation(
            mode,
            card_ids,
            levels,
            lb_levels,
            assist_ids=assist_ids,
            reserve_ids=reserve_ids,
            reserve_assist_ids=reserve_assist_ids,
        )
        results.append(result)

    scores = [r.score for r in results]
    avg = mean(scores)
    std = stdev(scores) if len(scores) > 1 else 0.0

    return avg, std, results
