"""Selecting and installing the skill-casting policy.

This lived in ``monte_carlo`` -- the *search* module -- so the scoring contract
(``spec.py``) and the per-card benchmark both had to import from the team searcher
to find out how skills get cast. That is backwards: the policy is a property of the
fight, not of the thing searching for teams.

The default matters more than it looks. ``MC_SCHEDULER`` unset used to mean "no
scheduler at all", which scores a team at roughly HALF its damage, and three of the
seven CLI commands were in that state. It now defaults to cadence everywhere.
"""

from __future__ import annotations

import os


def resolve_scheduler(explicit: str | None, roster_active: bool) -> str:
    """Decide the skill-cast policy for a run. Default: "cadence".

    An explicit --scheduler always wins. Otherwise every run gets cadence —
    teams should be scored played well (buffs grouped, then carries dumped),
    which both scores higher and reproduces on re-scoring.

    Non-roster runs used to fall back to "apl" to keep canonical tier generation
    unchanged. That made the standard tier path the ONE path not using the
    default, so it disagreed with every hand-run benchmark. Tier lists generated
    before 2026-08-25 are already not comparable (self-amp ordering, skill-tick
    decoupling, stagger_amp), so there is nothing left to preserve by splitting.
    """
    if explicit:
        return explicit.lower()
    return "cadence"


def install_cadence_scheduler() -> bool:
    """Install a team-level scheduler on this process's APL engine from MC_SCHEDULER.

    **cadence is the DEFAULT** (2026-08-25). Env vars propagate to spawned workers
    on Windows. Params are all relative — no absolute damage number, so teams are
    compared at their best without a gameable floor.

        MC_SCHEDULER=cadence     MC_CADENCE_CYCLE (20.5)  MC_CADENCE_CPC (1)
        (default)                MC_CADENCE_STAGGER_AMP (1)
                                 MC_CADENCE_SELECT_FRAC  MC_CADENCE_WINDOW_FRAC
                                 MC_CADENCE_END_DUMP
        MC_SCHEDULER=survival    cadence + burst hold under CC + panic heal.
                                 Shares the MC_CADENCE_* params, plus
                                 MC_SURVIVAL_PANIC_HP (0 = off, measured negative)
                                 MC_SURVIVAL_MAX_HOLD (10)
                                 MC_SURVIVAL_HOLD_COST (1)
        MC_SCHEDULER=planner     MC_PLANNER_END_DUMP (8)  MC_PLANNER_VALUE_FLOOR (0)
                                 MC_PLANNER_PAD  MC_PLANNER_REQUIRE_BUFFS
        MC_SCHEDULER=none        no rotation policy (legacy; ~half the damage)

        MC_SCHEDULER=group       MC_GROUPS (JSON [["P1","P2"],["P3"]])
                                 MC_GROUP_SKIP_AFTER (8)
                                 player-authored cast groups; drives the web calculator

        MC_SCHEDULER=ramp        MC_RAMP_CYCLE (20.5)  MC_RAMP_SLIP (5)
                                 MC_RAMP_CPC (1)       MC_RAMP_SELECT_FRAC
                                 MC_RAMP_WINDOW_FRAC   MC_RAMP_END_DUMP
                                 MC_RAMP_STOP (1)      MC_RAMP_GRACE

    'survival' is what a world-boss fight needs: it will not open a burst while
    a unit is stunned/silenced or still paying an escalated orb cost, and it lets
    a healer jump the rotation when an ally is about to die. Both are inert
    against the immortal dummy, but it is a separate policy so the dummy
    benchmark and tier list keep fighting the fight they were generated with.

    'cadence' groups buffs into a window then dumps carries. 'ramp' additionally
    front-loads a ramp buffer (a card granting a permanent CHIT_ATK stack — the
    Nimbus[Awakened] duration bug) and retires it once the carry's autos cap.

    Returns True if a scheduler was installed.
    """
    # DEFAULT: cadence. Unset used to mean "no scheduler at all", which is a
    # silent ~2x damage cut -- a caller that did everything else right but forgot
    # MC_SCHEDULER got a team scored without any rotation policy. That is how the
    # 74.4M reference team came to re-score at 34.3M and look like a regression.
    # Set MC_SCHEDULER=none (or off/legacy) to deliberately run without one.
    which = (os.environ.get("MC_SCHEDULER") or "cadence").lower()
    from .engine import get_engine

    if which in ("none", "off", "legacy", "-"):
        get_engine().scheduler = None
        return False

    if which == "cadence":
        from .scheduler import CadenceScheduler

        get_engine().scheduler = CadenceScheduler(
            cycle=float(os.environ.get("MC_CADENCE_CYCLE", "20.5")),
            casts_per_carry=int(os.environ.get("MC_CADENCE_CPC", "1")),
            carry_select_frac=float(os.environ.get("MC_CADENCE_SELECT_FRAC", "0.5")),
            window_frac=float(os.environ.get("MC_CADENCE_WINDOW_FRAC", "0.85")),
            end_dump=float(os.environ.get("MC_CADENCE_END_DUMP", "8")),
            stagger_amp=os.environ.get("MC_CADENCE_STAGGER_AMP", "1") != "0",
        )
        return True

    if which == "survival":
        from .scheduler import SurvivalScheduler

        # Cadence params are shared deliberately: survival IS cadence plus a
        # burst hold and a panic heal, so a survival run stays comparable to the
        # cadence baseline it is being measured against.
        get_engine().scheduler = SurvivalScheduler(
            cycle=float(os.environ.get("MC_CADENCE_CYCLE", "20.5")),
            casts_per_carry=int(os.environ.get("MC_CADENCE_CPC", "1")),
            carry_select_frac=float(os.environ.get("MC_CADENCE_SELECT_FRAC", "0.5")),
            window_frac=float(os.environ.get("MC_CADENCE_WINDOW_FRAC", "0.85")),
            end_dump=float(os.environ.get("MC_CADENCE_END_DUMP", "8")),
            stagger_amp=os.environ.get("MC_CADENCE_STAGGER_AMP", "1") != "0",
            panic_hp=float(os.environ.get("MC_SURVIVAL_PANIC_HP", "0")),
            max_hold=float(os.environ.get("MC_SURVIVAL_MAX_HOLD", "10")),
            hold_on_cost=os.environ.get("MC_SURVIVAL_HOLD_COST", "1") != "0",
        )
        return True

    if which == "group":
        import json as _json

        from .scheduler import GroupScheduler

        # Group layout is structured, so it rides one JSON env var rather than a
        # scalar per knob. Shape: [["P1","P2"],["P3"]] -- priority left to right,
        # slots in no group never cast.
        raw = os.environ.get("MC_GROUPS", "[]")
        try:
            groups = _json.loads(raw)
        except ValueError:
            groups = []
        # {"P2": "P3"} -- P2 retires when a carry's autos cap and P3 takes over.
        try:
            swap = _json.loads(os.environ.get("MC_GROUP_SWAP", "{}"))
        except ValueError:
            swap = {}
        get_engine().scheduler = GroupScheduler(
            groups=groups,
            skip_after=float(os.environ.get("MC_GROUP_SKIP_AFTER", "8")),
            stagger_amp=os.environ.get("MC_CADENCE_STAGGER_AMP", "1") != "0",
            swap=swap,
            hold_cc=float(os.environ.get("MC_GROUP_HOLD_CC", "0")),
            end_dump=float(os.environ.get("MC_GROUP_END_DUMP", "8")),
            swap_when=os.environ.get("MC_GROUP_SWAP_WHEN", "autos"),
        )
        return True

    if which == "planner":
        from .scheduler import PlannerScheduler

        get_engine().scheduler = PlannerScheduler(
            end_dump=float(os.environ.get("MC_PLANNER_END_DUMP", "8")),
            value_floor=float(os.environ.get("MC_PLANNER_VALUE_FLOOR", "0")),
            lookahead_pad=float(os.environ.get("MC_PLANNER_PAD", "0")),
            require_buffs=os.environ.get("MC_PLANNER_REQUIRE_BUFFS", "1") != "0",
        )
        return True

    if which == "ramp":
        from .scheduler import RampRotation

        get_engine().scheduler = RampRotation(
            cycle=float(os.environ.get("MC_RAMP_CYCLE", "20.5")),
            slip=float(os.environ.get("MC_RAMP_SLIP", "5")),
            casts_per_carry=int(os.environ.get("MC_RAMP_CPC", "1")),
            carry_select_frac=float(os.environ.get("MC_RAMP_SELECT_FRAC", "0.5")),
            window_frac=float(os.environ.get("MC_RAMP_WINDOW_FRAC", "0.85")),
            end_dump=float(os.environ.get("MC_RAMP_END_DUMP", "8")),
            ramp_stop=os.environ.get("MC_RAMP_STOP", "1") != "0",
            crit_window_grace=float(os.environ.get("MC_RAMP_GRACE", "0.5")),
        )
        return True

    return False
