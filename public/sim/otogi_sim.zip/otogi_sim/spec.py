"""Team in -> score out. The one way to run the simulator.

    score(team, scenario, seed) -> Result

Three inputs, one rule: **anything that changes the score must live in exactly one
of them.** Every divergence we have chased lived somewhere else instead --

  * a module constant (bench dummy ATK 50 vs 3500: the same team scored ~2x apart
    depending on which harness ran it),
  * a builder-local hardcode (assist bonds built as SKILL_DMG in one team builder
    and NORMAL_DMG in the other: ~2%),
  * global RNG state (callers seeded at different points, so "identical" runs
    drew different numbers),
  * a hand-written cache key that had drifted from what actually matters
    (backline order was sorted away though it moves the score 45%).

None of those were visible in a score on its own. They surfaced only when someone
compared two numbers that were supposed to match, months apart. A single typed
entry point is what makes them impossible rather than merely unlikely.

Identity is the load-bearing idea here. ``TeamSpec.key()`` and
``Scenario.key()`` are DERIVED from the fields the simulator actually consumes --
never written out by hand alongside them. A key that is maintained separately
from the thing it identifies will drift from it, and a lossy key silently feeds
wrong scores back to whatever is caching on it.

The invariant that encodes all of this, enforced in test_spec.py:

    key(a) == key(b)  =>  score(a) == score(b)
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field, replace
from statistics import mean, stdev
from typing import Any, List, Optional, Protocol, Sequence, Tuple

from .data_loader import get_loader
from .lifecycle import make_stat_bond
from .worldboss import load_boss
from .modes import (
    ATTR_NEUTRAL,
    BENCH_TARGET_ATK,
    BENCH_TARGET_DEFENSE,
    BENCH_TARGET_HP,
    BENCH_TARGET_SPEED,
    run_benchmark_battle,
)

NO_ASSIST = 0


class GameDataSource(Protocol):
    """The slice of the data loader that scoring actually needs.

    Declared as a Protocol rather than the concrete GameDataLoader so a caller can
    supply game data from anywhere -- a past patch, a fixture, a hypothetical card --
    without importing or subclassing the loader. It also documents the dependency:
    scoring needs exactly two things from game data, not the loader's whole surface.
    """

    _abilities: dict

    def load_all(self) -> None: ...

    def build_team_with_assists(
        self,
        card_ids: List[int],
        assist_ids: Optional[List[int]],
        levels: Optional[List[int]],
        lb_levels: Optional[List[int]],
    ) -> List[Any]: ...


@dataclass(frozen=True)
class TeamSpec:
    """A complete team: everything that changes the score, and nothing that doesn't.

    Ordering semantics are not stylistic -- both were measured on 2026-08-25 with
    549/1720/1721/1615:

    * ``active`` is ORDERED. Slot 0 is the leader (entry_leader abilities only fire
      there) and the cadence scheduler casts in slot order, so permuting the
      backline moved the score from 33.6M to 48.7M -- a 45% spread. Sorting it (as
      the old Team.cache_key did) collapses teams that score differently.
    * ``reserve`` is UNORDERED, and so are the reserve assists -- INDEPENDENTLY of
      each other. A reserve card is not on the field, so a self-targeting buff has
      no one to register on; only team-wide buffs do anything, and those apply the
      same no matter which reserve slot carries them. Measured: swapping the cards
      and swapping the assists both leave the score unchanged.

      So the canonical form sorts reserve cards and reserve assists SEPARATELY
      rather than as bound pairs. Keying them as pairs (as this did initially)
      distinguishes specs that must score identically -- harmless to correctness,
      but it doubles this part of the search space and costs cache hits. Anything
      sweeping reserve assists should treat them as a SET for the same reason.
    """

    active: Tuple[int, int, int, int]
    helper: int
    reserve: Tuple[int, int]

    # Assists are bound to a SLOT, not to a card. 0 = no assist.
    active_assists: Tuple[int, int, int, int] = (
        NO_ASSIST,
        NO_ASSIST,
        NO_ASSIST,
        NO_ASSIST,
    )
    helper_assist: int = NO_ASSIST
    reserve_assists: Tuple[int, int] = (NO_ASSIST, NO_ASSIST)

    # Uniform across the team today because every caller uses MLB. Per-card levels
    # belong here too the moment anything needs them -- they change the score, so
    # they are identity, not configuration.
    level: int = 90
    lb: int = 4

    # The free bond slots, per player slot, in player_ids() order (4 active, then
    # helper), then the 2 reserves. Each entry is that card's bonds as
    # ((type, percent), ...) where type is "normal" | "skill" | "hp".
    #
    # These are identity, not configuration: a 7.5% normal-damage bond is worth a
    # few percent of a team's score, which is larger than the margins ranking
    # decides on. Empty means no bonds, which is what every caller did implicitly
    # before this existed -- so an empty tuple must leave key() byte-identical.
    #
    # A card has 3 bond slots at MLB and the assist occupies one of them, so a
    # slot with an assist has at most 2 here. Nothing enforces that: the engine
    # applies what it is given, and the UI owns the rule.
    bonds: Tuple[Tuple[Tuple[str, float], ...], ...] = ()

    def key(self) -> tuple:
        """Canonical identity. DERIVED -- never maintain a parallel encoding.

        Two specs share a key if and only if they must score the same.
        """
        base = self._canonical() + (self.level, self.lb)
        # Appended only when present. Every existing caller passes no bonds, and a
        # key that changed shape for all of them would invalidate every MC
        # checkpoint and cached score on disk for a field they never set.
        if any(self.bonds):
            base = base + (tuple(tuple(b) for b in self.bonds),)
        return base

    def _canonical(self) -> tuple:
        """THE canonicalization rules, defined exactly once.

        What is ordered and what is sorted is the thing that drifted before: the
        rule lived in a hand-written cache key rather than being derived, and it
        said the backline was unordered when it is not. Every rendering of identity
        (``key``, ``flat_key``) builds on this, so the rules cannot fork again.
        """
        return (
            tuple(self.active),  # ORDERED: leader slot + scheduler cast priority
            self.helper,
            tuple(sorted(self.reserve)),  # unordered: passives only
            tuple(sorted(self.reserve_assists)),  # pairing is free (see docstring)
            tuple(self.active_assists),  # bound to slot
            self.helper_assist,
        )

    def flat_key(self) -> tuple:
        """Flat, positionally-sliceable key in Monte Carlo's historical layout.

            (a0, a1, a2, a3, helper, r0, r1)            <- assist-free, len 7
            ... + (aa0, aa1, aa2, aa3, ra0, ra1, ha)    <- with assists, len 14

        MC slices this positionally (``key[:4]``, ``key[4]``, ``key[5:7]``) and uses
        ``len(key) == 7`` to mean "assist-free", so the shape is load-bearing there.
        Keeping it lets MC adopt derived identity without rewriting every consumer;
        the deeper change (opaque keys carrying their spec) is a separate step.

        ``level``/``lb`` are deliberately absent: MC runs a fixed 90/4, so they are
        constant within a run and cannot cause a collision. The assert makes that
        assumption fail loudly instead of silently -- omitting a varying field from
        a key is exactly the bug this module exists to prevent.
        """
        assert (self.level, self.lb) == (90, 4), (
            f"flat_key omits level/lb, but this spec varies them ({self.level}/"
            f"{self.lb}). Use key() instead, or add them to the layout."
        )
        assert not any(self.bonds), (
            "flat_key omits bonds, but this spec sets them. MC slices this layout "
            "positionally, so bonds cannot be appended -- use key() instead, or add "
            "them to the layout. Omitting a varying field from a key is exactly the "
            "bug this module exists to prevent."
        )
        active, helper, reserve, res_assists, act_assists, helper_assist = (
            self._canonical()
        )
        team_part = active + (helper,) + reserve
        assist_part = act_assists + res_assists + (helper_assist,)
        # Match the historical "no assists -> no assist suffix" shape so len()==7
        # keeps meaning assist-free.
        return team_part if not any(assist_part) else team_part + assist_part

    def player_ids(self) -> list[int]:
        """The 5 battle slots, in order: active 0-3 then helper."""
        return list(self.active) + [self.helper]

    def player_assists(self) -> list[int]:
        return list(self.active_assists) + [self.helper_assist]

    @classmethod
    def from_mc(
        cls,
        team: Any,
        assists: Optional[dict] = None,
        level: int = 90,
        lb: int = 4,
    ) -> "TeamSpec":
        """Bridge from Monte Carlo's split identity: a ``Team`` plus a side dict.

        That split is the defect this migration removes -- a team's assists lived
        in a separate structure keyed by ``(slot_name, index)``, so any code
        handling one without the other was silently working with a partial
        identity. Until every MC call site is converted, this rebuilds the whole
        spec from the pair.

        ``assists`` is None (or empty) for the assist-blind search phases, which is
        represented as all-zero assists -- the same battle, and now the same key.
        """
        a = assists or {}
        return cls(
            active=tuple(team.active),  # type: ignore[arg-type]
            helper=team.helper,
            reserve=tuple(team.reserve),  # type: ignore[arg-type]
            active_assists=tuple(a.get(("active", i), NO_ASSIST) for i in range(4)),  # type: ignore[arg-type]
            helper_assist=a.get(("helper", 0), NO_ASSIST),
            reserve_assists=tuple(a.get(("reserve", i), NO_ASSIST) for i in range(2)),  # type: ignore[arg-type]
            level=level,
            lb=lb,
        )

    SLOTS: Tuple[str, ...] = (
        "active:0",
        "active:1",
        "active:2",
        "active:3",
        "helper:0",
        "reserve:0",
        "reserve:1",
    )

    def card_at(self, slot: str) -> int:
        """The card currently occupying ``slot`` (e.g. "active:2")."""
        kind, _, idx = slot.partition(":")
        i = int(idx)
        if kind == "active":
            return self.active[i]
        if kind == "helper":
            return self.helper
        if kind == "reserve":
            return self.reserve[i]
        raise ValueError(f"unknown slot {slot!r}")

    def with_card_at(self, slot: str, card_id: int) -> "TeamSpec":
        """Swap ``card_id`` into ``slot``, keeping that slot's assist.

        The assist stays put deliberately: an A/B asks what THIS card is worth in
        a slot that is otherwise unchanged. Re-optimising the assist at the same
        time measures two changes at once and attributes both to the card.
        """
        kind, _, idx = slot.partition(":")
        i = int(idx)
        if kind == "active":
            act = list(self.active)
            act[i] = card_id
            return replace(self, active=tuple(act))  # type: ignore[arg-type]
        if kind == "helper":
            return replace(self, helper=card_id)
        if kind == "reserve":
            res = list(self.reserve)
            res[i] = card_id
            return replace(self, reserve=tuple(res))  # type: ignore[arg-type]
        raise ValueError(f"unknown slot {slot!r}")

    def with_active_order(self, order: Sequence[int]) -> "TeamSpec":
        """Reorder active slots, keeping each card's assist with it.

        ``order`` is a permutation of 0-3 giving the new slot for each old index.
        """
        act = tuple(self.active[i] for i in order)
        asst = tuple(self.active_assists[i] for i in order)
        return replace(self, active=act, active_assists=asst)  # type: ignore[arg-type]


@dataclass(frozen=True)
class Scenario:
    """The fight. Everything about the world the team is dropped into.

    Defaults are the world-boss DPS benchmark: an immortal 1B-HP neutral dummy with
    the observed in game flat 500 defense, 300s + whatever TIME abilities extend.

    ``scheduler`` is recorded here so a Result carries the rotation policy that
    produced it. Installing the scheduler is still global process state
    (install_cadence_scheduler), which this does not yet fix -- but a run whose
    scheduler is not in its key cannot be reproduced later, and we have already been
    bitten by exactly that (a 45-minute run recorded neither its benchmark_time nor
    its scheduler params, so its top score could not be reproduced at all).
    """

    time_limit: float = 300.0
    enemy_atk: int = BENCH_TARGET_ATK
    enemy_hp: int = BENCH_TARGET_HP
    enemy_speed: int = BENCH_TARGET_SPEED
    enemy_defense: float = BENCH_TARGET_DEFENSE
    enemy_attribute: int = ATTR_NEUTRAL
    immortal_players: bool = True
    # World boss 1-4 instead of the dummy. None = the immortal-dummy default, so
    # every existing scenario and the golden corpus are untouched. With a boss
    # set, players are mortal and the fight can end in a wipe.
    boss_id: Optional[int] = None
    boss_level: int = 30
    regen_cd: Optional[float] = None  # None = the shared combat-constant default
    scheduler: str = "cadence"
    scheduler_params: Tuple[Tuple[str, Any], ...] = ()

    # Env vars that change a score and therefore belong to the scenario. Recording
    # them is what makes a stored result re-runnable: cadence_v2 logged neither its
    # benchmark_time nor its scheduler params, so when its top team later scored
    # half as much there was no way to tell a regression from a config difference.
    # (It was a config difference -- MC_SCHEDULER unset meant "no scheduler".)
    SCORING_ENV_VARS = (
        "MC_SCHEDULER",
        "MC_SKILL_TICK",
        "MC_CADENCE_CYCLE",
        "MC_CADENCE_CPC",
        "MC_CADENCE_SELECT_FRAC",
        "MC_CADENCE_WINDOW_FRAC",
        "MC_CADENCE_END_DUMP",
        "MC_CADENCE_STAGGER_AMP",
        "MC_PLANNER_END_DUMP",
        "MC_PLANNER_VALUE_FLOOR",
        "MC_PLANNER_PAD",
        "MC_PLANNER_REQUIRE_BUFFS",
        "MC_ASSIST_AWARE",
        "MC_CRN",
        "MC_CRN_SEED",
    )

    @classmethod
    def from_env(cls, **overrides: Any) -> "Scenario":
        """Snapshot the process's current scoring config into a Scenario.

        Captures only vars that are actually SET, so the snapshot distinguishes
        "explicitly chosen" from "left at the default" -- and the defaults live in
        one place rather than being duplicated here.
        """
        import os

        params = tuple(
            (name, os.environ[name])
            for name in cls.SCORING_ENV_VARS
            if os.environ.get(name) not in (None, "")
        )
        fields: dict = {
            "scheduler": (os.environ.get("MC_SCHEDULER") or "cadence").lower(),
            "scheduler_params": params,
        }
        fields.update(overrides)
        return cls(**fields)

    def key(self) -> tuple:
        """Canonical identity. Derived, like TeamSpec.key."""
        return (
            self.time_limit,
            self.enemy_atk,
            self.enemy_hp,
            self.enemy_speed,
            self.enemy_defense,
            self.enemy_attribute,
            self.immortal_players,
            self.boss_id,
            self.boss_level,
            self.regen_cd,
            self.scheduler,
            tuple(sorted(self.scheduler_params)),
        )


@dataclass
class Result:
    """One battle's outcome, carrying the identity that produced it.

    The keys travel with the number so a stored result can always be re-run. Results
    that did not record their scenario are why the reproduction work above had to
    guess at benchmark_time and scheduler params.
    """

    damage: float
    seed: int
    team_key: tuple
    scenario_key: tuple
    effective_time: float = 0.0
    # Survivability, only meaningful in boss mode (players are immortal against
    # the default dummy, so these are constant there).
    #
    # `deaths` is the metric that matters: `wiped` needs ALL FIVE dead, and a
    # team that loses its two carries and limps to the timer is not a survivor
    # in any useful sense -- it reads as 0% wipe while scoring a quarter of its
    # damage. Kinoe does exactly that to the current best team.
    wiped: bool = False
    deaths: int = 0
    survival_time: float = 0.0
    battle: Any = None  # populated only when trace/record_casts were requested


@dataclass
class ScoreResult:
    """An aggregate over seeds."""

    mean: float
    sd: float
    n: int
    team_key: tuple
    scenario_key: tuple
    per_seed: list[float] = field(default_factory=list)


def build_models(
    spec: TeamSpec, loader: Optional[GameDataSource] = None
) -> tuple[list, list]:
    """(players, reserves) as MonsterModels. THE team builder -- there is only one.

    There used to be two (data_loader.build_team_with_assists and
    AssistPool.build_assisted_model) and they disagreed on the assist bond type,
    which moved auto-attack teams ~2%. Anything needing models goes through here.

    ``loader`` defaults to the process-wide singleton, which is right for the CLI
    and for a single-dataset process. Pass one explicitly to score against
    different game data (a past patch, a hypothetical card) without the answer
    depending on which module happened to touch the singleton first.
    """
    loader = loader or get_loader()
    loader.load_all()

    n = len(spec.player_ids())
    players = loader.build_team_with_assists(
        spec.player_ids(),
        spec.player_assists(),
        [spec.level] * n,
        [spec.lb] * n,
    )
    reserves = loader.build_team_with_assists(
        list(spec.reserve),
        list(spec.reserve_assists),
        [spec.level] * len(spec.reserve),
        [spec.lb] * len(spec.reserve),
    )
    _apply_bonds(players + reserves, spec.bonds)
    return players, reserves


def _apply_bonds(models: list, bonds: tuple) -> None:
    """Attach the player's free-slot bonds to the models build_models just built.

    They go on as real ``Bond`` objects so ``MonsterStat._apply_bonds`` applies them
    -- the one path that already knows a normal-damage bond feeds the NORMAL-attack
    bucket and never the skill path (measured in play 2026-08-25). ``bond_optimize``
    instead scales ``base_atk`` directly, which is a different mechanism: base ATK
    multiplies against everything, whereas the bucket is additive within itself. That
    module predates this and is now the odd one out.
    """
    for model, slot_bonds in zip(models, bonds):
        for kind, pct in slot_bonds:
            if pct:
                model.bonds.append(make_stat_bond(kind, pct))


def _install_scheduler(scenario: Scenario) -> None:
    """Make the process's rotation policy match the scenario that asked for it.

    The Scenario named a scheduler but nothing acted on it, so the policy was
    whatever the process happened to have installed -- ambient state, exactly what
    this module exists to eliminate. With no scheduler a team is scored with no
    rotation at all, which is roughly HALF its damage: the 74.4M reference team
    re-scored at 34.3M and looked like a regression until the missing
    MC_SCHEDULER was found.

    Every var this touches is restored, not just MC_SCHEDULER: the params used to
    leak, so one scenario with explicit params silently became the default for
    every later score in the same process.
    """
    import os

    from .apl.install import install_cadence_scheduler

    names = ["MC_SCHEDULER"] + [str(k) for k, _ in scenario.scheduler_params]
    prev = {n: os.environ.get(n) for n in names}
    os.environ["MC_SCHEDULER"] = scenario.scheduler
    try:
        for k, v in scenario.scheduler_params:
            os.environ[str(k)] = str(v)
        install_cadence_scheduler()
    finally:
        for n, old in prev.items():
            if old is None:
                os.environ.pop(n, None)
            else:
                os.environ[n] = old


def simulate(
    team: TeamSpec,
    scenario: Optional[Scenario] = None,
    seed: int = 0,
    trace: bool = False,
    record_casts: bool = False,
    loader: Optional[GameDataSource] = None,
) -> Result:
    """Run ONE battle. Deterministic in (team, scenario, seed).

    The seed is an argument, not ambient state. Callers used to seed the global RNG
    at whatever point suited them, so two harnesses running "the same" battle
    consumed different draws and disagreed by ~2%.
    """
    scenario = scenario or Scenario()
    _install_scheduler(scenario)
    random.seed(seed)

    loader = loader or get_loader()
    players, reserves = build_models(team, loader)

    # The enemy fields used to stop here: only target_defense was passed on, so
    # two scenarios with different enemy ATK hashed differently and then fought
    # an identical battle. Defaults are unchanged, so scores do not move.
    battle = run_benchmark_battle(
        player_models=players,
        ability_data=loader._abilities,
        reserve_models=reserves,
        benchmark_time=scenario.time_limit,
        target_defense=scenario.enemy_defense,
        target_hp=scenario.enemy_hp,
        target_atk=scenario.enemy_atk,
        target_speed=scenario.enemy_speed,
        target_attribute=scenario.enemy_attribute,
        immortal_players=scenario.immortal_players,
        boss=(
            load_boss(scenario.boss_id, scenario.boss_level)
            if scenario.boss_id
            else None
        ),
        regen_cd=scenario.regen_cd,
        trace=trace,
        record_casts=record_casts,
        tick_headroom=5.0,
    )
    return Result(
        damage=float(battle.player_damage_total),
        seed=seed,
        team_key=team.key(),
        scenario_key=scenario.key(),
        effective_time=float(battle.effective_time_limit),
        wiped=not any(p.is_alive for p in battle.players),
        deaths=sum(1 for p in battle.players if not p.is_alive),
        survival_time=float(battle.current_time),
        battle=battle if (trace or record_casts) else None,
    )


def score(
    team: TeamSpec,
    scenario: Optional[Scenario] = None,
    seeds: Sequence[int] = (0,),
    loader: Optional[GameDataSource] = None,
) -> ScoreResult:
    """Mean damage over ``seeds``.

    Pass the SAME seeds to both arms of a comparison (common random numbers): the
    per-battle sd is ~1.1% of the mean, but paired differences under shared seeds
    are far tighter, so an A/B needs a handful of seeds rather than dozens.

    When selecting a winner over many candidates, re-score the winner on FRESH
    seeds before reporting it -- picking and reporting on the same seeds inflates
    the reported value by roughly sd*sqrt(2*ln(candidates)).
    """
    scenario = scenario or Scenario()
    vals = [simulate(team, scenario, s, loader=loader).damage for s in seeds]
    return ScoreResult(
        mean=mean(vals),
        sd=stdev(vals) if len(vals) > 1 else 0.0,
        n=len(vals),
        team_key=team.key(),
        scenario_key=scenario.key(),
        per_seed=vals,
    )
