"""World bosses 1-4, straight from game config.

The MC benchmark fights an immortal dummy, which makes survivability
unmeasurable. This module supplies the real thing: HP/defense from ``wbLv``, the
five per-boss skills from ``wbSkill`` (same ``ie``/``ts``/``de`` grammar the card
skills use), the two cast timelines, and the fight's state machine.

Everything here is pure data plus one pure state function -- no engine imports --
so the rotation and the state machine can be tested without building a Battle.
The engine side lives in ``Battle._boss_phase``.

Boss behaviour (state transitions, rotation wrap, the damage check) is
documented under ``docs/`` -- see the World Boss timing and skills notes.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Dict, List, Optional, Tuple

from .data_loader import GameDataLoader, SkillData, get_loader, ie_damage  # noqa: F401

# Names are not in config -- they come from the drama/NPC ids and are hardcoded
# in otogidb/src/lib/worldBossParser.ts. Mirror that map so the sim and the site
# agree. (docs/data/WORLD_BOSS_SKILLS.md says "Kanoe" for boss 4; the site says
# "Kanoto" and is what users actually see.)
BOSS_NAMES = {1: "Kinoe", 2: "Hinoto", 3: "Mizunoe", 4: "Kanoto"}

# The boss has no ATK column anywhere in config -- not in wbLv, not in monster,
# not in npc. Every point of its damage comes from a scheduled cast's own `ie`
# value, so the default is no auto-attack at all.
#
# The bench dummy's ATK 3500 is NOT a survival-calibrated number: it was only
# ever measured against immortal players. Handing it to the boss makes every
# team wipe inside 45s of a 300s fight (measured: 42.1s), which is the mode's
# own failure sanity-check.
#
# CONFIRMED by live observation 2026-09-09 (244s against boss 2/4 at lv16-30):
# the boss never swings a normal attack -- it deals damage only through its
# scheduled casts, and its attack timer never advances. --boss-auto-atk is for
# what-if runs only. See the World Boss timing notes under docs/.
DEFAULT_BOSS_AUTO_ATK = 0
DEFAULT_BOSS_SPEED = 1300


class BossState(IntEnum):
    """The five states the boss moves through during a 5-minute fight."""

    NORMAL = 1
    CRAZY_PREPARE = 2
    CRAZYING = 3
    CRAZY = 4
    KILL_ALL = 5


def _hp_threshold(raw: object, default: float) -> float:
    """``"HP<100000,0>"`` -> 100000.0."""
    m = re.match(r"HP<(-?[\d.]+)", str(raw or ""))
    return float(m.group(1)) if m else default


@dataclass(frozen=True)
class BossTiming:
    """The wb_* constants that drive the state machine. Seconds, except damage."""

    # Enrage telegraph, in fight seconds. Observed in play at 240.06s (2026-09-30)
    # and ~239.8s (2026-09-09, boss 2 Lv30), and 240.05s (2026-10-01, boss 3 Lv1).
    # Pinned to the fight clock: TIME extensions do not move it, they only lengthen
    # the enraged loop afterwards. The boss does not cast during the telegraph.
    kill_skill_start: float = 240.0
    kill_countdown: float = 10.0  # wb_kill_countdown
    # Interrupt success (observed once, 2026-10-01): 100K was crossed 0.53s into
    # the telegraph and CRAZYING began at 3.26s. Modelled as a minimum telegraph
    # length. ponytail: one sample -- "crossing + 2.7s" fits it equally well.
    kill_interrupt_min: float = 3.26
    # CRAZY starts at a fixed fight time: `wb_kill_skill_start` (4.42) is MINUTES
    # = 265.2s, observed 265.27s. Until then (CRAZYING) the boss is NOT stunned:
    # it restarts `s` from the top with an immediate cast, already enraged.
    crazy_start: float = 265.2
    # Damage the team must deal during the telegraph to avoid KILL_ALL. Read from
    # `wb_kill_interrupt_hp` (HP<100000,0>), NOT `wb_kill_interrupt` (60000): a
    # 2026-09-30 capture dealt ~79K in the window and still got KILL_ALL.
    kill_interrupt: float = 100000.0
    # wb_kill_skill_atk: a PERCENT added to the boss's own damage modifier, never
    # removed. Measured 2026-10-01: live from the first CRAZYING cast (1725 ->
    # 2587 on ranged). Applied on entering CRAZYING or KILL_ALL.
    #
    # This is the ONLY source of damage growth on bosses 2 and 4, whose fifth
    # skill is a self-cleanse rather than the self-buff bosses 1 and 3 carry
    # (`ATK<30.00%,0.99%,15>` and `ATK<70.00%,0.99%,8>`). Without it their damage
    # is identical at t=0 and t=350 and enrage changes only cast frequency.
    #
    kill_skill_atk: float = 50.0
    # Orb economy in world boss (observed 2026-09-30, boss 2 Lv30): the pool opens
    # at exactly 3 (three +1 grants in the first 2.5s, vs the random 1-3 wave grant
    # of normal content) and regens one orb per ~5.44s (44 gaps, 5.33-5.55s). Both
    # match config (wb_start_skill_pts / wb_skill_pts_drop), so config is used.
    start_skill_pts: int = 3
    skill_pts_drop: float = 5.5
    # The boss's own clock advances at 0.9807x the battle clock (observed in play
    # 2026-09-30: boss time + battle time-remaining fell linearly 300.11 -> 295.36
    # over 246s). So its 5s cast slots are ~5.10s of player time and the 240s
    # enrage lands at ~244.7s. Measured at 3.2x battle speed only.
    clock_rate: float = 0.9807
    # Seconds from a boss cast to its hit landing (observed 2026-09-30): targeted
    # skills ~1.8s (damage) with their debuffs at +0.9-2.2s; the self-cleanse
    # +0.64s. Animation-driven; one averaged value per kind until the clips are read.
    impact_delay: float = 1.8

    @classmethod
    def from_constants(cls, constants: Dict[str, str]) -> "BossTiming":
        def num(name: str, default: float) -> float:
            try:
                return float(constants[name])
            except (KeyError, TypeError, ValueError):
                return default

        return cls(
            kill_countdown=num("wb_kill_countdown", 10.0),
            crazy_start=num("wb_kill_skill_start", 4.42) * 60.0,
            kill_interrupt=_hp_threshold(
                constants.get("wb_kill_interrupt_hp"), 100000.0
            ),
            kill_skill_atk=num("wb_kill_skill_atk", 50.0),
            start_skill_pts=int(num("wb_start_skill_pts", 3)),
            skill_pts_drop=num("wb_skill_pts_drop", 5.5),
        )


@dataclass(frozen=True)
class BossSpec:
    """One world boss at one level: what it is and what it does."""

    boss_id: int
    level: int
    name: str
    hp: int
    defense: float
    skills: Dict[int, SkillData]
    s_rotation: Tuple[Tuple[float, int], ...]
    ks_rotation: Tuple[Tuple[float, int], ...]
    # Skills whose `ie` is ERASE_DEBUFF: bosses 2 and 4 cleanse themselves
    # instead of self-buffing. Not expressible as a stat modifier, so the engine
    # special-cases these ids.
    cleanse_skills: frozenset[int] = frozenset()
    timing: BossTiming = field(default_factory=BossTiming)
    auto_atk: int = DEFAULT_BOSS_AUTO_ATK
    speed: int = DEFAULT_BOSS_SPEED

    def rotation(self, state: "BossState") -> Tuple[Tuple[float, int], ...]:
        """`ks` once enraged, `s` before that."""
        if state in (BossState.CRAZY, BossState.KILL_ALL):
            return self.ks_rotation
        return self.s_rotation

    def key(self) -> tuple:
        """Identity for a Scenario key. Level pins hp/defense/rotations."""
        return (self.boss_id, self.level, self.auto_atk, self.speed)


def parse_rotation(spec: str) -> Tuple[Tuple[float, int], ...]:
    """``"5,1;10,2"`` -> ``((5.0, 1), (10.0, 2))``, sorted by time."""
    out: List[Tuple[float, int]] = []
    for part in (spec or "").split(";"):
        part = part.strip()
        if not part:
            continue
        t, _, sid = part.partition(",")
        out.append((float(t), int(sid)))
    return tuple(sorted(out))


def parse_target_spec(ts: str) -> Tuple[int, Optional[List[int]]]:
    """``ts`` -> ``(target_count, prof_priority_order)``.

    ``count<N>`` and ``range_front<N.N>`` both give the count (front-N is the
    first N slots). ``prof<a,b,c>`` on a boss skill is a *priority order*, not
    the membership filter the card-side ``_apply_target_filter`` treats it as --
    boss rows list all three roles, so filtering on it is a no-op and would
    silently discard the targeting the skill actually describes.
    """
    count = 1
    m = re.search(r"count<(\d+)>", ts)
    if m:
        count = int(m.group(1))
    else:
        m = re.search(r"range_front<([\d.]+)>", ts)
        if m:
            count = int(float(m.group(1)))
    prof = re.search(r"prof<([\d,]+)>", ts)
    order = [int(x) for x in prof.group(1).split(",")] if prof else None
    return count, order


def load_boss(
    boss_id: int,
    level: int = 30,
    auto_atk: Optional[int] = None,
    loader: Optional[GameDataLoader] = None,
) -> BossSpec:
    """Build a BossSpec from output/data/wbLv.json + wbSkill.json."""
    loader = loader or get_loader()
    row = loader.get_wb_level(boss_id, level)
    if row is None:
        raise ValueError(f"no wbLv row for boss {boss_id} level {level}")

    skills: Dict[int, SkillData] = {}
    cleanse: List[int] = []
    for skill_id, raw in loader.get_wb_skills(boss_id).items():
        sd = loader.skill_from_raw(skill_id, raw)
        sd.slv1, sd.slvup = ie_damage(raw.get("ie", "none"))
        sd.target_count, _ = parse_target_spec(raw.get("ts", ""))
        skills[skill_id] = sd
        if str(raw.get("ie", "")).startswith("ERASE_DEBUFF"):
            cleanse.append(skill_id)

    return BossSpec(
        boss_id=boss_id,
        level=level,
        name=BOSS_NAMES.get(boss_id, f"Boss {boss_id}"),
        hp=int(row["hp"]),
        defense=float(row["defense"]),
        skills=skills,
        s_rotation=parse_rotation(row.get("s", "")),
        ks_rotation=parse_rotation(row.get("ks", "")),
        cleanse_skills=frozenset(cleanse),
        timing=BossTiming.from_constants(loader._constants),
        auto_atk=DEFAULT_BOSS_AUTO_ATK if auto_atk is None else auto_atk,
    )


def next_boss_state(
    state: BossState,
    t_state: float,
    t_total: float,
    damage_since_prepare: float,
    timing: BossTiming,
) -> BossState:
    """The fight's state machine. Returns the state for this instant.

    Reach ``wb_kill_interrupt`` damage during the telegraph (CRAZY_PREPARE) and the
    boss moves to CRAZYING once the telegraph has run ``kill_interrupt_min``
    (observed 2026-10-01). Miss it and KILL_ALL fires at the end of the 10s
    countdown -- observed 2026-09-30 at exactly prepare + 10.02s. CRAZYING lasts
    until the fixed ``crazy_start`` fight time, then CRAZY loops `ks`.

    CRAZY is terminal in practice: it loops `ks` until the battle timer ends.
    KILL_ALL is the failure branch, NOT a timeout out of CRAZY, and there is no
    path back to NORMAL.
    """
    if state == BossState.NORMAL:
        if t_total >= timing.kill_skill_start:
            return BossState.CRAZY_PREPARE
    elif state == BossState.CRAZY_PREPARE:
        if (
            damage_since_prepare >= timing.kill_interrupt
            and t_state >= timing.kill_interrupt_min
        ):
            return BossState.CRAZYING
        if t_state >= timing.kill_countdown:
            return BossState.KILL_ALL
    elif state == BossState.CRAZYING:
        if t_total >= timing.crazy_start:
            return BossState.CRAZY
    return state
