"""Selecting and installing the skill-casting policy.

This lived in ``monte_carlo`` -- the *search* module -- so the scoring contract
(``spec.py``) and the per-card benchmark both had to import from the team searcher
to find out how skills get cast. That is backwards: the policy is a property of the
fight, not of the thing searching for teams.

The default matters more than it looks. ``MC_SCHEDULER`` unset used to mean "no
scheduler at all", which scores a team at roughly HALF its damage, and three of the
seven CLI commands were in that state. It now defaults to cadence everywhere.
"""

from __future__ import annotations

import os


def resolve_scheduler(explicit: str | None, roster_active: bool) -> str:
    """Decide the skill-cast policy for a run. Default: "cadence".

    An explicit --scheduler always wins. Otherwise every run gets cadence —
    teams should be scored played well (buffs grouped, then carries dumped),
    which both scores higher and reproduces on re-scoring.

    Non-roster runs used to fall back to "apl" to keep canonical tier generation
    unchanged. That made the standard tier path the ONE path not using the
    default, so it disagreed with every hand-run benchmark. Tier lists generated
    before 2026-08-25 are already not comparable (self-amp ordering, skill-tick
    decoupling, stagger_amp), so there is nothing left to preserve by splitting.
    """
    if explicit:
        return explicit.lower()
    return "cadence"


# Retired 2026-11-03: raced against `plan` on 750 searched teams (bosses 2/3/4,
# Lv1 + Lv30, a roster), none beat it on any team once re-scored on fresh seeds.
# Mean shortfall vs the best policy: survival 11.7%, standalone chain 13.9%, window
# 15.7%, ramp 19.8%. Names raise so an old script cannot silently score with no
# scheduler (an unknown name installs nothing, ~half the damage).
RETIRED = {
    n: "use plan (the default for searches) or cadence; see scripts/scheduler_race.py"
    for n in ("survival", "planner", "window", "chain", "ramp")
}


def install_cadence_scheduler() -> bool:
    """Install a team-level scheduler on this process's APL engine from MC_SCHEDULER.

    **cadence is the DEFAULT** (2026-08-25). Env vars propagate to spawned workers
    on Windows. Params are all relative — no absolute damage number, so teams are
    compared at their best without a gameable floor.

        MC_SCHEDULER=cadence     MC_CADENCE_CYCLE (20.5)  MC_CADENCE_CPC (1)
        (default)                MC_CADENCE_STAGGER_AMP (1)
                                 MC_CADENCE_SELECT_FRAC  MC_CADENCE_WINDOW_FRAC
                                 MC_CADENCE_END_DUMP
        MC_SCHEDULER=none        no rotation policy (legacy; ~half the damage)

        MC_SCHEDULER=group       MC_GROUPS (JSON [["P1","P2"],["P3"]])
                                 MC_GROUP_SKIP_AFTER (8)
                                 player-authored cast groups; drives the web calculator

        MC_SCHEDULER=plan        MC_PLAN_FORCE (short|long)  MC_PLAN_REPLAN (0)
                                 MC_PLAN_GROUPS (player casters/groups, JSON)
                                 two-phase cycle switch (cost 1 -> carry x3/40s):
                                 MC_CYCLE_SWITCH_CAP (both:1.2+bank; off = bank only;
                                   auto|skill|both|either:<ratio>[+bank])
                                 MC_CYCLE_SWITCH_AT (s)  MC_CYCLE_NEED (orbs)
                                 MC_CYCLE_DROP (slots left out of the long phase)
                                 MC_PLAN_CC_DODGE (3:0.18 = horizon s:risk; off)
                                 MC_GROUP_* burst knobs (planner skip_after 10)

        MC_SCHEDULER=replay      MC_REPLAY_CASTS ({"P1": [t | [t, max_cost] |
                                 [t, max_cost, lead_slot, lag]], ...})

    'cadence' groups buffs into a window then dumps carries; 'plan' picks the
    shape (burst, chain, amp-chain timeline, two-phase cycle) from the kit and is
    what the team search runs. survival/planner/window/chain/ramp are in RETIRED.

    Returns True if a scheduler was installed.
    """
    # DEFAULT: cadence. Unset used to mean "no scheduler at all", which is a
    # silent ~2x damage cut -- a caller that did everything else right but forgot
    # MC_SCHEDULER got a team scored without any rotation policy. That is how the
    # 74.4M reference team came to re-score at 34.3M and look like a regression.
    # Set MC_SCHEDULER=none (or off/legacy) to deliberately run without one.
    which = (os.environ.get("MC_SCHEDULER") or "cadence").lower()
    from .engine import get_engine

    if which in RETIRED:
        raise ValueError(f"MC_SCHEDULER={which!r} was retired: {RETIRED[which]}")
    if which in ("none", "off", "legacy", "-"):
        get_engine().scheduler = None
        return False

    if which == "cadence":
        from .scheduler import CadenceScheduler

        get_engine().scheduler = CadenceScheduler(
            cycle=float(os.environ.get("MC_CADENCE_CYCLE", "20.5")),
            casts_per_carry=int(os.environ.get("MC_CADENCE_CPC", "1")),
            carry_select_frac=float(os.environ.get("MC_CADENCE_SELECT_FRAC", "0.5")),
            window_frac=float(os.environ.get("MC_CADENCE_WINDOW_FRAC", "0.85")),
            end_dump=float(os.environ.get("MC_CADENCE_END_DUMP", "8")),
            stagger_amp=os.environ.get("MC_CADENCE_STAGGER_AMP", "1") != "0",
        )
        return True

    if which == "group":
        import json as _json

        from .scheduler import GroupScheduler

        # Group layout is structured, so it rides one JSON env var rather than a
        # scalar per knob. Shape: [["P1","P2"],["P3"]] -- priority left to right,
        # slots in no group never cast.
        raw = os.environ.get("MC_GROUPS", "[]")
        try:
            groups = _json.loads(raw)
        except ValueError:
            groups = []
        # {"P2": "P3"} -- P2 retires when a carry's autos cap and P3 takes over.
        try:
            swap = _json.loads(os.environ.get("MC_GROUP_SWAP", "{}"))
        except ValueError:
            swap = {}
        # {"1": 11} -- group 1's first opening is due 11s in (fixed-grid phase).
        try:
            offset = _json.loads(os.environ.get("MC_GROUP_OFFSET", "{}"))
        except ValueError:
            offset = {}
        get_engine().scheduler = GroupScheduler(
            groups=groups,
            offset=offset,
            speed_stagger=os.environ.get("MC_GROUP_SPEED_STAGGER", "0") != "0",
            # {"P1": "skills"} -- P1 stops casting once a carry's skill caps without it.
            retire=_json.loads(os.environ.get("MC_GROUP_RETIRE", "{}") or "{}"),
            protect_lead=os.environ.get("MC_GROUP_PROTECT_LEAD", "0") != "0",
            # [["P1", 1], ["P4", 4]] -- dump this sequence when the orb pool is full.
            overflow=_json.loads(os.environ.get("MC_GROUP_OVERFLOW", "[]") or "[]"),
            overflow_after=float(os.environ.get("MC_GROUP_OVERFLOW_AFTER", "0")),
            overflow_horizon=float(os.environ.get("MC_GROUP_OVERFLOW_HORIZON", "0")),
            # {"P4": 2} -- P4 may cast at cost 2-3 when the pool keeps >= 2 after.
            rich=_json.loads(os.environ.get("MC_GROUP_RICH", "{}") or "{}"),
            rich_window=os.environ.get("MC_GROUP_RICH_WINDOW", "1") != "0",
            skip_after=float(os.environ.get("MC_GROUP_SKIP_AFTER", "8")),
            stagger_amp=os.environ.get("MC_CADENCE_STAGGER_AMP", "1") != "0",
            swap=swap,
            hold_cc=float(os.environ.get("MC_GROUP_HOLD_CC", "0")),
            end_dump=float(os.environ.get("MC_GROUP_END_DUMP", "8")),
            swap_when=os.environ.get("MC_GROUP_SWAP_WHEN", "autos"),
            cc_mid=os.environ.get("MC_GROUP_CC_MID", "skip"),
            cc_wait=float(os.environ.get("MC_GROUP_CC_WAIT", "6")),
            cleanse_dodge=float(os.environ.get("MC_GROUP_CLEANSE_DODGE", "4")),
            amp_wait=os.environ.get("MC_GROUP_AMP_WAIT", "1") != "0",
            buffer_wait=float(os.environ.get("MC_GROUP_BUFFER_WAIT", "6")),
            late_carry=float(os.environ.get("MC_GROUP_LATE_CARRY", "1")),
        )
        return True

    if which == "plan":
        import json as _json

        from .scheduler import PlanScheduler

        get_engine().scheduler = PlanScheduler(
            force=os.environ.get("MC_PLAN_FORCE", ""),
            replan=os.environ.get("MC_PLAN_REPLAN", "0") != "0",
            groups=_json.loads(os.environ.get("MC_PLAN_GROUPS", "[]") or "[]"),
            late_carry=float(os.environ.get("MC_GROUP_LATE_CARRY", "1")),
            chain={"1": "timeline"}.get(
                os.environ.get("MC_PLAN_CHAIN", "timeline"),
                os.environ.get("MC_PLAN_CHAIN", "timeline"),
            ),
            chain_margin=float(os.environ.get("MC_CHAIN_MARGIN", "0.5")),
            chain_recover=os.environ.get("MC_CHAIN_RECOVER", "skip:4+dump"),
            chain_close=os.environ.get("MC_CHAIN_CLOSE", "1") != "0",
            chain_swap_k=float(os.environ.get("MC_CHAIN_SWAP_K", "16") or 0),
            keeper_dodge=tuple(
                float(x)
                for x in os.environ.get("MC_KEEPER_DODGE", "").split(":")
                if x and x != "off"
            ),
            cycle_switch_at=(
                float(os.environ["MC_CYCLE_SWITCH_AT"])
                if os.environ.get("MC_CYCLE_SWITCH_AT")
                else None
            ),
            cycle_need=int(os.environ.get("MC_CYCLE_NEED", "0") or 0),
            cycle_switch_cap=os.environ.get("MC_CYCLE_SWITCH_CAP", "both:1.2+bank"),
            cycle_drop=os.environ.get("MC_CYCLE_DROP", ""),
            # Group timing knobs, forwarded only when set (defaults unchanged):
            # lets a scan tune the planner's burst the way it tunes `group`.
            group_kw={
                k: cast(os.environ[e])
                for k, e, cast in (
                    ("skip_after", "MC_GROUP_SKIP_AFTER", float),
                    ("cc_mid", "MC_GROUP_CC_MID", str),
                    ("cc_wait", "MC_GROUP_CC_WAIT", float),
                    ("cleanse_dodge", "MC_GROUP_CLEANSE_DODGE", float),
                    ("buffer_wait", "MC_GROUP_BUFFER_WAIT", float),
                    ("hold_cc", "MC_GROUP_HOLD_CC", float),
                )
                if os.environ.get(e)
            },
            cc_dodge=tuple(
                float(x)
                for x in os.environ.get("MC_PLAN_CC_DODGE", "3:0.18").split(":")
                if x and x != "off"
            ),
        )
        return True

    if which == "replay":
        import json as _json

        from .scheduler import ReplayScheduler

        # {"P2": [4.2, 28.0, ...], ...} -- a captured fight's cast times per slot.
        get_engine().scheduler = ReplayScheduler(
            _json.loads(os.environ.get("MC_REPLAY_CASTS", "{}") or "{}")
        )
        return True

    return False
