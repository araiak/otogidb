"""
Pool-and-burst rotation scheduler (the 40s-rotation model).

The community rotation is: pool orbs, then burst — cast the buffs together, then
dump the carry skills while the buffs are peaked — then pool again. A reactive
per-unit APL can't express "wait for orbs then fire the whole group", so this is
a small team-level state machine consulted in place of the APL rules.

Phases (hysteresis on the team orb pool):
  POOL   : hold everything until team orbs >= pool_target.
  BURST  : buffers cast (peak the buffs); carries cast only when their projected
           crit is near cap (which is only true once the buffs have landed, so
           carries naturally fire AFTER the buffers). Continue until orbs drain
           to burst_floor, then return to POOL.

Tunable + meta-aware: buffers/carries are identified from each unit's own skill
flags, and the thresholds are params so we can min-max per team.
"""

from __future__ import annotations

import math
import os
import re
from typing import Any

from .payload import amp_effects, skill_payload
from .state import _buff_remains, _source_matches, _team_buff_remains, skill_flags
from .state import APL_PROJECTION_EXCEED
from .window_value import _DMG_MULT_WEIGHT, value_per_orb

# Stats whose ALLY-side version is defensive and worth no damage; only the
# enemy-side (negative) version is a damage amplifier.
_DEFENSIVE_ON_ALLY = ("SHIELD", "DEF", "DEFENSE")
_TEAM_SIZE = 5

# Slots that never cast under CadenceScheduler -- the player's "this card sits out"
# decision, made per TEAM by measurement (scripts/medium_sweep.py tries each slot)
# rather than mid-fight by a rule. Two in-fight rules (value trim, starvation-gated
# trim) each helped some teams +40% and cost others -10% (2026-10-02).
FORCED_SKIP: set[str] = set()

# Parse a buff/debuff effect token: TYPE<base%,scale%,dur>  ->  (TYPE, base).
_BUFF_EFF_RE = re.compile(r"([A-Z_]+)<(-?[\d.]+)(%?),")


def _buffer_signature(unit: Any) -> tuple[dict[str, float], int]:
    """(stat -> base magnitude%, target_count) for a buff-skill unit.

    Only percentage buffs are kept (a real stat buff, not a flat/duration token).
    Used to spot *dominated* buffers: a single-target buff whose stat is already
    provided to more targets at >= magnitude by another buffer is redundant.
    """
    sig: dict[str, float] = {}
    skill = getattr(unit, "skill", None)
    if skill is None:
        return sig, 1
    for eff in list(getattr(skill, "buff_effects", []) or []) + list(
        getattr(skill, "debuff_effects", []) or []
    ):
        m = _BUFF_EFF_RE.match(eff.strip())
        if not m or not m.group(3):  # require '%' — skip flat/CC tokens
            continue
        stat, mag = m.group(1), float(m.group(2))
        if mag > sig.get(stat, float("-inf")):
            sig[stat] = mag
    return sig, int(getattr(skill, "target_count", 1) or 1)


# The cycle constants below (20.5s) were tuned at the 5.0s orb regen of normal
# content, where a cycle funds ~4.1 casts. World boss regens every 5.5s, so a
# fixed 20.5s cycle opens bursts the pool cannot fund and trims a buffer from
# teams that fit. Scaling by regen keeps the ORB budget per cycle constant
# (20.5s -> 22.55s at 5.5s); at 5.0s it is the identity, so the dummy is unchanged.
# Measured on boss 2 Lv30 (v2 team, 12 seeds): 20.5s 59.67M, 22.5s 60.47M,
# 23s 61.58M, 24s 59.87M.
REFERENCE_REGEN = 5.0


def scaled_cycle(cycle: float, battle: Any) -> float:
    """``cycle`` expressed at the battle's orb regen (seconds per orb)."""
    regen = float(getattr(battle, "skill_points_regen_cd", REFERENCE_REGEN) or 0)
    return cycle * (regen / REFERENCE_REGEN) if regen > 0 else cycle


def _note_buff(st: dict, battle: Any, caster: Any) -> None:
    """Record a buff cast and when its effect will land (per-caster delay)."""
    now = battle.current_time
    st["last_buff_at"] = now
    delay_for = getattr(battle, "skill_effect_delay_for", None)
    delay = delay_for(caster) if delay_for else 0.0
    st["buff_land_at"] = max(st.get("buff_land_at", now), now + delay)


class ScriptedRotation:
    """Execute a fixed cast sequence per cycle (test a known human rotation).

    sequence: ordered list of slots to cast, e.g.
        ['P1','P4','P3','P3','P5','P5']  = Sola, Orihime, HikoA x2, HikoB x2
    The current sequence slot casts as soon as it can afford (the engine gates on
    orbs + energy before calling this), then the position advances. When the
    sequence finishes it waits until `cycle_time` has elapsed since the cycle
    start (pooling orbs), then repeats. A slot that can't cast for `skip_after`
    seconds is skipped so the rotation doesn't deadlock.
    """

    def __init__(
        self, sequence: list[str], cycle_time: float = 40.0, skip_after: float = 8.0
    ) -> None:
        self.sequence = sequence
        self.cycle_time = cycle_time
        self.skip_after = skip_after
        self.pos = 0
        self.cycle_start = 0.0
        self._waiting_since = 0.0

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        now = battle.current_time
        # Sequence finished -> pool until the cycle window elapses, then restart.
        if self.pos >= len(self.sequence):
            if now - self.cycle_start >= self.cycle_time:
                self.pos = 0
                self.cycle_start = now
                self._waiting_since = now
            else:
                return False
        want = self.sequence[self.pos]
        if attacker.slot != want:
            # Deadlock guard: if the wanted slot has been stuck too long, skip it.
            if now - self._waiting_since > self.skip_after:
                self.pos += 1
                self._waiting_since = now
            return False
        # It's this slot's turn and it can afford (engine already checked).
        self.pos += 1
        self._waiting_since = now
        return True


class CadenceScheduler:
    """Time-cadence generalization of the human "buff then dump carries" rotation.

    Every ``cycle`` seconds a fresh burst opens: cast each buffer once
    (``buff & !damage``, synced by construction), then fire each *true carry* up
    to ``casts_per_carry`` times. In the last ``end_dump`` seconds everything is
    dumped (orbs are worthless after the bell).

    A carry is gated by two **relative** thresholds — no absolute damage number,
    so the policy puts *every* team in its best light and can't be gamed by
    absolute-damage inflation (a fixed floor let mediocre cards + strong assists
    clear a magic number and spam; the score then reflected the exploit, not the
    cards). The two roles a floor plays are split:

    - **Selection** — a unit is a spam-carry only if its peak projected crit is at
      least ``carry_select_frac`` of the *team's best* carry peak. This drops
      utility damage skills (a debuffer that merely *has* a damage skill) whose
      ceiling sits far below the real carries, on any team, at any magnitude.
    - **Timing** — a selected carry fires only when its *current* projected crit is
      at least ``window_frac`` of *its own* running peak, i.e. it is inside its
      buff window. Between bursts (buffs expired) its crit falls below that and it
      holds; the next buff refresh lifts it back and it fires.

    Peaks are per-unit running maxima of the forced-crit skill projection, tracked
    on the battle (``_carry_peak``); the projection reuses
    ``Battle.calculate_action_damage(force_crit=True)`` — no new damage math.

    Why time-cadence rather than an orb threshold: the orb pool caps (~10), so
    pooling to a high threshold leaks regen; a fixed cadence keeps orbs churning
    and spends the full ~72-orb budget. Affordability is still gated by the engine
    before ``should_cast`` is consulted, so this only expresses judgment.

    Per-burst state lives on the battle so one instance is safe to share across
    battles. Tuned on the Sola/Orihime + 2x Hikoboshi worldboss team -- a
    *2*-buffer team. The sync-block and buffs-first gates both scale with buffer
    count, so a 3+-buffer team (e.g. Mira/Nimbus/Ohina) pays a heavier tax than
    this class was ever validated against; a ramp-shaped buffer (see
    ``_ramp_profile``) is exempted from both gates for exactly that reason.
    """

    # Value trim fires only when carries logged at least this many orb-starved cast
    # checks (one per ~0.5s skill tick) in the previous cycle.
    starve_min = 2

    def __init__(
        self,
        cycle: float = 20.5,
        casts_per_carry: int = 1,
        carry_select_frac: float = 0.5,
        window_frac: float = 0.85,
        end_dump: float = 8.0,
        cost_target: int = 1,
        scarcity_order: bool = False,
        reserve_orbs: bool = False,
        stagger_amp: bool = True,
    ) -> None:
        self.cycle = cycle
        self.casts_per_carry = casts_per_carry
        self.carry_select_frac = carry_select_frac
        self.window_frac = window_frac
        self.end_dump = end_dump
        self.cost_target = cost_target
        self.scarcity_order = scarcity_order
        self.reserve_orbs = reserve_orbs
        # Hold a carry whose damage-amp debuff is ALREADY running on the target until
        # it is about to lapse, instead of re-applying it inside its own window.
        #
        # Why this matters: a duplicated carry (e.g. Hikoboshi in the active team AND
        # as the helper) fires both copies in the same burst, 0.3s apart. The amp is
        # already at the -75% shield floor from one cast, so the second adds no
        # magnitude -- it only refreshes a full window, buying ~0s of extra coverage.
        # Spacing the second cast to just before expiry roughly doubles amp uptime for
        # the same two orbs. Buff timing and the burst structure are untouched.
        self.stagger_amp = stagger_amp

    # -- orb-cost economy ---------------------------------------------------
    def _cost_ready(self, unit: Any, battle: Any) -> bool:
        """Has this unit's escalated orb cost decayed back to ``cost_target``?

        Skill cost escalates 1 -> 2 -> 3 per cast (``MonsterComponent.add_cast_cost``)
        and decays one step per ``BattleConfig.skill_minus_cost_cd`` (20s). So casting
        a unit ONCE per ~21s keeps every cast at 1 orb, while casting it twice inside a
        burst immediately pays 1+2 and then 2+3 on the following cycle.

        Measured on a world-boss team: the cliff sits exactly on the 20s constant —
        cycle 20 scores 45.9M, cycle 21 scores 69.98M, because at 21s every cast is
        affordable at 1 orb and the carries get 38 casts instead of 29.

        Gating on the *cost itself* rather than on a tuned cycle length means the
        rotation stays correct if ``skill_minus_cost_cd`` changes, and a unit whose
        cost has drifted to 2-3 simply waits one decay step instead of paying triple.
        """
        if int(getattr(unit, "need_cast_point", 1)) <= self.cost_target:
            return True
        # Safety valve: only hold if waiting can actually help. Decay runs one step
        # per 20s all the way back to 1 (measured in play), so a unit above
        # cost_target always has decay pending; if one ever does not, its cost is
        # as low as it will get and holding would be an indefinite lockout.
        return not bool(getattr(unit, "minus_cost_pending", False))

    # -- opening sync -------------------------------------------------------
    def _sync_block(self, battle: Any, pending_buffers: int) -> int:
        """Orbs the opening of a burst costs: every buffer still owing a cast,
        plus ONE carry.

        A buff lasts ~8s and orb income is 1 per 5s, so a burst that opens on a
        thin pool spends its orbs on buffs and then leaves the first nuke waiting
        for income until the window it was buffed for has lapsed. Measured on the
        reference world-boss team with the corrected 2-orb opening: the two
        buffers cast at 0.5s, the carry could not afford to cast until 10.2s, and
        the 8s crit window it was supposed to fire inside was already gone.

        Only the FIRST carry is counted. A second copy is free to lag -- the
        `window_frac` timing gate already refuses to let it fire outside its buff
        window, so delaying it buys amp uptime rather than losing the window.

        Clamped to the pool cap: a team whose opening block is larger than the
        pool could never open at all, and a burst that fires late beats one that
        never fires.
        """
        # Read the carry off the team's SKILLS, not off `_carry_peak_life`: that
        # dict is populated by projections, so it is empty on the opening tick --
        # exactly the moment this gate has to be right.
        carries = (
            1
            if any(
                p.is_alive
                and getattr(p, "skill", None) is not None
                and skill_flags(p.skill, p)["damage"]
                for p in battle.players
            )
            else 0
        )
        cap = int(getattr(battle, "skill_points_max", 10) or 10)
        return min(pending_buffers + carries, cap)

    def _opening_funded(self, battle: Any, pending_buffers: int) -> bool:
        return battle.skill_points >= self._sync_block(battle, pending_buffers)

    def _turn_rate(self, unit: Any) -> float:
        """Lower = acts less often. Used to let scarce actors claim orbs first.

        OFF BY DEFAULT (``scarcity_order=False``) — measured neutral-to-negative.
        The theory was sound: on the reference world-boss team Sola takes 36 turns
        over 390s against Hikoboshi's 325, and casts only 10 of a possible 18
        cycles, so a window she misses looks unrecoverable. But letting her claim
        orbs first does not change her cast count and costs ~0.4% overall
        (cycle 20: 71.67M with the ordering off vs 71.37M on). Retained behind a
        flag because it may matter on teams with more competing slow buffers;
        do not enable it without re-measuring.

        ``stat.final_speed`` is an attack *interval* (higher is slower), so a healer at
        ~4370 acts far less than a ranged carry at ~2795. Measured over 390s: Sola took
        36 turns against Hikoboshi's 325, so a window Sola misses is one she cannot get
        back, while a carry has hundreds of chances.
        """
        st = getattr(unit, "stat", None)
        spd = float(getattr(st, "final_speed", 0.0) or 0.0) if st else 0.0
        return 1.0 / spd if spd > 0 else 0.0

    def _orbs_reserved(self, battle: Any, st: dict, exclude: str) -> int:
        """Orbs owed by units that still have a cast pending this burst.

        OFF BY DEFAULT (``reserve_orbs=False``) — measured neutral-to-negative,
        same as ``scarcity_order`` (cycle 20: 71.57M on vs 71.76M with both off).
        The cost gate already prevents the starvation this was meant to fix: once
        every unit casts at 1 orb, the pool is deep enough that a carry taking an
        orb early does not deny a buffer later. Kept behind a flag for team shapes
        with a tighter orb budget; re-measure before enabling.

        Without this a carry spends the orb a buffer is waiting on: Sola casts only 10
        of a possible 18 cycles despite having enough turns, because she is last in line
        and her cost had escalated. Reservation is skipped once the cycle is nearly over
        so a unit that cannot act (dead, silenced, no turn left) never deadlocks the pool.
        """
        if not self.reserve_orbs:
            return 0
        if battle.current_time - st["start"] > scaled_cycle(self.cycle, battle) * 0.75:
            return 0  # late in the burst — let anyone spend
        owed = 0
        dominated = self._skipped_buffers(battle)
        for p in battle.players:
            if not p.is_alive or p.slot == exclude or p.skill is None:
                continue
            if p.slot in st["buffed"] or p.slot in dominated:
                continue
            f = skill_flags(p.skill, p)
            if f["buff"] and not f["damage"] and self._cost_ready(p, battle):
                owed += int(getattr(p, "need_cast_point", 1))
        return owed

    def _casting_slots(self, battle: Any) -> set[str] | None:
        """Slots this policy will actually cast, or None for "everyone alive".

        Domination asks whether another buffer ALREADY supplies this stat. A buffer
        that is never going to cast supplies nothing, so it cannot dominate anything.
        The base policy casts whoever is alive; `GroupScheduler` knows better.
        """
        return None

    def _dominated_buffers(self, battle: Any) -> set[str]:
        """Slots of buffers that are redundant this battle — a same-stat buff is
        already provided to >= targets at >= magnitude by another buffer THAT CASTS,
        so casting them just burns orbs (e.g. Classic Alice's single-target ATK buff
        when Orihime gives the same 35% ATK to two targets).

        Removing the rule entirely measured -11.7% on the player's Odairi team and
        0.0% on thirteen others, so it earns its place -- but only against a supplier
        that is really in the rotation. It used to mute a copy on behalf of a card
        sitting in the "do not cast" bucket or already retired by a swap, which is
        how a retired Nimbus left its replacement muted and ~15 orbs of income
        unspent: 63 casts against 78 orbs, where not swapping at all casts 70.

        Cached per battle AND per casting set, because that set changes when someone
        dies or a swap fires -- the old cache was computed once on the opening tick
        and never revisited, so `is_alive` below was effectively frozen there.
        """
        casting = self._casting_slots(battle)
        ckey = None if casting is None else frozenset(casting)
        cached = getattr(battle, "_dominated_buffers_cache", None)
        if cached is not None and cached[0] == ckey:
            return cached[1]
        buffers = []
        for p in battle.players:
            if not p.is_alive or p.skill is None:
                continue
            if casting is not None and p.slot not in casting:
                continue
            f = skill_flags(p.skill, p)
            if f["buff"] and not f["damage"]:
                sig, tc = _buffer_signature(p)
                if sig:
                    buffers.append((p.slot, sig, tc))
        dominated: set[str] = set()
        for slot, sig, tc in buffers:
            for oslot, osig, otc in buffers:
                if oslot == slot:
                    continue
                # o covers every stat of this buffer at >= magnitude and >= targets
                covers = all(
                    stat in osig and osig[stat] >= mag for stat, mag in sig.items()
                )
                if not covers or otc < tc:
                    continue
                strictly_better = otc > tc or any(
                    osig[stat] > mag for stat, mag in sig.items()
                )
                # Strictly-better dominates; exact ties broken by slot so identical
                # buffers don't mutually cancel (keep the lower slot, drop the rest).
                if strictly_better or oslot < slot:
                    dominated.add(slot)
                    break
        battle._dominated_buffers_cache = (ckey, dominated)
        return dominated

    def _value_trim(self, battle: Any) -> set[str]:
        """Every buffer the orb budget cannot fund, lowest damage value first.

        ``MC_CADENCE_TRIM=value``. The surplus rule below drops at most ONE buffer and
        only a surplus copy, because its weights cannot compare stats across buckets
        -- so a sole-source weak buffer casts every cycle on an orb-bound team. On
        boss 3 Lv1 the Anima core (Mira/Nimbus/Ohina/Odairi) scored 47.1M under it
        against 51.0M with Ohina out of the rotation, while a team with nothing worth
        dropping lost 0.2% (2026-10-02).

        Value here is what the engine multiplies: per carry, damage is a product of
        buckets -- additive inside one, multiplicative across -- so a buff is worth
        P(stats + buff) / P(stats) - 1, weighted by the carry's share of team damage.
        Crit rate caps at 100% and the enemy amp at 75%, so a buff into a capped
        bucket is worth ~0, and crit rate is worth a lot exactly when crit damage is
        stacked high (the Tsukuyomi case the surplus gate exists for). A buffer with
        an effect this cannot price is never dropped.

        OFF BY DEFAULT -- measured mixed on the 200-core validation set (2026-10-02):
        it changed ~5% of teams, from +50% to -13%, mostly by dropping a healer
        leader (Mira, Sola) whose carries were not actually orb-short. Gating it on
        `Battle._orb_starved` made it fire more, not more accurately. The bench is
        now chosen by measurement instead (FORCED_SKIP + scripts/medium_sweep.py).
        """
        life = getattr(battle, "_carry_peak_life", None)
        if not life:
            return set()
        buffers = [
            p
            for p in battle.players
            if p.is_alive
            and getattr(p, "skill", None) is not None
            and (lambda f: f["buff"] and not f["damage"])(skill_flags(p.skill, p))
            and not _ramp_profile(p)[0]
            and p.slot not in self._dominated_buffers(battle)
        ]
        best = max(life.values())
        carries = [s for s, v in life.items() if v >= self.carry_select_frac * best]
        # Trim only on MEASURED starvation: a carry ready at base cost with an empty
        # pool during the last cycle. Counting casters against the budget alone
        # dropped Mira / Sola on teams whose carries already cast every cycle -- the
        # freed orb had no taker and the buff was simply lost (-8%..-11%).
        starved = getattr(battle, "_orb_starved", {})
        now = sum(starved.get(s, 0) for s in carries)
        prev = getattr(battle, "_starve_mark", 0)
        battle._starve_mark = now
        if now - prev < self.starve_min:
            return set()
        # Ramp casters spend orbs too: the Anima core's Nimbus cast 14 times, the
        # most on the team, while its one carry got 9. Leaving them out of the
        # demand is how a 5-caster team looked like it fit a 4-cast budget.
        ramps = sum(
            1
            for p in battle.players
            if p.is_alive
            and getattr(p, "skill", None) is not None
            and _ramp_profile(p)[0]
        )
        # Same budget as suggest.budget: cost decay / the 5.0s rate, not world boss's
        # 5.5s -- boss CC pauses the decay and stretches the real cycle, so four casts
        # per cycle still fit in play (player-confirmed 2026-09-30).
        decay = float(getattr(battle.config, "skill_minus_cost_cd", 20.0) or 20.0)
        budget = max(1, int(decay // 5.0))
        over = len(buffers) + ramps + len(carries) * self.casts_per_carry - budget
        if over <= 0 or not buffers:
            return set()

        by_slot = {p.slot: p for p in battle.players}
        enemy = next((e for e in getattr(battle, "enemies", []) if e.is_alive), None)
        amp0 = -enemy.stat.shield_modifier.get_percentage_sum() if enemy else 0.0
        total_life = sum(life[s] for s in carries) or 1.0

        def stats(u: Any) -> dict[str, float]:
            st_ = u.stat
            return {
                "dmg": st_.damage_modifier.get_percentage_sum(),
                "rate": st_.crit_modifier.final_value * 100,
                "cdmg": st_.crit_dmg_modifier.get_percentage_sum(),
                "skill": st_.skill_dmg_modifier.get_percentage_sum(),
                "spd": st_.speed_modifier.get_percentage_sum(),
                "amp": amp0,
            }

        def product(s: dict[str, float]) -> float:
            rate = min(100.0, s["rate"]) / 100
            crit = 1 + rate * (2 * (1 + s["cdmg"] / 100) - 1)
            chan = 0.5 * (1 + s["skill"] / 100) + 0.5 / (1 - min(100.0, s["spd"]) / 200)
            return (1 + s["dmg"] / 100) * crit * chan * (1 + min(75.0, s["amp"]) / 100)

        bucket = {
            "ATK": "dmg",
            "CHIT": "rate",
            "CHIT_ATK": "cdmg",
            "SKILL_ATK": "skill",
            "SPD": "spd",
        }
        base = {s: stats(by_slot[s]) for s in carries if s in by_slot}
        order = sorted(base, key=lambda s: -life[s])
        values: dict[str, float] = {}
        for p in buffers:
            sk = p.skill
            sel = str(getattr(sk, "target_selector", "") or "")
            n_t = int(getattr(sk, "target_count", 1) or 1)
            gain, priced = 0.0, True
            for eff in skill_payload(p, p.model.level if p.model else 1):
                if eff.on_enemy:
                    if eff.raw_type == "SHIELD" and eff.magnitude < 0:
                        keys, field, mag = order, "amp", -eff.magnitude
                    else:
                        continue  # CC / boss debuffs: no damage bucket
                elif eff.raw_type in _DEFENSIVE_ON_ALLY or eff.raw_type in (
                    "HEAL",
                    "HP",
                ):
                    continue  # defence buys nothing in a damage race
                elif eff.raw_type in bucket:
                    field, mag = bucket[eff.raw_type], eff.magnitude
                    if "max_atk" in sel:
                        keys = order[:n_t]
                    elif n_t >= _TEAM_SIZE:
                        keys = order
                    else:  # unfiltered partial spray: covers carries in proportion
                        keys, mag = order, mag * n_t / _TEAM_SIZE
                else:
                    priced = False
                    break
                for s in keys:
                    b0 = base[s]
                    b1 = {**b0, field: b0[field] + mag}
                    gain += life[s] / total_life * (product(b1) / product(b0) - 1)
            values[p.slot] = gain if priced else float("inf")
        drop = sorted((v, s) for s, v in values.items() if v != float("inf"))
        return {s for _v, s in drop[: int(over)]}

    def _surplus_buffer(self, battle: Any) -> str | None:
        """The one buffer to drop when the team cannot afford its own rotation, else None.

        Orb income is 1 per ``skill_points_regen_cd`` (5s), so a 20.5s cycle funds
        ~4.1 casts. A team that wants MORE than that every cycle cannot hold the
        cadence: each burst opens a little later than the last, and the slip
        compounds. Measured on the player's Hinoto Lv30 team (Mira + Tsukuyomi +
        Orihime buffing 2x Hikoboshi = 5 casts a cycle against 4.1 orbs): bursts ran
        25.6s apart instead of 20.5s, so every unit got 15 casts instead of 19-20 and
        the team scored 66.8M against the 71.0M the same roster reaches with the
        weakest buffer simply left out of the rotation.

        So drop exactly one buffer and let the other four casts run on time. The
        candidate must be a *surplus copy* -- every stat it supplies also comes from
        another live buffer -- because dropping a sole source is a different and much
        worse trade: on this team skipping Tsukuyomi (the only crit-rate buffer)
        costs 13%, while skipping Mira (ATK +71.6%, behind Orihime's +124.9%) gains
        4.5%.

        Carries are counted off ``_carry_peak_life`` through the same selection gate
        ``should_cast`` uses, so a utility damage skill that never qualifies to spam
        is not counted against the budget. That dict is empty on the opening tick, so
        this returns None for the first cycle and the rotation starts intact.

        ponytail: drops at most one, ranked by summed buff magnitude. Target count is
        ignored -- the payload does not say WHICH allies a partial-target buff hits.
        Drop more than one, or rank by magnitude x carries-covered, if a team ever
        overruns the budget by more than a single cast.
        """
        life = getattr(battle, "_carry_peak_life", None)
        if not life:
            return None  # first cycle: nothing has projected yet

        buffers: list[Any] = []
        for p in battle.players:
            if not p.is_alive or getattr(p, "skill", None) is None:
                continue
            f = skill_flags(p.skill, p)
            if not (f["buff"] and not f["damage"]) or _ramp_profile(p)[0]:
                continue
            if p.slot in self._dominated_buffers(battle):
                continue
            buffers.append(p)

        best = max(life.values())
        carries = sum(1 for v in life.values() if v >= self.carry_select_frac * best)
        wanted = len(buffers) + carries * self.casts_per_carry
        regen = float(getattr(battle, "skill_points_regen_cd", 5.0) or 5.0)
        if wanted <= scaled_cycle(self.cycle, battle) / regen:
            return None  # the rotation fits in the orb budget -- nothing to trim

        # Rank every buffer by the damage it actually delivers to the carries, and
        # trim the weakest. Three things this used to get wrong, each measured on
        # the rank-10 team of the 2026-09-18 cadence run (Seel Imperio + Senji
        # Ryakketsu + Edo Castle), which cadence scored 29% under what it is worth:
        #
        #   * an ALLY-side positive SHIELD is defence and buys nothing in a damage
        #     race, but `on_enemy` skipped the enemy-side debuff -- the one that IS
        #     a damage amp -- and kept the ally buff at full weight. Edo Castle's
        #     +71.6% shield outranked Il Milione's +53.3% crit rate, so the crit
        #     buffer was cut and the defensive one survived.
        #   * `_DMG_MULT_WEIGHT` decided WHETHER to count an effect and never how
        #     much, so crit rate (0.5) and crit damage (0.4) were summed raw.
        #   * target count was ignored, which cannot compare a 5-target 40% against
        #     a 2-target 50% -- and cards like 1129 and 564 make that the live
        #     question rather than a hypothetical.
        n_carries = max(1, carries)
        totals: dict[str, float] = {}
        supply: dict[str, int] = {}
        stats: dict[str, set[str]] = {}
        unpriced: set[str] = set()
        for p in buffers:
            sk = getattr(p, "skill", None)
            sel = str(getattr(sk, "target_selector", "") or "")
            n_t = int(getattr(sk, "target_count", 1) or 1)
            # `max_atk` picks the top-ATK allies, which is where the carries are; an
            # unfiltered count<n> sprays across the whole team and only covers the
            # carries in proportion.
            ally_hits = (
                min(n_t, n_carries)
                if "max_atk" in sel
                else n_carries * min(n_t, _TEAM_SIZE) / _TEAM_SIZE
            )
            for eff in skill_payload(p, p.model.level if p.model else 1):
                w = _DMG_MULT_WEIGHT.get(eff.raw_type)
                if w is None:
                    # UNKNOWN is not WORTHLESS. The table has no entry for SPD,
                    # POISON or HIT, and scoring those 0 made the weakest-looking
                    # buffer the trim-first candidate: on the Seel Imperio team that
                    # cut a +14% attack-speed buff, which is real auto damage, and
                    # left a defensive ally shield casting all fight. A buffer we
                    # cannot price falls back to the surplus-copy gate below.
                    unpriced.add(p.slot)
                    continue
                if eff.raw_type in _DEFENSIVE_ON_ALLY:
                    # Only the enemy-side (negative) version amplifies damage.
                    if not eff.on_enemy:
                        continue
                elif eff.on_enemy:
                    continue
                # An enemy debuff multiplies every carry's damage at once.
                hits = n_carries if eff.on_enemy else ally_hits
                totals[p.slot] = totals.get(p.slot, 0.0) + w * abs(eff.magnitude) * hits
                supply[eff.raw_type] = supply.get(eff.raw_type, 0) + 1
                stats.setdefault(p.slot, set()).add(eff.raw_type)
        # Only a SURPLUS COPY may be trimmed -- one whose every stat another live
        # buffer also supplies. The gate stays because the weights above cannot
        # compare across stats: CHIT is weighted 0.5 ("each crit ~2x"), but on a team
        # stacking crit DAMAGE a crit is worth far more than 2x, so ranking by value
        # alone trims Tsukuyomi on the Hinoto team -- measured at -13%.
        candidates = {
            slot: v
            for slot, v in totals.items()
            if all(supply[stat] > 1 for stat in stats.get(slot, ()))
        }
        # ...with one exception: a buffer supplying NOTHING damage-relevant. It was
        # structurally undroppable, because with no counted effect it never entered
        # the candidate map, so the most worthless card on the team was the one card
        # the budget could never reclaim an orb from. That is the whole of the 29%.
        for p in buffers:
            if not stats.get(p.slot) and p.slot not in unpriced:
                candidates[p.slot] = 0.0
        if not candidates:
            return None
        return min(candidates, key=lambda slot: (candidates[slot], slot))

    def _skipped_buffers(self, battle: Any) -> set[str]:
        """Buffers that must not cast this burst: redundant by construction, plus the
        one surplus buffer an orb-bound team cannot afford (see ``_surplus_buffer``)."""
        skipped = self._dominated_buffers(battle)
        if FORCED_SKIP:
            # A benched slot must also leave the buffs-first wait and the opening
            # sync, or the carries wait on a buffer that never casts: benching Ohina
            # alone left Odairi at 1 cast in 300s instead of 16.
            skipped = skipped | FORCED_SKIP
        st = getattr(battle, "_cadence", None)
        surplus = st.get("skip") if isinstance(st, dict) else None
        if isinstance(surplus, set):
            return skipped | surplus
        return (skipped | {surplus}) if surplus else skipped

    def _waiting_for_buffs(self, battle: Any, unit: Any) -> bool:
        """Should this carry hold until the buffs cast this opening have LANDED?

        A buff applies its caster's own delay after the cast (animation asset, e.g.
        Orihime 1.0s, Tsukuyomi 0.5s; see Battle.skill_effect_delay_for),
        so a carry firing in the same tick as its buffers gets none of them. That is
        not how the fight is played -- the player casts the buffers, waits ~1s, then
        the carry -- and modelling the delay WITHOUT the wait is strictly worse than
        modelling neither: it keeps the unrealistic simultaneous cast and then strips
        the buffs off it.

        Inert when the delay is 0, which is the default.
        """
        delay = float(getattr(battle.config, "skill_effect_delay", 0.0) or 0.0)
        if delay <= 0 or unit is None or getattr(unit, "skill", None) is None:
            return False
        if not skill_flags(unit.skill, unit)["damage"]:
            return False  # buffers open the window, they never wait on it
        for key in ("_group_st", "_cadence", "_ramp_burst"):
            st = getattr(battle, key, None)
            if isinstance(st, dict) and "buff_land_at" in st:
                # Each buff lands after its caster's own delay (animation asset);
                # the carry waits for the slowest one cast this opening.
                return battle.current_time < st["buff_land_at"]
        return False

    def _amp_still_running(
        self, attacker: Any, battle: Any, target: Any, enemy_only: bool = False
    ) -> bool:
        """Is this unit's damage-amp debuff already running with time to spare?

        The amp is capped (it sits at the -75% shield floor from a single cast), so
        re-applying it while it still has plenty of duration left buys no magnitude
        and no meaningful coverage -- it just burns an orb. True means "wait": the
        debuff would outlive this unit's next turn, so casting now is pure waste.

        Shared by CadenceScheduler and GroupScheduler. It used to be inlined in
        CadenceScheduler.should_cast; GroupScheduler needs the identical judgment
        and a second copy is exactly the drift this package keeps getting bitten by.

        **It does not apply to a CARRY.** "Pure waste" is only true for a support
        whose cast is nothing but the debuff. A carry whose skill both nukes and amps
        (Hikoboshi: "Deals {value} DMG ... Targets take {delay1} more DMG") loses far
        more by waiting than the orb is worth -- held until the window lapses, it then
        fires with the amp DOWN and misses the damage cap on its own nuke. Measured on
        the player's Hinoto team, duplicate Hikoboshi in slots P4/P5: the second copy
        capped 12.5% of its casts with the stagger on and 80-94% with it off, which is
        what the player reports seeing in play.
        """
        if getattr(attacker, "skill", None) is not None:
            if skill_flags(attacker.skill, attacker)["damage"]:
                return False
        try:
            gap = float(attacker.get_attack_interval())
        except Exception:
            gap = 2.0
        for e in amp_effects(attacker):
            if e.is_permanent or e.mod_type is None:
                continue
            # `enemy_only` restricts this to debuffs on the target -- the capped
            # damage-amp this was written for. Ally buffs stack ADDITIVELY within
            # their bucket, so two different buffers are not redundant: Mira and
            # Orihime take one carry 145% -> 300.2% -> 383.4%. Measuring "is a DAMAGE
            # modifier running on the recipient" cannot tell those apart, and held
            # Orihime for the whole 8s window behind Mira.
            if enemy_only and not e.on_enemy:
                continue
            recipient = target if e.on_enemy else attacker
            if recipient is None:
                continue
            if _buff_remains(battle, recipient, e.mod_type.name) > gap:
                return True
        return False

    def _project_crit(self, unit: Any, battle: Any, target: Any) -> float:
        """Forced-crit skill projection, maintaining two peaks.

        ``_carry_peak`` is per-cycle (cleared each burst) and drives the *timing*
        gate, so a transient — e.g. the enemy's shield break — can't leave a stale
        unreachable peak that deadlocks the window check.

        ``_carry_peak_life`` is the battle-lifetime max and drives *selection*.
        Using the per-cycle peak for selection leaks: the dict is empty at every
        cycle boundary, so whichever unit projects first compares against only
        itself (``team_best == own_peak``) and always clears the gate — letting a
        utility damage skill (an AoE chip, a healer's nuke) spend an orb that
        belonged to a real carry. Shorter cycles reset more often and leak more:
        measured 4 carry casts vs 6 junk casts at cycle=15, against 25 vs 3 at
        cycle=30. Splitting the two roles closes it at every cycle length.
        """
        f = skill_flags(unit.skill, unit) if getattr(unit, "skill", None) else None
        if not f or not f["damage"] or target is None:
            return 0.0
        crit = float(
            battle.calculate_action_damage(
                unit,
                target,
                is_skill=True,
                force_crit=True,
                exceed_pct=APL_PROJECTION_EXCEED,
            ).final_damage
        )
        peak = getattr(battle, "_carry_peak", None)
        if peak is None:
            peak = {}
            battle._carry_peak = peak
        if crit > peak.get(unit.slot, 0.0):
            peak[unit.slot] = crit
        life = getattr(battle, "_carry_peak_life", None)
        if life is None:
            life = {}
            battle._carry_peak_life = life
        if crit > life.get(unit.slot, 0.0):
            life[unit.slot] = crit
        return crit

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        if FORCED_SKIP and attacker.slot in FORCED_SKIP:
            return False
        # End-of-fight dump: spend everything affordable before the bell.
        if battle.effective_time_limit - battle.current_time <= self.end_dump:
            return True

        # Open a fresh burst every `cycle` seconds (state on the battle). Reset
        # the per-unit crit peaks each cycle: the forced-crit projection includes
        # the enemy's transient shield-break, so a peak captured right after a
        # carry applied SHIELD<-75%> is unreachable once that shield decays —
        # which would deadlock the window gate and starve carries for the rest of
        # the fight. A per-cycle peak keeps the window relative to what's
        # achievable *this* burst (buffs-first still holds carries for the buffs).
        st = getattr(battle, "_cadence", None)
        if st is None or battle.current_time - st["start"] >= scaled_cycle(
            self.cycle, battle
        ):
            st = {"start": battle.current_time, "buffed": set(), "nc": {}}
            battle._cadence = st
            battle._carry_peak = {}
            st["skip"] = (
                self._value_trim(battle)
                if os.environ.get("MC_CADENCE_TRIM", "surplus") == "value"
                else self._surplus_buffer(battle)
            )

        f = (
            skill_flags(attacker.skill, attacker)
            if getattr(attacker, "skill", None)
            else None
        )
        if f is None:
            return False

        # Cost gate: hold until this unit's escalated orb cost has decayed back to
        # `cost_target`. This is what the tuned ~21.5s cadence was really expressing.
        if not self._cost_ready(attacker, battle):
            return False

        # Buffers: cast once per burst (synced), refreshed every cycle. Skip
        # redundant buffers whose stat a better buffer already covers on >= targets.
        if f["buff"] and not f["damage"]:
            if attacker.slot in self._skipped_buffers(battle):
                return False
            # A ramp-shaped buffer (permanent no-duration stack -- Nimbus[Awakened])
            # does not need to land INSIDE the group's burst window: its main payoff
            # never expires, so syncing it costs the team a sync-block orb and an
            # extra name on the carry's buffs-first wait-list for zero timing benefit.
            # Measured on a 3-buffer Anima team: folding it into the shared sync
            # (like every other buffer) held the lone carry behind all three buffers
            # every cycle and taxed the opening block at 4 orbs instead of 3, costing
            # ~12% versus manually pulling it into its own group. Casting it purely
            # off its own cost-decay gate reproduces that manual split automatically.
            if _ramp_profile(attacker)[0]:
                return True
            if attacker.slot in st["buffed"]:
                return False
            # Opening sync: do not start a burst the pool cannot see through to its
            # first nuke. Checked only while the burst is still closed -- once a
            # buffer has cast the window is running and stalling mid-burst would
            # waste the buffs already spent. Ramp buffers are excluded (see above).
            if not st["buffed"]:
                pending = sum(
                    1
                    for p in battle.players
                    if p.is_alive
                    and getattr(p, "skill", None) is not None
                    and p.slot not in self._skipped_buffers(battle)
                    and not _ramp_profile(p)[0]
                    and (lambda pf: pf["buff"] and not pf["damage"])(
                        skill_flags(p.skill, p)
                    )
                )
                if not self._opening_funded(battle, pending):
                    return False
            # Scarcity order: a rarely-acting unit (healer) claims orbs before a
            # frequently-acting one, since a window it misses is unrecoverable.
            if self.scarcity_order:
                mine = self._turn_rate(attacker)
                dominated = self._skipped_buffers(battle)
                for p in battle.players:
                    if not p.is_alive or p.slot == attacker.slot or p.skill is None:
                        continue
                    if p.slot in st["buffed"] or p.slot in dominated:
                        continue
                    pf = skill_flags(p.skill, p)
                    if not (pf["buff"] and not pf["damage"]):
                        continue
                    if not self._cost_ready(p, battle):
                        continue
                    # Someone scarcer than me still owes a cast — yield to them.
                    if self._turn_rate(p) < mine:
                        return False
            st["buffed"].add(attacker.slot)
            _note_buff(st, battle, attacker)
            return True

        # Damage units: wait for the buffs cast this cycle to LAND, then the
        # relative selection + timing gates.
        if self._waiting_for_buffs(battle, attacker):
            return False
        crit = self._project_crit(attacker, battle, target)
        if crit <= 0.0:
            return False
        # Selection off the battle-lifetime peak — a weak carry can never qualify
        # merely by being the first to project in a freshly-cleared cycle.
        life = battle._carry_peak_life
        if life.get(attacker.slot, crit) < self.carry_select_frac * max(life.values()):
            return False
        own_peak = battle._carry_peak.get(attacker.slot, crit)
        # Timing: only fire inside this carry's own buff window.
        if crit < self.window_frac * own_peak:
            return False
        # Redundant-amp stagger: the debuff is capped, so re-applying it while it still
        # has plenty of time left is pure waste. Wait unless it would lapse before this
        # unit's next turn (a unit is only asked once per attack interval).
        if self.stagger_amp and self._amp_still_running(attacker, battle, target):
            return False
        # Buffs-first: hold the carry until every *worthwhile* buffer has cast
        # this burst (dominated/redundant buffers never cast, so don't wait on
        # them; a ramp buffer runs its own independent cadence, so don't wait on
        # it either -- see the ramp branch above).
        dominated = self._skipped_buffers(battle)
        for p in battle.players:
            if not p.is_alive or p.skill is None:
                continue
            pf = skill_flags(p.skill, p)
            if (
                pf["buff"]
                and not pf["damage"]
                and p.slot not in st["buffed"]
                and p.slot not in dominated
                and not _ramp_profile(p)[0]
            ):
                return False
        # Orb reservation: don't spend an orb a still-pending buffer needs. A buffer
        # that misses its window costs the whole team's next burst, whereas a carry
        # has hundreds of turns and will simply fire a moment later.
        reserved = self._orbs_reserved(battle, st, attacker.slot)
        if (
            reserved
            and battle.skill_points - int(getattr(attacker, "need_cast_point", 1))
            < reserved
        ):
            return False
        if st["nc"].get(attacker.slot, 0) < self.casts_per_carry:
            st["nc"][attacker.slot] = st["nc"].get(attacker.slot, 0) + 1
            return True
        return False


def next_cleanse_in(battle: Any) -> float | None:
    """Battle seconds until the boss's next scheduled self-cleanse, or None.

    Walks the same timeline `Battle._boss_phase` fires from (boss clock, looping).
    ponytail: ignores boss CC delaying the cast and state changes (enrage) in between.
    """
    boss = getattr(battle, "boss", None)
    if boss is None or not boss.cleanse_skills:
        return None
    rotation = boss.rotation(battle._boss_state)
    if not rotation:
        return None
    rate = boss.timing.clock_rate
    cycle = rotation[-1][0]
    idx = battle._boss_cast_idx
    for k in range(idx, idx + len(rotation)):
        at, sid = rotation[k % len(rotation)]
        if sid in boss.cleanse_skills:
            due = battle._boss_rotation_base + (k // len(rotation)) * cycle + at
            return due / rate - battle.current_time
    return None


class GroupScheduler(CadenceScheduler):
    """Player-authored cast groups: the policy the web calculator drives.

    The player drags cards into ordered groups. Priority is left to right; any slot
    in no group never casts at all (the "do not cast" bucket). A group *opens* when
    every one of its eligible members can cast at cost 1, and once open it stays the
    active group until all of them have fired -- that is what makes a group fire
    *together* rather than dribbling out as orbs trickle in.

    This is deliberately less optimal than ``cadence``. Cadence discovers a rotation;
    this one executes the rotation the player asked for, so they can compare two
    teams under a policy they can reason about. Three of cadence's judgments are
    kept because they are about waste, not optimisation:

    - **cost 1 only** (``_cost_ready``): skill cost escalates 1 -> 2 -> 3 and decays
      one step per 20s, so a group that re-fires too early pays double and triple.
      This gate is what produces the natural ~20s group cadence -- no cycle constant.
    - **dominated buffers** (``_dominated_buffers``): a buff another member already
      supplies to more targets at higher magnitude is skipped. It neither casts nor
      blocks its group.
    - **amp stagger** (``_amp_still_running``): a duplicate damage-amp debuff that is
      already running is skipped for this opening rather than refreshed into itself.

    ``skip_after`` is the deadlock guard: a member held by CC (or by a lapsing amp)
    for that many seconds is passed over so one stunned unit cannot lock the group.
    """

    def __init__(
        self,
        groups: list[list[str]],
        cost_target: int = 1,
        skip_after: float = 8.0,
        stagger_amp: bool = True,
        cycle: float = 20.5,
        swap: dict[str, str] | None = None,
        hold_cc: float = 0.0,
        end_dump: float = 8.0,
        swap_when: str = "autos",
        cc_mid: str = "skip",
        cc_wait: float = 6.0,
        cleanse_dodge: float = 4.0,
        amp_wait: bool = True,
        buffer_wait: float = 6.0,
        offset: dict[int, float] | None = None,
        speed_stagger: bool = False,
        retire: dict[str, str] | None = None,
        protect_lead: bool = False,
        overflow: list[tuple[str, int]] | None = None,
        overflow_after: float = 0.0,
        overflow_horizon: float = 0.0,
        rich: dict[str, int] | None = None,
        rich_window: bool = True,
    ) -> None:
        super().__init__(cost_target=cost_target, stagger_amp=stagger_amp)
        # {group_index: seconds} -- that group's first opening is due this far into
        # the fight, and the fixed grid below keeps the phase. Puts a second buffer
        # half a cycle off the burst so a timed buff (an 8s speed buff) is up
        # between bursts instead of on top of the burst's own.
        self.offset = {int(k): float(v) for k, v in (offset or {}).items()}
        # A speed-only cast (Ohina) holds while the carry is already speed-capped by
        # a timed buff, and fires as that buff runs out -- overlapping two capped
        # speed buffs buys nothing. See `_speed_held`.
        self.speed_stagger = speed_stagger
        # {slot: condition} -- that slot stops casting for good once the condition
        # ("autos"/"skills"/"either"/"both") reads true at a cold moment, with no
        # replacement. A buffer whose only job was pushing a carry's nuke to the
        # cap (Mira) frees its orb once the nuke caps without it.
        # Later groups may not spend an orb the FIRST group needs at its next due
        # time: the burst outranks the fillers between bursts. See `_starves_lead`.
        self.protect_lead = protect_lead
        # [(slot, casts), ...] -- the player's orb-overflow dump ("Mira x1, Odairi
        # x4 when orbs are in excess"): once the pool is FULL (income would be lost)
        # and the fight is past `overflow_after` s, cast this sequence at whatever
        # cost it takes, then resume the rotation. See `_overflow_cast`.
        self.overflow = [(str(s), int(n)) for s, n in (overflow or [])]
        self.overflow_after = overflow_after
        # 0 = dump whenever the pool is full. N = only when the excess is sustained:
        # pool + income over the next N s must still cover the bursts due in that
        # window after paying for the dump (N=40: cost 3 decays back to 1 in 40s).
        self.overflow_horizon = overflow_horizon
        # {slot: reserve} -- that slot may also cast ABOVE cost 1 (2 or 3 orbs)
        # whenever the pool stays >= reserve after paying; with `rich_window`, only
        # while a timed DAMAGE/ATK buff is on it (Mira's window, so the nuke caps).
        # Cost-1 casts still go through the group. Cost decays one step per 20s to
        # 1, so a card averages one cost-1 cast per 20s; every cast beyond that is
        # paid at 2-3 orbs -- this is where surplus orbs become extra nukes.
        self.rich = {str(k): int(v) for k, v in (rich or {}).items()}
        self.rich_window = rich_window
        self.retire = {
            k: (v if v in SWAP_CONDITIONS else "skills")
            for k, v in (retire or {}).items()
        }
        # A BUFFER CC'd after its group has opened (the player's mid-rotation call):
        #   skip -- step over it, carries fire now, it may still cast late this opening
        #   drop -- step over it and give up its cast this opening (keeps its orb)
        #   wait -- carries hold for it, up to `cc_wait` s after the opening
        self.cc_mid = cc_mid
        self.cc_wait = cc_wait
        # Don't open a burst if the boss self-cleanse lands within this many seconds:
        # it would strip the first carry's amp before the second carry casts. 0 = off.
        # Defaults (4s / amp_wait / buffer_wait 6s) measured 2026-09-30 on the player's
        # 67M Hinoto team: 64.6M -> 66.5M, Hiko skill cap rate 74% -> 99%.
        self.cleanse_dodge = cleanse_dodge
        # A carry whose cast also debuffs the enemy (Hikoboshi's amp) is a buffer for
        # the carries after it: they wait for its debuff to land, as for a support's.
        self.amp_wait = amp_wait
        # Carries hold for an earlier, unfired buffer that will be castable within
        # this many seconds (CC ending, or its cost decaying back after a CC pause).
        self.buffer_wait = buffer_wait

        # End-of-fight rotation, the one piece of `cadence` this policy was missing.
        # Orbs are worthless after the bell, so the last `end_dump` seconds spend
        # everything affordable regardless of cost or beat -- and the `skill_minus_cost_cd`
        # seconds BEFORE that window are held idle so every cost decays back to 1 and
        # the buffs cast at the opening cover the whole dump. 8s == the standard buff
        # duration, so hold from T-28 to T-8 then dump fully buffed.
        self.end_dump = end_dump
        # Drop empty groups so an empty UI row can't stall the rotation.
        self.groups = [list(g) for g in groups if g]
        self.skip_after = skip_after
        # {retiring_slot: replacement_slot}. The ramp swap: a permanent-crit-damage
        # buffer (Nimbus) is worth nothing once a carry's autos cap, so at that
        # point it drops out and the named slot takes over its place in the group.
        # Both slots are listed in the group as normal, adjacent and in the order
        # the player wants them; exactly one of the pair is eligible at a time.
        self.swap = dict(swap or {})
        self.swap_in = {v: k for k, v in self.swap.items()}
        # Which channel has to saturate before the retiring card stands down.
        self.swap_when = swap_when if swap_when in SWAP_CONDITIONS else "autos"
        # Seconds a group will wait for a CC'd member before opening without it.
        # 0 = off, which is the default and the measured-best setting: see
        # `test_group_scheduler.test_cc_hold_is_not_worth_it` and CLAUDE.md.
        self.hold_cc = hold_cc
        # The beat a group tries to keep. Openings are scheduled on a FIXED grid
        # (due, due+cycle, due+2*cycle, ...) rather than measured from the previous
        # cast, because the latter compounds: a cast delayed by CC, a stagger hold or
        # plain turn timing pushes the next opening, which pushes the one after that.
        # Measured on a real team, that drift walked the carries out of an 8s crit
        # window by 66s and never recovered -- 5 of 31 casts landed with no crit for
        # ~150k instead of ~950k. A fixed grid lets a late cycle catch up instead.
        self.cycle = cycle

    def _is_buffer_cast(self, unit: Any) -> bool:
        f = skill_flags(unit.skill, unit)
        return not f["damage"] or (self.amp_wait and f["debuff"])

    def _castable_in(self, battle: Any, u: Any) -> float:
        """Seconds until this unit can cast at cost 1: CC left, then cost decay left."""
        now = battle.current_time
        cc = (
            max(
                [d.expire_time - now for d in u.active_debuffs if d.expire_time > now]
                or [0.0]
            )
            if u.is_cast_blocked(now)
            else 0.0
        )
        steps = int(u.need_cast_point) - self.cost_target
        if steps <= 0:
            return cc
        cd = float(getattr(battle.config, "skill_minus_cost_cd", 20.0) or 20.0)
        return cc + (cd - u.minus_cost_timer) + (steps - 1) * cd

    # -- membership ---------------------------------------------------------
    def _group_of(self, slot: str) -> int | None:
        for i, g in enumerate(self.groups):
            if slot in g:
                return i
        return None

    def _unit(self, battle: Any, slot: str) -> Any:
        for p in battle.players:
            if p.slot == slot:
                return p
        return None

    def _dominated_buffers(self, battle: Any) -> set[str]:
        """Strict domination only -- an exact duplicate is the player's to place.

        A strictly worse copy of a live buff is never worth an orb, under any policy.
        An IDENTICAL copy is different: worthless at the same instant, but a real
        refresher, because the two sit on separate cost tracks and can alternate.
        Measured on the player's Odairi team, the second Ohina is +1.6% with orb
        headroom and -7.4% when it competes with the burst -- so the answer is where
        it is placed, and a group layout already says that. `cadence` has no groups
        and must decide for itself, so it keeps muting ties; here the player decides.

        This is also what left a swap's replacement permanently mute: it was an exact
        tie with the card already casting, so it never fired and the retired card's
        orbs simply evaporated -- 57 casts against 78 orbs of income.
        """
        return {
            slot
            for slot in super()._dominated_buffers(battle)
            if slot not in self._exact_ties(battle)
        }

    def _exact_ties(self, battle: Any) -> set[str]:
        """Slots whose buff signature exactly matches another casting buffer's."""
        casting = self._casting_slots(battle)
        seen: dict[tuple, str] = {}
        ties: set[str] = set()
        for p in battle.players:
            if p.slot not in casting or getattr(p, "skill", None) is None:
                continue
            f = skill_flags(p.skill, p)
            if not (f["buff"] and not f["damage"]):
                continue
            sig, tc = _buffer_signature(p)
            if not sig:
                continue
            key = (tuple(sorted(sig.items())), tc)
            if key in seen:
                ties.add(p.slot)
                ties.add(seen[key])
            else:
                seen[key] = p.slot
        return ties

    def _casting_slots(self, battle: Any) -> set[str]:
        """Who this rotation will actually cast: grouped, alive, and on the right
        side of a swap.

        A slot in no group never casts, and a swapped-out card has stopped casting,
        so neither can dominate anything. That is what left a retired Nimbus still
        muting the Ohina meant to replace it, with the freed orbs going nowhere:
        63 casts against 78 orbs of income, where not swapping casts 70.
        """
        out: set[str] = set()
        capped = self._capped(battle)
        for g in self.groups:
            for slot in g:
                if slot in self.swap and capped:
                    continue  # retired
                if slot in self.swap_in and not capped:
                    continue  # not on yet
                u = self._unit(battle, slot)
                if u is not None and u.is_alive and getattr(u, "skill", None):
                    out.add(slot)
        return out

    def _eligible(self, battle: Any, slot: str) -> bool:
        """Can this slot cast right now? Dead/skill-less/dominated/swapped-out cannot."""
        u = self._unit(battle, slot)
        if u is None or not u.is_alive or getattr(u, "skill", None) is None:
            return False
        if slot in self.swap and self._capped(battle):
            return False  # the ramp has done its job
        if slot in self.swap_in and not self._capped(battle):
            return False  # its replacement is not on yet
        if slot in self.retire and self.retire[slot] in getattr(
            battle, "_group_capped_by", ()
        ):
            return False  # its condition has been met: retired for the fight
        return slot not in self._dominated_buffers(battle)

    def _capped(self, battle: Any) -> bool:
        """Sticky "a carry's baseline autos have capped", sampled BETWEEN bursts.

        Sampling only while no group holds the floor is what keeps the reading at
        baseline: that is when the cycle's timed buffs are down, the same moment
        RampRotation reads it. Sticky because a permanent crit-damage ramp never
        gives its stacks back, and because a mid-fight flip-flop would swap a card
        out and back inside one rotation.
        """
        return bool(getattr(battle, "_group_capped", False))

    def _sample_capped(self, battle: Any) -> None:
        """Read the cap only at a COLD moment: no group holding the floor AND no
        timed buff live on anyone.

        "No group active" alone is not cold enough -- with three groups something is
        almost always mid-rotation, and a buffed carry reads as capped long before
        its baseline does, retiring the ramp far too early. `_active_buffs` is
        exactly the timed set (permanent ability buffs are never tracked there), so
        an empty live set is the baseline the retire rule means.

        ponytail: a team that keeps a timed buff up 100% of the time never samples,
        so its ramp never retires -- which is the safe failure (that is the
        whole-fight rotation). Project the buffs off instead if that ever bites.
        """
        conds = set(self.retire.values())
        if self.swap:
            conds.add(self.swap_when)
        done = getattr(battle, "_group_capped_by", None)
        if done is None:
            done = battle._group_capped_by = set()
        if not conds - done:
            return
        now = battle.current_time
        for _t, sid, expire in getattr(battle, "_active_buffs", ()):
            # A speed buff changes how often a unit hits, not how hard, so it does
            # not spoil a cap reading -- and a team built to keep speed up 100% of
            # the time would otherwise never sample at all.
            if expire > now and not _source_matches(sid, "SPEED"):
                return
        for c in conds - done:
            if swap_triggered(battle, c):
                done.add(c)
        if self.swap_when in done:
            battle._group_capped = True

    def _can_act(self, battle: Any, slot: str) -> bool:
        """Cost has decayed back to 1 and no CC is stopping this unit casting.

        Deliberately does NOT include the amp-stagger check. Stagger is a judgment
        about one unit wasting its own orb; folding it in here made a single carry
        whose debuff was still running hold the ENTIRE group at the gate, which
        measured -20% and left the orb pool pinned at its cap of 10 with income
        overflowing. Stagger belongs to the caster, not to the group.
        """
        u = self._unit(battle, slot)
        if u is None:
            return False
        if u.is_cast_blocked(battle.current_time):
            return False
        return self._cost_ready(u, battle)

    def _speed_held(self, battle: Any, unit: Any) -> bool:
        """Is this a speed-only cast whose speed the carry already has at the cap?

        Speed-only = a SPD buff with no damage, ATK, crit or shield in the cast
        (a heal is allowed: Ohina). The carry is the top post-setup-ATK ally, the
        same ranking `max_atk` buffs use. Holds while the carry sits at the +100%
        speed clamp and its timed speed buff outlasts this cast's own landing
        delay, so the new buff lands as the old one expires. A DELAY, like the amp
        stagger: it resolves within one buff window.
        """
        if not self.speed_stagger or unit is None or unit.skill is None:
            return False
        f = skill_flags(unit.skill, unit)
        if not f["speed"] or any(
            f[k] for k in ("damage", "atk", "crit_rate", "crit_dmg", "shield")
        ):
            return False
        alive = [p for p in battle.players if p.is_alive and p.stat is not None]
        if not alive:
            return False
        carry = max(
            alive,
            key=lambda p: p.stat.base_atk
            * p.stat.normal_dmg_modifier.get_modifier_total(),
        )
        if carry.stat.speed_modifier.get_modifier_total() - 1.0 < 1.0:
            return False
        return _buff_remains(battle, carry, "SPEED") > battle.skill_effect_delay_for(
            unit
        )

    def _lead_block(self, battle: Any, gi: int) -> int:
        """Orbs group `gi` needs to open: members up to and including its first nuke."""
        n = 0
        for s in self.groups[gi]:
            if not self._eligible(battle, s):
                continue
            n += 1
            u = self._unit(battle, s)
            if u is not None and skill_flags(u.skill, u)["damage"]:
                break
        return n

    def _starves_lead(self, battle: Any, gi: int) -> bool:
        """Would one more orb spent by group `gi` (> 0) leave group 0 short at its due?

        Counts the pool after this cast plus income until group 0's next due time,
        against what group 0 needs to open. Group 0 already open, or no orb income
        modelled, never starves.
        """
        if not self.protect_lead or gi == 0 or not self.groups:
            return False
        st = getattr(battle, "_group_st", None)
        if st is not None and st["gi"] == 0:
            return False
        regen = float(getattr(battle, "skill_points_regen_cd", 0) or 0)
        if regen <= 0:
            return False
        timer = getattr(battle, "skill_points_timer", 0.0)
        due0 = (getattr(battle, "_group_due", None) or {}).get(
            0, self.offset.get(0, 0.0)
        )
        wait = max(0.0, due0 - battle.current_time)
        income = int((timer + wait) // regen)
        return battle.skill_points - 1 + income < self._lead_block(battle, 0)

    def _ready(self, battle: Any, slot: str, target: Any) -> bool:
        """`_can_act`, the caster's own amp-stagger skip, and the buff-landing wait.

        Applied to the unit actually asking to cast, never to the group as a whole.
        """
        if not self._can_act(battle, slot):
            return False
        u = self._unit(battle, slot)
        if self._waiting_for_buffs(battle, u):
            return False
        if self.stagger_amp and self._amp_still_running(
            u, battle, target, enemy_only=True
        ):
            return False
        if self._speed_held(battle, u):
            return False
        return True

    # -- rotation -----------------------------------------------------------
    def _overflow_cast(self, battle: Any, attacker: Any) -> bool:
        """Is this cast the next step of an orb-overflow dump?

        A dump starts when the pool is full past `overflow_after`. It spends the
        listed sequence in order and ignores the cost-1 rule -- the orbs would
        otherwise be lost to the cap -- and the escalated cost it leaves behind is
        the trade the player accepts. It ends when the sequence is spent, or when
        the next step cannot be paid or cannot act (dead / CC'd).
        """
        if not self.overflow:
            return False
        q = getattr(battle, "_overflow_q", None)
        if q is None:
            cap = int(getattr(battle, "skill_points_max", 10) or 10)
            if (
                battle.skill_points < cap
                or battle.current_time < self.overflow_after
                or not self._excess_sustained(battle)
            ):
                return False
            q = battle._overflow_q = [s for s, n in self.overflow for _ in range(n)]
        while q:
            u = self._unit(battle, q[0])
            if (
                u is None
                or not u.is_alive
                or u.skill is None
                or u.is_cast_blocked(battle.current_time)
                or battle.skill_points < u.need_cast_point
            ):
                q.clear()  # cannot finish the sequence: back to the rotation
                break
            if q[0] != attacker.slot:
                return False  # someone else is next; normal rotation meanwhile
            q.pop(0)
            if not q:
                battle._overflow_q = None
            return True
        battle._overflow_q = None
        return False

    def _excess_sustained(self, battle: Any) -> bool:
        """Will the pool still fund every burst due in the horizon after a dump?

        Dump cost assumes each repeat escalates 1 -> 2 -> 3 (capped at 3); bursts
        are counted at cost 1 per eligible member of every group, per cycle.
        """
        h = self.overflow_horizon
        if h <= 0:
            return True
        regen = float(getattr(battle, "skill_points_regen_cd", 5.0) or 5.0)
        dump = sum(min(i + 1, 3) for _s, n in self.overflow for i in range(n))
        per_cycle = sum(
            len([s for s in g if self._eligible(battle, s)]) for g in self.groups
        )
        bursts = per_cycle * h / scaled_cycle(self.cycle, battle)
        return battle.skill_points + h / regen - dump >= bursts

    def _rich_cast(self, battle: Any, unit: Any) -> bool:
        """An above-cost-1 cast the pool can afford while keeping its reserve."""
        reserve = self.rich.get(unit.slot)
        if reserve is None or unit.need_cast_point <= self.cost_target:
            return False
        if battle.skill_points - unit.need_cast_point < reserve:
            return False
        if not self._eligible(battle, unit.slot) or unit.is_cast_blocked(
            battle.current_time
        ):
            return False
        # Mira's "deal X% more DMG" is a DAMAGE buff; ATK-type buffs count too.
        if self.rich_window and max(
            _buff_remains(battle, unit, "DAMAGE"), _buff_remains(battle, unit, "ATK")
        ) <= battle.skill_effect_delay_for(unit):
            return False
        return True

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        if self._overflow_cast(battle, attacker):
            return True
        if self.rich and self._rich_cast(battle, attacker):
            return True
        gi = self._group_of(attacker.slot)
        if gi is None:
            return False  # "do not cast" bucket
        # The caster's own eligibility was only ever consulted for the group's
        # bookkeeping, never for the unit actually asking -- so a slot the policy
        # had ruled out (swapped-out ramp, dominated buffer) still cast.
        if not self._eligible(battle, attacker.slot):
            return False

        now = battle.current_time
        if self.end_dump:
            left = battle.effective_time_limit - battle.current_time
            if left <= self.end_dump:
                # Orbs are worthless after the bell, so cost and beat stop mattering
                # -- but a nuke that lands before its buff does is still wasted, so
                # the dump keeps its own opening state purely to time that wait.
                dst = getattr(battle, "_group_st", None)
                if not isinstance(dst, dict) or not dst.get("dump"):
                    dst = {"gi": -1, "fired": set(), "opened": now, "due": now}
                    dst["dump"] = True
                    battle._group_st = dst
                if self._waiting_for_buffs(battle, attacker):
                    return False
                if not skill_flags(attacker.skill, attacker)["damage"]:
                    # Buff once at cost 1, then nuke. A second buff inside one 8s
                    # window only refreshes a buff that already outlasts the fight,
                    # and it costs the orb a carry would have spent on damage
                    # (measured -3.5%) -- so damage skills alone are allowed to
                    # climb 1 -> 2 -> 3 here until the pool is empty.
                    if attacker.slot in dst["fired"]:
                        return False
                    if not self._cost_ready(attacker, battle):
                        return False
                    dst["fired"].add(attacker.slot)
                    _note_buff(dst, battle, attacker)
                elif self.amp_wait:
                    # Carries fire in group order: one listed after an amp carry that
                    # has not fired this dump waits for it, if it can come back in time.
                    amp = dst.setdefault("amp_fired", set())
                    g = self.groups[gi]
                    for s_ in g[: g.index(attacker.slot)]:
                        u_ = self._unit(battle, s_)
                        if (
                            s_ not in amp
                            and self._eligible(battle, s_)
                            and skill_flags(u_.skill, u_)["damage"]
                            and skill_flags(u_.skill, u_)["debuff"]
                            and self._castable_in(battle, u_) < left - 1.0
                        ):
                            return False
                    if skill_flags(attacker.skill, attacker)["debuff"]:
                        amp.add(attacker.slot)
                        _note_buff(dst, battle, attacker)  # next carry waits for it
                return True
            if left <= self.end_dump + float(
                getattr(battle.config, "skill_minus_cost_cd", 20.0) or 20.0
            ):
                return False  # hold: let every cost decay to 1 for the dump window

        st = getattr(battle, "_group_st", None)

        # Retire the active group once everyone eligible has fired, or once it has
        # been stuck past skip_after (a chain-CC'd member must not lock the team out).
        if st is not None:
            members = [
                s
                for s in self.groups[st["gi"]]
                if self._eligible(battle, s) and s not in st["fired"]
            ]
            # A member that CAN act but is being held by the amp stagger is waiting on
            # purpose. Timing the group out on it is how the duplicate carry ended up
            # never casting at all, so the clock does not run against it.
            held = any(
                self._can_act(battle, s) and not self._ready(battle, s, target)
                for s in members
            )
            if not members or (now - st["opened"] > self.skip_after and not held):
                # Next opening is one cycle after the time this one was DUE, not after
                # the time it actually happened -- so a cycle that ran late does not
                # push every cycle after it.
                due = getattr(battle, "_group_due", None)
                if due is None:
                    due = {}
                    battle._group_due = due
                due[st["gi"]] = st.get("due", st["opened"]) + scaled_cycle(
                    self.cycle, battle
                )
                st = None
                battle._group_st = None

        # No group active: open the highest-priority one whose LEAD member can act.
        #
        # Requiring every member to be ready simultaneously was too strong. Orb income
        # is 1 per 5s -- 4 per 20s, enough to fund a four-card group each cycle -- but
        # lockstep paced the group to its slowest member, so it fired 13 times instead
        # of 17 and the pool sat pinned at its cap of 10 with the surplus evaporating.
        # Opening on the lead card starts the window on time; the rest join as their
        # turns come, and anyone CC'd or still paying an escalated cost is passed over
        # rather than holding the window shut.
        if st is None:
            # No group holds the floor, so the timed buffs are down -- the only
            # moment the ramp-retire check reads a baseline rather than a peak.
            self._sample_capped(battle)
            due = getattr(battle, "_group_due", None)
            if due is None:
                due = {}
                battle._group_due = due
            for i, g in enumerate(self.groups):
                elig = [s for s in g if self._eligible(battle, s)]
                if not elig:
                    continue
                if now < due.get(i, self.offset.get(i, 0.0)):
                    continue  # not yet on this group's beat
                # Opening sync: the group's lead block is everyone up to and
                # including its first damage dealer -- they must fire inside one
                # buff window, so do not open until the pool can fund all of them.
                # Members after the first nuke may lag; `_amp_still_running` and
                # the player's own ordering handle those.
                lead_block = 0
                for s_ in elig:
                    lead_block += 1
                    u_ = self._unit(battle, s_)
                    uf = skill_flags(u_.skill, u_) if u_ is not None else None
                    if uf is not None and uf["damage"]:
                        break
                cap = int(getattr(battle, "skill_points_max", 10) or 10)
                if battle.skill_points < min(lead_block, cap):
                    continue
                if self._starves_lead(battle, i):
                    continue
                # Optional: wait out a CC'd member so the group fires whole, up to
                # `hold_cc` seconds past its due time. Off by default -- measured a
                # loss on every team tried, because boss CC recurs faster than the
                # rotation and the slid cycle never catches up.
                if self.hold_cc and now - due.get(i, now) < self.hold_cc:
                    if any(
                        self._unit(battle, s_).is_cast_blocked(now)
                        for s_ in elig
                        if self._unit(battle, s_) is not None
                    ):
                        continue
                if self.cleanse_dodge:
                    t_cl = next_cleanse_in(battle)
                    if t_cl is not None and t_cl <= self.cleanse_dodge:
                        continue  # open just after the cleanse instead
                if self._can_act(battle, elig[0]):
                    st = {
                        "gi": i,
                        "fired": set(),
                        "opened": now,
                        "due": due.get(i, now),
                    }
                    battle._group_st = st
                    break
            if st is None:
                return False

        if st["gi"] != gi:
            return False  # a higher-priority group holds the floor

        # One cast per member per opening. Without this a healer whose skill carries a
        # buff (Sola, Ameno Uzume, Classic Alice) casts TWICE in the same tick: the
        # engine offers it a cast on both the heal path and the attack path, and the
        # in-order loop below breaks at the attacker immediately, re-approving it.
        if attacker.slot in st["fired"]:
            return False

        # Re-check THIS unit at cast time. `_ready` was previously consulted only when
        # opening the group, so once open a member could cast at an escalated cost --
        # the one thing this policy promises never to do. The engine gate only asks
        # whether the orbs are affordable, not whether the cost is still 1, so nothing
        # downstream would have caught it.
        if not self._can_act(battle, attacker.slot):
            return False

        # Amp stagger is a DELAY, not a veto: a duplicated carry holds while its own
        # debuff is still running with time to spare, then fires as that window is
        # about to lapse -- which extends the debuff rather than re-applying it into
        # itself. `_ready` carries that check, and the retire rule below refuses to
        # time out on a member that is only being held, so the delay always resolves.
        if self._waiting_for_buffs(battle, attacker):
            return False

        if self.stagger_amp and self._amp_still_running(
            self._unit(battle, attacker.slot), battle, target, enemy_only=True
        ):
            return False

        if self._speed_held(battle, attacker):
            return False

        if self._starves_lead(battle, gi):
            return False

        # Cast in the player's listed order within the group. An earlier member holds
        # the queue only while it CAN act and simply has not had its turn yet -- one
        # that is stunned, silenced or still paying an escalated cost is stepped over,
        # so a single CC cannot cost the whole group its window.
        for s in self.groups[gi]:
            if s == attacker.slot:
                break
            if s in st["fired"] or not self._eligible(battle, s):
                continue
            su = self._unit(battle, s)
            if (
                self.buffer_wait
                and not self._ready(battle, s, target)
                and self._is_buffer_cast(su)
                and not self._speed_held(battle, su)  # held on purpose: don't wait
                and skill_flags(attacker.skill, attacker)["damage"]
                and now - st["opened"] < self.buffer_wait
                and self._castable_in(battle, su) <= self.buffer_wait
            ):
                return False  # hold for a buffer that will be back within the window
            if (
                self.cc_mid != "skip"
                and su.is_cast_blocked(now)
                and not skill_flags(su.skill, su)["damage"]
            ):
                if self.cc_mid == "drop":
                    st["fired"].add(s)  # gives up this opening's cast
                    continue
                if now - st["opened"] < self.cc_wait:
                    return False  # wait: hold the queue for the CC'd buffer
                continue
            if not self._ready(battle, s, target):
                continue  # blocked or deliberately held -- step over it
            return False  # an earlier member still owes its cast

        st["fired"].add(attacker.slot)
        if getattr(attacker, "skill", None) is not None and self._is_buffer_cast(
            attacker
        ):
            # A support just cast; its effects land after its own delay and the
            # carries in this opening wait for them.
            _note_buff(st, battle, attacker)
        return True


class SurvivalScheduler(CadenceScheduler):
    """Cadence, adapted to a fight where the team can actually die.

    ``cadence`` was tuned against the immortal dummy, where nothing interrupts
    the rotation and healing changes nothing. Against a real world boss both
    assumptions break:

    - **CC shreds the burst.** Every boss but one leans on STUN / SILENCE /
      FROZEN / STONE / NUMB. A burst that opens while the buffers are stunned is
      spent: the buffers never cast, and the carries fire naked. Worse, CC also
      pauses skill-cost decay, so a unit caught mid-burst comes back at cost 2-3
      and pays triple on the next cycle.
    - **A dead carry deals no damage.** Holding a heal to keep the rotation tidy
      is a good trade when nobody can die and a bad one when the boss is about to
      delete your highest-ATK unit. Measured against Kinoe (which snipes
      ``max_atk`` with a 6000 nuke twice per rotation), the reference team loses
      three of five units and scores 26% of its dummy damage.

    So this subclass changes one thing and inherits the rest:

    **Burst hold** -- do not open a fresh burst while any living unit with a
    skill is cast-blocked, or (with ``hold_on_cost``) still above
    ``cost_target``. The cycle slides rather than being spent, so the team fires
    together once the CC clears and the costs have decayed. ``max_hold`` caps the
    wait so a chain-CC'd unit cannot lock the other four out for the rest of the
    fight.

    Measured on the reference team (Mira[4th]/Orihime/Hikoboshi/Kashinkoji +
    Hikoboshi helper), 6 paired CRN seeds, 300s, bosses at Lv30:

    ========  =============  ==============  =============  =============
    policy    Kinoe          Hinoto          Mizunoe        Kanoto
    ========  =============  ==============  =============  =============
    cadence   20.7M / 3.2d   60.5M / 0.0d    44.4M / 1.3d   42.1M / 0.0d
    hold      17.9M / 3.2d   65.3M / 0.0d    45.9M / 0.7d   45.9M / 0.0d
    ========  =============  ==============  =============  =============

    So the cost half of the hold wins on three of four bosses on *both* axes --
    Mizunoe halves its deaths while scoring more -- and loses only on Kinoe,
    which kills the carries early enough that a synced rotation has nobody left
    to sync. It costs **16% on the immortal dummy** (79.0M -> 66.2M), because
    there a stretched cadence is just fewer casts with no upside; that is why
    this is a separate policy and not a flag on ``CadenceScheduler``. The CC half
    alone is inert on the dummy (79.0M) and worth up to +5.7% (Kanoto).

    **Panic heal is off by default (``panic_hp=0``) -- measured negative.** The
    idea was to let a healer jump the rotation when an ally is about to die. It
    loses damage at every threshold tried and does not reliably buy survival:

    ========  =============  =============
    panic_hp  Kinoe          Mizunoe
    ========  =============  =============
    0 (off)   17.9M / 3.2d   45.9M / 0.7d
    0.10      14.0M / 3.2d   43.0M / 0.8d
    0.20      14.1M / 3.3d   29.4M / 1.7d
    0.35      12.8M / 2.8d   34.6M / 1.5d
    ========  =============  =============

    The reason is that healers already heal without casting: ``_should_healer_heal``
    heals the most injured ally on every turn any ally is damaged, so the *skill*
    cast adds little healing and costs the orbs a carry needed. Kept as a knob
    (``MC_SURVIVAL_PANIC_HP``) with the numbers recorded, rather than deleted, so
    nobody re-derives it.

    Kept as a separate policy rather than options on ``CadenceScheduler`` so the
    dummy benchmark, the tier list and the golden corpus keep fighting exactly
    the fight they were generated with.
    """

    def __init__(
        self,
        *args: Any,
        panic_hp: float = 0.0,  # off: measured negative, see the class docstring
        max_hold: float = 10.0,
        hold_on_cost: bool = True,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, **kwargs)
        self.panic_hp = panic_hp
        self.max_hold = max_hold
        self.hold_on_cost = hold_on_cost

    # -- panic heal ---------------------------------------------------------
    @staticmethod
    def _can_heal(unit: Any) -> bool:
        """Healer by role, or any unit whose skill carries a HEAL effect."""
        model = getattr(unit, "model", None)
        if model is not None and getattr(model, "unit_type", 0) == 3:
            return True
        skill = getattr(unit, "skill", None)
        if skill is None:
            return False
        for eff in list(getattr(skill, "buff_effects", [])) + list(
            getattr(skill, "debuff_effects", [])
        ):
            if eff.split("<")[0].strip() in ("HEAL", "HEAL_DOT"):
                return True
        return False

    @staticmethod
    def _hp_frac(unit: Any) -> float:
        stat = getattr(unit, "stat", None)
        if stat is None:
            return 1.0
        try:
            cap = float(stat.hp_modifier.final_value)
        except Exception:
            return 1.0
        return stat.current_hp / cap if cap > 0 else 1.0

    def _panic(self, attacker: Any, battle: Any) -> bool:
        """True when an ally is low enough that the rotation stops mattering."""
        if self.panic_hp <= 0.0:
            return False  # off by default -- measured negative
        if getattr(battle.config, "immortal_players", False):
            return False  # nothing can die; a panic heal would be pure noise
        if not self._can_heal(attacker):
            return False
        return any(
            p.is_alive and self._hp_frac(p) <= self.panic_hp for p in battle.players
        )

    # -- burst hold ---------------------------------------------------------
    def _team_ready(self, battle: Any) -> bool:
        """Can the team actually execute a burst right now?

        A unit that is stunned or silenced cannot cast at all, and one whose orb
        cost has not decayed back would pay 2-3 for the privilege. Either way the
        burst is better spent a moment later, together.
        """
        now = battle.current_time
        for p in battle.players:
            if not p.is_alive or getattr(p, "skill", None) is None:
                continue
            if p.is_cast_blocked(now):
                return False
            if self.hold_on_cost and not self._cost_ready(p, battle):
                return False
        return True

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        if self._panic(attacker, battle):
            return True

        st = getattr(battle, "_cadence", None)
        due = st is None or battle.current_time - st["start"] >= scaled_cycle(
            self.cycle, battle
        )
        if due and not self._team_ready(battle):
            held = getattr(battle, "_survival_hold", None)
            if held is None:
                battle._survival_hold = battle.current_time
                return False
            # Give up holding after max_hold: a unit chain-CC'd for the rest of
            # the fight must not lock the other four out of casting entirely.
            if battle.current_time - held < self.max_hold:
                return False
        battle._survival_hold = None
        return super().should_cast(attacker, battle, target)


def _channel_capped(battle: Any, is_skill: bool) -> bool:
    """Is some living ally's *baseline* hit on this channel already at its cap?

    The two channels cap at different numbers (99,999 autos, 999,999 skills) and
    saturate at different times, so "is this buff still buying anything" has a
    different answer for each. A crit-damage stack is spent once the channel it
    feeds is capped, and that is what a retire condition is really asking about.
    """
    enemy = next((e for e in battle.enemies if e.is_alive), None)
    if enemy is None:
        return False
    cap = battle.config.skill_damage_cap if is_skill else battle.config.damage_cap
    for p in battle.players:
        if not p.is_alive:
            continue
        if is_skill and getattr(p, "skill", None) is None:
            continue
        # exceed_pct=0 is the floor of the roll: a stack is only definitively
        # waste when even the worst hit is capped. Anything higher retires the
        # ramp while the low rolls are still gaining.
        dmg = battle.calculate_action_damage(
            p, enemy, is_skill=is_skill, force_crit=True, exceed_pct=0.0
        ).final_damage
        if dmg >= cap:
            return True
    return False


def skills_capped(battle: Any) -> bool:
    """Is some living ally's baseline SKILL hit already at the skill damage cap?"""
    return _channel_capped(battle, True)


# Retire conditions a player can choose between. Both channels are offered because
# they saturate independently: a team can cap its autos while its nukes still scale,
# or the reverse, and which one a retiring card was feeding decides when its cast
# stops being worth an orb.
SWAP_CONDITIONS = ("autos", "skills", "either", "both")


def swap_triggered(battle: Any, when: str) -> bool:
    if when == "skills":
        return skills_capped(battle)
    if when == "either":
        return autos_capped(battle) or skills_capped(battle)
    if when == "both":
        return autos_capped(battle) and skills_capped(battle)
    return autos_capped(battle)


def autos_capped(battle: Any) -> bool:
    """Is some living ally's *baseline* auto attack already at the damage cap?

    The stop condition for a ramp buffer (Nimbus): once a carry's autos cap,
    further permanent crit-damage stacks are pure waste. Shared by RampRotation
    and GroupScheduler so there is one definition of "capped", not two.

    Read it only when the team's timed buffs are DOWN -- between bursts, or at the
    ramp's own cast moment. Inside a buff window it reports the buffed peak, which
    caps far earlier than the baseline and retires the ramp too soon.
    """
    enemy = next((e for e in battle.enemies if e.is_alive), None)
    if enemy is None:
        return False
    cap = battle.config.damage_cap
    for p in battle.players:
        if not p.is_alive:
            continue
        dmg = battle.calculate_action_damage(
            p, enemy, is_skill=False, force_crit=True, exceed_pct=0.0
        ).final_damage
        if dmg >= cap:
            return True
    return False


def _ramp_profile(unit: Any) -> tuple[bool, float]:
    """(is_ramp_buffer, crit_rate_window_seconds) for a unit.

    A *ramp buffer* carries an on-skill (``attack_skill``) ability granting a
    PERMANENT crit-damage stack — ``CHIT_ATK`` with ``duration == 0``. Nimbus
    [Awakened] 514's ability 51402 is the only card in the game with this shape,
    and the missing duration is a real game bug: the +60% crit damage never
    expires, so it compounds once per cast for the whole battle. Detected by
    signature rather than by card id so any future card with the same shape is
    picked up.

    The same ability's ``CHIT`` (crit *rate*) half DOES have a duration (4s on
    Nimbus). That short window is a hard deadline — a carry skill has to land
    inside it to bank a guaranteed crit — so it is returned alongside.
    """
    is_ramp = False
    window = 0.0
    for ab in getattr(unit, "abilities", []) or []:
        trig = getattr(ab, "trigger", None)
        if getattr(trig, "value", trig) != "attack_skill":
            continue
        for eff in getattr(ab, "effects", []) or []:
            name = getattr(getattr(eff, "effect_type", None), "name", None)
            dur = float(getattr(eff, "duration", 0) or 0)
            if name == "CHIT_ATK" and dur == 0:
                is_ramp = True
            elif name == "CHIT" and dur > 0:
                window = max(window, dur)
    return is_ramp, window


class RampRotation:
    """Ordered burst on the cost-decay cadence: ramp -> buffers -> carries.

    Models the human world-boss rotation rather than a reactive per-unit policy.
    Every ``cycle`` seconds (default 20s — ``BattleConfig.skill_minus_cost_cd``,
    the interval over which each unit's escalated orb cost decays back toward 1)
    a burst opens and the team casts *in order*:

        1. the ramp buffer (Nimbus), banking a permanent crit-damage stack
        2. the remaining buffers (Orihime, ...)
        3. each carry, up to ``casts_per_carry`` times (Hiko x2)

    Two things distinguish this from CadenceScheduler:

    **Front-loading.** CadenceScheduler casts each buffer once per 30s cycle, so a
    ramp buffer fires only ~12 times across a 330s fight and the carry does not
    finish capping its autos until the final bucket. The same casts spent earlier
    convert the whole back half of the fight to capped autos at no extra orb cost.

    **Knowing when to stop.** Once the ramp's target caps its auto attacks, further
    stacks are pure waste, so the ramp drops out of the sequence and its orbs go to
    the carries instead. Saturation is measured at the moment the ramp would cast —
    which, because the ramp casts *first* in the burst, is exactly when the timed
    team buffs are down. So the check reads the carry's *baseline*, not its buffed
    peak, and won't stop the ramp early just because the carry caps inside a window.

    The buffs-first gate is deliberately not absolute: the ramp's crit-*rate* half
    lasts only ~4s, so once the ramp has cast, a carry may preempt any still-pending
    buffers rather than miss that window (``crit_window_grace``).
    """

    def __init__(
        self,
        cycle: float = 20.5,
        slip: float = 5.0,
        casts_per_carry: int = 1,
        carry_select_frac: float = 0.5,
        window_frac: float = 0.85,
        end_dump: float = 8.0,
        ramp_stop: bool = True,
        crit_window_grace: float = 0.5,
    ) -> None:
        self.cycle = cycle
        self.slip = slip
        self.casts_per_carry = casts_per_carry
        self.carry_select_frac = carry_select_frac
        self.window_frac = window_frac
        self.end_dump = end_dump
        self.ramp_stop = ramp_stop
        self.crit_window_grace = crit_window_grace

    # -- role classification ------------------------------------------------
    def _roles(self, battle: Any) -> dict[str, int]:
        """slot -> stage (0 ramp, 1 buffer, 2 carry). Cached per battle."""
        cached = getattr(battle, "_ramp_roles", None)
        if cached is not None:
            return cached
        roles: dict[str, int] = {}
        for p in battle.players:
            if getattr(p, "skill", None) is None:
                continue
            f = skill_flags(p.skill, p)
            is_ramp, _ = _ramp_profile(p)
            if is_ramp:
                roles[p.slot] = 0
            elif f["buff"] and not f["damage"]:
                roles[p.slot] = 1
            elif f["damage"]:
                roles[p.slot] = 2
        battle._ramp_roles = roles
        return roles

    def _crit_window(self, battle: Any) -> float:
        cached = getattr(battle, "_ramp_window", None)
        if cached is not None:
            return float(cached)
        w = 0.0
        for p in battle.players:
            is_ramp, win = _ramp_profile(p)
            if is_ramp:
                w = max(w, win)
        battle._ramp_window = w
        return w

    # -- saturation ---------------------------------------------------------
    def _ramp_saturated(self, battle: Any) -> bool:
        """Is some ally's *baseline* auto attack already at the damage cap?

        Evaluated live (not sticky) at the ramp's cast moment. Uses the same
        force-crit projection the carry gating uses, so no new damage math.
        """
        if not self.ramp_stop:
            return False
        return autos_capped(battle)

    def _project_crit(self, unit: Any, battle: Any, target: Any) -> float:
        """Forced-crit skill projection, maintaining TWO peaks.

        CadenceScheduler keeps one per-cycle peak and uses it for both carry
        *selection* and *timing*. That leaks: the peak dict is cleared at every
        cycle boundary, so whichever unit projects first in a fresh cycle compares
        against only itself (``team_best == own_peak``) and always clears the
        selection gate — letting a utility damage skill (Ibaraki's AoE, a healer's
        chip) spend an orb that belonged to a real carry. The shorter the cycle,
        the more often the gate is open: measured 4 Andromeda casts vs 6 junk casts
        at cycle=15, against 25 vs 3 at cycle=30.

        So the two jobs are split:
          * ``_carry_peak_life`` — battle-lifetime max, never reset. Used for
            SELECTION, so a weak carry can never qualify just by going first.
          * ``_carry_peak`` — per-cycle, reset each burst. Used for TIMING, so the
            window gate stays reachable when a transient (e.g. a shield break)
            inflates one projection and then decays.
        """
        f = skill_flags(unit.skill, unit) if getattr(unit, "skill", None) else None
        if not f or not f["damage"] or target is None:
            return 0.0
        crit = float(
            battle.calculate_action_damage(
                unit,
                target,
                is_skill=True,
                force_crit=True,
                exceed_pct=APL_PROJECTION_EXCEED,
            ).final_damage
        )
        peak = getattr(battle, "_carry_peak", None)
        if peak is None:
            peak = {}
            battle._carry_peak = peak
        if crit > peak.get(unit.slot, 0.0):
            peak[unit.slot] = crit
        life = getattr(battle, "_carry_peak_life", None)
        if life is None:
            life = {}
            battle._carry_peak_life = life
        if crit > life.get(unit.slot, 0.0):
            life[unit.slot] = crit
        return crit

    # -- main ---------------------------------------------------------------
    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        now = battle.current_time
        # Orbs are worthless after the bell — dump everything affordable.
        if battle.effective_time_limit - now <= self.end_dump:
            return True

        roles = self._roles(battle)
        stage = roles.get(attacker.slot)
        if stage is None:
            return False

        st = getattr(battle, "_ramp_burst", None)
        if st is None:
            st = {"start": now, "done": set(), "nc": {}, "ramp_at": None}
            battle._ramp_burst = st
            battle._carry_peak = {}
        else:
            # A new burst opens on the cadence once the previous one finished, or
            # after `slip` extra seconds if it stalled waiting on orbs.
            elapsed = now - st["start"]
            pending = self._pending(battle, st, 3)
            cycle = scaled_cycle(self.cycle, battle)
            if elapsed >= cycle and (not pending or elapsed >= cycle + self.slip):
                st = {"start": now, "done": set(), "nc": {}, "ramp_at": None}
                battle._ramp_burst = st
                battle._carry_peak = {}

        # Stage 0 — ramp buffer.
        if stage == 0:
            if attacker.slot in st["done"]:
                return False
            if self._ramp_saturated(battle):
                st["done"].add(attacker.slot)  # retire it for this burst
                return False
            st["done"].add(attacker.slot)
            st["ramp_at"] = now
            return True

        # Everything else waits for the ramp to resolve this burst.
        # (_pending(.., n) = "any unit in a stage strictly below n still owes a
        # cast", so waiting on the ramp — stage 0 — is a query for n = 1.)
        if self._pending(battle, st, 1):
            return False

        # Stage 1 — remaining buffers, once each per burst. Skip redundant ones
        # whose stat a better buffer already covers on >= targets (same reasoning
        # as CadenceScheduler: casting them just burns orbs the carries want).
        if stage == 1:
            if attacker.slot in self._dominated_buffers(battle):
                return False
            if attacker.slot in st["done"]:
                return False
            st["done"].add(attacker.slot)
            return True

        # Stage 2 — carries.
        crit = self._project_crit(attacker, battle, target)
        if crit <= 0.0:
            return False
        # Selection off the battle-lifetime peak (a weak carry can never qualify
        # by being first in a fresh cycle); timing off the per-cycle peak.
        life = battle._carry_peak_life
        if life.get(attacker.slot, crit) < self.carry_select_frac * max(life.values()):
            return False
        own_peak = battle._carry_peak.get(attacker.slot, crit)
        if crit < self.window_frac * own_peak:
            return False
        # Buffs-first, EXCEPT the ramp's crit-rate window is closing: a guaranteed
        # crit on a carry skill is worth more than a still-pending buffer.
        if self._pending(battle, st, 2):
            ramp_at = st.get("ramp_at")
            win = self._crit_window(battle)
            closing = (
                ramp_at is not None
                and win > 0.0
                and now - ramp_at >= max(0.0, win - self.crit_window_grace)
            )
            if not closing:
                return False
        if st["nc"].get(attacker.slot, 0) < self.casts_per_carry:
            st["nc"][attacker.slot] = st["nc"].get(attacker.slot, 0) + 1
            return True
        return False

    def _pending(self, battle: Any, st: dict, stage: int) -> bool:
        """Any live unit in a stage *strictly below* `stage` that still owes a cast?

        So "has the ramp (stage 0) resolved?" is `_pending(.., 1)`, and "have the
        ramp and all buffers resolved?" is `_pending(.., 2)`.
        """
        roles = self._roles(battle)
        dominated = self._dominated_buffers(battle)
        for p in battle.players:
            if not p.is_alive:
                continue
            r = roles.get(p.slot)
            if r is None or r >= stage:
                continue
            if r == 2:
                if st["nc"].get(p.slot, 0) < self.casts_per_carry:
                    return True
            elif p.slot not in st["done"] and p.slot not in dominated:
                # Dominated buffers never cast, so nothing should wait on them.
                return True
        return False

    # Borrowed verbatim — identical semantics to CadenceScheduler.
    # (_project_crit is NOT borrowed: this class defines its own above, which
    # additionally maintains the battle-lifetime peak used for carry selection.)
    _dominated_buffers = CadenceScheduler._dominated_buffers
    _casting_slots = CadenceScheduler._casting_slots  # _dominated_buffers calls it


class PlannerScheduler:
    """Uptime-first scheduler: hold each cast until just before its effect lapses.

    `CadenceScheduler` fires on a fixed cadence and models neither effect duration nor
    orb inventory, so a unit whose damage comes from *maintaining* a debuff casts far
    too early. Measured on 549/1720/1721/1615: Hikoboshi casts once per ~21s cycle, so
    its 8s SHIELD amp covers ~38% of the fight -- while ~74% is reachable. That matters
    because 63% of that team's damage is auto attacks hitting into the amp.

    The rule here follows from `window_value`'s (now marginal) uptime term: re-applying
    a running effect only buys coverage past its current expiry, so value climbs
    monotonically as the effect decays. "Wait" therefore always beats "cast now" until
    the effect is about to lapse -- which makes the decision simply:

        cast when  remaining_coverage <= time_until_my_next_turn

    The pre-compensation is essential and is why this cannot be expressed as "cast at
    expiry": a unit is only asked once per its own attack interval (~1-4s), so waiting
    for exact expiry opens a gap of up to one interval. Firing at the last opportunity
    *before* expiry keeps coverage continuous. `unit.next_attack_time` /
    `get_attack_interval()` give this exactly, and no existing scheduler uses them.

    Units with no timed payload (pure nukes) can't be timed this way, so they fall back
    to a value gate and simply spend spare orbs.

    All per-battle state lives on `battle` (never on self), so one instance is safe to
    share across battles and worker processes -- the same convention CadenceScheduler
    uses, and the reason `ScriptedRotation` is not process-safe.
    """

    def __init__(
        self,
        end_dump: float = 8.0,
        value_floor: float = 0.0,
        lookahead_pad: float = 0.0,
        require_buffs: bool = True,
    ):
        # Seconds before the bell where leftover orbs are worthless, so cost stops
        # mattering. Defaults to 8s == the standard buff duration, so the final buffs
        # and the dump coincide; widening it makes buffs expire mid-dump.
        self.end_dump = end_dump
        # Minimum value-per-orb for a *pure damage* cast (no timed payload).
        self.value_floor = value_floor
        # Extra slack added to the pre-compensation window (tuning knob).
        self.lookahead_pad = lookahead_pad
        # Hold amp carries until the team's damage buffs are up.
        self.require_buffs = require_buffs

    # -- helpers ---------------------------------------------------------------

    @staticmethod
    def _next_turn_gap(unit: Any, battle: Any) -> float:
        """Seconds until this unit can be asked to cast again."""
        try:
            nxt = float(getattr(unit, "next_attack_time", 0.0)) - battle.current_time
            if nxt > 0:
                return nxt
            return float(unit.get_attack_interval())
        except Exception:
            return 2.0

    def _coverage_slack(self, attacker: Any, battle: Any, target: Any) -> float | None:
        """Least remaining coverage across this cast's timed damage effects.

        Returns None when the skill has no timed damage payload (a pure nuke), which
        means uptime scheduling does not apply to it.
        """
        effs = [
            e
            for e in amp_effects(attacker)
            # A permanent effect never lapses, so it can never be "about to expire";
            # scheduling it on uptime would hold it forever.
            if not e.is_permanent
        ]
        if not effs:
            return None
        worst = None
        for e in effs:
            recipient = target if e.on_enemy else attacker
            if recipient is None or e.mod_type is None:
                continue
            rem = _buff_remains(battle, recipient, e.mod_type.name)
            worst = rem if worst is None else min(worst, rem)
        return worst

    @staticmethod
    def _team_damage_buff_up(battle: Any) -> bool:
        """Is any team-wide damage buff currently running?"""
        return _team_buff_remains(battle, "DAMAGE") > 0.0

    # -- decision --------------------------------------------------------------

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        # End of fight: orbs left over at the bell are worth zero, so spend whatever is
        # affordable regardless of escalated cost. (The caller has already checked the
        # unit can pay.)
        if battle.effective_time_limit - battle.current_time <= self.end_dump:
            return True

        skill = getattr(attacker, "skill", None)
        if skill is None:
            return False

        slack = self._coverage_slack(attacker, battle, target)

        # No timed payload -> uptime is meaningless. Spend spare orbs on it when it is
        # worth more than the floor, and only once the buffs it wants are up.
        if slack is None:
            if self.require_buffs and not self._team_damage_buff_up(battle):
                return False
            try:
                return value_per_orb(attacker, battle, target) > self.value_floor
            except Exception:
                return True

        gap = self._next_turn_gap(attacker, battle) + self.lookahead_pad

        # Still covered, and I get another turn before it lapses -> waiting strictly
        # buys more marginal uptime.
        if slack > gap:
            return False

        # About to lapse. Hold an amp carry for the team buffs *only* while that does
        # not cost coverage -- an amp that has already lapsed is refreshed immediately.
        if self.require_buffs and slack > 0 and not self._team_damage_buff_up(battle):
            f = skill_flags(skill, attacker)
            if f["damage"]:
                return False

        return True


def derive_chain(players: list[Any]) -> tuple[list[list[str]], float]:
    """(links, gap) for a damage-up chain, or ([], 0) when the team cannot chain.

    Chain carries are units whose skill deals damage AND leaves a timed damage-up
    on the boss (negative SHIELD/DEF, or a DAMAGE debuff). A team needs two of them
    to chain -- one amp can only cover its own window. Carries go in ranked-ATK
    order, because a ranked (``max_atk``) single-target buffer lands on the top one,
    so those buffers join link 0 just ahead of it. Team-wide buffers are left out:
    an AoE buff cast costs a chain link its orb (Mira on the Senji/Andromeda team,
    -3.7%). ``gap`` is the shortest amp duration, so no link opens a hole.
    """

    def atk(u: Any) -> float:
        st = getattr(u, "stat", None)
        if st is None:
            return 0.0
        return float(st.base_atk) * float(st.normal_dmg_modifier.get_modifier_total())

    carries, buffers, durs = [], [], []
    for u in players:
        sk = getattr(u, "skill", None)
        if sk is None:
            continue
        fl = skill_flags(sk, u)
        amps = [
            e
            for e in amp_effects(u)
            if e.on_enemy and e.magnitude < 0 and 0 < e.duration < math.inf
        ]
        if fl["damage"] and amps:
            carries.append(u)
            durs.append(min(e.duration for e in amps))
        elif not fl["damage"] and "max_atk" in str(
            getattr(sk, "target_selector", "") or ""
        ):
            buffers.append(u)
    if len(carries) < 2:
        return [], 0.0
    carries.sort(key=atk, reverse=True)
    links = [[b.slot for b in buffers] + [carries[0].slot]]
    links += [[c.slot] for c in carries[1:]]
    return links, min(durs)


class ChainScheduler(CadenceScheduler):
    """Back-to-back debuff chain: each link refreshes the damage-up as the last expires.

    The Assassination-rogue model: keep one damage window up permanently instead of
    bursting everything into one window. ``links`` is the chain in order, e.g.
    ``[["P2", "P4"], ["P3"], ["P5"]]`` -- Senji buffs, Dora casts her amp, then each
    Andromeda's amp follows. Link k is due ``k * gap`` after the chain's anchor, and the
    anchor advances on a fixed ``cycle`` grid (orb-bound, scaled to regen) so small
    per-cast slips do not pile up. Members of a link fire in listed order, each after
    the previous member's effect has landed (a buffer first, so the carry casts inside
    it). Slots in no link never cast except in the end dump.

    A link that cannot fire within ``late`` seconds of its due time has broken the
    chain (CC, orb shortage). ``restart="clean"`` abandons the rest of the chain and
    pools until ``pool`` orbs are banked and every link-0 member is back to cost 1,
    then re-anchors on a fresh chain; ``restart="slip"`` keeps going from the late link.
    """

    def __init__(
        self,
        links: list[list[str]] | None = None,
        gap: float = 0.0,
        cycle: float = 20.5,
        late: float = 4.0,
        restart: str = "clean",
        pool: int = 2,
        end_dump: float = 8.0,
        spare: int = 0,
    ) -> None:
        super().__init__(cycle=cycle, end_dump=end_dump)
        # links=None derives the chain from the team's kit (``derive_chain``); gap 0
        # uses the derived amp duration.
        self.links = [list(link) for link in links] if links else None
        self.gap, self.late = gap, late
        self.restart, self.pool = restart, pool
        # Orbs at or above this let an off-chain caster (a team buffer) cast; 0 = never.
        self.spare = spare

    def _st(self, battle: Any) -> dict:
        st = getattr(battle, "_chain_st", None)
        if st is None:
            links, gap = derive_chain(list(battle.players))
            links = self.links or links
            st = {"anchor": 0.0, "link": 0, "fired": [], "land": 0.0}
            st.update(idle=True, breaks=0, links=links, gap=self.gap or gap or 8.0)
            st["link_of"] = {s: i for i, link in enumerate(links) for s in link}
            battle._chain_st = st
        return st

    def _slot_ready(self, battle: Any, slot: str) -> bool:
        u = next((p for p in battle.players if p.slot == slot and p.is_alive), None)
        return (
            u is not None
            and not u.is_cast_blocked(battle.current_time)
            and self._cost_ready(u, battle)
        )

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        now = battle.current_time
        if self.end_dump and battle.effective_time_limit - now <= self.end_dump:
            return True  # orbs are worthless after the bell
        st = self._st(battle)
        if not st["links"]:
            # No chain on this team: fall back to the default rotation.
            return CadenceScheduler.should_cast(self, attacker, battle, target)
        li = st["link_of"].get(attacker.slot)
        if li is None:
            # Off-chain caster: only spends orbs the chain would not, at cost 1.
            return bool(
                self.spare
                and battle.skill_points >= self.spare
                and self._cost_ready(attacker, battle)
            )
        links = st["links"]
        if st["idle"]:
            # Clean start: link 0 only, once the pool and every link-0 member are ready.
            if li != 0 or battle.skill_points < self.pool:
                return False
            if not all(self._slot_ready(battle, s) for s in links[0]):
                return False
            st.update(idle=False, anchor=now, link=0, fired=[], land=now)
        due = st["anchor"] + st["link"] * st["gap"]
        if now > due + self.late and not st["fired"]:
            st["breaks"] += 1
            if self.restart == "clean":
                st.update(idle=True, link=0, fired=[])
                return False
        if li != st["link"] or now < due or now < st["land"]:
            return False
        link = links[li]
        if link[len(st["fired"])] != attacker.slot:
            return False  # members go in listed order
        if not self._cost_ready(attacker, battle):
            return False
        st["fired"].append(attacker.slot)
        delay_for = getattr(battle, "skill_effect_delay_for", None)
        st["land"] = now + (delay_for(attacker) if delay_for else 0.0)
        if len(st["fired"]) == len(link):
            st.update(link=(li + 1) % len(links), fired=[])
            if st["link"] == 0:
                st["anchor"] += scaled_cycle(self.cycle, battle)
        return True


# Timed effects that raise a carry's damage when an ally puts them on it.
_DMG_BUFF_TAGS = ("DAMAGE", "ATK", "CRIT", "CRIT_DMG", "SKILL_DMG", "NORMAL_DMG")
# Timed effects on the boss that raise everyone's damage taken.
_AMP_TAGS = ("SHIELD", "DEF", "DEFENSE", "DAMAGE")


class WindowScheduler(CadenceScheduler):
    """EXPERIMENTAL (2026-10-15: 5-35% behind cadence on the Lv1 finalists).

    Per-caster window rule: cast while buffed AND the boss is debuffed, as late as
    both still hold.

    Roles come from the kit. A *buff target* is a carry some buffer's skill lands on
    (a ranked ``max_atk`` buffer hits the top-ATK carry; a team buffer hits all).
    Every other carry is a *debuff keeper*.

    A carry acts on two questions -- am I buffed by an ally, is the boss under a
    damage-up (landed, or cast and about to land):

    - buff target, unbuffed, its buffer ready within ``buff_wait``: hold for the buff;
    - buffed + debuffed: cast on the last turn whose hit still lands inside both;
    - buffed only: an amp carry casts now to open the debuff, others cast late in
      the buff window;
    - debuffed only: cast on the last turn that still extends/lands in the debuff;
    - neither: an amp carry opens the debuff now, others hold.

    So buff targets debuff/extend during their buffs, and keepers extend the debuff
    through the downtime. "Last turn" = this unit's next action (attack interval) plus
    its cast-to-land lag would miss the window. A buffer casts once at least one of
    its targets is cost-ready and not yet buffed by it, and other casters leave the
    pair two orbs. Every cast stays at cost 1; the last ``end_dump`` seconds dump.
    """

    def __init__(self, end_dump: float = 8.0, buff_wait: float = 4.0) -> None:
        super().__init__(end_dump=end_dump)
        self.buff_wait = buff_wait

    @staticmethod
    def _atk(u: Any) -> float:
        st = getattr(u, "stat", None)
        if st is None:
            return 0.0
        return float(st.base_atk) * float(st.normal_dmg_modifier.get_modifier_total())

    @staticmethod
    def _amps(u: Any) -> list:
        return [
            e
            for e in amp_effects(u)
            if e.on_enemy and e.magnitude < 0 and 0 < e.duration < math.inf
        ]

    def _roles(self, battle: Any) -> dict:
        """{slot: targets} for each buffer, cached per battle."""
        r = getattr(battle, "_window_roles", None)
        if r is None:
            team = [p for p in battle.players if p.skill is not None]
            carries = sorted(
                (p for p in team if skill_flags(p.skill, p)["damage"]),
                key=self._atk,
                reverse=True,
            )
            r = {}
            for p in team:
                if skill_flags(p.skill, p)["damage"]:
                    continue
                ranked = "max_atk" in str(getattr(p.skill, "target_selector", ""))
                r[p.slot] = carries[:1] if ranked else carries
            battle._window_roles = r
        return r

    @staticmethod
    def _ends(battle: Any, pred: Any) -> float:
        best = 0.0
        for t, sid, exp in getattr(battle, "_active_buffs", None) or ():
            if pred(t, sid):
                best = max(best, exp)
        return best

    def _buff_end(self, battle: Any, u: Any, src: str = "") -> float:
        """When ``u``'s ally damage buffs run out (only ``src``'s, if given)."""
        return self._ends(
            battle,
            lambda t, sid: t is u
            and (not src or f"_{src}_" in sid or sid.startswith(src + "_"))
            and f"_{u.slot}_" not in sid
            and not sid.startswith(u.slot + "_")
            and any(_source_matches(sid, k) for k in _DMG_BUFF_TAGS),
        )

    def _debuff_end(self, battle: Any) -> float:
        """Landed amp debuffs on the boss, plus ones cast and still in flight."""
        landed = self._ends(
            battle,
            lambda t, sid: t.is_enemy
            and sid.startswith("skill_")
            and any(_source_matches(sid, k) for k in _AMP_TAGS),
        )
        return max(landed, getattr(battle, "_window_pending", 0.0))

    def _last_chance(self, battle: Any, u: Any, end: float) -> bool:
        """Casting now still lands before ``end`` but waiting one more turn would not."""
        now = battle.current_time
        lag = battle.skill_effect_delay_for(u)
        try:
            gap = float(u.get_attack_interval())
        except Exception:
            gap = 2.0
        return now + lag < end <= now + gap + lag

    def _ready_pairs(self, battle: Any, roles: dict) -> list:
        """(buffer slot, ready unbuffed targets) for each cost-ready buffer."""
        now = battle.current_time
        out = []
        for b, targets in roles.items():
            bu = next((p for p in battle.players if p.slot == b), None)
            if bu is None or not bu.is_alive or not self._cost_ready(bu, battle):
                continue
            ts = [
                p
                for p in targets
                if p.is_alive
                and self._cost_ready(p, battle)
                and self._buff_end(battle, p, src=b) <= now
            ]
            if ts:
                out.append((b, ts))
        return out

    def _cast(self, battle: Any, u: Any) -> bool:
        amps = self._amps(u)
        if amps:
            land = battle.current_time + battle.skill_effect_delay_for(u)
            end = land + min(e.duration for e in amps)
            battle._window_pending = max(getattr(battle, "_window_pending", 0.0), end)
        return True

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        now = battle.current_time
        if self.end_dump and battle.effective_time_limit - now <= self.end_dump:
            return True
        if not self._cost_ready(attacker, battle):
            return False
        roles = self._roles(battle)
        # A ready buffer whose target is ready too gets the next two orbs: anyone
        # else may only spend above that, or the pair never lines up.
        pairs = self._ready_pairs(battle, roles)
        if pairs and battle.skill_points < 3:
            mine = any(attacker.slot == b or attacker in ts for b, ts in pairs)
            if not mine:
                return False
        if attacker.slot in roles:
            # Buffer: fire when a target is ready to follow up and not already buffed.
            want = [
                p
                for p in roles[attacker.slot]
                if p.is_alive
                and self._cost_ready(p, battle)
                and self._buff_end(battle, p, src=attacker.slot) <= now
            ]
            return bool(want) and battle.skill_points >= 2
        buff_end = self._buff_end(battle, attacker)
        buffed = buff_end > now
        debuff_end = self._debuff_end(battle)
        debuffed = debuff_end > now
        amp = bool(self._amps(attacker))
        if not buffed:
            for b, targets in roles.items():
                bu = next((p for p in battle.players if p.slot == b), None)
                if (
                    attacker in targets
                    and bu is not None
                    and bu.is_alive
                    and self._cost_ready(bu, battle)
                    and not bu.is_cast_blocked(now + self.buff_wait)
                ):
                    return False  # a buff is coming: wait for it
        if buffed and debuffed:
            ok = self._last_chance(battle, attacker, min(buff_end, debuff_end))
        elif debuffed:
            ok = self._last_chance(battle, attacker, debuff_end)
        elif buffed:
            ok = amp or self._last_chance(battle, attacker, buff_end)
        else:
            ok = amp
        return ok and self._cast(battle, attacker)


class PlanScheduler(CadenceScheduler):
    """Budget then timing: pick who gets the ~4 orbs a cycle, then the shape to cast in.

    Built from two measured rotations (boss 3, 2026-10-15). Both follow one timing
    rule -- a buff target casts inside its buff, opening the debuff early or casting
    late in the overlap; a carry no buffer reaches keeps the debuff going through the
    downtime -- and differ only in which casters are funded:

    - Senji/Andromeda/Dora: Senji's ranked buff reaches only Dora, so both
      Andromedas are *debuff keepers* -> chain (``ChainScheduler``), and Mira's team
      buff is dropped (an 8s window over spread-out casts covers one of them).
    - Hikoboshi x2 + Orihime: Orihime's top-2 buff reaches both carries, so there
      are no keepers -> burst (``GroupScheduler``: buffers, then carries), funding
      the buffers that reach the most carries with a stat that is not capped
      (Mira, Orihime; Tsukuyomi's crit is already capped).

    Carries are damage skills whose projected skill hit (forced crit) is at least
    ``carry_frac`` of the team's best -- not ATK: an AoE skill hits each target for
    far less. Low-hit damage-up casters are supports, funded on value. The budget is the orbs one cycle earns. The plan is fixed
    at the first cast check of each battle and stored on the battle.
    """

    def __init__(
        self,
        cycle: float = 20.5,
        carry_frac: float = 0.5,
        long_cycle: float = 40.5,
        perm_windows: float = 5.0,
        force: str = "",
        replan: bool = False,
        groups: list | None = None,
    ) -> None:
        super().__init__(cycle=cycle)
        self.carry_frac = carry_frac
        self.long_cycle = long_cycle
        # "short" / "long": override the projected pick (measuring near-ties).
        self.force = force
        # Re-fill the long cycle from the live state at each of its starts.
        self.replan = replan
        # Player groups (calculator): WHO casts and which casts go together is the
        # player's; order, carry repeats and cycle length are planned. One group ->
        # burst or long cycle; several -> a chain, one link per group, in order.
        # The planner's own layout fed back in rebuilds the same executor.
        self.groups = [list(g) for g in groups or [] if g]
        # ponytail: a permanent stack counts as `perm_windows` 8s windows of its t=0
        # gain, a flat stand-in for its diminishing worth as caps bind. Calibrated
        # against phantom-cast measurements, not derived.
        self.perm_windows = perm_windows

    def plan(self, battle: Any, target: Any) -> tuple[str, list[list[str]]]:
        team = [p for p in battle.players if p.skill is not None]
        chosen = {s for g in self.groups for s in g}
        if chosen:
            team = [p for p in team if p.slot in chosen]
        atk = WindowScheduler._atk
        dmg = [p for p in team if skill_flags(p.skill, p)["damage"]]
        # Carries are picked by what one skill cast hits for (forced crit), not ATK:
        # an AoE skill (Kashinkoji) has a far smaller per-target multiplier.
        hit = (
            {
                p.slot: float(
                    battle.calculate_action_damage(
                        p,
                        target,
                        is_skill=True,
                        force_crit=True,
                        exceed_pct=APL_PROJECTION_EXCEED,
                    ).final_damage
                )
                for p in dmg
            }
            if target is not None
            else {p.slot: atk(p) for p in dmg}
        )
        top = max(hit.values(), default=0.0)
        battle._plan_hits = hit
        amp = {p.slot for p in dmg if WindowScheduler._amps(p)}
        carries = sorted(
            (p for p in dmg if hit[p.slot] >= self.carry_frac * top),
            key=atk,
            reverse=True,
        )
        # Low-ATK damage casters that leave a damage-up: supports, funded on value.
        debuffers = [p.slot for p in dmg if p.slot in amp and p not in carries]
        # Who each buffer reaches: a ranked buff the top `count` carries, else all.
        reach: dict[str, list[Any]] = {}
        ranked_reach: dict[str, list[Any]] = {}
        by_atk = sorted(
            (p for p in battle.players if p.is_alive), key=atk, reverse=True
        )
        for p in team:
            if skill_flags(p.skill, p)["damage"]:
                continue
            ranked = "max_atk" in str(getattr(p.skill, "target_selector", ""))
            n = int(getattr(p.skill, "target_count", 5) or 5)
            # A ranked buff picks the top-n of the WHOLE team: a support that
            # out-ATKs a carry takes its share (the buff-steal case).
            top = by_atk[:n]
            reach[p.slot] = top if ranked and n < 5 else by_atk
            if ranked and n < 5:
                ranked_reach[p.slot] = [c for c in carries if c in top]
        targeted = {t.slot for ts in ranked_reach.values() for t in ts}
        if len(self.groups) >= 2:
            # Each player group is a chain link: its buffers (ranked first), then
            # its carries -- the order the planner's own head link uses.
            cs = {c.slot for c in carries}

            def order(g: list) -> list:
                bufs = [s for s in g if s not in cs]
                bufs.sort(key=lambda s: s not in ranked_reach)
                return bufs + [s for s in g if s in cs]

            return "chain", [order(g) for g in self.groups]
        keepers = [c for c in carries if c.slot not in targeted and c.slot in amp]
        head = [b for b in ranked_reach] + [
            c.slot for c in carries if c.slot in targeted
        ]
        # A chain needs three 8s links to cover a ~22.5s cycle; with two it leaves a
        # gap a burst does better with (Sengen/Beelzebub teams, -3 to -8%).
        # What a simulation-in-the-loop probe needs to build alternative layouts.
        battle._plan_meta = {
            "carries": [c.slot for c in carries],
            "cands": list(reach) + debuffers,
        }
        if not self.groups and keepers and len(keepers) + bool(head) >= 3:
            return "chain", [head] + [[k.slot] for k in keepers]
        regen = float(getattr(battle, "skill_points_regen_cd", 5.0) or 5.0)
        budget = max(len(carries), int(scaled_cycle(self.cycle, battle) / regen))

        units = {p.slot: p for p in team}

        def value(b: str, nukes: dict | None, given: list = ()) -> float:
            # Only carries cast nukes in the plan; everyone else counts autos only.
            planned = nukes if nukes is not None else {c.slot: 1 for c in carries}
            prior = [(units[g], reach.get(g, by_atk)) for g in given]
            return self._buff_gain(
                battle, target, units[b], reach.get(b, by_atk), planned, prior
            )

        cands = list(reach) + debuffers
        ev = {c.slot: self._expected(battle, c, target, True) for c in carries}
        # The player's buffers are all kept: only repeats and the cycle are planned.
        forced = cands if self.groups else None
        # Short cycle: everyone at cost 1. Long cycle: the cost-decay window (3 -> 1
        # takes 40s) lets carries recast at escalated cost. Keep the better per second.
        v1, bufs1, _, n1 = self._fill(value, ev, cands, carries, budget, False, forced)
        budget2 = min(10, int(scaled_cycle(self.long_cycle, battle) / regen))
        v2, bufs2, nukes2, n2 = self._fill(
            value, ev, cands, carries, budget2, True, forced
        )
        rate1 = v1 / max(scaled_cycle(self.cycle, battle), n1 * regen)
        rate2 = v2 / max(self.long_cycle, n2 * regen)
        battle._plan_values = {b: value(b, None) for b in cands}
        battle._plan_rates = (rate1, rate2, nukes2)
        short = bufs1 + [c.slot for c in carries]
        pick_long = rate2 > rate1 if not self.force else self.force == "long"
        if pick_long and any(n > 1 for n in nukes2.values()):
            long = bufs2 + [c.slot for c in carries for _ in range(nukes2[c.slot])]

            def refill(b: Any) -> tuple[list, int]:
                """The long cycle re-filled from the live state (stacks, deaths)."""
                live = [c for c in carries if c.is_alive]
                if not live:
                    return long, n2
                ev_now = {c.slot: self._expected(b, c, target, True) for c in live}
                _, bufs, nukes, n = self._fill(
                    value, ev_now, cands, live, budget2, True
                )
                return bufs + [c.slot for c in live for _ in range(nukes[c.slot])], n

            battle._plan_refill = refill if self.replan else None
            # Phase 1 casts the long cycle's members once each, so the pool banks
            # toward it; the short plan's extra buffers would spend every orb.
            return "cycle", [list(dict.fromkeys(long)), long, [n2]]
        return "burst", [short]

    @staticmethod
    def _expected(battle: Any, u: Any, boss: Any, skill: bool) -> float:
        """Expected (crit-weighted) damage of one hit, caps included. Fixed exceed, so
        the probe draws no random numbers and cannot shift the battle's rolls."""
        c = min(1.0, max(0.0, float(u.stat.final_crit)))
        hi = battle.calculate_action_damage(
            u, boss, is_skill=skill, force_crit=True, exceed_pct=APL_PROJECTION_EXCEED
        )
        lo = battle.calculate_action_damage(
            u, boss, is_skill=skill, force_crit=False, exceed_pct=APL_PROJECTION_EXCEED
        )
        return c * float(hi.final_damage) + (1 - c) * float(lo.final_damage)

    def _window_damage(
        self, battle: Any, boss: Any, carries: list, nukes: dict | None = None
    ) -> float:
        """Damage ``units`` deal in one 8s window: their planned skill casts
        (``nukes`` per slot; None = one each) plus their autos. Healers heal
        instead of attacking, so their autos count for nothing."""
        total = 0.0
        for t in carries:
            try:
                autos = 8.0 / float(t.get_attack_interval())
            except Exception:
                autos = 4.0
            n = 1 if nukes is None else nukes.get(t.slot, 0)
            if n:
                total += n * self._expected(battle, t, boss, True)
            if getattr(getattr(t, "model", None), "unit_type", 1) != 3:
                total += autos * self._expected(battle, t, boss, False)
        return total

    @staticmethod
    def _effects(u: Any) -> list:
        """The damage-relevant timed and permanent effects one cast of ``u`` applies."""
        return [
            e
            for e in skill_payload(u)
            if e.mod_type is not None
            and e.duration > 0
            and (e.on_enemy or e.raw_type not in _DEFENSIVE_ON_ALLY)
        ]

    def _probe(self, battle: Any, boss: Any, layers: list, nukes: dict | None) -> float:
        """Team window damage with each ``(effects, recipients)`` layer applied, then
        taken off again. Each modifier gets its own source id: two effects of one
        type on one unit must stack, not replace each other."""
        applied = []
        for effs, reach in layers:
            for e in effs:
                for h in [boss] if e.on_enemy else reach:
                    sid = f"_plan_probe{len(applied)}"
                    h.stat.add_modify(e.mod_type, e.magnitude, sid)
                    applied.append((h, e.mod_type, sid))
        try:
            team = [p for p in battle.players if p.is_alive]
            return self._window_damage(battle, boss, team, nukes)
        finally:
            for h, m, sid in applied:
                h.stat.get_modifier(m).remove_modify(sid)

    def _buff_gain(
        self,
        battle: Any,
        boss: Any,
        u: Any,
        reach: list,
        nukes: dict | None = None,
        given: list = (),
    ) -> float:
        """Extra team damage from one cast of ``u`` ON TOP OF the ``given``
        ``(unit, recipients)`` casts, by the damage formula: one 8s window (``nukes``
        skill casts per carry inside it). Puts ATK%, crit, crit damage and boss
        damage-taken on one scale, with dilution and caps -- and, because the given
        buffs are applied first, with additive buckets already part-filled: a second
        +DMG buff beside Mira's, or a second speed buff at the cap, is worth less.

        A permanent effect (Nimbus's crit-damage stack) keeps paying after the window,
        so its window gain counts ``perm_windows`` times.
        """
        effs = self._effects(u)
        if boss is None or not effs:
            return 0.0
        base = [(self._effects(g), r) for g, r in given]
        total = 0.0
        for group, weight in (
            ([e for e in effs if e.duration < math.inf], 1.0),
            ([e for e in effs if e.duration == math.inf], self.perm_windows),
        ):
            if group:
                before = self._probe(battle, boss, base, nukes)
                after = self._probe(battle, boss, base + [(group, reach)], nukes)
                total += weight * max(0.0, after - before)
        return total

    def _fill(
        self,
        value: Any,
        ev: dict,
        cands: list,
        carries: list,
        budget: int,
        multi: bool,
        forced: list | None = None,
    ) -> tuple[float, list, dict, int]:
        """Spend ``budget`` orbs greedily on the cast worth most per orb.

        Every carry's first cast is funded. A buffer is valued on top of the buffers
        already chosen (``value(b, nukes, given)``), so overlapping buffs are not
        double-counted. With ``multi`` a carry may cast again at its escalated cost
        (the k-th cast costs min(k, 3)), which only pays while its hit beats the next
        buffer per orb; each escalation also raises the buffers' worth, since more
        nukes land in their windows. ``forced`` buffers are always cast (a player's
        choice). The result is ordered and totalled the same way whichever path
        chose it, so a player who enters the planner's own layout gets its result.
        """
        nukes = {c.slot: 1 for c in carries}
        bufs = list(forced) if forced is not None else []
        spent = len(carries) + len(bufs)
        while True:
            opts = []
            if forced is None:
                for b in cands:
                    if b not in bufs and spent + 1 <= budget:
                        v = value(b, nukes, bufs)
                        if v > 0:
                            opts.append((v, 1, b))
            if multi:
                for c in carries:
                    k = nukes[c.slot] + 1
                    if k <= 5 and spent + min(k, 3) <= budget:
                        opts.append((ev[c.slot], min(k, 3), c.slot))
            if not opts:
                break
            v, cost, slot = max(opts, key=lambda o: o[0] / o[1])
            spent += cost
            if slot in nukes:
                nukes[slot] += 1
            else:
                bufs.append(slot)
        # Cast order (and the total) depend only on the chosen set: best alone first.
        bufs.sort(key=lambda b: -value(b, nukes, []))
        total = sum(ev[c] * n for c, n in nukes.items())
        total += sum(value(b, nukes, bufs[:i]) for i, b in enumerate(bufs))
        return total, bufs, nukes, spent

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        d = getattr(battle, "_plan_delegate", None)
        if d is None:
            kind, groups = self.plan(battle, target)
            if kind == "chain":
                d = ChainScheduler(links=groups, cycle=self.cycle)
            elif kind == "cycle":
                short, long, (need,) = groups
                d = CycleScheduler(
                    [(self.cycle, short), (self.long_cycle, long)],
                    need=need,
                    refill=getattr(battle, "_plan_refill", None),
                )
            else:
                d = GroupScheduler(groups=groups, cycle=self.cycle)
            battle._plan_delegate = d
            battle._plan = (kind, groups)
        return d.should_cast(attacker, battle, target)


class CycleScheduler:
    """Two-phase fixed sequence: ``phases[0]`` every short cycle until the orb pool
    can fund one ``phases[1]`` cycle (``need`` orbs), then ``phases[1]`` for good.

    The player rotation for single-carry Nimbus teams (Discord guide, 2026-07-15):
    Nimbus, Mikado, carry once per 20s until 8 orbs bank, then Nimbus, Mikado, carry
    x3 per 40s: 1+1+1+2+3 = 8 orbs, exactly 40s of income, and 40s is what the
    carry's cost 3 takes to decay back to 1. In each sequence a slot's first cast
    waits for cost 1; its repeats pay the escalated cost. Scanned over 20-60s cycles
    and 1-6 carry casts, 40s x3 was best (Odairi team, Hinoto Lv30: 50.95M cadence
    -> 53.9M; dummy 54.2M -> 58.7M).
    """

    def __init__(
        self,
        phases: list,
        need: int,
        skip_after: float = 8.0,
        repeat_wait: float = 25.0,
        end_dump: float = 8.0,
        refill: Any = None,
    ) -> None:
        self.phases = phases
        self.need = min(10, need)
        self.refill = refill  # battle -> (long sequence, orbs it needs)
        self.skip_after, self.repeat_wait = skip_after, repeat_wait
        self.end_dump = end_dump
        self.slots = {s for _, seq in phases for s in seq}

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        now = battle.current_time
        if battle.effective_time_limit - now <= self.end_dump:
            return attacker.slot in self.slots  # orbs are worthless after the bell
        st = getattr(battle, "_cycle_st", None)
        if st is None:
            st = battle._cycle_st = {"phase": 0, "anchor": 0.0, "pos": 0, "wait": 0.0}
        if now < st["anchor"]:
            return False
        if st["phase"] == 0 and st["pos"] == 0 and battle.skill_points >= self.need:
            st["phase"] = 1  # checked before this cycle spends anything
        if st["phase"] == 1 and st["pos"] == 0 and self.refill and not st.get("filled"):
            seq, need = self.refill(battle)
            self.phases[1] = (self.phases[1][0], seq)
            self.need = min(10, need)
            st["filled"] = True
        cycle, seq = self.phases[st["phase"]]
        if st["pos"] >= len(seq):
            st.update(pos=0, anchor=st["anchor"] + cycle, wait=0.0, filled=False)
            return False
        if not st["wait"]:
            st["wait"] = now
        want = seq[st["pos"]]
        first = want not in seq[: st["pos"]]
        if attacker.slot != want:
            # A slot that cannot cast (dead, CC'd, starved) is skipped, not waited on.
            if now - st["wait"] > (self.skip_after if first else self.repeat_wait):
                st.update(pos=st["pos"] + 1, wait=now)
            return False
        if first and int(getattr(attacker, "need_cast_point", 1)) > 1:
            return False  # its first cast of the cycle waits for cost decay
        st.update(pos=st["pos"] + 1, wait=now)
        return True
