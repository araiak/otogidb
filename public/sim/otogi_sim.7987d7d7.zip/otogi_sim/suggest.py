"""Which skills belong in the cast group.

The group SIZE is arithmetic, not a search. A skill's orb cost decays back to 1
every ``skill_minus_cost_cd`` (20s) and the team earns one orb every
``skill_points_regen_cd`` (5s), so a group of N members costs N orbs per 20s
against an income of 4. Measured on the three verified teams: at N=4 the income
is exactly spent (0.96 orbs per 5s against an income of 1.00) and every member
still casts on its 20s floor; at N=5 the total cast count does not move -- orbs
are still the ceiling -- but the beat stretches to ~26s, so the fifth member's
casts come straight out of the carries'. On `mira_1631_1720_1721_hinoto` that is
35 carry casts becoming 28, and 71.4M becoming 67.6M.

So above the budget a member is pure redistribution from the best cards to the
worst, and the cap is `skill_minus_cost_cd / skill_points_regen_cd`.

Only the RANKING needs the simulator, because a skill's worth depends on the
group it joins rather than on the skill: on `mira_nimbus_ohina_odairi` a buffer
worth +1.2M beside the bare carry is -2.1M once the real group is there, having
eaten the orb a stronger buffer would have spent. So each candidate is measured
at the margin, against the group chosen so far.

ponytail: greedy, not exhaustive. Greedy matched brute force to within 0.16% on
all three verified teams (inside the ~1% seed noise) for 7 scored groups instead
of 31. Enumerate if a team ever shows a real gap.
"""

from __future__ import annotations

import json
from typing import Any, Callable, Optional, Sequence

from .apl.scheduler import _ramp_profile, skill_flags
from .spec import Scenario, TeamSpec, score, simulate

SLOTS = ("P1", "P2", "P3", "P4", "P5")


def budget(scenario: Scenario, loader: Any = None) -> int:
    """How many members a group can fund per cost-decay window."""
    from .battle import BattleConfig

    defaults = BattleConfig()
    decay = float(defaults.skill_minus_cost_cd)
    regen = float(scenario.regen_cd or defaults.skill_points_regen_cd)
    return max(1, int(decay // regen))


def classify(team: TeamSpec, scenario: Scenario, loader: Any = None) -> dict[str, dict]:
    """Per-slot skill shape, read off a real opening battle state.

    One battle, not a data-file lookup: whether a slot can cast at all depends on
    assists, bonds and passives that only exist once the team is built.
    """
    battle = simulate(team, scenario, 0, record_casts=True, loader=loader).battle
    out: dict[str, dict] = {}
    for p in battle.players:
        if getattr(p, "skill", None) is None:
            continue
        is_ramp, _window = _ramp_profile(p)
        out[p.slot] = {
            "name": getattr(getattr(p, "model", None), "name", p.slot),
            "damage": bool(skill_flags(p.skill, p)["damage"]),
            "ramp": bool(is_ramp),
        }
    return out


def _score(
    team: TeamSpec,
    scenario: Scenario,
    group: Sequence[str],
    seeds: Sequence[int],
    loader: Any,
    swap: Optional[dict[str, str]] = None,
) -> float:
    params: list[tuple[str, Any]] = [("MC_GROUPS", json.dumps([list(group)]))]
    if swap:
        params.append(("MC_GROUP_SWAP", json.dumps(swap)))
    sc = Scenario(
        **{
            k: v
            for k, v in vars(scenario).items()
            if k not in ("scheduler", "scheduler_params")
        },
        scheduler="group",
        scheduler_params=tuple(params),
    )
    return score(team, sc, seeds=seeds, loader=loader).mean


def suggest(
    team: TeamSpec,
    scenario: Optional[Scenario] = None,
    seeds: Sequence[int] = (0, 1, 2),
    loader: Any = None,
    progress: Optional[Callable[[int, int], None]] = None,
) -> dict:
    """Greedy group selection. Returns the group, an optional ramp swap, and a trace.

    The trace is the point as much as the answer: a player who is told "drop Mira"
    and shown what each candidate was worth at the margin can disagree with it.
    """
    scenario = scenario or Scenario()
    info = classify(team, scenario, loader)
    carries = [s for s in SLOTS if info.get(s, {}).get("damage")]
    rest = [s for s in SLOTS if s in info and s not in carries]
    cap = min(len(info), budget(scenario))

    # A carry is never optional: dropping one cost 11-48% on every verified team.
    group = list(carries)
    if not group:  # a team with no damage skill at all -- rank everything instead
        group, rest = [], list(info)

    steps = 1 + sum(range(max(1, len(rest)) + 1)) + 1
    done = 0

    def tick() -> None:
        nonlocal done
        done += 1
        if progress:
            progress(min(done, steps), steps)

    current = _score(team, scenario, group, seeds, loader) if group else 0.0
    tick()
    trace = [{"group": list(group), "score": current, "added": None}]

    while rest and len(group) < cap:
        scored = []
        for c in rest:
            g = [s for s in group if s not in carries] + [c] + carries
            scored.append((_score(team, scenario, g, seeds, loader), c))
            tick()
        best, pick = max(scored)
        if best <= current:
            trace.append({"group": None, "score": best, "rejected": pick})
            break
        group = [s for s in group if s not in carries] + [pick] + carries
        rest.remove(pick)
        current = best
        trace.append({"group": list(group), "score": best, "added": pick})

    # The ramp special case. Nimbus [Awakened] 514 is the only card in the game whose
    # on-cast buff has no duration (a real game bug: the +60% crit damage never
    # expires), so it does not want a permanent group slot -- it wants one until its
    # stacks cap a carry's autos, after which every further stack is waste. That is
    # what MC_GROUP_SWAP expresses, so offer it the best card the cap left out.
    swap: dict[str, str] = {}
    ramp = next((s for s in group if info.get(s, {}).get("ramp")), None)
    if ramp and rest:
        cand = {ramp: rest[0]}
        v = _score(team, scenario, group, seeds, loader, swap=cand)
        tick()
        if v > current:
            swap, current = cand, v
            trace.append({"group": list(group), "score": v, "swap": cand})
    if progress:
        progress(steps, steps)

    return {
        "groups": [group],
        "swap": swap,
        "score": current,
        "cap": cap,
        "dropped": rest,
        "info": info,
        "trace": trace,
    }
