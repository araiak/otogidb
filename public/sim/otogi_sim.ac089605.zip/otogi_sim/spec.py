"""Team in -> score out. The one way to run the simulator.

    score(team, scenario, seed) -> Result

Three inputs, one rule: **anything that changes the score must live in exactly one
of them.** Every divergence we have chased lived somewhere else instead --

  * a module constant (bench dummy ATK 50 vs 3500: the same team scored ~2x apart
    depending on which harness ran it),
  * a builder-local hardcode (assist bonds built as SKILL_DMG in one team builder
    and NORMAL_DMG in the other: ~2%),
  * global RNG state (callers seeded at different points, so "identical" runs
    drew different numbers),
  * a hand-written cache key that had drifted from what actually matters
    (backline order was sorted away though it moves the score 45%).

None of those were visible in a score on its own. They surfaced only when someone
compared two numbers that were supposed to match, months apart. A single typed
entry point is what makes them impossible rather than merely unlikely.

Identity is the load-bearing idea here. ``TeamSpec.key()`` and
``Scenario.key()`` are DERIVED from the fields the simulator actually consumes --
never written out by hand alongside them. A key that is maintained separately
from the thing it identifies will drift from it, and a lossy key silently feeds
wrong scores back to whatever is caching on it.

The invariant that encodes all of this, enforced in test_spec.py:

    key(a) == key(b)  =>  score(a) == score(b)
"""

from __future__ import annotations

import os
import random
from contextlib import contextmanager
from dataclasses import dataclass, field, replace
from statistics import mean, stdev
from typing import Any, Callable, List, Optional, Protocol, Sequence, Tuple

from .data_loader import get_loader
from .lifecycle import make_stat_bond
from .battle import SKILL_CAST_LOCK, SKILL_EFFECT_DELAY
from .worldboss import load_boss
from .modes import (
    ATTR_NEUTRAL,
    BENCH_TARGET_ATK,
    BENCH_TARGET_DEFENSE,
    BENCH_TARGET_HP,
    BENCH_TARGET_SPEED,
    run_benchmark_battle,
)

NO_ASSIST = 0


class GameDataSource(Protocol):
    """The slice of the data loader that scoring actually needs.

    Declared as a Protocol rather than the concrete GameDataLoader so a caller can
    supply game data from anywhere -- a past patch, a fixture, a hypothetical card --
    without importing or subclassing the loader. It also documents the dependency:
    scoring needs exactly two things from game data, not the loader's whole surface.
    """

    _abilities: dict

    def load_all(self) -> None: ...

    def build_team_with_assists(
        self,
        card_ids: List[int],
        assist_ids: Optional[List[int]],
        levels: Optional[List[int]],
        lb_levels: Optional[List[int]],
    ) -> List[Any]: ...


@dataclass(frozen=True)
class TeamSpec:
    """A complete team: everything that changes the score, and nothing that doesn't.

    Ordering semantics are not stylistic -- both were measured on 2026-08-25 with
    549/1720/1721/1615:

    * ``active`` is ORDERED. Slot 0 is the leader (entry_leader abilities only fire
      there) and the cadence scheduler casts in slot order, so permuting the
      backline moved the score from 33.6M to 48.7M -- a 45% spread. Sorting it (as
      the old Team.cache_key did) collapses teams that score differently.
    * ``reserve`` is UNORDERED, and so are the reserve assists -- INDEPENDENTLY of
      each other. A reserve card is not on the field, so a self-targeting buff has
      no one to register on; only team-wide buffs do anything, and those apply the
      same no matter which reserve slot carries them. Measured: swapping the cards
      and swapping the assists both leave the score unchanged.

      So the canonical form sorts reserve cards and reserve assists SEPARATELY
      rather than as bound pairs. Keying them as pairs (as this did initially)
      distinguishes specs that must score identically -- harmless to correctness,
      but it doubles this part of the search space and costs cache hits. Anything
      sweeping reserve assists should treat them as a SET for the same reason.
    """

    active: Tuple[int, int, int, int]
    helper: int
    reserve: Tuple[int, int]

    # Assists are bound to a SLOT, not to a card. 0 = no assist.
    active_assists: Tuple[int, int, int, int] = (
        NO_ASSIST,
        NO_ASSIST,
        NO_ASSIST,
        NO_ASSIST,
    )
    helper_assist: int = NO_ASSIST
    reserve_assists: Tuple[int, int] = (NO_ASSIST, NO_ASSIST)

    # Uniform across the team today because every caller uses MLB. Per-card levels
    # belong here too the moment anything needs them -- they change the score, so
    # they are identity, not configuration.
    level: int = 90
    lb: int = 4

    # The free bond slots, per player slot, in player_ids() order (4 active, then
    # helper), then the 2 reserves. Each entry is that card's bonds as
    # ((type, percent), ...) where type is "normal" | "skill" | "hp".
    #
    # These are identity, not configuration: a 7.5% normal-damage bond is worth a
    # few percent of a team's score, which is larger than the margins ranking
    # decides on. Empty means no bonds, which is what every caller did implicitly
    # before this existed -- so an empty tuple must leave key() byte-identical.
    #
    # A card has 3 bond slots at MLB and the assist occupies one of them, so a
    # slot with an assist has at most 2 here. Nothing enforces that: the engine
    # applies what it is given, and the UI owns the rule.
    bonds: Tuple[Tuple[Tuple[str, float], ...], ...] = ()

    def key(self) -> tuple:
        """Canonical identity. DERIVED -- never maintain a parallel encoding.

        Two specs share a key if and only if they must score the same.
        """
        base = self._canonical() + (self.level, self.lb)
        # Appended only when present. Every existing caller passes no bonds, and a
        # key that changed shape for all of them would invalidate every MC
        # checkpoint and cached score on disk for a field they never set.
        if any(self.bonds):
            base = base + (tuple(tuple(b) for b in self.bonds),)
        return base

    def _canonical(self) -> tuple:
        """THE canonicalization rules, defined exactly once.

        What is ordered and what is sorted is the thing that drifted before: the
        rule lived in a hand-written cache key rather than being derived, and it
        said the backline was unordered when it is not. Every rendering of identity
        (``key``, ``flat_key``) builds on this, so the rules cannot fork again.
        """
        return (
            tuple(self.active),  # ORDERED: leader slot + scheduler cast priority
            self.helper,
            tuple(sorted(self.reserve)),  # unordered: passives only
            tuple(sorted(self.reserve_assists)),  # pairing is free (see docstring)
            tuple(self.active_assists),  # bound to slot
            self.helper_assist,
        )

    def flat_key(self) -> tuple:
        """Flat, positionally-sliceable key in Monte Carlo's historical layout.

            (a0, a1, a2, a3, helper, r0, r1)            <- assist-free, len 7
            ... + (aa0, aa1, aa2, aa3, ra0, ra1, ha)    <- with assists, len 14

        MC slices this positionally (``key[:4]``, ``key[4]``, ``key[5:7]``) and uses
        ``len(key) == 7`` to mean "assist-free", so the shape is load-bearing there.
        Keeping it lets MC adopt derived identity without rewriting every consumer;
        the deeper change (opaque keys carrying their spec) is a separate step.

        ``level``/``lb`` are deliberately absent: MC runs a fixed 90/4, so they are
        constant within a run and cannot cause a collision. The assert makes that
        assumption fail loudly instead of silently -- omitting a varying field from
        a key is exactly the bug this module exists to prevent.
        """
        assert (self.level, self.lb) == (90, 4), (
            f"flat_key omits level/lb, but this spec varies them ({self.level}/"
            f"{self.lb}). Use key() instead, or add them to the layout."
        )
        assert not any(self.bonds), (
            "flat_key omits bonds, but this spec sets them. MC slices this layout "
            "positionally, so bonds cannot be appended -- use key() instead, or add "
            "them to the layout. Omitting a varying field from a key is exactly the "
            "bug this module exists to prevent."
        )
        active, helper, reserve, res_assists, act_assists, helper_assist = (
            self._canonical()
        )
        team_part = active + (helper,) + reserve
        assist_part = act_assists + res_assists + (helper_assist,)
        # Match the historical "no assists -> no assist suffix" shape so len()==7
        # keeps meaning assist-free.
        return team_part if not any(assist_part) else team_part + assist_part

    def player_ids(self) -> list[int]:
        """The 5 battle slots, in order: active 0-3 then helper."""
        return list(self.active) + [self.helper]

    def player_assists(self) -> list[int]:
        return list(self.active_assists) + [self.helper_assist]

    def with_bonds(
        self, slot_index: int, profile: Sequence[Tuple[str, float]]
    ) -> "TeamSpec":
        """Copy of this spec carrying ``profile`` on exactly one bond row.

        Row order matches ``_apply_bonds``'s ``zip(players + reserves, bonds)``:
        0-3 active, 4 helper, 5-6 reserve.

        One row, not several, is deliberate. The bond extremes sweep scores a team
        twice -- bonds on the carry, then the same bonds on the support most likely
        to steal its ranked buffs -- and both arms must carry IDENTICAL bond mass, or
        the spread would measure how much bond a team has rather than who receives
        the buffs, which is the only question being asked.
        """
        rows: list[tuple] = [() for _ in range(7)]
        if not 0 <= slot_index < 7:
            raise ValueError(f"bond row {slot_index} out of range 0..6")
        rows[slot_index] = tuple(tuple(b) for b in profile)
        return replace(self, bonds=tuple(rows))

    @classmethod
    def from_mc(
        cls,
        team: Any,
        assists: Optional[dict] = None,
        level: int = 90,
        lb: int = 4,
    ) -> "TeamSpec":
        """Bridge from Monte Carlo's split identity: a ``Team`` plus a side dict.

        That split is the defect this migration removes -- a team's assists lived
        in a separate structure keyed by ``(slot_name, index)``, so any code
        handling one without the other was silently working with a partial
        identity. Until every MC call site is converted, this rebuilds the whole
        spec from the pair.

        ``assists`` is None (or empty) for the assist-blind search phases, which is
        represented as all-zero assists -- the same battle, and now the same key.
        """
        a = assists or {}
        return cls(
            active=tuple(team.active),  # type: ignore[arg-type]
            helper=team.helper,
            reserve=tuple(team.reserve),  # type: ignore[arg-type]
            active_assists=tuple(a.get(("active", i), NO_ASSIST) for i in range(4)),  # type: ignore[arg-type]
            helper_assist=a.get(("helper", 0), NO_ASSIST),
            reserve_assists=tuple(a.get(("reserve", i), NO_ASSIST) for i in range(2)),  # type: ignore[arg-type]
            level=level,
            lb=lb,
        )

    SLOTS: Tuple[str, ...] = (
        "active:0",
        "active:1",
        "active:2",
        "active:3",
        "helper:0",
        "reserve:0",
        "reserve:1",
    )

    def card_at(self, slot: str) -> int:
        """The card currently occupying ``slot`` (e.g. "active:2")."""
        kind, _, idx = slot.partition(":")
        i = int(idx)
        if kind == "active":
            return self.active[i]
        if kind == "helper":
            return self.helper
        if kind == "reserve":
            return self.reserve[i]
        raise ValueError(f"unknown slot {slot!r}")

    def with_card_at(self, slot: str, card_id: int) -> "TeamSpec":
        """Swap ``card_id`` into ``slot``, keeping that slot's assist.

        The assist stays put deliberately: an A/B asks what THIS card is worth in
        a slot that is otherwise unchanged. Re-optimising the assist at the same
        time measures two changes at once and attributes both to the card.
        """
        kind, _, idx = slot.partition(":")
        i = int(idx)
        if kind == "active":
            act = list(self.active)
            act[i] = card_id
            return replace(self, active=tuple(act))  # type: ignore[arg-type]
        if kind == "helper":
            return replace(self, helper=card_id)
        if kind == "reserve":
            res = list(self.reserve)
            res[i] = card_id
            return replace(self, reserve=tuple(res))  # type: ignore[arg-type]
        raise ValueError(f"unknown slot {slot!r}")

    def with_active_order(self, order: Sequence[int]) -> "TeamSpec":
        """Reorder active slots, keeping each card's assist with it.

        ``order`` is a permutation of 0-3 giving the new slot for each old index.
        """
        act = tuple(self.active[i] for i in order)
        asst = tuple(self.active_assists[i] for i in order)
        return replace(self, active=act, active_assists=asst)  # type: ignore[arg-type]


@dataclass(frozen=True)
class Scenario:
    """The fight. Everything about the world the team is dropped into.

    Defaults are the world-boss DPS benchmark: an immortal 1B-HP neutral dummy with
    the observed in game flat 500 defense, 300s + whatever TIME abilities extend.

    ``scheduler`` is recorded here so a Result carries the rotation policy that
    produced it, and ``scheduler_params`` carries every MC_* knob it was scored
    with. ``simulate`` runs the whole battle under exactly those (see
    ``_scenario_env``), so the env a caller happens to have cannot move a score
    behind its key. A run whose config is not in its key cannot be reproduced: a
    45-minute run once recorded neither its benchmark_time nor its scheduler
    params, so its top score could not be reproduced at all.
    """

    time_limit: float = 300.0
    enemy_atk: int = BENCH_TARGET_ATK
    enemy_hp: int = BENCH_TARGET_HP
    enemy_speed: int = BENCH_TARGET_SPEED
    enemy_defense: float = BENCH_TARGET_DEFENSE
    enemy_attribute: int = ATTR_NEUTRAL
    immortal_players: bool = True
    # World boss 1-4 instead of the dummy. None = the immortal-dummy default, so
    # every existing scenario and the golden corpus are untouched. With a boss
    # set, players are mortal and the fight can end in a wipe.
    boss_id: Optional[int] = None
    boss_level: int = 30
    regen_cd: Optional[float] = None  # None = the shared combat-constant default
    # Seconds between a cast and its buff/debuff landing; measured in play.
    skill_effect_delay: float = SKILL_EFFECT_DELAY
    # Seconds the CASTER cannot auto-attack for after casting (the animation).
    skill_cast_lock: float = SKILL_CAST_LOCK
    # Auto timing from the animation assets (see BattleConfig); on by default.
    auto_interval_scale: float = 1.0
    anim_auto_timing: bool = True
    scheduler: str = "cadence"
    scheduler_params: Tuple[Tuple[str, Any], ...] = ()

    # Every MC_* env var the simulator reads. Recording them is what makes a stored
    # result re-runnable: cadence_v2 logged neither its benchmark_time nor its
    # scheduler params, so when its top team later scored half as much there was no
    # way to tell a regression from a config difference. This list was hand-kept
    # and had drifted to miss 34 of them (every MC_PLAN_/MC_CHAIN_/MC_CYCLE_ knob);
    # test_spec.py now fails if a read is missing. A few (MC_SEED_TEAMS,
    # MC_BOND_*, MC_ABORT_*, MC_CRN*) steer only the search, not a battle -- listed
    # anyway so the registry is simply "everything read", with no judgement to drift.
    SCORING_ENV_VARS = (
        "MC_ABORT_AT",
        "MC_ABORT_PACE",
        "MC_ASSIST_AWARE",
        "MC_BOND_PROFILE",
        "MC_BOND_SWEEP",
        "MC_BOSS_IMMORTAL",
        "MC_CADENCE_CPC",
        "MC_CADENCE_CYCLE",
        "MC_CADENCE_END_DUMP",
        "MC_CADENCE_SELECT_FRAC",
        "MC_CADENCE_STAGGER_AMP",
        "MC_CADENCE_WINDOW_FRAC",
        "MC_CHAIN_CLOSE",
        "MC_CHAIN_MARGIN",
        "MC_CHAIN_RECOVER",
        "MC_CHAIN_SWAP_K",
        "MC_CRN",
        "MC_CRN_SEED",
        "MC_CYCLE_DROP",
        "MC_CYCLE_NEED",
        "MC_CYCLE_SWITCH_AT",
        "MC_CYCLE_SWITCH_CAP",
        "MC_GROUPS",
        "MC_GROUP_AMP_WAIT",
        "MC_GROUP_BUFFER_WAIT",
        "MC_GROUP_CC_MID",
        "MC_GROUP_CC_WAIT",
        "MC_GROUP_CLEANSE_DODGE",
        "MC_GROUP_END_DUMP",
        "MC_GROUP_HOLD_CC",
        "MC_GROUP_LATE_CARRY",
        "MC_GROUP_OFFSET",
        "MC_GROUP_OVERFLOW",
        "MC_GROUP_OVERFLOW_AFTER",
        "MC_GROUP_OVERFLOW_HORIZON",
        "MC_GROUP_PROTECT_LEAD",
        "MC_GROUP_RETIRE",
        "MC_GROUP_RICH",
        "MC_GROUP_RICH_WINDOW",
        "MC_GROUP_SKIP_AFTER",
        "MC_GROUP_SPEED_STAGGER",
        "MC_GROUP_SWAP",
        "MC_GROUP_SWAP_WHEN",
        "MC_KEEPER_DODGE",
        "MC_PLAN_CC_DODGE",
        "MC_PLAN_AMP_OPENER",
        "MC_PLAN_CHAIN",
        "MC_PLAN_FORCE",
        "MC_PLAN_GROUPS",
        "MC_PLAN_REPLAN",
        "MC_REPLAY_CASTS",
        "MC_CC_AHEAD",
        "MC_CC_HORIZON",
        "MC_CC_MARGIN",
        "MC_CC_RULES",
        "MC_CC_SAMPLES",
        "MC_CHAIN_GATE",
        "MC_CHAIN_RECOVER_BY",
        "MC_KEEPER_GATE",
        "MC_SCHEDULER",
        "MC_SEED_TEAMS",
        "MC_SILENCE_ESCAPE",
        "MC_SILENCE_HORIZON",
        "MC_SILENCE_MARGIN",
        "MC_SKILL_TICK",
        "MC_TEAM_DR",
        "MC_WB_SUPPRESS",
    )

    @classmethod
    def from_env(cls, **overrides: Any) -> "Scenario":
        """Snapshot the process's current scoring config into a Scenario.

        Captures only vars that are actually SET, so the snapshot distinguishes
        "explicitly chosen" from "left at the default" -- and the defaults live in
        one place rather than being duplicated here.
        """
        params = tuple(
            (name, os.environ[name])
            for name in cls.SCORING_ENV_VARS
            if os.environ.get(name) not in (None, "")
        )
        fields: dict = {
            "scheduler": (os.environ.get("MC_SCHEDULER") or "cadence").lower(),
            "scheduler_params": params,
        }
        fields.update(overrides)
        return cls(**fields)

    def key(self) -> tuple:
        """Canonical identity. Derived, like TeamSpec.key."""
        return (
            self.time_limit,
            self.enemy_atk,
            self.enemy_hp,
            self.enemy_speed,
            self.enemy_defense,
            self.enemy_attribute,
            self.immortal_players,
            self.boss_id,
            self.boss_level,
            self.regen_cd,
            self.skill_effect_delay,
            self.skill_cast_lock,
            self.auto_interval_scale,
            self.anim_auto_timing,
            self.scheduler,
            tuple(sorted(self.scheduler_params)),
        )


@dataclass
class Result:
    """One battle's outcome, carrying the identity that produced it.

    The keys travel with the number so a stored result can always be re-run. Results
    that did not record their scenario are why the reproduction work above had to
    guess at benchmark_time and scheduler params.
    """

    damage: float
    seed: int
    team_key: tuple
    scenario_key: tuple
    effective_time: float = 0.0
    # Survivability, only meaningful in boss mode (players are immortal against
    # the default dummy, so these are constant there).
    #
    # `deaths` is the metric that matters: `wiped` needs ALL FIVE dead, and a
    # team that loses its two carries and limps to the timer is not a survivor
    # in any useful sense -- it reads as 0% wipe while scoring a quarter of its
    # damage. Kinoe does exactly that to the current best team.
    wiped: bool = False
    deaths: int = 0
    survival_time: float = 0.0
    battle: Any = None  # populated only when trace/record_casts were requested


@dataclass
class ScoreResult:
    """An aggregate over seeds."""

    mean: float
    sd: float
    n: int
    team_key: tuple
    scenario_key: tuple
    per_seed: list[float] = field(default_factory=list)


def build_models(
    spec: TeamSpec, loader: Optional[GameDataSource] = None
) -> tuple[list, list]:
    """(players, reserves) as MonsterModels. THE team builder -- there is only one.

    There used to be two (data_loader.build_team_with_assists and
    AssistPool.build_assisted_model) and they disagreed on the assist bond type,
    which moved auto-attack teams ~2%. Anything needing models goes through here.

    ``loader`` defaults to the process-wide singleton, which is right for the CLI
    and for a single-dataset process. Pass one explicitly to score against
    different game data (a past patch, a hypothetical card) without the answer
    depending on which module happened to touch the singleton first.
    """
    loader = loader or get_loader()
    loader.load_all()

    n = len(spec.player_ids())
    players = loader.build_team_with_assists(
        spec.player_ids(),
        spec.player_assists(),
        [spec.level] * n,
        [spec.lb] * n,
    )
    reserves = loader.build_team_with_assists(
        list(spec.reserve),
        list(spec.reserve_assists),
        [spec.level] * len(spec.reserve),
        [spec.lb] * len(spec.reserve),
    )
    _apply_bonds(players + reserves, spec.bonds)
    return players, reserves


def _apply_bonds(models: list, bonds: tuple) -> None:
    """Attach the player's free-slot bonds to the models build_models just built.

    They go on as real ``Bond`` objects so ``MonsterStat._apply_bonds`` applies them
    -- the one path that already knows a normal-damage bond feeds the NORMAL-attack
    bucket and never the skill path (measured in play 2026-08-25).
    """
    for model, slot_bonds in zip(models, bonds):
        for kind, pct in slot_bonds:
            if pct:
                model.bonds.append(make_stat_bond(kind, pct))


@contextmanager
def _scenario_env(scenario: Scenario):
    """The process env holds exactly the scenario's scoring config while it runs.

    Every scoring var is cleared, then MC_SCHEDULER and the scenario's params are
    set; all of it is restored afterwards. It covers the whole battle, not just
    the scheduler install: battle.py, config.py and modes.py read MC_SKILL_TICK,
    MC_TEAM_DR, MC_WB_SUPPRESS and MC_BOSS_IMMORTAL while the fight runs, so a
    Scenario recording MC_SKILL_TICK=0 used to score on the 0.5 default (and an
    ambient one moved a score without moving its key). Params also used to leak,
    so one scenario with explicit params became the default for every later score.
    """
    names = set(Scenario.SCORING_ENV_VARS) | {
        str(k) for k, _ in scenario.scheduler_params
    }
    prev = {n: os.environ.get(n) for n in names}
    try:
        for n in names:
            os.environ.pop(n, None)
        os.environ["MC_SCHEDULER"] = scenario.scheduler
        for k, v in scenario.scheduler_params:
            os.environ[str(k)] = str(v)
        yield
    finally:
        for n, old in prev.items():
            if old is None:
                os.environ.pop(n, None)
            else:
                os.environ[n] = old


def _install_scheduler(scenario: Scenario) -> None:
    """Install the rotation policy the scenario names (see `_scenario_env`)."""
    from .apl.install import install_cadence_scheduler

    with _scenario_env(scenario):
        install_cadence_scheduler()


def simulate(
    team: TeamSpec,
    scenario: Optional[Scenario] = None,
    seed: int = 0,
    trace: bool = False,
    record_casts: bool = False,
    loader: Optional[GameDataSource] = None,
) -> Result:
    """Run ONE battle. Deterministic in (team, scenario, seed).

    The seed is an argument, not ambient state. Callers used to seed the global RNG
    at whatever point suited them, so two harnesses running "the same" battle
    consumed different draws and disagreed by ~2%.
    """
    scenario = scenario or Scenario()
    # The installed scheduler is process-global, and `_install_scheduler` restores
    # only the ENV it read -- so every simulate() left its policy installed for
    # whatever ran next. Anything not going through this module then silently
    # inherited it: the benchmark ratio tests in test_wave_abilities passed run
    # alone (no policy) and failed run after test_cast_gate (cadence still
    # installed), which is a ~2x swing in scored damage. The Scenario names the
    # policy; it must not outlive the battle that asked for it.
    from .apl.engine import get_engine

    from .apl.install import install_cadence_scheduler

    previous_scheduler = get_engine().scheduler
    loader = loader or get_loader()
    # The enemy fields used to stop here: only target_defense was passed on, so
    # two scenarios with different enemy ATK hashed differently and then fought
    # an identical battle. Defaults are unchanged, so scores do not move.
    try:
        with _scenario_env(scenario):
            install_cadence_scheduler()
            random.seed(seed)
            players, reserves = build_models(team, loader)
            battle = _run(scenario, players, reserves, loader, trace, record_casts)
    finally:
        get_engine().scheduler = previous_scheduler
    return Result(
        damage=float(battle.player_damage_total),
        seed=seed,
        team_key=team.key(),
        scenario_key=scenario.key(),
        effective_time=float(battle.effective_time_limit),
        wiped=not any(p.is_alive for p in battle.players),
        deaths=sum(1 for p in battle.players if not p.is_alive),
        survival_time=float(battle.current_time),
        battle=battle if (trace or record_casts) else None,
    )


def _run(scenario, players, reserves, loader, trace, record_casts):
    """The battle itself. Split out only so simulate() can restore the scheduler."""
    return run_benchmark_battle(
        player_models=players,
        ability_data=loader.abilities,
        reserve_models=reserves,
        benchmark_time=scenario.time_limit,
        target_defense=scenario.enemy_defense,
        target_hp=scenario.enemy_hp,
        target_atk=scenario.enemy_atk,
        target_speed=scenario.enemy_speed,
        target_attribute=scenario.enemy_attribute,
        immortal_players=scenario.immortal_players,
        boss=(
            load_boss(scenario.boss_id, scenario.boss_level)
            if scenario.boss_id
            else None
        ),
        regen_cd=scenario.regen_cd,
        skill_effect_delay=scenario.skill_effect_delay,
        skill_cast_lock=scenario.skill_cast_lock,
        auto_interval_scale=scenario.auto_interval_scale,
        anim_auto_timing=scenario.anim_auto_timing,
        trace=trace,
        record_casts=record_casts,
        tick_headroom=5.0,
    )


def score(
    team: TeamSpec,
    scenario: Optional[Scenario] = None,
    seeds: Sequence[int] = (0,),
    loader: Optional[GameDataSource] = None,
    progress: Optional[Callable[[int, int], None]] = None,
) -> ScoreResult:
    """Mean damage over ``seeds``.

    Pass the SAME seeds to both arms of a comparison (common random numbers): the
    per-battle sd is ~1.1% of the mean, but paired differences under shared seeds
    are far tighter, so an A/B needs a handful of seeds rather than dozens.

    When selecting a winner over many candidates, re-score the winner on FRESH
    seeds before reporting it -- picking and reporting on the same seeds inflates
    the reported value by roughly sd*sqrt(2*ln(candidates)).

    ``progress(done, total)`` is called after each seed. It exists so a caller that
    cannot see this loop -- the browser, where a ten-seed run is ten seconds of
    apparently nothing -- can report which seed is running. Scoring stays here rather
    than being re-implemented by that caller, which is the whole point of this module.
    """
    scenario = scenario or Scenario()
    vals = []
    for i, s in enumerate(seeds):
        vals.append(simulate(team, scenario, s, loader=loader).damage)
        if progress is not None:
            progress(i + 1, len(seeds))
    return ScoreResult(
        mean=mean(vals),
        sd=stdev(vals) if len(vals) > 1 else 0.0,
        n=len(vals),
        team_key=team.key(),
        scenario_key=scenario.key(),
        per_seed=vals,
    )
