"""
WS2 — marginal value-per-orb objective.

The signal that lets the APL compare *different kinds* of casts (a damage skill vs
a support debuff vs a buff) on one scale, so it spends each orb on its highest-value
use. A buff/debuff's worth is indirect — it multiplies the *team's* damage over its
duration — so we estimate it from the observed team DPS:

    value(cast) = direct_skill_damage
                + Σ_effects  team_dps × uptime × magnitude
    value_per_orb = value / orb_cost

``team_dps`` = ``player_damage_total / current_time`` (what the team is actually
doing so far). This is an estimate, not a simulation — good enough to rank casts
and gate low-value ones.

**uptime is MARGINAL** (since 2026-08-25): re-applying an effect that is still running
is credited only with the coverage past its current expiry. Crediting the full duration
made "cast now" score identically to "cast at expiry", so nothing ever waited — the
scheduler kept Hikoboshi's 8s amp at ~38% uptime when ~74% was available. Because value
now climbs as an effect decays, holding a cast until just before expiry falls out of the
objective instead of needing a hand-written rule.

Still approximate: ``team_dps`` is backward-looking (≈0 early, and it lags after buffs
land), ``_DMG_MULT_WEIGHT`` is a hand-tuned table rather than the real damage pipeline
(``planner._project_payload`` uses the actual one), and diminishing returns near the
damage cap are not modelled.
"""

from __future__ import annotations

from typing import Any

from .payload import skill_payload
from .state import APL_PROJECTION_EXCEED, _buff_remains

# Fraction of team damage each buff/debuff type multiplies. Full multipliers for
# general ATK / enemy SHIELD / DEF; partial for type-specific; crit effects are
# only realised on crits, so weighted down (rough).
_DMG_MULT_WEIGHT: dict[str, float] = {
    "ATK": 1.0,  # +x% general damage (ally buff)
    "SHIELD": 1.0,  # -x% shield on enemy = +x% damage amp
    "DEF": 1.0,  # -x% defense on enemy = +x% damage amp
    "DEFENSE": 1.0,
    "SKILL_ATK": 0.6,  # skill hits only
    "NORM_ATK": 0.4,  # normal hits only
    "CHIT_ATK": 0.4,  # crit damage — crits only
    "CHIT": 0.5,  # crit rate — each crit ~2x
    # Attack speed. A speed BUFF halves into the cooldown and speeds the attack clip
    # by a tier (`lifecycle.attack_interval`), so +X% speed buys roughly
    # 1/(1 - X/200) attack rate -- about half what +X% NORM_ATK buys -- and it
    # buys it on auto attacks only. Hence half of NORM_ATK's 0.4.
    #
    # Omitting it was not neutral: an unpriced stat scored 0, which made the weakest-
    # looking buffer the trim-first candidate, and on the Seel Imperio team that cut
    # a +14% speed buff while a defensive ally shield kept casting.
    #
    # Approximate in two known directions. Near the +/-100% speed clamp the buff is
    # worth less than this (clamp assumed at +100%; measured to +90%). On a team
    # whose autos are capped it is worth MORE than this, because damage per hit is
    # fixed and hits per second is the only lever left.
    "SPD": 0.2,
}


def _time_remaining(battle: Any) -> float:
    tl = getattr(battle.config, "time_limit", 0.0)
    if not tl or tl <= 0:
        return 60.0  # fallback horizon when no time limit configured
    return max(1.0, tl - battle.current_time)


def value_per_orb(attacker: Any, battle: Any, enemy: Any) -> float:
    """Estimated marginal team damage per orb of casting attacker's skill now."""
    cost = max(int(getattr(attacker, "need_cast_point", 1) or 1), 1)
    skill = getattr(attacker, "skill", None)
    if skill is None:
        return 0.0

    # Direct: the skill's own damage (damage skills), as the crit-weighted
    # EXPECTED hit. The breakpoint only makes sense against the buffed crit — a
    # skill is worth casting when stacked buffs (crit rate + Nimbus crit dmg + atk
    # concentrated on the target) push its crit over the floor. Non-crit alone
    # under-values it and holds everything.
    direct = 0.0
    if getattr(skill, "target_type", "enemy") == "enemy" and enemy is not None:
        crit_rate = 0.0
        if getattr(attacker, "stat", None) is not None:
            crit_rate = min(max(float(attacker.stat.final_crit), 0.0), 1.0)
        noncrit = battle.calculate_action_damage(
            attacker, enemy, is_skill=True, force_crit=False
        ).final_damage
        crit = battle.calculate_action_damage(
            attacker,
            enemy,
            is_skill=True,
            force_crit=True,
            exceed_pct=APL_PROJECTION_EXCEED,
        ).final_damage
        direct = crit_rate * float(crit) + (1.0 - crit_rate) * float(noncrit)

    # Indirect: team_dps × MARGINAL uptime × magnitude for each buff/debuff applied.
    #
    # Marginal, not nominal. Re-applying an effect that is still running buys only the
    # coverage past its current expiry, not another full duration. Crediting the full
    # duration (as this did before 2026-08-25) makes casting immediately look as good as
    # casting at expiry, which is why the scheduler never learned to space casts: a
    # second Hikoboshi cast 0.5s into its own 8s debuff adds 0.5s of coverage but was
    # scored as if it added 8s. With this correction value-per-orb rises as the effect
    # decays and peaks just before expiry, which is the rotation players actually use.
    team_dps = battle.player_damage_total / max(battle.current_time, 1.0)
    remaining = _time_remaining(battle)
    level = attacker.model.level if getattr(attacker, "model", None) else 1

    indirect = 0.0
    for eff in skill_payload(attacker, level):
        weight = _DMG_MULT_WEIGHT.get(eff.raw_type)
        if weight is None:
            continue  # not a damage-multiplying effect (CC, HP, ...)
        mag = abs(eff.magnitude) / 100.0 * weight

        # A permanent effect never expires, so its window is the rest of the fight and
        # re-applying it always stacks -- no overlap to subtract.
        if eff.is_permanent:
            indirect += team_dps * remaining * mag
            continue

        recipient = enemy if eff.on_enemy else attacker
        already = 0.0
        if recipient is not None and eff.mod_type is not None:
            already = _buff_remains(battle, recipient, eff.mod_type.name)
        window = max(0.0, min(float(eff.duration), remaining) - already)
        indirect += team_dps * window * mag

    return (direct + indirect) / cost
