"""ChainScheduler and TimelineScheduler: back-to-back amp chains and fixed cast timelines."""

from __future__ import annotations

from typing import Any
from ..scheduler import ROTATION_DUMP, derive_chain, scaled_cycle
from .cadence import CadenceScheduler


def ready_at(unit: Any, now: float, cd: float) -> float:
    """When ``unit``'s skill cost will be back to 1.

    Cost decays one step per ``cd`` s (``MonsterComponent.update_cast_cost``) and
    hard CC pauses the decay; silence does not (read from the unit's cc_log).
    """
    need = int(getattr(unit, "need_cast_point", 1))
    if need <= 1:
        return now
    t = now + (need - 1) * cd - float(getattr(unit, "minus_cost_timer", 0.0))
    held = [
        end
        for kind, start, end in getattr(unit, "cc_log", None) or ()
        if kind != "SILENCE" and start <= now < end
    ]
    return t + (max(held) - now if held else 0.0)


def gate_delay(battle: Any, turns: list, orbs: bool) -> float:
    """How long to delay a rotation so each (due, unit) turn finds its unit at cost
    1 and, with ``orbs``, the pool able to fund every cast up to it (1 orb each)."""
    now = battle.current_time
    cd = float(getattr(battle.config, "skill_minus_cost_cd", 20.0) or 20.0)
    turns = sorted(turns, key=lambda t: t[0])
    delay = 0.0
    for d, u in turns:
        delay = max(delay, ready_at(u, now, cd) - d)
    if orbs:
        pool = float(battle.skill_points)
        regen = float(getattr(battle, "skill_points_regen_cd", 5.0) or 5.0)
        timer = float(getattr(battle, "skill_points_timer", 0.0))
        for i, (d, _u) in enumerate(turns):
            short = (i + 1) - pool
            if short > 0:
                delay = max(delay, short * regen - timer - (d - now))
    return delay


class ChainScheduler(CadenceScheduler):
    """Back-to-back debuff chain: each link refreshes the damage-up as the last expires.

    The Assassination-rogue model: keep one damage window up permanently instead of
    bursting everything into one window. ``links`` is the chain in order, e.g.
    ``[["P2", "P4"], ["P3"], ["P5"]]`` -- Senji buffs, Dora casts her amp, then each
    Andromeda's amp follows. Link k is due ``k * gap`` after the chain's anchor, and the
    anchor advances on a fixed ``cycle`` grid (orb-bound, scaled to regen) so small
    per-cast slips do not pile up. Members of a link fire in listed order, each after
    the previous member's effect has landed (a buffer first, so the carry casts inside
    it). Slots in no link never cast except in the end dump.

    A link that cannot fire within ``late`` seconds of its due time has broken the
    chain (CC, orb shortage). ``restart="clean"`` abandons the rest of the chain and
    pools until ``pool`` orbs are banked and every link-0 member is back to cost 1,
    then re-anchors on a fresh chain; ``restart="slip"`` keeps going from the late link.
    """

    def __init__(
        self,
        links: list[list[str]] | None = None,
        gap: float = 0.0,
        cycle: float = 20.5,
        late: float = 4.0,
        restart: str = "clean",
        pool: int = 2,
        end_dump: float = 8.0,
        spare: int = 0,
        gate: str = "",
    ) -> None:
        super().__init__(cycle=cycle, end_dump=end_dump)
        # Start gate: "" (link 0 ready + `pool` orbs, the old rule), "cost" or
        # "cost+orbs": also hold the start until EVERY link's members will be at
        # cost 1 on their link's turn (and the pool can fund each cast).
        if gate not in ("", "cost", "cost+orbs"):
            raise ValueError(f"gate={gate!r}: want '', 'cost' or 'cost+orbs'")
        self.gate = gate
        # links=None derives the chain from the team's kit (``derive_chain``); gap 0
        # uses the derived amp duration.
        self.links = [list(link) for link in links] if links else None
        self.gap, self.late = gap, late
        self.restart, self.pool = restart, pool
        # Orbs at or above this let an off-chain caster (a team buffer) cast; 0 = never.
        self.spare = spare

    def _st(self, battle: Any) -> dict:
        st = getattr(battle, "_chain_st", None)
        if st is None:
            links, gap = derive_chain(list(battle.players))
            links = self.links or links
            st = {"anchor": 0.0, "link": 0, "fired": [], "land": 0.0}
            st.update(idle=True, breaks=0, links=links, gap=self.gap or gap or 8.0)
            st["link_of"] = {s: i for i, link in enumerate(links) for s in link}
            battle._chain_st = st
        return st

    def _slot_ready(self, battle: Any, slot: str) -> bool:
        u = next((p for p in battle.players if p.slot == slot and p.is_alive), None)
        return (
            u is not None
            and not u.is_cast_blocked(battle.current_time)
            and self._cost_ready(u, battle)
        )

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        now = battle.current_time
        if self.end_dump and battle.effective_time_limit - now <= self.end_dump:
            return True  # orbs are worthless after the bell
        st = self._st(battle)
        if not st["links"]:
            # No chain on this team: fall back to the default rotation.
            return CadenceScheduler.should_cast(self, attacker, battle, target)
        li = st["link_of"].get(attacker.slot)
        if li is None:
            # Off-chain caster: only spends orbs the chain would not, at cost 1.
            return bool(
                self.spare
                and battle.skill_points >= self.spare
                and self._cost_ready(attacker, battle)
            )
        links = st["links"]
        if st["idle"]:
            # Clean start: link 0 only, once the pool and every link-0 member are ready.
            if li != 0 or battle.skill_points < self.pool:
                return False
            if not all(self._slot_ready(battle, s) for s in links[0]):
                return False
            if self.gate:
                units = {p.slot: p for p in battle.players if p.is_alive}
                turns = [
                    (now + i * st["gap"], units[s])
                    for i, link in enumerate(links)
                    for s in link
                    if s in units
                ]
                if gate_delay(battle, turns, self.gate == "cost+orbs") > 0.05:
                    return False
            st.update(idle=False, anchor=now, link=0, fired=[], land=now)
        if st.get("gate_pending") and now >= st["anchor"] - 1e-6:
            # Rotation start: push it back until every link's members will be at
            # cost 1 (and, with +orbs, funded) on their link's turn.
            st["gate_pending"] = False
            units = {p.slot: p for p in battle.players if p.is_alive}
            turns = [
                (st["anchor"] + i * st["gap"], units[s])
                for i, lk in enumerate(links)
                for s in lk
                if s in units
            ]
            d = gate_delay(battle, turns, self.gate == "cost+orbs")
            if d > 0.05:
                st["anchor"] += d
                st.setdefault("gated", []).append((round(now, 1), round(d, 2)))
        due = st["anchor"] + st["link"] * st["gap"]
        if now > due + self.late and not st["fired"]:
            st["breaks"] += 1
            if self.restart == "clean":
                st.update(idle=True, link=0, fired=[])
                return False
        if li != st["link"] or now < due or now < st["land"]:
            return False
        link = links[li]
        if link[len(st["fired"])] != attacker.slot:
            return False  # members go in listed order
        if not self._cost_ready(attacker, battle):
            return False
        st["fired"].append(attacker.slot)
        delay_for = getattr(battle, "skill_effect_delay_for", None)
        st["land"] = now + (delay_for(attacker) if delay_for else 0.0)
        if len(st["fired"]) == len(link):
            st.update(link=(li + 1) % len(links), fired=[])
            if st["link"] == 0:
                st["anchor"] += scaled_cycle(self.cycle, battle)
                st["gate_pending"] = bool(self.gate)
        return True

    # -- for CCPlay "break" rules (apl/schedulers/cc.py) -------------------------
    def next_due(self, battle: Any, slot: str) -> float | None:
        """When ``slot`` is next due to fire, if it is the current link's next member
        (the only out-of-turn cast ``mark_cast`` can book). None otherwise."""
        st = self._st(battle)
        li = st["link_of"].get(slot)
        if li is None or st["idle"] or li != st["link"]:
            return None
        link = st["links"][li]
        if len(st["fired"]) >= len(link) or link[len(st["fired"])] != slot:
            return None
        return max(st["anchor"] + st["link"] * st["gap"], st["land"])

    def mark_cast(self, battle: Any, slot: str) -> None:
        """Book an early cast of ``slot`` as its chain turn (see ``next_due``)."""
        if self.next_due(battle, slot) is None:
            return
        st = self._st(battle)
        li = st["link"]
        st["fired"].append(slot)
        delay_for = getattr(battle, "skill_effect_delay_for", None)
        unit = next((p for p in battle.players if p.slot == slot), None)
        st["land"] = battle.current_time + (
            delay_for(unit) if delay_for and unit is not None else 0.0
        )
        if len(st["fired"]) == len(st["links"][li]):
            st.update(link=(li + 1) % len(st["links"]), fired=[])
            if st["link"] == 0:
                st["anchor"] += scaled_cycle(self.cycle, battle)


class TimelineScheduler:
    """The amp-chain timeline with a choice of how to recover from a CC'd cast.

    ``recover``: "grid" -- the slipped cast fires when free, the rest keep their
    times (what ``ReplayScheduler(rotation_timeline(...))`` does); "shift" -- every
    later cast slides by the delay, for the rest of the fight; "shift-cycle" -- only
    this cycle's later casts slide, the next cycle starts on the grid; "skip" -- a
    cast more than ``late`` s past due is dropped and its orb kept. ``dump_all``
    spends the banked orbs in the last ``ROTATION_DUMP`` s instead of one cast each.
    """

    RECOVER = ("grid", "shift", "shift-cycle", "skip")

    def __init__(
        self,
        rot: dict,
        horizon: float,
        recover: str = "grid",
        late: float = 99.0,
        dump_all: bool = False,
        recover_by: dict | None = None,
        gate: str = "",
    ) -> None:
        self.cycle, self.t0, self.off = rot["cycle"], rot["t0"], rot["off"]
        # Start gate: "" off; "cost" / "cost+orbs", optionally ":fight". At each
        # rotation start, push the rotation back until every member will be at cost
        # 1 (and, with +orbs, the pool can fund each cast) on its turn. ":fight"
        # slides every later rotation too; default slides only this one.
        what, _, scope = (gate or "").partition(":")
        if what not in ("", "cost", "cost+orbs") or scope not in ("", "cycle", "fight"):
            raise ValueError(f"gate={gate!r}: want cost[+orbs][:cycle|:fight]")
        self.gate, self.gate_fight = what, scope == "fight"
        self.end = horizon - ROTATION_DUMP
        if recover not in self.RECOVER:
            raise ValueError(f"recover={recover!r}: want one of {self.RECOVER}")
        self.recover, self.late, self.dump_all = recover, late, dump_all
        # Per CC kind: {"STUN": ("shift", 99.0), "SILENCE": ("skip", 4.0)}. A cast
        # held late by that CC recovers that way; any other lateness (orbs, a kind
        # not listed) uses `recover` / `late`.
        self.recover_by = {}
        for kind, (mode, lt) in (recover_by or {}).items():
            if mode not in self.RECOVER:
                raise ValueError(f"recover_by[{kind}]={mode!r}: want {self.RECOVER}")
            self.recover_by[kind.upper()] = (mode, float(lt))

    def _why(self, battle: Any, slot: str, due: float) -> str | None:
        """The CC kind that held ``slot`` past ``due`` (from the unit's cc_log)."""
        now = battle.current_time
        u = next((p for p in battle.players if p.slot == slot), None)
        for kind, start, end in reversed(getattr(u, "cc_log", None) or ()):
            if start <= now + 1e-9 and end >= due - 0.05:
                return kind
        return None

    def _mode(self, battle: Any, slot: str, due: float) -> tuple:
        """(recover mode, late) for a cast of ``slot`` that was due at ``due``."""
        if self.recover_by and battle.current_time > due + 0.05:
            kind = self._why(battle, slot, due)
            if kind in self.recover_by:
                return self.recover_by[kind]
        return self.recover, self.late

    def _due(self, st: dict, slot: str, k: int) -> float:
        # `shift` is only ever non-zero under shift recovery and `cs` under
        # shift-cycle, so adding both is the old per-mode formula.
        due = round(self.t0 + k * self.cycle + self.off[slot], 1)
        return due + st["shift"] + st["cs"].get(k, 0.0)

    @staticmethod
    def _ready_at(unit: Any, now: float, cd: float) -> float:
        return ready_at(unit, now, cd)

    def _gate_cycle(self, battle: Any, st: dict, now: float) -> None:
        """At rotation K's start, delay it until its members are ready on their turns."""
        k = st.setdefault("gate_k", 0)
        starts = {s: self._due(st, s, k) for s in self.off}
        start = min(starts.values())
        if now < start - 1e-6:
            return
        st["gate_k"] = k + 1
        if start >= self.end:
            return
        units = {p.slot: p for p in battle.players if p.is_alive}
        turns = [
            (d, units[s])
            for s, d in starts.items()
            if s in units and st["k"].get(s, 0) <= k
        ]
        delay = gate_delay(battle, turns, self.gate == "cost+orbs")
        if delay > 0.05:
            if self.gate_fight:
                st["shift"] += delay
            else:
                st["cs"][k] = st["cs"].get(k, 0.0) + delay
            st.setdefault("gated", []).append((round(now, 1), round(delay, 2)))

    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        s = attacker.slot
        if s not in self.off:
            return False
        st = getattr(battle, "_tl_st", None)
        if st is None:
            st = battle._tl_st = {"k": {}, "shift": 0.0, "cs": {}, "dumped": set()}
        now = battle.current_time
        if self.gate and now < self.end - 1e-6:
            self._gate_cycle(battle, st, now)
        if now >= self.end - 1e-6:
            if self.dump_all:
                return True
            if s in st["dumped"]:
                return False
            st["dumped"].add(s)
            return True
        k = st["k"].get(s, 0)
        while True:
            due = self._due(st, s, k)
            if due >= self.end:
                return False
            if now < due - 1e-6:
                return False
            mode, late = self._mode(battle, s, due)
            if mode == "skip" and now - due > late:
                k += 1
                st["k"][s] = k
                continue
            break
        if int(getattr(attacker, "need_cast_point", 1)) > 1:
            return False
        d = now - due
        if d > 0.05:
            if mode == "shift":
                st["shift"] += d
            elif mode == "shift-cycle":
                st["cs"][k] = st["cs"].get(k, 0.0) + d
        st["k"][s] = k + 1
        return True

    # -- for CCPlay "break" rules (apl/schedulers/cc.py) -------------------------
    def _next(self, battle: Any, slot: str) -> tuple | None:
        """(k, due) of ``slot``'s next timeline cast, without changing any state."""
        if slot not in self.off:
            return None
        st = getattr(battle, "_tl_st", None) or {"k": {}, "shift": 0.0, "cs": {}}
        now = battle.current_time
        k = st["k"].get(slot, 0)
        while True:
            due = self._due(st, slot, k)
            if due >= self.end:
                return None
            mode, late = self._mode(battle, slot, due)
            if mode == "skip" and now - due > late:
                k += 1
                continue
            return k, due

    def next_due(self, battle: Any, slot: str) -> float | None:
        nx = self._next(battle, slot)
        return None if nx is None else nx[1]

    def mark_cast(self, battle: Any, slot: str) -> None:
        """Book an early cast of ``slot`` as its next timeline cast."""
        nx = self._next(battle, slot)
        if nx is None:
            return
        st = getattr(battle, "_tl_st", None)
        if st is None:
            st = battle._tl_st = {"k": {}, "shift": 0.0, "cs": {}, "dumped": set()}
        st["k"][slot] = nx[0] + 1
