"""CCPlay: per-CC-type rules for playing around boss crowd control.

Experiment, off unless ``MC_CC_RULES`` (or the older ``MC_SILENCE_ESCAPE``) is set.
Wraps whatever scheduler is installed. Two things decide what a player can do:

- **Is the cast happening?** A boss CC is either *in flight* (cast, targets picked,
  waiting out its animation -- ``Battle._boss_pending``) or *ahead* (due on the
  boss timeline in the next few seconds, targets not yet picked).
- **Do we know the target?** In flight we do; ahead we only know the skill.

Four regimes, each enabled per CC kind (STUN, SILENCE, STONE, FROZEN, NUMB, SLEEP,
or ALL):

- ``react``: a cast-blocking CC is in flight AT this card -> cast now, before it
  lands, instead of holding.
- ``ahead``: a cast-blocking CC is due within ``MC_CC_AHEAD`` s and this card may
  be hit -> cast now instead of holding.
- ``hold``: a CC is in flight (at anyone) and the inner policy says cast -> wait
  until it has landed and, if it stuck, worn off (don't buff a stunned carry).
- ``dodge``: the same, for a CC that is only due ahead.

Chain teams (the planner's timeline / keeper chain) also get:

- ``break``: a cast-blocking CC is in flight AT this card and its next SCHEDULED
  chain cast falls inside the CC (it would be blocked, and the chain's recovery
  then fires it late or drops it) -> break the chain: cast now and book it as that
  scheduled cast. ``:x`` = the most seconds early it may go.
- ``breakahead``: the same for a CC only due on the timeline (targets unknown;
  certain for Kanoto's all-team stun). ``:x`` as for ``break``.

``react``/``ahead``/``break*`` turn a "no" into a "yes"; ``hold``/``dodge`` turn a "yes" into a
wait. NUMB never blocks casting (``MonsterComponent.is_cast_blocked``), so it only
takes part in hold/dodge.

Modes: ``any`` (always), ``cost1`` (react/ahead only: only at cost 1), and
``rollout`` -- the scan: fork the battle, play ``MC_CC_HORIZON`` s both ways, cast
vs. hold, and take the better. A fork replays the same RNG state for both arms and
the real battle's RNG is restored afterwards, so a decision never moves CRN.
Each (CC cast, card, regime) is decided once, at the first moment it applies.

- react / ahead stratify on the card's OWN roll: the fork forces the CC onto this
  card (if it was targeted) and off it, and weights the two by the engine's land
  chance. Other targets roll as usual.
- hold / dodge care about everyone the CC hits, so they use natural rolls.
- Every scan averages ``MC_CC_SAMPLES`` paired forks (per stratum): once the two
  arms' casts differ their RNG streams desync, so one pair is a noisy estimate.

Rules: ``MC_CC_RULES="STUN.react.rollout,SILENCE.react.cost1:1,ALL.hold.any:0.5"``.
An optional ``:x`` timer window limits a rule to the last x s before the CC
lands (react/hold) or before the boss casts it (ahead/dodge; default
``MC_CC_AHEAD``) -- to test whether a rule pays at 1s but not at 4s.
"""

from __future__ import annotations

import copy
import random
import re
from typing import Any

from ...battle import _SKILL_DEBUFFS
from ...worldboss import boss_impact_lag

CC_KINDS = ("STUN", "SILENCE", "STONE", "FROZEN", "SLEEP", "NUMB")
CAST_BLOCKING = frozenset(CC_KINDS) - {"NUMB"}
REGIMES = ("react", "ahead", "hold", "dodge", "break", "breakahead")
EARLY = ("react", "ahead", "break", "breakahead")
MODES = ("any", "cost1", "rollout")


def parse_rules(spec: str) -> dict:
    """``"STUN.react.rollout,ALL.hold.any:1.5"`` -> {(kind, regime): (mode, window)}.

    ``:x`` is the timer window (None = no limit): react/hold act only once the CC
    lands within x s; ahead/dodge only once the boss CASTS it within x s (its
    targets are not picked before that, so the cast is the only clock).
    """
    rules: dict = {}
    for tok in (spec or "").replace(";", ",").split(","):
        tok = tok.strip()
        if not tok:
            continue
        parts = tok.upper().split(".", 2)
        if len(parts) != 3:
            raise ValueError(f"CC rule {tok!r}: want KIND.regime.mode")
        kind, regime, mode = parts[0], parts[1].lower(), parts[2].lower()
        mode, _, win = mode.partition(":")
        try:
            window = float(win) if win else None
        except ValueError:
            raise ValueError(f"CC rule {tok!r}: window {win!r} is not seconds")
        kinds = CC_KINDS if kind == "ALL" else (kind,)
        if kind != "ALL" and kind not in CC_KINDS:
            raise ValueError(f"CC rule {tok!r}: kind not in {CC_KINDS} / ALL")
        if regime not in REGIMES:
            raise ValueError(f"CC rule {tok!r}: regime not in {REGIMES}")
        if mode not in MODES or (mode == "cost1" and regime in ("hold", "dodge")):
            raise ValueError(f"CC rule {tok!r}: mode not valid for {regime}")
        for k in kinds:
            if regime in EARLY and k not in CAST_BLOCKING:
                continue  # NUMB does not block casting: nothing to escape
            rules[(k, regime)] = (mode, window)
    return rules


def _cc_of(skill: Any) -> tuple | None:
    """(kind, seconds) of the first CC token in a boss skill, or None."""
    for e in skill.debuff_effects or ():
        kind = e.split("<")[0]
        if kind in CC_KINDS:
            return kind, float(re.split(r"[<,>]", e)[1])
    return None


def in_flight(battle: Any) -> list:
    """Boss CC casts in flight: (idx, land_at, kind, secs, chance, targets)."""
    now = battle.current_time
    out = []
    for i, (land_at, skill, targets) in enumerate(
        getattr(battle, "_boss_pending", None) or ()
    ):
        if targets is None or land_at <= now:
            continue
        cc = _cc_of(skill)
        if cc is not None:
            out.append(
                (i, land_at, cc[0], cc[1], battle.boss_cc_chance(skill), targets)
            )
    return out


def incoming_silence(battle: Any, unit: Any) -> tuple | None:
    """The in-flight SILENCE aimed at ``unit``: (idx, land_at, secs, chance)."""
    for i, land_at, kind, secs, p, targets in in_flight(battle):
        if kind == "SILENCE" and any(t is unit for t in targets):
            return i, land_at, secs, p
    return None


def due_ahead(battle: Any, horizon: float) -> list:
    """Boss CC casts due within ``horizon`` s: (due, land_at, kind, secs, chance, skill).

    Walks the timeline `Battle._boss_phase` fires from, like `next_cc_risk`, and
    skips casts a slow will drop (the engine's own flag).
    """
    boss = getattr(battle, "boss", None)
    if boss is None:
        return []
    rotation = boss.rotation(battle._boss_state)
    if not rotation or battle._boss_state.name == "CRAZY_PREPARE":
        return []
    rate = boss.timing.clock_rate
    cycle = rotation[-1][0]
    idx = battle._boss_cast_idx
    unit = battle._boss_unit()
    speed = unit.stat.speed_modifier.get_modifier_total() if unit else 1.0
    out, nth = [], {}
    for k in range(idx, idx + len(rotation)):
        at, sid = rotation[k % len(rotation)]
        due = (battle._boss_rotation_base + (k // len(rotation)) * cycle + at) / rate
        if due - battle.current_time > horizon:
            break
        sk = boss.skills.get(sid)
        cc = _cc_of(sk) if sk is not None else None
        if cc is None or due < battle.current_time:
            continue
        n = nth[sid] = nth.get(sid, -1) + 1
        if battle.boss_cast_will_drop(sk, n):
            continue
        lag = boss_impact_lag(boss.cast_timing.get(sid), speed)
        land = due + (boss.timing.impact_delay if lag is None else lag)
        out.append((due, land, cc[0], cc[1], battle.boss_cc_chance(sk), sk))
    return out


def _forced(skill: Any, lands: bool) -> Any:
    sk = copy.copy(skill)
    if lands:
        sk.debuff_effects = [
            "HIT<100%,0%>" if e.startswith("HIT<") else e for e in skill.debuff_effects
        ]
    else:
        kind = _cc_of(skill)[0]
        sk.debuff_effects = [e for e in skill.debuff_effects if not e.startswith(kind)]
    return sk


def _split(entry: tuple, slot: str, lands: bool) -> list:
    """Split one pending cast so ``slot``'s roll is forced and the rest roll as usual."""
    land_at, skill, targets = entry
    mine = [t for t in targets if t.slot == slot]
    rest = [t for t in targets if t.slot != slot]
    out = [(land_at, skill, rest)] if rest else []
    if mine:
        out.append((land_at, _forced(skill, lands), mine))
    return out


class CCPlay:
    """Wrap a scheduler with per-CC-kind react / ahead / hold / dodge rules."""

    def __init__(
        self,
        inner: Any,
        rules: dict,
        horizon: float = 20.0,
        margin: float = 0.0,
        ahead: float = 4.0,
        samples: int = 3,
    ) -> None:
        self.inner = inner
        self.rules = {k: v[0] for k, v in rules.items()}
        self.windows = {k: v[1] for k, v in rules.items()}
        self.horizon = horizon
        self.margin = margin
        self.ahead = ahead
        self.samples = samples
        self._regimes = {r for _, r in self.rules}
        # How far down the boss timeline ahead/dodge need to look.
        self._look = max(
            [
                self.ahead if w is None else w
                for (_, r), w in self.windows.items()
                if r in ("ahead", "dodge", "breakahead")
            ]
            or [0.0]
        )

    def _within(self, kind: str, regime: str, dt: float) -> bool:
        """Inside this rule's timer window (dt = s until it lands / is cast)?"""
        w = self.windows.get((kind, regime))
        if w is None:
            w = self.ahead if regime in ("ahead", "dodge", "breakahead") else 1e9
        return dt <= w + 1e-9

    # -- the hook ----------------------------------------------------------------
    def should_cast(self, attacker: Any, battle: Any, target: Any) -> bool:
        slot = attacker.slot
        force = getattr(battle, "_cc_cast_force", None)
        if force is not None and force == slot:  # rollout arm: cast now
            battle._cc_cast_force = None
            if getattr(battle, "_cc_cast_book", False):
                self._book(battle, slot)
            return True
        if self._vetoed(battle, slot):
            return False
        ok = self.inner.should_cast(attacker, battle, target)
        if getattr(battle, "_cc_rollout", False):
            return ok  # inside a fork: the inner policy plays it out
        if ok:
            return not self._wait(attacker, battle)
        return self._early(attacker, battle)

    # -- early casts (react / ahead) ---------------------------------------------
    def _early(self, attacker: Any, battle: Any) -> bool:
        memo = self._memo(battle)
        cost1 = int(getattr(attacker, "need_cast_point", 1)) <= 1
        cands = []
        if "react" in self._regimes:
            for i, land, kind, _s, p, targets in in_flight(battle):
                if any(t is attacker for t in targets):
                    mode = self.rules.get((kind, "react"))
                    if mode and self._within(kind, "react", land - battle.current_time):
                        cands.append(("react", kind, mode, (round(land, 2), i), p))
        if "ahead" in self._regimes:
            for due, land, kind, _s, p, sk in due_ahead(battle, self._look):
                mode = self.rules.get((kind, "ahead"))
                if mode and self._within(kind, "ahead", due - battle.current_time):
                    cands.append(("ahead", kind, mode, (round(due, 2), sk.id), p))
        chain = self._chain(battle)
        if chain is not None and self._regimes & {"break", "breakahead"}:
            now = battle.current_time
            due_me = chain.next_due(battle, attacker.slot)
            if due_me is not None and due_me > now:
                if "break" in self._regimes:
                    for i, land, kind, secs, p, targets in in_flight(battle):
                        if not any(t is attacker for t in targets):
                            continue
                        mode = self.rules.get((kind, "break"))
                        if (
                            mode
                            and land - 0.05 <= due_me <= land + secs
                            and self._within(kind, "break", due_me - now)
                        ):
                            cands.append(("break", kind, mode, (round(land, 2), i), p))
                if "breakahead" in self._regimes:
                    for due, land, kind, secs, p, sk in due_ahead(battle, self._look):
                        mode = self.rules.get((kind, "breakahead"))
                        if (
                            mode
                            and land - 0.05 <= due_me <= land + secs
                            and self._within(kind, "breakahead", due_me - now)
                        ):
                            cands.append(
                                ("breakahead", kind, mode, (round(due, 2), sk.id), p)
                            )
        for regime, kind, mode, ev, p in cands:
            key = (regime, ev[0], attacker.slot)
            state = memo.get(key)
            if state == "cast":
                continue
            if mode == "any" or (mode == "cost1" and cost1):
                go = True
            elif mode == "rollout":
                if state is None:
                    gain = self._scan_early(battle, attacker, regime, ev, p)
                    state = memo[key] = "yes" if gain > self.margin else "no"
                    self._log(battle, regime, kind, attacker.slot, gain, state)
                go = state == "yes"
            else:
                go = False
            if go:
                memo[key] = "cast"
                self._count(battle, regime)
                if regime in ("break", "breakahead"):
                    self._book(battle, attacker.slot)
                return True
        return False

    def _chain(self, battle: Any) -> Any:
        """The chain/timeline executor playing this battle, if it is one."""
        d = getattr(battle, "_plan_delegate", None) or self.inner
        return d if hasattr(d, "next_due") and hasattr(d, "mark_cast") else None

    def _book(self, battle: Any, slot: str) -> None:
        """Count an early cast as the slot's next scheduled chain cast."""
        chain = self._chain(battle)
        if chain is not None:
            chain.mark_cast(battle, slot)

    # -- waits (hold / dodge) ----------------------------------------------------
    def _wait(self, attacker: Any, battle: Any) -> bool:
        memo = self._memo(battle)
        cands = []
        if "hold" in self._regimes:
            for _i, land, kind, secs, _p, _t in in_flight(battle):
                mode = self.rules.get((kind, "hold"))
                if mode and self._within(kind, "hold", land - battle.current_time):
                    cands.append(("hold", kind, mode, land, secs))
        if "dodge" in self._regimes:
            for due, land, kind, secs, _p, _sk in due_ahead(battle, self._look):
                mode = self.rules.get((kind, "dodge"))
                if mode and self._within(kind, "dodge", due - battle.current_time):
                    cands.append(("dodge", kind, mode, land, secs))
        for regime, kind, mode, land, secs in cands:
            key = (regime, round(land, 2), attacker.slot)
            state = memo.get(key)
            if state in ("held", "no"):
                continue
            if mode == "rollout" and state is None:
                gain = self._scan_wait(battle, attacker, kind, land, secs)
                state = memo[key] = "yes" if gain > self.margin else "no"
                self._log(battle, regime, kind, attacker.slot, gain, state)
            if mode == "any" or state == "yes":
                memo[key] = "held"
                self._set_veto(battle, attacker.slot, kind, land, secs)
                self._count(battle, regime)
                return True
        return False

    @staticmethod
    def _set_veto(battle: Any, slot: str, kind: str, land: float, secs: float) -> None:
        v = getattr(battle, "_cc_veto", None)
        if v is None:
            v = battle._cc_veto = {}
        v[slot] = (land + 0.05, kind, land + secs + 0.05)

    @staticmethod
    def _vetoed(battle: Any, slot: str) -> bool:
        """Held: until the CC lands, then while it is stuck on anyone (capped)."""
        v = getattr(battle, "_cc_veto", None)
        if not v or slot not in v:
            return False
        until, kind, cap = v[slot]
        now = battle.current_time
        if now < until:
            return True
        dt = _SKILL_DEBUFFS[kind]
        if now < cap and any(
            p.is_alive and p.has_debuff(dt, now) for p in battle.players
        ):
            return True
        del v[slot]
        return False

    # -- rollouts ----------------------------------------------------------------
    def _play(self, fork: Any) -> float:
        end = fork.current_time + self.horizon
        fork.run_until_time_limit(
            int(self.horizon / fork.config.tick_rate) + 2,
            stop_when=lambda b: b.current_time >= end
            or b.phase.name in ("VICTORY", "DEFEAT"),
        )
        return fork.player_damage_total

    def _fork(self, battle: Any) -> Any:
        f = copy.deepcopy(battle)
        f._cc_rollout = True
        return f

    def _seeds(self) -> list:
        """Paired-fork seeds, drawn from (not consuming) the battle's RNG state."""
        rng = random.Random()
        rng.setstate(random.getstate())
        return [rng.getrandbits(64) for _ in range(max(1, self.samples))]

    def _scan_early(self, battle, attacker, regime, ev, p) -> float:
        """E[damage(cast now) - damage(hold)], stratified on this card's own roll."""
        state = random.getstate()
        seeds = self._seeds()
        slot = attacker.slot
        gain = 0.0
        try:
            for lands, w in ((True, p), (False, 1.0 - p)):
                if w <= 0.0:
                    continue
                for s in seeds:
                    out = []
                    for cast_now in (True, False):
                        random.seed(s)
                        f = self._fork(battle)
                        f._cc_cast_force = slot if cast_now else None
                        f._cc_cast_book = regime in ("break", "breakahead")
                        if regime in ("react", "break"):
                            i = ev[1]
                            f._boss_pending[i : i + 1] = _split(
                                f._boss_pending[i], slot, lands
                            )
                        else:
                            sid = ev[1]
                            f._boss_cast_hook = lambda b, entry, sid=sid, lands=lands: (
                                _split(entry, slot, lands)
                                if entry[1].id == sid
                                else None
                            )
                        out.append(self._play(f))
                    gain += w * (out[0] - out[1]) / len(seeds)
        finally:
            random.setstate(state)
        return gain

    def _scan_wait(self, battle, attacker, kind, land, secs) -> float:
        """E[damage(hold) - damage(cast now)] over paired natural-roll forks."""
        state = random.getstate()
        seeds = self._seeds()
        gain = 0.0
        try:
            for s in seeds:
                out = []
                for hold in (True, False):
                    random.seed(s)
                    f = self._fork(battle)
                    if hold:
                        self._set_veto(f, attacker.slot, kind, land, secs)
                    else:
                        f._cc_cast_force = attacker.slot
                    out.append(self._play(f))
                gain += (out[0] - out[1]) / len(seeds)
        finally:
            random.setstate(state)
        return gain

    # -- bookkeeping -------------------------------------------------------------
    @staticmethod
    def _memo(battle: Any) -> dict:
        m = getattr(battle, "_cc_memo", None)
        if m is None:
            m = battle._cc_memo = {}
        return m

    @staticmethod
    def _count(battle: Any, regime: str) -> None:
        c = getattr(battle, "cc_play_counts", None)
        if c is None:
            c = battle.cc_play_counts = {}
        c[regime] = c.get(regime, 0) + 1

    @staticmethod
    def _log(battle, regime, kind, slot, gain, verdict) -> None:
        log = getattr(battle, "cc_play_log", None)
        if log is None:
            log = battle.cc_play_log = []
        log.append((battle.current_time, regime, kind, slot, gain, verdict))
